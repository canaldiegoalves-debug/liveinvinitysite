(function() {
  // Elementos do DOM das Abas Estáticas
  const tabInicio = document.getElementById('tab-inicio');
  const tabCentral = document.getElementById('tab-central');
  const tabAudio = document.getElementById('tab-audio');

  const paneInicio = document.getElementById('pane-inicio');
  const paneCentral = document.getElementById('pane-central');
  const paneAudio = document.getElementById('pane-audio');
  const paneAi = document.getElementById('pane-ai');
  const paneVideo = document.getElementById('pane-video');

  // Cria os botões dinamicamente após o carregamento para evitar interceptação de clique pelo sidebar.js
  const tabBar = document.querySelector('.tab-bar');
  let tabAutomacoes = null;
  let tabAi = null;
  let tabVideo = null;
  let tabSuporte = null;

  // Carrega e redefine os titles das abas estáticas para a barra lateral compacta
  if (tabInicio) { tabInicio.innerHTML = '🏠'; tabInicio.setAttribute('data-title', 'Monitor'); }
  if (tabCentral) { tabCentral.innerHTML = '🔔'; tabCentral.setAttribute('data-title', 'Alertas'); }
  if (tabAudio) { tabAudio.innerHTML = '🎙️'; tabAudio.setAttribute('data-title', 'Mídia'); }

  const paneAutomacoes = document.getElementById('pane-automacoes');
  const paneSuporte = document.getElementById('pane-suporte');

  if (tabBar) {
    // Reusa ou cria 1. Painel de Automações
    tabAutomacoes = document.getElementById('tab-automacoes');
    if (!tabAutomacoes) {
      tabAutomacoes = document.createElement('button');
      tabAutomacoes.className = 'tab-btn';
      tabAutomacoes.id = 'tab-automacoes';
      tabAutomacoes.setAttribute('data-title', 'Painel');
      tabAutomacoes.innerHTML = '⚙️';
      if (tabCentral) tabBar.insertBefore(tabAutomacoes, tabCentral);
      else tabBar.appendChild(tabAutomacoes);
    }

    // Reusa ou cria 2. IA Chat
    tabAi = document.getElementById('tab-ai');
    if (!tabAi) {
      tabAi = document.createElement('button');
      tabAi.className = 'tab-btn';
      tabAi.id = 'tab-ai';
      tabAi.setAttribute('data-title', 'IA Chat');
      tabAi.innerHTML = '🤖';
      tabBar.appendChild(tabAi);
    }

    // Reusa ou cria 3. Player de Vídeos
    tabVideo = document.getElementById('tab-video');
    if (!tabVideo) {
      tabVideo = document.createElement('button');
      tabVideo.className = 'tab-btn';
      tabVideo.id = 'tab-video';
      tabVideo.setAttribute('data-title', 'Player');
      tabVideo.innerHTML = '🎬';
      tabBar.appendChild(tabVideo);
    }

    // Reusa ou cria 4. Central de Suporte
    tabSuporte = document.getElementById('tab-suporte');
    if (!tabSuporte) {
      tabSuporte = document.createElement('button');
      tabSuporte.className = 'tab-btn';
      tabSuporte.id = 'tab-suporte';
      tabSuporte.setAttribute('data-title', 'Suporte');
      tabSuporte.innerHTML = '🎫';
      tabBar.appendChild(tabSuporte);
    }
  }

  // Estado local para vídeos e HTML original
  let videoFiles = [];
  const originalAiHtml = paneAi ? paneAi.querySelector('.main').innerHTML : '';
  const originalVideoHtml = paneVideo ? paneVideo.querySelector('.main').innerHTML : '';

  // Alternador de Abas Personalizado
  function deactivateAll() {
    document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  }

  function bindTabClick(btn, pane, callback) {
    if (!btn || !pane) return;
    btn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      deactivateAll();
      btn.classList.add('active');
      pane.classList.add('active');
      if (callback) callback();
    });
  }

  bindTabClick(tabInicio, paneInicio);
  bindTabClick(tabCentral, paneCentral);
  bindTabClick(tabAudio, paneAudio);
  bindTabClick(tabAutomacoes, paneAutomacoes);
  bindTabClick(tabAi, paneAi, checkFeatureLock);
  bindTabClick(tabVideo, paneVideo, checkFeatureLock);
  bindTabClick(tabSuporte, paneSuporte, () => {
    clearInterval(chatPollInterval);
    activeTicketId = null;
    if (suporteTelaChat) suporteTelaChat.style.display = 'none';
    if (suporteTelaForm) suporteTelaForm.style.display = 'none';
    if (suporteTelaLista) suporteTelaLista.style.display = 'block';
    loadTicketsList();
  });

  // Se o usuário clicar nas abas originais do sidebar.js, garante que as customizadas fechem
  [tabInicio, tabCentral, tabAudio].forEach(tab => {
    tab?.addEventListener('click', () => {
      [tabAutomacoes, tabAi, tabVideo, tabSuporte].forEach(t => t?.classList.remove('active'));
      [paneAutomacoes, paneAi, paneVideo, paneSuporte].forEach(p => p?.classList.remove('active'));
    });
  });

  // Verificação de bloqueio por plano (Liberado para todos os usuários)
  function checkFeatureLock() {
    return;
  }

  // 🎬 CONTROLE DO PLAYER DE VÍDEO
  const videoListEl = document.getElementById('video-file-list');

  function bindVideoEvents() {
    const videoInput = document.getElementById('video-files');
    const btnVideoOpen = document.getElementById('video-open');
    const btnVideoClear = document.getElementById('video-clear');

    if (videoInput) {
      videoInput.onchange = (e) => {
        const files = Array.from(e.target.files || []);
        files.forEach(f => {
          videoFiles.push({
            name: f.name,
            url: URL.createObjectURL(f)
          });
        });
        renderVideoFiles();
      };
    }

    if (btnVideoClear) {
      btnVideoClear.onclick = () => {
        videoFiles.forEach(f => URL.revokeObjectURL(f.url));
        videoFiles = [];
        renderVideoFiles();
      };
    }

    if (btnVideoOpen) {
      btnVideoOpen.onclick = () => {
        if (!videoFiles.length) {
          alert('Selecione pelo menos um vídeo para a fila.');
          return;
        }
        // Abre a janela do player
        const filesJson = JSON.stringify(videoFiles);
        window.open(
          `player/index.html?files=${encodeURIComponent(filesJson)}`,
          'infinity-player',
          'width=520,height=900'
        );
      };
    }

    renderVideoFiles();
  }

  // Inicializa binds de vídeo
  bindVideoEvents();

  function renderVideoFiles() {
    if (!videoListEl) return;
    if (!videoFiles.length) {
      videoListEl.innerHTML = `<p class="helper" style="font-size:10px;color:var(--muted);text-align:center;">Nenhum vídeo selecionado.</p>`;
      return;
    }
    videoListEl.innerHTML = videoFiles.map((file, idx) => {
      return `
        <div style="display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:6px;padding:6px 10px;font-size:10px;color:var(--text);">
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:210px;">🎬 ${file.name}</span>
          <span class="remove-vid-btn" data-index="${idx}" style="color:var(--red);cursor:pointer;font-weight:700;font-size:14px;padding:0 4px;">×</span>
        </div>
      `;
    }).join('');

    // Bind botões de remover
    videoListEl.querySelectorAll('.remove-vid-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.index);
        const removed = videoFiles.splice(idx, 1)[0];
        if (removed) URL.revokeObjectURL(removed.url);
        renderVideoFiles();
      });
    });
  }

  // 🛒 PROVA SOCIAL (MENSAGENS PÓS-VENDA)
  const togPostSale = document.getElementById('togPostSale');
  const bProvaSocial = document.getElementById('bProvaSocial');
  const postSaleMessages = document.getElementById('postSaleMessages');
  const postSaleDelay = document.getElementById('postSaleDelay');

  // Carrega configurações salvas
  chrome.storage.local.get(['ilPostSaleEnabled', 'ilPostSaleMessages', 'ilPostSaleDelay'], (d) => {
    const enabled = !!d.ilPostSaleEnabled;
    const defaultMsgs = 'Parabéns pela compra! 🎉 {salesCount} pessoas já garantiram o produto nesta live!\n🔥 Excelente escolha! Já temos {salesCount} compras confirmadas ao vivo!\n👏 Parabéns! {salesCount} pessoas já aproveitaram a promoção especial hoje!\n⚡ Incrível! O estoque está acabando e já são {salesCount} vendas finalizadas!\n🛒 Mais uma venda confirmada! {salesCount} pessoas já compraram nesta live!';
    const messages = (d.ilPostSaleMessages && d.ilPostSaleMessages.trim()) ? d.ilPostSaleMessages : defaultMsgs;
    const delay = d.ilPostSaleDelay || 10;

    if (togPostSale) {
      togPostSale.className = enabled ? 'tog on' : 'tog';
      togPostSale.title = enabled ? 'Desativar Prova Social' : 'Ativar Prova Social';
    }
    if (bProvaSocial) {
      bProvaSocial.textContent = enabled ? 'Ativo' : 'Inativo';
      bProvaSocial.className = enabled ? 'cbadge bon' : 'cbadge boff';
    }
    if (postSaleMessages) {
      postSaleMessages.value = messages;
    }
    if (postSaleDelay) {
      postSaleDelay.value = delay;
    }
  });

  // Eventos de alteração nas configurações
  function salvarConfigPostSale() {
    const enabled = togPostSale ? togPostSale.classList.contains('on') : false;
    const messages = postSaleMessages ? postSaleMessages.value : '';
    const delay = postSaleDelay ? parseInt(postSaleDelay.value) || 10 : 10;

    chrome.storage.local.set({
      ilPostSaleEnabled: enabled,
      ilPostSaleMessages: messages,
      ilPostSaleDelay: delay
    }, () => {
      // Notifica o background
      const msgList = messages.split('\n').map(m => m.trim()).filter(Boolean);
      chrome.runtime.sendMessage({
        action: 'updatePostSaleConfig',
        ativo: enabled,
        delay: delay,
        messages: msgList
      });
    });
  }

  if (togPostSale) {
    togPostSale.addEventListener('click', () => {
      togPostSale.classList.toggle('on');
      const isOn = togPostSale.classList.contains('on');
      togPostSale.title = isOn ? 'Desativar Prova Social' : 'Ativar Prova Social';
      if (bProvaSocial) {
        bProvaSocial.textContent = isOn ? 'Ativo' : 'Inativo';
        bProvaSocial.className = isOn ? 'cbadge bon' : 'cbadge boff';
      }
      salvarConfigPostSale();
    });
  }

  if (postSaleMessages) {
    postSaleMessages.addEventListener('input', salvarConfigPostSale);
  }

  if (postSaleDelay) {
    postSaleDelay.addEventListener('change', salvarConfigPostSale);
  }

  // 📡 SINCRONIZAÇÃO DE MÉTRICAS E CHAT
  const metricVendas = document.getElementById('metricVendas');
  const metricGmv = document.getElementById('metricGmv');
  const aiChatLog = document.getElementById('aiChatLog');

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'statusFromContent') {
      const d = msg.data || {};
      if (metricVendas && d.vendas !== undefined) {
        metricVendas.textContent = d.vendas;
      }
      if (metricGmv && d.gmv !== undefined) {
        metricGmv.textContent = d.gmv;
      }

      // Atualiza Log do Chat da IA
      if (aiChatLog && d.chatMessages && Array.isArray(d.chatMessages)) {
        if (!d.chatMessages.length) {
          aiChatLog.innerHTML = `<div style="color:var(--muted);text-align:center;padding:20px 0;">Nenhuma mensagem de chat detectada ainda.</div>`;
        } else {
          aiChatLog.innerHTML = d.chatMessages.map(m => {
            return `
              <div style="border-bottom:1px solid rgba(255,255,255,0.02);padding:4px 0;word-break:break-word;">
                <span style="color:var(--yellow);font-weight:700;">💬 Chat:</span> ${escapeHtml(m)}
              </div>
            `;
          }).join('');
        }
      }
    }
  });

  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  // ── ASSISTENTE DE IA ──
  const togAIActive = document.getElementById('togAIActive');
  const aiGeminiKey = document.getElementById('aiGeminiKey');
  const aiSystemPrompt = document.getElementById('aiSystemPrompt');
  const aiProductDesc = document.getElementById('aiProductDesc');
  const aiResponseDelay = document.getElementById('aiResponseDelay');

  if (togAIActive && aiGeminiKey && aiSystemPrompt && aiProductDesc && aiResponseDelay) {
    // Carrega configurações da IA salvas
    chrome.storage.local.get(['ilAIActive', 'ilAIGeminiKey', 'ilAISystemPrompt', 'ilAIProductDesc', 'ilAIResponseDelay'], (d) => {
      const active = !!d.ilAIActive;
      const key = d.ilAIGeminiKey || '';
      const prompt = d.ilAISystemPrompt || 'Você é o assistente da live. Responda de forma curta e objetiva (máximo 120 caracteres).';
      const prodDesc = d.ilAIProductDesc || '';
      const delay = d.ilAIResponseDelay !== undefined ? d.ilAIResponseDelay : 8;

      if (active) togAIActive.classList.add('on'); else togAIActive.classList.remove('on');
      aiGeminiKey.value = key;
      aiSystemPrompt.value = prompt;
      aiProductDesc.value = prodDesc;
      aiResponseDelay.value = delay;
    });

    // Eventos de alteração
    togAIActive.addEventListener('click', () => {
      const active = !togAIActive.classList.contains('on');
      if (active) togAIActive.classList.add('on'); else togAIActive.classList.remove('on');
      chrome.storage.local.set({ ilAIActive: active });
      // Envia mensagem ao content script para ativar/desativar em tempo real
      chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
        tabs.forEach(t => {
          chrome.tabs.sendMessage(t.id, { action: 'updateAIConfig', data: { active } }, () => {
            if (chrome.runtime.lastError) {}
          });
        });
      });
    });

    aiGeminiKey.addEventListener('input', () => {
      chrome.storage.local.set({ ilAIGeminiKey: aiGeminiKey.value.trim() });
    });

    aiSystemPrompt.addEventListener('input', () => {
      chrome.storage.local.set({ ilAISystemPrompt: aiSystemPrompt.value });
    });

    aiProductDesc.addEventListener('input', () => {
      chrome.storage.local.set({ ilAIProductDesc: aiProductDesc.value });
    });

    aiResponseDelay.addEventListener('input', () => {
      const delay = parseInt(aiResponseDelay.value) || 8;
      chrome.storage.local.set({ ilAIResponseDelay: delay });
    });
  }

  // ↔️ MARGEM DA TELA (PUSH MARGIN)
  const sliderPushMargin = document.getElementById('sliderPushMargin');
  const valPushMargin = document.getElementById('valPushMargin');

  if (sliderPushMargin && valPushMargin) {
    // Carrega margem salva
    chrome.storage.local.get(['ilPushMargin'], (d) => {
      const margin = d.ilPushMargin !== undefined ? d.ilPushMargin : 390;
      sliderPushMargin.value = margin;
      valPushMargin.textContent = margin + 'px';
    });

    // Salva ao arrastar
    sliderPushMargin.addEventListener('input', () => {
      const margin = parseInt(sliderPushMargin.value);
      valPushMargin.textContent = margin + 'px';
      chrome.storage.local.set({ ilPushMargin: margin });
    });
  }

  // 🎫 CENTRAL DE SUPORTE
  const btnNovoChamado = document.getElementById('btnNovoChamado');
  const btnCancelarNovo = document.getElementById('btnCancelarNovo');
  const btnVoltarLista = document.getElementById('btnVoltarLista');
  const btnChatEnviar = document.getElementById('btnChatEnviar');

  const suporteTelaLista = document.getElementById('suporteTelaLista');
  const suporteTelaForm = document.getElementById('suporteTelaForm');
  const suporteTelaChat = document.getElementById('suporteTelaChat');

  const suporteListaItens = document.getElementById('suporteListaItens');
  const chatMensagensBox = document.getElementById('chatMensagensBox');
  const chatMensagemInput = document.getElementById('chatMensagemInput');
  const chatTicketSubject = document.getElementById('chatTicketSubject');
  const chatTicketStatus = document.getElementById('chatTicketStatus');

  const btnSuporteEnviar = document.getElementById('suporteEnviar');
  const inputSuporteAssunto = document.getElementById('suporteAssunto');
  const txtSuporteMensagem = document.getElementById('suporteMensagem');
  const labelSuporteStatus = document.getElementById('suporteMsgStatus');

  let activeTicketId = null;
  let chatPollInterval = null;

  function loadTicketsList() {
    if (!suporteListaItens) return;
    suporteListaItens.innerHTML = '<div style="color:var(--muted);text-align:center;padding:20px 0;font-size:11px;">Carregando chamados...</div>';

    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
      const key = d.ilAcessoToken || '';
      const email = d.ilAcessoEmail || '';

      if (!key || !email) {
        suporteListaItens.innerHTML = '<div style="color:#ff1717;text-align:center;padding:20px 0;font-size:11px;">Erro: Login não detectado.</div>';
        return;
      }

      fetch(`https://api.valoranegocios.com.br/api/support/tickets?key=${encodeURIComponent(key)}&email=${encodeURIComponent(email)}`)
        .then(res => {
          if (!res.ok) {
            return res.text().then(txt => {
              console.error('[Suporte] Resposta do servidor:', res.status, txt);
              throw new Error(`Servidor retornou ${res.status}: ${txt.substring(0, 120)}`);
            });
          }
          return res.json();
        })
        .then(data => {
          if (data && data.ok) {
            if (!data.tickets.length) {
              suporteListaItens.innerHTML = '<div style="color:var(--muted);text-align:center;padding:20px 0;font-size:11px;">Nenhum chamado registrado. Crie um novo chamado no botão acima!</div>';
              return;
            }

            suporteListaItens.innerHTML = data.tickets.map(t => {
              const dateStr = t.createdAt ? new Date(t.createdAt).toLocaleString('pt-BR', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '';
              const isResolved = t.status === 'resolved';
              const statusBg = isResolved ? 'rgba(0,230,118,0.12)' : 'rgba(255,208,0,0.12)';
              const statusColor = isResolved ? '#00e676' : '#ffd000';
              return `
                <div class="ticket-row-btn" data-id="${t.id}" data-subject="${escapeHtml(t.subject)}" data-status="${t.status}" style="background:rgba(255,255,255,0.02); border:1px solid var(--border); border-radius:8px; padding:10px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; transition: all 0.2s;">
                  <div>
                    <div style="font-weight:700; color:#fff; font-size:11px;">${escapeHtml(t.subject)}</div>
                    <span style="font-size:9px; color:var(--muted);">${dateStr}</span>
                  </div>
                  <span style="font-size:9px; font-weight:800; padding:2px 6px; border-radius:4px; text-transform:uppercase; background:${statusBg}; color:${statusColor};">${t.status}</span>
                </div>
              `;
            }).join('');

            // Bind click rows
            suporteListaItens.querySelectorAll('.ticket-row-btn').forEach(row => {
              row.addEventListener('click', () => {
                const id = row.getAttribute('data-id');
                const subject = row.getAttribute('data-subject');
                const status = row.getAttribute('data-status');
                openTicketChat(id, subject, status);
              });
            });
          } else {
            suporteListaItens.innerHTML = `<div style="color:#ff1717;text-align:center;padding:20px 0;font-size:11px;">Erro: ${data.error || 'Erro na listagem.'}</div>`;
          }
        })
        .catch(err => {
          console.error('[Suporte] Erro ao carregar chamados:', err);
          suporteListaItens.innerHTML = `<div style="color:#ff1717;text-align:center;padding:20px 0;font-size:11px;">Erro: ${err.message}</div>`;
        });
    });
  }

  function openTicketChat(ticketId, subject, status) {
    activeTicketId = ticketId;
    chatTicketSubject.textContent = subject;
    chatTicketStatus.textContent = 'Status: ' + status;
    chatTicketStatus.style.color = status === 'resolved' ? '#00e676' : '#ffd000';

    suporteTelaLista.style.display = 'none';
    suporteTelaForm.style.display = 'none';
    suporteTelaChat.style.display = 'flex';

    loadChatMessages();

    // Inicia polling a cada 5 segundos
    clearInterval(chatPollInterval);
    chatPollInterval = setInterval(loadChatMessages, 5000);
  }

  function loadChatMessages() {
    if (!activeTicketId || !chatMensagensBox) return;

    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
      const key = d.ilAcessoToken || '';
      const email = d.ilAcessoEmail || '';

      fetch(`https://api.valoranegocios.com.br/api/support/tickets/${activeTicketId}/messages?key=${encodeURIComponent(key)}&email=${encodeURIComponent(email)}`)
        .then(res => res.json())
        .then(data => {
          if (data && data.ok) {
            const scrollAtBottom = chatMensagensBox.scrollHeight - chatMensagensBox.scrollTop <= chatMensagensBox.clientHeight + 40;
            
            chatMensagensBox.innerHTML = data.messages.length ? "" : '<div style="color:var(--muted); text-align:center; font-size:11px; padding:20px 0;">Nenhuma mensagem de suporte ainda. Descreva sua dúvida abaixo!</div>';
            
            data.messages.forEach(m => {
              const div = document.createElement("div");
              if (m.sender === "agent") {
                div.style.cssText = "align-self: flex-start; background: rgba(255,208,0,0.12); border: 1px solid rgba(255,208,0,0.25); color: #ffd000; border-radius: 8px 8px 8px 0px; padding: 6px 10px; font-size: 11px; max-width: 85%; word-break: break-word;";
                div.innerHTML = `<strong>Suporte:</strong> ${escapeHtml(m.message)}`;
              } else {
                div.style.cssText = "align-self: flex-end; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px 8px 0px 8px; padding: 6px 10px; font-size: 11px; max-width: 85%; word-break: break-word;";
                div.innerHTML = `${escapeHtml(m.message)}`;
              }
              chatMensagensBox.appendChild(div);
            });

            if (scrollAtBottom) {
              chatMensagensBox.scrollTop = chatMensagensBox.scrollHeight;
            }
          }
        })
        .catch(err => {
          console.error('[Chat Suporte] Erro ao carregar mensagens:', err);
        });
    });
  }

  function sendChatMessage() {
    if (!activeTicketId || !chatMensagemInput) return;
    const msg = chatMensagemInput.value.trim();
    if (!msg) return;

    chatMensagemInput.disabled = true;

    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
      const key = d.ilAcessoToken || '';
      const email = d.ilAcessoEmail || '';

      fetch(`https://api.valoranegocios.com.br/api/support/tickets/${activeTicketId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: key,
          email: email,
          message: msg
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data && data.ok) {
          chatMensagemInput.value = '';
          loadChatMessages();
        }
      })
      .catch(err => {
        console.error('[Chat Suporte] Erro ao enviar mensagem:', err);
      })
      .finally(() => {
        chatMensagemInput.disabled = false;
        chatMensagemInput.focus();
      });
    });
  }

  if (btnNovoChamado) {
    btnNovoChamado.addEventListener('click', () => {
      suporteTelaLista.style.display = 'none';
      suporteTelaChat.style.display = 'none';
      suporteTelaForm.style.display = 'block';
    });
  }

  if (btnCancelarNovo) {
    btnCancelarNovo.addEventListener('click', () => {
      suporteTelaForm.style.display = 'none';
      suporteTelaChat.style.display = 'none';
      suporteTelaLista.style.display = 'block';
      loadTicketsList();
    });
  }

  if (btnVoltarLista) {
    btnVoltarLista.addEventListener('click', () => {
      clearInterval(chatPollInterval);
      activeTicketId = null;
      suporteTelaChat.style.display = 'none';
      suporteTelaForm.style.display = 'none';
      suporteTelaLista.style.display = 'block';
      loadTicketsList();
    });
  }

  if (btnChatEnviar) {
    btnChatEnviar.addEventListener('click', sendChatMessage);
  }

  if (chatMensagemInput) {
    chatMensagemInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') sendChatMessage();
    });
  }

  // (Listener da aba de Suporte já está no bloco de inicialização das tabs acima)

  if (btnSuporteEnviar && inputSuporteAssunto && txtSuporteMensagem && labelSuporteStatus) {
    btnSuporteEnviar.addEventListener('click', () => {
      const assunto = inputSuporteAssunto.value.trim();
      const mensagem = txtSuporteMensagem.value.trim();

      if (!assunto || !mensagem) {
        labelSuporteStatus.style.color = '#ff1717';
        labelSuporteStatus.textContent = '❌ Preencha todos os campos.';
        return;
      }

      labelSuporteStatus.style.color = '#ffd000';
      labelSuporteStatus.textContent = '⏳ Enviando chamado...';
      btnSuporteEnviar.disabled = true;

      // Obtém chave e e-mail salvos do storage
      chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
        const key = d.ilAcessoToken || '';
        const email = d.ilAcessoEmail || '';

        if (!key || !email) {
          labelSuporteStatus.style.color = '#ff1717';
          labelSuporteStatus.textContent = '❌ Erro: Chave de acesso não encontrada.';
          btnSuporteEnviar.disabled = false;
          return;
        }

        // Faz o POST para a rota de criação de chamados no servidor
        fetch('https://api.valoranegocios.com.br/api/support/tickets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            key: key,
            email: email,
            subject: assunto,
            message: mensagem
          })
        })
        .then(res => {
          if (!res.ok) {
            return res.json().then(errData => {
              throw new Error(errData.error || 'Erro ao registrar chamado.');
            });
          }
          return res.json();
        })
        .then(data => {
          if (data && data.ok) {
            labelSuporteStatus.style.color = '#00e676';
            labelSuporteStatus.textContent = '✅ Chamado enviado com sucesso!';
            inputSuporteAssunto.value = '';
            txtSuporteMensagem.value = '';
            
            // Retorna para a lista de tickets após 1.5s
            setTimeout(() => {
              suporteTelaForm.style.display = 'none';
              suporteTelaChat.style.display = 'none';
              suporteTelaLista.style.display = 'block';
              loadTicketsList();
            }, 1500);
          } else {
            labelSuporteStatus.style.color = '#ff1717';
            labelSuporteStatus.textContent = '❌ ' + (data.error || 'Erro ao enviar chamado.');
          }
        })
        .catch(err => {
          labelSuporteStatus.style.color = '#ff1717';
          labelSuporteStatus.textContent = '❌ ' + err.message;
        })
        .finally(() => {
          btnSuporteEnviar.disabled = false;
        });
      });
    });
  }

  // Verifica plano na inicialização
  checkFeatureLock();
})();
