// VidCam — v2.2 (com ativação por chave)
// A live inicia normal + minimizar não deixa o vídeo preto.
// O painel só liga quando o guardião de licença (gate.js) confirma a chave.

(function () {
  'use strict';

  if (window.__vidcamInstalada) return;
  window.__vidcamInstalada = true;

  let VERSAO = '2.9.7';
  let ASSINATURA = { email: '', key: '', exp: 0 };

  // ---------- Ícones SVG (estilo LiveGo Pro) ----------
  const IC = {
    gear:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    power:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
    min:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" width="16" height="16"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    back:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
    play:'<svg viewBox="0 0 24 24" fill="currentColor" width="15" height="15"><path d="M8 5v14l11-7z"/></svg>',
    pause:'<svg viewBox="0 0 24 24" fill="currentColor" width="15" height="15"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>',
    restart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
    rewind:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="11 17 6 12 11 7"/><polyline points="18 17 13 12 18 7"/></svg>',
    forward:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="13 17 18 12 13 7"/><polyline points="6 17 11 12 6 7"/></svg>',
    volOn:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>',
    volOff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>',
    plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    sync:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
    micOn:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0"/><line x1="12" y1="19" x2="12" y2="22"/></svg>',
    micOff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><line x1="2" y1="2" x2="22" y2="22"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V5a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12"/><line x1="12" y1="19" x2="12" y2="22"/></svg>',
    fx:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
    infinito:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><path d="M18.178 8c5.096 0 5.096 8 0 8-5.095 0-7.133-8-12.739-8-4.585 0-4.585 8 0 8 5.606 0 7.644-8 12.74-8z"/></svg>'
  };
  const LOGO_URI = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAABnCAYAAABxTpuQAABau0lEQVR4nO39d5wkV3m3D1/3OVUdJ2+OymklgcQKBEigFUkEmTwLmJzEg3lssAEbG9u7AxhsDAYeDDbYJphkdsHkJEABJCEJSUhaaaVV2Jwnz3SsqnPu949TPbtKIIG8wr+3Lz7NrGa6q6urq7515wNdunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0uWRRx7pHfhdUFRYh2zc/Os+x8aHtM3hVcMKsH7uN+tZP7JeoXOwRB/qfnbp0qXLw4YOq9V1ah6R91aVS8/TaN0j9P5dunR5+Ige6R14qKiqiIgD+PHSa+bNe8qC5aaivXEhkppvSerRKIpo+0yyVoZ61FjrU1LUoM4gEJO0U82ylCiK8Wo9BedcEvnMW5+peokl9ZnNWpO0btm9pXnzti1p0055EZkBMi4HXadGRtCuVdily/9O/le5wEFwxO8a3vvi/sG+i8xx9kydz2CxUrRaELyC5lqkCt55vCpePKoCDlADHlyseK+oE7yDJPVkbXCJetdC06b65pRoq65pu+latUaa+kxcLU12tl1y2c7Z7f/9/l+eex3AOtSMIP6RPDZdunR56PyvEcCO+I2+dPR985fPfze9wD7wo6j3Xr1HVQ0q4DPUe8RZ8IJ6RZ1DnAsq5Ty4GDILmUczH/6WadDIxEMKJAkmc0EzU6Dzb4lhyjd0n9vzhW/seedbb9rxramuCHbp8r+P/xUCqMNqZaO4nRfsuWDF8qU/pETi70Z01FuxBq+Icx6vBu9R58EDTiBTcA5N8eK8IRMkAzxoqpAJmoA4IBUvTo2mgiYGMo+kCpnx6jCaAm0cqRWvxphyhWia/Zt2meuf/y9XXLi1K4Jduvzv4n9HIH8VClAtl99BjPN7vNdJb7SEOuvVqfeZ4jPwqXhNxfsE79s+PFrifQt8y3htiacpnqbx0oq8tKyXJIIkQlJrSKyXtvGS4Gmrl7Z6SVXDT++NU6xzxG2X2YMzrh27xafP53Hfv3D1h+azDtax7n/HMe3SpcvvvwXYcX2vP/fmR5256PSbBGAcSMjNvPBIsvCfKeB9cHMzDY9EIc3d20zQ1EPq0MRBgifJN5MSnpcao2rAWyQxSGqdJh5NPZKKkgqSCerEk1iTlKtRaXvzzv/6z5tOfNnwsNqNG0OSpkuXLr/f/F4KYKe+j83I9YPXm9WTq/21+246biAZ/GSxFS+2WJ/4zCTekTmviVdxqqTOkODJfKqperzaxEam1qLlGq20b6beXtHIskEXIXaelXjIEFcLYnospmiClrqI1oxqVhetHzCSTvdKQaoalSOkaiWzSOIFZ1BnPakFZ6xzsYt3yU1PLL/zcdcOTl5vlly02gGMrAdYD+tDLWE44t2scZcuvw/83gigosIwhlWojDxscbTyibziCSdx5rOWDy1fs/jUweNOfMyC/mNOH2LRyirl3iJxFKmPjLhYxFs0s54k8tpMMqZnGrJtc0t2X5Pprl+i6V0liV1MuRxJFEfazow2EWnF1lEoxfuTg1/80e5Fr3xQn1dV1oI5CLJw40bduHZt12rs0uUI83shgJ0kR+e/Jx/9q4HykhVLZ0wyX0piozjSrOVsbCPRyDrSTNpZYlHrU6O+PYvMNBtmRbRQb6/dab6w89KB2Ynmkyz9z3nUWWcc+8Qnn8wJqwdZuNRCjJIBChRRH4MvQ1pCMgvOQhKhqYU0QlwBEovONBK23d6WzVe3uf1Am7aJdEkc0VexZAdSnWlFZrrVGi8+d+o1/Y9ZuWc88e2x6Ua7sdO7Rm02K8y61r6tU43dH/lRG0buI/AdQdwoXfe5S5cjxSMugB3xu4V1haNe/ObhQk/vS6Nq8SwjdgGKxXIouOcIwpUALSBRtNFG6oImlruS/fx05w1smRrnqDOO5kkvWMWjH7soiwyOOpYSQj/GFWAsa7N3ZkKn6pO6b2xGZpqIKSrFimdwXo/2DM3XwaVDUplXFltAWx6tGSSLYGIykRtuafPzLYnfXS7I0hVlWbpAGShbKcYGV1ScaFY03ptIPPhMrDSNNTX1PkmdOoyOTXvdNz2T3Dy1N730p2fP+wXAOlUzIt1McpcuR4JHVAA74jd9we7nlpcMvTceLD+KDDjo8FNNT815Ug+Zw3jAOSHN1DuPOsicx7hYxjXhJ81NevPEbvH9PXrB68/SpzzjFLV1rKsjdgClB7nxwJ1cfsutcsOmndy9e1qnZg2zmScRi4ur4q3iTaYSgTWZDvRE5vhjB3jsY5bqYx9/oi459XjJKjCZIEXjaEx5fnJFUz97TSbTxR5MRYhi9XHFSFRGilUjhaqhUISoCMUSlHugVIByEXp7oLcX4kyZbieXHziYfeCyY3t+pKoSQoXdWGGXLv+TPGIC2BG/5vDk+tKCgXUUgbtaKVvb0HQG9QJeQymzU7wXvAdVvPd4VCLbo7emE/Lj6Rt1a2uc484+Tl74+ieyYn6/95NOzHwr7R78t6+5Qjf88Epz5+0TeAakUO3FFI1636CZzdBsz5Bks+KN4GwBShXV6nxNKoOmZav4ZktL2bieuELkmc87gye96ElSGCwz0cZXi5iJHQ0+/Y0Gl9ersKCspBnERokRYiNE6GEPIQIERbzGsWHZAHbViZi+Koztb33kJ0vK71inyghoVwS7dPmf4xERwDnxe+74e0orhv6Gtk/95oaYscwQ5bvkPXinXp0Y9Yp6wSlOPVYFR5Ff1Pdw9eztciCp85hXncbw8x9PNAkoymL47uar5FP/dbHffmdbe+P5plTwTLd2ycTUNlqMaaGklIdiehbOQwdL0nSJJt7TrLVpjs1oe7Jp1JWIFx6nuvhMZpkH0+NyzMImr3vDY3niy5+hkxbaHgaTTL74+YN8eXdBzdHz0dRBQYSSgQgkRrEwJ4AWNEJVEATFe3/8CsOpxxKN7at/6cqlPa8YVrUPX0xQ5f6yz4r+2nNAHpaMtf7ajTw87/GQEOX+3/Lh2xcVFFi/Xli/PvxqPbA+f+Puje33giMugB3xm3je7j8YXLbs2zSylJvbhjZCpErmwWlo0FWnqMd7L0YJ4ieGWadcNTumd9S2y+5slKe85Wy5YM1ppPsz4kURu5Mpv+4/PsOvrtor/cXlFIp1HZ24gelsr8xfMo/VT320POrcM1hx6gkaLepj1Hp2mUwmsoxJ5/TgbMp0LdED2w+Yseu30PjlTepuv1UlK4o5+sm0+s4UPbCTs05x+sb3vYZFZ6yQvaljcWz1ki9ukU9cDTz+JKXt0YIRLCH5EoRPiAEL2CCKYoECaAorFvv09ONNce+2mXfeeGz/h34nEVSVdZdh16/BSfeCA2ADG+xLeIl7IAH8rVEVQmOBAJ7fFMcVYdh7u/HBPr/L/whHVAA1vyvuPev68rzTT95UrFSP4bqGo2UMRvHOYZwq3hvUK96r915QjypYY2QscXrl5JjuT/fKne27ueCPn8zTn3SqtPclFJcX+Om2m3jfx77oObCQocGSHJz5JRPNu/1JJx0rL/7DF8gzXr6G+ccNCUDDo7unZtl0cJTttbocrLeYTJ3ub7SYRpgpFGQ2qtKoWW3sGNPW5T+T7KcbkTQSs+qlmrj5FGt3yZveuUbXXPQM2dFyLC1ZfvWVW/WDP5hCnnMOrumDAEZGc+E7TAC9Eplw2URgCohv4U45BQarWWPn9/at2r125Z5gJz54AVunak4FWXuYcCrrImEkO/x53z/+jmI8bktb2YrzbTNjGr4sbW1qUZrS1n0Te+TTvGsGfje1+PDyDWUzu6DYnh5VGKTZv1uYjjz0mKOPOprX7jhz6tCzg7X4P2EVKiqd7b6r/5OD0E8/INM1v6J/lVlaODE9f3RR7aFtVIPo3ecmta7AB15UXfb4pdViyZdjJ0ajLGlNtls7bxpr8K6zpu+1nXzcZPdGdSQ5sgJ4nkZyuWQzLzr4xt7lCz7NnS5hTxb5SDCZw3mPeMV4FbxXrw48eO+IjJF9SarXTtZ1Wsfl+tqVcu4bnqDDFzxe2rsTiscX+NIvLuVDH/oaxxZOVyns1z0T10hPNdbXnveH+sLznyWlx/ULpyBpf6aoF1OMtA2M1TP21Buyu5Gwt+XYV0t070ybbeM1OTDbIEkybfqYtDiP5v5ZSb77Obj2G9hlT/J+2YXidtzEC159Ji/7wMvZ3UhlaSXml5/+pX74sqaYFz9Z/JRTCjYI4GEuMFHuFod/IxZR0EJEeubZFBtbZ/9603F9f3eeanS5SPZrDi2oyjCYDeA71t65G+5Y8KonL32+VIuvvHUyaV38H9suvHX9qenGtZi1G8W957irV5/RPP0HzlnnvDfGoOLBiBpFkkhdabcf+8T/GT9m3aVcGp3P+b9+H+69S7ng/Pe88Yv7pLI6waeCkKliRNKqUJ5m5kvPG1381uvQeDV4CW3ZCMJX8XYtD08IoNOn/ZnBbc9eVBx4v3i7BLUIirGk/WIr9Wj2M0/dtfAdl6LR+fzG4x1aHnPLbeWXdgw2H9XzuEJ/6UnlcrQ6juRYpzpYKttiZCjmF1omTlOf+lbTm92Jy+5KZ9pXJVunfrr/aUdvfjg+Z5eHxpGdB7gGz+Ug5fLLaaFMeKFgMA7AICoh9qe+M7ZKvapENmJvK9Xrp9o4cXL97DWc8MxVOvz0x5PsTCiuKPDZy36qn/jIf8vp/Y/TmWwTByd+JatWnMDfPOXtcnSyGPfLcZJlHnt6H3EhBBqb9VQmdtX17h112TraYseUYywTHVPPTMHQigcxOiDaaqqfmdVs7E4xRrBPfyOsfKJm3/8HkaltUjz9T/Qbn7mZLHO86h9fpVubGasveizP33WpfvPbV2Kfew5u1oMx4ZZzeLewIoSopagHYkhqmAOzaDxUfD7w/stDAdD9cri1tzHMf2Dt9tpjTuyJX7+oal48XooWXgdcdTdp38nLlorI9uHhDQjCf9z9g1tHFp/UGooGVrR9OBnEAhoqjyxQ8f4Vq7nofWtY85DEbx3rjCD+o4O3rIyi/vMyYwvhgwa8Dx9qd7rr8lwo0/CX86J/XPSx4jsPnFFfi7jDrbbflnWsM+sRXbby9mMWthZ/vVdKpbo99PfE4J1gRtPpfQ9qg6q2Y/EtuGH8iXF/6U0MFJ9RrdrFpgjOQdIGn0C9ASJgMtQIRbFgCmD7WFwmOqs6r/TS5sJqKqPN6+Tm2mv3PmX+HQSLsusSHwGOmAAqKjIi/uazf7Go0FN4NFMqODFecgEQASQ4QN6qx+NQiU2kO9qpbJpuYW2Zm2Z/gTm2l9e+4mni9mQU5hf4/i2/4OP/9BVO61tDLbuB8dlNnHfME/ibc99BZaKmjW03U6r2U7ijDM+y1K+bZOfF+9m9rcWBFPYYowdjI5NimURkiowZr4zhqOMV68kKkXi3gGTXNvWzP5Vo8QkSPfuDmv307zS97v0UzngH3/nsjfQtqPLMP38RW9uOZ687n1tf+nW58+pNap5wOn7GBYURFSLptMbpXH0j4WJRRWYOIP2L7XE9X9ozryYydg83WFU2gBkO1p4HWH3dRP8ZK6vPXNQjb+iL7ZpGZKIfZrAL0tk7vezfiVkQMQhs37hhWC+V4eh8pDWRvnpjnwz8aaqkGT5CDQZQ9VrHEFM55mUL/uhsGZUrNrDBruXBdaysYb0ZYcTH0rvGGluoKwlKpKAOrwWM3ZdO7//OxJd/8hZG9H1DVy1bZU7+m9hU1+BN9RtD0wf32/GPyaj85+86ZWcN640wkn2xOf+l5ahUGvO0gIKGTar3xk8qkjq3CWD0gVz+dWp4j/GIuMqVk2eaZZWRtBBdmPYY8XVwM7g0w6cOURDUB1PWhBmUdP7fhEdk0FKMj3ujQqY83uypJ8gCZd2vT0x1efg4chbgOoQRdP7gUStjEw9QVwdGDKrhNBRAVVQAEa8QG9H9LeXmmZSYfna2buFO3cmfXfQKqg2rlLxsnjjAe/7pP3lU4WzabgvjtU087qhH6d+d/9e4W28zSdSm8oenKv1G/JiX2b++m4mtDXwxoqe/qtpjsCVLOTZSRbUIGntPIXN4pyKthGajTjKd4NVjSwtFplpk11+LWbiM6Ox3kl35D5Jt+giFU/9Cv/ShS2X5qqP06AvPYhJ41XvP572v+iZu2Txk4dIwiUFyEzBYWxLsP0Dp5GSlPo3a+TIYLysvAcYAWacqHWtvbW4Vvnxv8thlg/blA1ZfZGO7fBy4IkG3tkmdYAfBbr3bqFFjdyWmBMBG5JNsVICDjP3XkFv+NiSONN+zYOoZESWLbWTLfv4wcMUChh/0hdkRkUjLf+AU2uqNqDEKqpisIkhD2z/9ISMzf1n9yaLj7WmXDtneE2YVvIHY9C0/lr7Pf2rw7sKbJuXfN6C/tTvc2Ze2N2c1HJoqFkHAqAMEbF2dTDN5EODW+xPADWpZK26YYfv9Kz/3nvbi4p/byEbJKC7dj1NDhMEguX1vQMSE7cxJtxfy3ymYTKHW9lAS4vHkivRVR2/Lb3Rd6+8IceRGN+ULF1UrxQUSCTjjMQYvAiIoggdxGElBIjGMp8Km2UwsRWpS41eta+TUp5zCo1cu1Ww6k6zPsO6L/8L8xjFoYYrR2q84Zt7RvOdJ62hvuU2yqmr0948X95cD4l/ah99aI7ouobenh/6hKv3livSZAoMaMR/RJSq6HGU5jqVkLCZhXtEwWO6nN65SaINMNBDbK7ayFL/tLnTP7RKd/hbUg7/785hFZ+l//NUX0Ylp2qmToVOGeN4rT1f331dgrQuH3GlQGUf4GbpcNIyjCb93TbSNQRYUKwCrr8eOiPi1Io5bpobePt149Qdb7idnLbDX9JbMW2+P7fJvZ2TfSsi2KVoUor4CUtsFtbHwFWSzh76Ojax1isrfj3/v+nE/ewtgUsWnms9AVDQBU1cQ03vheawrnY/J+A1lMwGVtYh7Jh/rs1J40myYyGPaiiYKiUfqCjPUvwuwJD7+jX30nrDL0Zzx+JrDT6pPpx0+ksF3P375h8vDQUZ+K8voJRgHw9aJObGpSDt8Vtr5pKBMMU3Xro3Wdo4BrL+3AObiN/jRiZXfuObzP2wurvxVNmttew9p0sJoRkyGhKm5QIqSkmmK0wzUY9Rh1BmjDtHwXE9KJs5kAkhTbgXgMixdjhhHTAAvO3iZACTtdBAgZDvA5Ke0SAiOKYIRw6yDm2cUp5EiJd3WvI2JUqYv/INzlTGI5kX6lasu0V3Xj+mivnmMN66HQqbrn/ludGyf1PZPU77gMcIZXgHvZxONJNLqaYtoTSZ6x/aDeuv2/f62/fv0xm13ceMtW9h8651su30r++/eSX3/QczUDD31GXqTKXptRH/PAkoaYWbralykJl6I27kVJvZijnkl2eSNEjVvYWxsAd9931d0QWzZ57ye+5pHyaIoFXfFdWIqQKo6N3+rI4BJ/shFUNuoz0BLlRjg+rMkfcOknrGu7T76kZN6bz6+r/y5maJ56qVi/DdT0hsSfM1j+sD2GMQIWgL2dULrbWDmnmG89WBhxNfczFecQqrGZ6AZkCqSeUzD4YxWj33cwPPOBmWYjb/xnNmQn1dr+p79hILpX9RUXKZG0jCWzCtE02lt/K7kV5cCJM6dWhdcClHbI21F2p6opkjmzMKhseJCQXQd634LAVRRlCfOO6viMQsb+WFuA21FEu/JgJpm05c1vzoG91LZXPyGvjC2auZxPVdkUflpfjcJM0CbKBc7zb8/JcEhGMrEFIilhZGZNJNa2pJ6VjezaSZNh0RYqsSqlGiLSj371UP/bF1+V46YC7yGNQCkKmHuFKH8wytgDeo9TkKeIElFN80qqVq8iEwxw+bkNladdyLHzx+EUS+TPuFz3/wuywurmEi2MOp28ebHvkmO1kVcf+vXdPVxL1O/pylsKsJQItF/tWTKOm6+5pdaeGoJe2qZS75wFTf8cBfG9EO1qC2fkYiQWsiKMa5Uxg70U14wAL0liCuU5q1Q12xLMrtHjLfqTI+muzaJXXYWZv4FpNu/TnTC27nkq7/i3Dfu1sJJy0y7r6jnvmiVfv0zNxOffpIkpQEh84oxc/GguUd+9akBTaDYCmLyT7PNDxZL/h31yMiNwN0p6bRHrCBFgy0K4oKNpKJQKSDtfTA+6kWKJsQZ2vexoDzAtuzOr1fMwpGCqcSuE4sMy6qIguvB2gFZ+Hzg8lUPwg2+Nf8URTPvAkDbihfFaEiu+Ipgp1z90n+tv+ggwKxP7mw6bFNJwUcAXsnKYNvqJ9PWtjEQRlivMPKQzjvND+kTonPL3sWFhGCAdz58ZxmZVGTycj6fzn16CJleEbfkU6Mnj64cuNipXcY4CYZ4znQQBIMCjhKRlDBmNj3gp/xPZCy73ExkN5oDs1MiLpPe2GnkCn5osOjLcpT0m8f6orlQGsWz3MHGzUBIFHY5YhwxAbws/+kMczERf9il5AWMEXWqclsNmt7iJcNpQXcld8qomeS15z0LaghDho2/+Dnje1Pm9xnZP7uFRT1L5A9XvESvue4HHGXOChf7VsV8ZlbTybZecfet3H7ndmlUm3rR37+OaqkkT3z9avnehqv03z54sd7xqzEpFwcp9ZVw3ikuwbVSae2vMX1gL3bePJWBXskqoxSWHEtWr6mbncSYorgsQg/eiPSfpTpxA0xcTktPkh9//Ou86JNv1f3AGc88hu/952aS629VOf8c0RnAerBG8RwSPyXPCXtxqUFT2rAu+s73m285dW1JbnC0nRJFQjQQLryOUGEMioabSgm46zaAPOakkPrsHuI1gvh1qBmZlTv/um/PLxYWK+elYYas7UiAV2wDiEzluc/kY+96D6Z92J7eL+/BZLDOeKJn1EEyDfvX2dm2wpQb/1an5u9V7jv/XnVL/njA9g808kWrjBB7hf26/0M/5sP13zYGuD7f13bbLnGR6XOK+nx/QprCaAS0tb0XcIoaobOKFjz6I5MDW5b1fDvL7DJmSLFEoXYmRBExKBmOAWKZyg7auxr/ULrl7i/UPvCYUYVfp2a3At8XGCl8aPsT+xcWNx0AuvG/I8sRc4HX5D+dzwq0CSe5CbvgBUQMGGTLlDCbWEBoq6Hp27KteQc9S/o5Y+UKaIRFi7572RXMsyuYznYwrnt57srn+ca+GTmwr8aAW6mt2Qb1sVn233BQvvCzH8qVN21mtu5pL1eJrIhPPVYtz3/pk2TDVX8pf/6vz5B4+TRbR7fKTG1KsqxOuzlLljTAJbRHD0hj116yfaMk+27CrFyFRjHqU7A9+Po42p6Evifgx3+F9Axy3cVbqO2dpA3ac+wAj37sYvymXWKmaiHdENxfIQMSL3O+WcuLb4CbhfpoGp8HXHpVsbHlCq9LLXGv86bMnNEosaAFQQuKFICeIiSjsH83EIUOExzgc9PmHmvFX2ZAqPnxL2f55Oz8IYkimXpT87iIvmNX9Z97rqJs4IHXRF6HGkV5R/W5pyGlk2sh7meSMKFbvRJPudr0XXrtT0B0LZgvtJ678w537bP2pnuvaqQzjXo2U59Np266I73rovfPrvroOtQ8BPGTPE4pAJvZGEIvTiopsUkUl+Sxv1b4jJoCLfUT+aHpHCMjIv72eeV/bRWjE5gkwRHNxW5D+EJxOOkhNnua39QfHDgre3n/P9U+8JhRVC2XaoSqYd39PDaEv6tA6x1HX3XgVUvqD/LzdXkYOfLrAgsGB14RLHgfemGNhS3jMJlYRJCWU1KNmdJ97PEHOO2Ek+mLIrCwZXIXe7ZOyOLCQkbb16s1sTy5skau2nGNFrIl7G9OiRdHSxv6gwM/171j4/QX+2S6PYPXJIiPGnGZ0yRVLccVeeObLtQXvORc+cynfsCn/t8l7N6bUi4PImR418JHRc3qmaCpmKaqLw6KWXmmpjd9P0/j9qH1bVA9HT99GVG6S2dny3L7xdex/DVPZxw49bwVXHPpDrhjK5z2qGAKmc5RMcFbMx7UKM6JrwP1zFzOiJrBv5KfXmzkD+Zn2n9yxGyKxrmfajRYIz5vquoHbtjs0cwghVBWiSeMELsXI1zmQdlTuOF7ve64WslUqhkei1FVUIwo+IKxtmIWvhD46a33CpPdCwPii7rgGZHEtu5J1eTnmccXBVPX2pUbG6/dr6jZCDwNjd80K1cD5/xh6YtHQYkvt168h6CZIr+mBCaswbLenAr6EozTYBDnB1VYxbBdx6UybgaqmQqZ5uce4Xh5wk0jQ7dD7r7ncb/qv0y+oN5ffAkHSTHE5HWaHd8Zi6NKbLbOfNy9vP9PALhUI9bg7tsZ8oAIGzYY1q7tbPX+URU2YliAzFkTHS4DRlGG8b+2k0R/TQLr3q9bt86wfv3cjaSzBXhQ73FYMCd/3fr1ysh952A+0hzxBXxMFCsOTKcEWNAogq3TXkYboVC47SHR0Dg36g8yTcLJxy2FRmgju/q222m1I21JnYNul6wsHq3zsnncNrVT1FXZ1RzV7a2DXDtxJ9eN3S7OwL5sgnFqzJKgJi9WbQlZy0ij7qnNZjLUN8Cf/8XL+Nl1f8eb3/YEnJ1manYcrynqGuKzOq45oy6zwq6b0b5+TO98NG2CVNGkAZqJlI5FZ24UigvYdOltWgZqwNJHz6dUKeLu2qGSuXzZurBACYkTUhfMr7YTWh5NIUsiAVQyUV+CS78IPQc9/TFSVCgYtNNZFwtaLKDplGf3NqAImuQWpgcK0f2cuCN+A2o3Trxmz6wbv0wUydS4JGSDJQMyMA0PQv9zhvlweST8+oEuJg+KmPIFzWBpSerzj5Vbl7PZ1LdA2AiyFnFvmiuChi+3XrHjy60X7yCvxnmgImhFZQNqRxjxI0iWF00D2PM4LwKsoowgyQjnZ2XbN+gJIyQzIJWwL5miLWDW12sA+0AYxp933rZSq1D9gNZQOscwo5OoEjK89BDb7bX/dC/v/xNULevUcL5kD7GdTQnTwO/7GlXJrchQA7pWXL79ez7Ol4y14hDRuf24P0T0AR8d1qlB1TIy4hFx93qvQ+9xf/saCsT1fl83MuLD636/ahyPuAXo86/aa7j+4xh2jyF7Z4JL3PL5IkYET2MyGydFOWr5kNAGKnDznduI6JWWn2GGaU4pPkq2z0zqzsasLtQme924SDnm0olrSIBxX8NbJUOpSBRSpBq6EURAXVhPeGbKozgWL1jIRz/yJnnt65/CyPov842v3wbSq+X+XskyR9qKiZOmMrEFWbYKDtwFNgJXFLJp1dKJ+NkfQz/svW0fppaSVWJ6j+5n6fJetu6ZFJmYUK0sgDQ7dPdVDVVkHsT4PBssAqj34iSCGYm4+MsJz3lzhItNx4IOUXiPVCxsugWyxCAxeZWlCdpwrxhgh1u5TAAZc/u/1GtXXJirkRIODyjGC1mB6lHzq888h/rbfzKMmo33cUtVRhD/Ar6+0Ev1sfVQ7ROK/8KZb6eyWm1cr/s+KP/Ap4tvq975jwWNB1FSEwrnREBLxkQH/MGL/6Wx+rP3LoQeRm3eMuf+pHTdyoF4yQug8EREToBCDyLmyZI4IZrKnL+7ztRPUifHJxbSzkgczc0ZQdqAs9EYwJZXb7fIMemNH6j9oS/EJzFLRoSdi3qGeK2jgmU0uXv+h6/6owOqhvUoD99SDod3m2QAla9vX+KP7jvBiZyg1vSZ3mLsxVhTbyfiZFo0uT2+qXHbrMh4/npzj3jiRdfF/e3jqqYxoT6ODLFXs7hf/f5psUenfmLkxJm59xwBvrBrefmUnsdqf/lYLGWT0tLZ2bsKP69dNi0ydY/tH/q36//kzYPNMxc/3gwUT6W3XDaZb2rq7irvGP/lhMieznny+7IuzhEXwExDFbA3EBeR8Sl0+yhqjKGVHlqU3KnRlsJodpC4UGBJzwDk7VM7xyewVKn5HWQkDLil3Dh1t4y7GXYzqbN2Bk0jdrX300sfbeqIiiakBl9Rg4Tsc/gWVCV45iIe7y2Tkw4xnkefdgL//bV1fPu7V+q69Rvkxuv3QDwksbE4IyIHNisnPAtKZWgnglqPm0IKiwTXUqQhE/vbtHePY09erN5Ylq3sZevtB1X2H4TjFkDimCsGUkLOIgONfF6rkc2lRlTBlNF9+yL5+ZecnPc6mFCjhjA1sRAjjRn0zi1IZ7pM7q4J0ilwvi8jrHGAbqlf8+MBe9xUxQ4NOPVegp0OAuLRSAwFM/h84Cer7scCXMdldgSyZT2PObcg5f66kine5tvxRTRqutpVX2q+cjcICRPFql3whnm2v5CEt0EkrOhXVZhRvyPf9FzqrJMMeUP5+8uXRKv/tiD9L4lssa/TRenkUMGgACXL4yIGXtZST83PHeFwuCWoWUshkdZuALZvzxjeYGtR4Y99bW75hFCqbvM9CVN8RPbU33vg5gvqXKYRI7+hd/ihkGef+z68c6hxzryX0Ru9sFWS1VqM+ymDxoeyULIg/496lXRx32i0tfUde83ke9si21mnhlM3CmvXusobT356fV7xi95VE3FEIVIqTnp6o2gq+wHr9VWIuOLX9h+rj+7/27QUv6BVsX3EHHJo0yKtowb2FZ9Wf29b5F/YsMEyPAwibtHb91WnXt/3l7P9xddqZJdSPex1GSSDheniHbV/X/zGjX+94zLa8NAGfPxPccSzwD7DkEFkYaaJbt4BSL4IeV6DlgFOjLS1zYyrE/eU6K+UlTrSdjDTaOLpp6l1HEKWVdnq91FD2cmEpJJoK20wSyJKWxWPQSQho0JoSVXvyYN3dCwoAGuNigRrfXQ0o1AQnnvhOfKMZzyWj3/iG/zTP32P/bsnMQMrMbNTIKnSv0g4sB2kINBULfYoFDHUaLctk/sOYE9eTA1kcEVPqMMYm4BjCH6YaGgF9BpmA2Z5P3QCuPwrcnkvVebF9Bu23Ir2fzfjjAsLTKYgglQMbL7FS5YYlQqiodzoQUx+Es2FZfx0f+GPynZobarGIfl0RgXwFjUg5QuX86fvHEGa976Tn8oaBShI/zOz4GKqYnIzErUq1Jn8Dvn1208lasLsmNIfwsLeoAbxZG0lart08vC97Ijf63uuG15sTvx4wfYuqgNeScOdDJmL7wUzWvNvGI+JCOblnFmkhL3PgOm01kLgZ5efn5Xfuu/sVmQfTY2wKEN4geBz36VqYsbae/wPfvm1fKLjw7eOS94JEl8888bZxZW/0T67Ag80gBoOCakszW9q2hmoIVhXtAtYaF+nT57/nPLV089vPl6u5hYtAA7PQjcQDeoMUMzfywH9QM3EiHhzxexL0mWlT/q+aIgpoIEjXDyBCEMxWpIeF32ycHWjN3l85YMA8XfGTxs7pfcLfl58hk4DdRwz+ZE3KAbj4qjfHx29fe+/DJ+IbHwBOjx3H3rYjt1vwRGPAdadRHiYTeHmuxHnQufBnOurkIXTl5a2ta0tNC4hxuBB661E6o2mOIk00UwdMJa22JlMMEObg8ww4evsTw9SI2WGltRIqJNSJ8Opz4MQBueQ3CBF9VCZBhiMQBxFeG8ZHcs0TQv6zj99Cb+64Z946zueTOTHVFsObU2L9C8A4xVrFGuh0gsmBjejaMTYrik8MAPaN5jfUqdnQ1IiBVIfLMHMg/MS4oKaW4DhglbtqLTBZ2DmGa69xLDj6oy+OHyRSRPu2kwYuRWyvocyvwDJ/bvAAJ/I3eA6O7/S8kiWd0ukeTgiUyMNxRnpPer86svOARi+5/kjaxF3PH9cbGj09NnwutBx4T0pxDVtJDN+5w/JHdB5pZNKXqNy2xOlSpSpsU6JUojaStQim7s4hjuWX98tb1lsz9iQSu+icefTtsenEp7fVkzSeWBoqzdp+G/bCau0CefZXCYYbENSMluaG4OlxfIzVYyQkc1l5pO8U8cZhwVJ/Lf58QV11mMfJncuJF9ERH5U/4/0qN5Pa8uuYBcZ+8iYwdNAaGBpYGhjSDA0iWgS0UKYwbODxNloUbun8uUln9pT4dQgzsms9jOFMk3CFJ4pPNOkTKNMJ3vNJbVX+6N6/su3oiF2+owaShtLMrf9iAaWSZzfRZbOL3yguGHfMfGVtTPTVX2XuTg+Q3eQMIOnhaFFRIKlTUQTQw2n22hnR1X/IL7yGa9HxHPppY9418sRF0BtGaMCt2+HtI2KzRccJxSg5euc40FTHAkOL8FG8g6xGBWx6vDicALCpG8w7etM0WKcOpPSYlZaNEmo06ZBWxqkNMnIxAdXOjcDOvVphx8OOUwmRMBaI+225+BESv/AfP3oP/6RnPPkFeJmGlja0FOGOIJCUdTGULBgrEAiiBWaLYRg0EWlAniP1uvQbuZtcU7C2ic+xADyFd01g6yde1ZedS772IlfDkX6k6/BxF0ZgxFsucnTnjWYOLjLhw56RzvlAQXwctY4EN1Uu+SnM25it1dsCr7zveRi6FQsBVnyfIDD3eBhNhiAM8uvejSmfHRT0VQxoVokzPtp6Mx1G9vPvGsDIYhuXLE/Q8oJkKqXwxexT4G2JC2ACe60GxH3yp4bXzgkJ/9zA5vV1bsME6UgSX6/SNSTKlmqqAOrakwGNm/x007jTaf5JsVoBiYha2ZxcqDzWTITrc5FT+7TspgitEAmW1c8rAF9VcNacdE3pt7Fssrr2EOTGZ/OvafLbalDTrjBYUhxtAg3ygRDSoEDpL4/OubA8f0vmctGe4nVIaTIYc+NmEB8W57n+0r/zhjKLCmZgQRHG58fBw67ERjqiGJNcuzQp7Nq6ZtoNI+DJGT5/qT4/DVCMveehsRHOoH3A+U3Kghr1jziWeEjLoC2KHZ8FqZmwUTQOkz80lA0S6aGTJEMJcOTkaLW4VMoxBFxpSKJZngR9XimpCF1ddRJmKXNNG0aKE2a2qStHfFrkpESalydz0XhXvduVUTV36NwVz2gTuI4pulg48U36S0370MqJbzJoCcKqxyVS0rJCuUovFokDD2NYyDkNtLIgs+g1YJGO9RltD2kh4lgmotgAiS5FeQI7XM+3/EQmxJXivjJ55WD48jmuwzEoNlcHcihz+fh10c8RM/DR5sZqTX86NfzjKnvWIFBOLxteMioXLCKdYURzFw2uNMhUpD+pxiNSBWXEdLFqaLOw4wb/S4In+HOCKCm9WpGLKni5/QlF79EwWs8BjDECelzy99c2sdx/9by1jcUUow53JprKT7DGIE4UWdq2dToTDZ+oOnqU16IvAZrNDtMYDufq6VZund2TwuFv+XSSJPoWJoE4en0Zx9STyM1r2a2sR1E2bzxd7f+gtvr+LPb57tKz9v1IA6lTMXElImwWGqpl6lkXCaTUTPZHpWJZFSmsxpChENo5+14HTFsoCr2uXPvYaPoHi2XCZAhTKNaLB5Dy9rc5Y8pEFEgwmNoo6E2NX80gRaGUbzGhadpYleynxQoUCCiSIzFkuTiGR55q6ARJjHqzfGLv37XAkQ869YdcQ06nCOeBJlMU89suB7b3ksaxE6D4KEJIUYT7J4QdW432szWnQ4axGRQLZW1jRORqngcB3RMC9JPjTYej1fFRhFJqqJ5fj7GS4qSqhP1qnkoBVVPZ4BHUDry2JFH1aOq2MgSF43esmWffOpfvyVf+sJVJFpGYivaX4EkhaFe0BgxbSjGqFHFlkFEsqECdUJS1yep4FTIUqWVKWJlLh0d4pJ0itVog+sIYCea5Q332N3YM1uM+d7f7dX2GQuhGKGKkmeHO60IAkF0fw0L8wkx+/2mDZGueKtSsUbyhELYC5MIPpK+40/uueCxm2sjVw6zwWwMI7J8eJ+Bp+WevYhC3uYSzfpmNu62fBuUUWby50Y2VZNHEs3cxxQN0XHnk0kIHSuvNDv/1pieoVpwRKNDFq6KIlkMUdtNH5xi5hOzevDinc3v3LGPze60yusqPW7gtEE57Z9jek7woRfZoEie/CdB29P90xkN+OjKqBfHorxYX+YyvyFPplgM3quJSlMArBr+3QUwDEDIzGNXPkvn2SGzPfWS+ltQd7VLzc0k2e3snt3TdzDdZ+4c9QC+WDDJE5ZW2scVX+xXlP8Rby3hdhT+10AEe6yyzsCI10QH5qy5PO6dI7RxFLFiEDOW3kwzuV0dBfoL5/hKvIBWnvuWfPuad8Kk+SC3XmIzmU2ag62rNNW6VuNTtL90urbn4oDhVizhhqKx9M+mvUuAg6xfDyMjv/Mh/G054gI4kXrKPhc4NeQ1WZIdZml0DBxDgcjE1Gt1HavVWGl7iR0cNW9Qf8VeKckgCozrHgZlPg0SFK+ZOnqiXjIBrx6TR3JDdjmvDBGDSB7yyy0lzZs6O6afsZZiGbbtmuE//uNb8qUvXikHdjegXEbKZTRWzPxezOQe3MJetJWKuj4k8iKuoZT6hbaFeRVqgAVxrQScDzZP5gCvYQAsh6y1zIV/J0BmDzUOKkH1fD5YNfWwyCC37aD92RvglY+Cpx8HB5wQ2zzJ4yUkLwCnv/Zi7UyIkZZce6HdtrnXHL0q9d6JmDxNbRTFWRMZdMGLgCuHGWZjXv7yJH6wxJmex7UEnHoTEq7GRUrU9Ad/dWk6vFlRWQv+eqAU9UYOiw851s6ARO2kfBsymQE8qfSNFSKDL59RvO8MESOfuYe4SIhq/sAN2xs/eeEveMWOwz/Tzxsbp4F9a3unDhjhxEyZOwg+r0V1IhN3VK+eBSgsGiziTByKxr2gJlzsmicbFI9Y69tp74M64R8Mo3mEYk9jQBvtT8rt45/N/vH467mXfzINeXwmj2l8j0ngY/KtxvN0Yfl86jjAYgiWV0a0mj+w1zPifapDcwJ4TzwxRmrZpOyo/x930Ue+BqFgufqXdy+qn7Pym/RGZ9PAYbD5LSFIqAGqRLKj8eXilsY7m3+xYG/Y5LCV//7sP7Cs+nZqZHn+PJyDFgUjaZo94vE/eAQEUFMjmT+0xrnTuZBXHrNHXT6SSSgT2wptv5dto+OyeuUSTVM4beUxfJlNWmK+WCpMsJWqORc0oubb4lQ0ooIt9tNqTUgkVfV42igpndIlj1dExMzFy4LuOcQIcdEyMZPxX5/5Pv/88W+ze3sNKgvVDhbw6kUrVcySHo3nW3FpA1nUI7p/XKU4T6EGvoWPB4iycXoXLmIC6Afdf7ARBmWqBCFzTuYidt6HCy3zwQJsAS0XTKOOjZWZ0EPsgCUG2bQV3XAzLOiH794Bp8yDgQFoeck7Xg7FAJ38RndjTRCYrMX4tyty9KpM8YILCqoGcBZvQfueA6vetRaTnIePLoesv3T0+Ui5t+3JVCUKHyYUN9b9+LcBXQPRwnx3Ipk3pATvUg77DoyGlGuDVAEG5fQXGunpaYX65YggYqqKj0Dqfmr3Jv3Whbfzpn0XofEScCOgsF5gvZ7HZbbts4Ui+XkX8kmqoCLQIpvlro+3AepU0eSw2J7OXb6dE9RrLFYT6QPmxrz9TqwNcbrsHfM/Pvc7AX6pMZuwnI7jrLxY/PB72PsOLrEn9Z7kxC6klruZ5JHCGDQhvZ7VGYBJteoyIM1viB1xtYDJUt08+Xz904U/C6P+11t+QFR/thwwn5v9iK/2fJU03+6hsEpGHzE76hv0pT0vb4Z9s1yP4SxJ9Zd/9w+Uj30zka3g8lcIh25fjfwzrP+dj97vxBEXwFaGZnJoEocHXO72zl3jQBZuOFK2Q7jUcevOvfri409jZhbOWHaiFApN1Fc0Ngul7nfSkFmsGaLhGyoyQK2dUuk5kVrr5wpGVSBDxYkJnlmoBgR8+M41dPgUSlZrDfjWd6/k//2/b3HjdduFqE9t/3ycKK7cAwLmqJVaPtFoeXGLZiuVpFBQ3V/HLDxV/LYbFFMAKenAoIiumE/Dw5CBybvHw9Vu4jD4JHU6p1DqyacWhKs0IyQ/IMQAMw7Nkl9g4Ia74FuboHcgjPhsCWy4Bf74XGiih52siodM7q8T5J6sAX85MJ1s/WqpeOI7jFStoip5GlpQcYqzpu+EZ5Y/9ZgfNp909cK57FHvBQ7I1Odv7hWIUmqupnu/A8HNPsgCAUi8W+wNZILK3I0JBGNEE6wrzADE0rcmC6tD5x9m7qc3QjytOz98eyOI36cP6yoJjOjlwIUyYfM4pmjukzm8WAyJdjJNYKbHM9JFofQjtDV3di18SodKCUxUOdqhwqqHQQA7hENmWZ9vM4he+Dzv2j3Prux/tJbj1Wo5C2tPVuEoV4z6EWAGzS20vCQAaPu5um+faCHEMvPhG50KvV4i2df6Ti5+MZIfv3WqqIr/9NRdTCt4CdZfJ6xisIxlbW6beDeqwnosYd0ah6qwduMEjztmO1VWkc2N+yDUrTmYbj18dZO/A0dcAB1GJQq38nz6sHhQJ8jcnFAJl44I9JlFFIm56fbt1J8G7cxzzLzlHLO8X+7eVtNSdKw2/BaZ0puoFh/DjP5MhEXazGoS62L6+k5keuZuEZkvignuFoBBvSNfP8gRFa20UvSyS2+Rj33k63r5JbcpVMX2LsZbERcVlP5+iGMxCwYonT2PFSertKtOsrQXt3MarUSqi/tFr/qVmL6jVH2kS1YtlbRSJMs8JvEc2DIG1ovaouIE0iS4WZDH+fJEiISpKNRb4W+phjt8qso8K9y4Fb57q2pvv87FEqoluG0afno7PP1kOJhvJ6+Ni7LsAYuhO4SOC5VfpnLT0wpbby5L72MyzVzeoJH7gqkvaMk6s/h5wNWrIDuKV5eclM5rKmTqgvsr3kca27abvP3K9A82gcpGxJ+XZ4Fb2iwmEmKj+SAbVD1GjHjSpomLe8kgUXOKVSTFG8iNEFUUGyVaS2bslu+CypL7rJ3SCXYNG0cUJXM3Xh/CHYI6gVS02XnF0IFrXSs5JfOdm0cnBhhiWaGHsw0Z5skg/8apvz6s8JBQwqCKvKi69O7dK5IFg8/Rnuj5GtvVLrbziQ/bpwyYIkW8xRjJ90/nRLB9mAudGUOLIIyHV4qnIFr8ma5Tw2X3SgmKaPzPkz5LJMSV6cSVvVI0Vpq6SzdfvQ1ZqaCHjr0RRXG8IPHEBHdcCFe6GDDO41sPX+3k78ARz8Ck+QDK7DCx62QLOy2rHlCxmgF9soSqVNmydT+3Te7HFA0lD899zNk6q7ukGB0nhiFms1+CLVOI+jWjBlFVZxozFKuPoVJdRpLNghgNq256vHci4oliixor1924Q//ozR/W4Rf9vV5+yTZs32IxA324uKxaHVAWL0fmLxEGFmrP80/llEerHHf2CdJXVXqXD2FmxrDHn4pJxpTdtypLzoLafll6/qnMAFFkaNw5IQd21SBS1UJPXl7hFZeLXjZXAqNzU6M7eYvMh2bafitsuhu+uwl6ewTxMpcZdqr0V+EHO5W9M1Axod7nIRYbnBfCldrWqa+F70W9w5GRSYYnU2dSVUQrF8JF8QjiV5Rf/WiksjIh8w6VDCeZeu+Alp/6PuDPO+QAAeCMiTMBl1dOZBoqmjOBRFO3s7mpsXrJpyrORPMSDdZbqAxQsjxllGh969Uzn9gORh9o3ZDVg8NlZ2wpT+IeVtkSRuJ7E+0DGB5We8z0gVkS3Y+DkDWDez0MdRQfP4OnXdfPMP5hK4cZDkMYeOvuk+Sjs//RXr74Zj9Y+RctFC4gtfOZwTFGm3FaTJPSBJSYNBe3FkoboZXvt/OHZoA74rkMcScb3CmMrCXTjIif61YAODWvPy0USmT58+ay4UbJQNsuZePaTpqtY5+HKOF5GuFM6R5Z5yS8jtS0TNH8Xky/OWICeFn+M82ctlxejuBDrK8jek7D7LhMw7/bCr1mCT3xIPW0KT+8eTPlfpiYhQsf9RSZ3++05WJK8Sk4nWQ2uZZy+YmiZg9qYsHETNVm6F3wZPoGl4DuF6cplXJMpWLRKNKbbtnDO//803rhs/6Kr331BnHRPDH9g7ioiC/2wsCQsHCpUBxA40Fd9LrHcObJCU981rn09URaXboAW2+i5QHiM08WvfkSES2I9hynvUMzVJ9zNuOZpwTsu2KnJk3FiBOKA6H6O9PgEoRHKIVJXShkToB2M5xYTRy9Apvugh9ugmoFvAtpAa9BDrwLqQRn4OuboZwf9I7b8uuTwHNcznoPyqi97usNPZg4JUrVa6aqqXoynGn5tvem/9Qn9g6fBSpG51+gUpbEJy4lI9NMM5xt+Vmt6bb/hkNZ5g7OiA1lNkqqoeTJqQYhpE2Lu5xM9s3LkP5D15+SqJMERwo0Scfg8mxdbh3ek/UC0GyW+jO0LxVI8blf6Uhx4WacNaYAfjVLdDkjmdRm7zChLkvnSjkOCYahTqZSWGiWHP1aRJSLrv/dPal1atgojndN/wlHLbpOyz2v06YdYJSMURwzZNQxQBFLiZSY6bQpo8lmam6WBKFBiK0180dN98xtv20LNOnU84W++lDqg2+5B7xFaoMlCuS1fXL41HLJJC/GOvwF+c8n7OwlpX+unOjwiecJrdj0BwFcz8NnQf8WHHELsOHSkNw0ef0f96zJchJs6UxCHNBKxIA9iiJWf3L1zTLhM2mmjnnFQV665gImkzupFlZjZQmzrZ/gtU6ldCKq25SoH2cjJmcalOefz9DSs9i2bat8+UvfYtOtW3n3uz8rz3vuX/KZf7tcGkk/tncBEsX4uCpUBqDSD6YXmgUtrFrByjcfxROOmpCnnrOavoEBegYG6C8WqG/bS++znoGp7SX7xcXIqc9THR+Xo5+zmtkF/TS9p+jgrm9shkLuh5XmQ9I6ZPWlXkhza3CuMwSwsQBInzg27/b8aFNKpaxz8UKdc9TyWKEq1Ti4wldshyETrAEPmXmw7tqIX4ea22cvuqMl49eoFCQl9Rn5/9SRkjqoivELnwWiKn1PT1RJSSXTTFJN1Wtk2kxvbWVfvAGEjay9x4XmpTgvfO+ZZHnRe4ojU0+Gulm2OoczTnPLTzt/6zzA66HxVw+Eeil6fMGp5uWUPsRz87BqosEdS28LGzK12iWkcugE7UyBOXTxG2p4KtW/4im/WMSnz0o579LfXgSHN1hGxPPOqX9kYd/HaEU9HCSliZIQ6vcskSQOOdi6lu2z67nt4DO55eBJ+o4vr5aW7spvmPcU7EbWnjsGiemdc4EP/ywtMEmWx00vO7RPt4Zj4epZNRctvUcdYbhYQ/eMP8wCDiO0wFGmpZW5bqfDX9eiXZ6YmAs7PJIc8RhgU1PvDGShNkXzIns5XPwOdXGFfy+yq6iYa9i2e7/+9I5N+qxjzmT3ZMYrz3kxP7z+F7prT12qpXOYaX6Hmdrn6Bv4MzI3KanfhRROwGmD0ekavQOrtVRdKq+66PNErk67LQrzMIWqepy41IGxYFRJFeIC9oSllM9dwsAZRV3W1zZLVj+RdrmY18ZF7L3iV9r3ggsli8tM/uXboboSnb+a/r3XcdRb3sYB5yUqRFr/+TZ23bgfqcb4uKrEfaEuTzqBKYVQmKN4r6RZcFXqPgYwt97wLb0r/VPfM1REW6A+zRdSyU8+CUF7JAhoT0H53u3C8QuEQlVpECzEB8llYVCqr2X7vhJFxz7J47QzQSLE90Ls1GnPuSt586Cn9Oi21vCkkjc3O8Salk5+dzMbk/PQ6PJ8sfFOFthpsiwzkPgk5BzC51AVJw6pj7K1vVjUpbjM4CLNQ3yd2QR5nqIHlBHuz5JYD6wXkW9rarwYvHrN6z/zSKBqhPMh21yt3uoBSgdv+Z7rW/ohH1eKJF6xJrQXdnowQgeG9+XSAlau+ir86bO4/PwmF2nMp8l+c2ucCuddZlmzxrMZYaM4c9Hu1/qh/ncwSYr3FmOiuUrOCpbx1nej+uT69MNLr7/Hpo66tETL9SJRp3YsxAFbYJrOhSO2LpJ6NqA2CtafzmV0BQPSNkEoT11z3/1Oc2uxzaH4YqckKKFjxR1ech9oVQ3JYVN0Dvu7pD4rbt4cdu3hSyH9VhxxAUy986mEJEi4hBAHmh2WBPESymM0Lyjvs8tZEB/PbHsTn/3eJfLkPztd01SIG1be8ZI/0rf8vw9oQU6RUvFcWu1LqM3+J6WhN6lr/FRcugUpnoJYz3StJsXyEvpOfJ1Ito+edEJatQnNkmbeKFGBYg8MzIfl87Enz8eeWFY7v0yycLGMHreQWwVWAP0793Dbj3+s2bOfY/pXLmPLK99Bess2zFP/Wv2dmzl5/fMYW9xHo53p0dZwx0d/gfcGSWrKopNCZYnLk2Mh+t+p2Q6usJg8/+cSAHflk97Owi/9zPjSK0XMs7wZKucBqjREwzQf0p4f2NgIDQvfug1eeRbMEoT9QXJ5Pii1qZu+V9KVLav9xRCYzN9EscosKqWTh0qvep2n1OtoePAmpErEep2kle79FtzX/SV891FwqbNQBigqYaprAafZNFyf1pt7ZnsrSc3iSy48j3C0VBwtFSkdf1Tlg4t3NDaO5jnkOStzFbdGmzktKUa3HoVWbUrqwriJPPEu+SvEjgEs2HyqZ1jt9EbZHi/cc7HMqzxXEpOpJSLi0EyaUM5hmSWlp+88ecW6H+jEG17NpyXUIIZ5fOYeMbUOlxFm6l1OxuUAKqy6tEfLA+9lBk+SJzQApDN2q/YNPtz7wjR88pBxBdiMktxY0rZU4bB9Mwgx+CQXNk412vIFCtyzENrkVX1ZbsndY1J4TiqlOctR8gkuShgMm7jwulMPl7H1wAgUjKWdF9bmgxs6+XRNcaVf7XvE2+DgiArgZQDU2olPfHBxHYcyvhm52+sPJbickI+jgJXxEzmQ3cXWXWPybz/7Ma95/LO4e2+iJyw9US56/lr9xMYvMdD3ODwtTdo/R2c+T3Heq0laN5KlN0H0KExcJckS2jMOW1lE1HuU2gURUawQeyhatGw16y3iFvTg+nrx9BOVemmnlvpBtDWEjP3sKsz+PRqtfbFEvT26823vk/oXv4U570/U757mqAuPQl77NEYbGYOVCPf9u7jr4h3IYAF1IgwcD61mbvV5PTSJQRSvSuogiiU0xmahumvdpZaR87/p4ZuF+e8/UXTFS72WX6Sm51Eq5ZCa9JqCF4wJAxWqRdg8Kty4G05aTjSV6oOvPQhu8EhLdj6qeu7PjMx/RuZbmQiRqlEjitPUK7IAWfxXLeoqYSFwVL0KZZO6g7vG3BevDe7v8H1OeIe3KQkZaZhIFlaFVsGTaLMGsJV3zQ7pi/YVdP78TDIVTK7wIko7i2VB73xz/qt38Nh/OA+N4FIDsIY1fgRJlrO8HJmBD3g1mpEd5i8rXoVIPFDfO3eObhwFINq/6e9ccfA53pRDosobybtxBZv7zpaIGTKt9p8n88vXyNqxv/c7rvwKI3KAB0o9CVSefeni1tLVz9F67TT9ivypPXHbk5ypLgvTXsTSqSLK57ZFu6c/lKkKa2+NEUlAHX98Z4GNJ7a5aP8apDBEg7DmqhIqJWOQhplQgMcvt7TF0uBQp0Fn+xm4BlNh5+6rgMZFvb4jgIfnemKgld23rLpD2RZIjJnbq8Oy6uJ8+8y7rsjuesAXHzkeAQuw2Uw8ZBGStZG8rE28HsoM56uH5VNhhERTBuxRDEXH0/S36Ve/ewmPPvFkWdJ/DFvHEp51zrNkV+OAfvt7l0nP4LkiNtZ243K8m6K0+P9gJSOpXY9niUr1aDFRCe+FdpoJRhSJhagKpgi2JERl0F4lrkJUkmwGvE812ns7U7tu0eaqY6X6qmG05WTs1X9N8z+/jlnzZvxsrwyePK0LP/QGOdB0ijUyOJPKL9/1A/WlItIah6VnKFIRkvqholLVYPb6oII4PD6f3541guW0eVRhg4VhTcbkDuA9wPvtvM89CQovF1N6njdD870I+MTh1eGcoVSCH9zpZf4iqMb5GXx/t/r7EtxgfEv3b4hY8QyHy00GpFNOpGBE7ZAn8YRVntWhPqIqzkz86ABfrA+j9r7DU0G9KaemRaopczYPqJKQkHYExGe+dXNk/WlOnRe8QcKgfBTrdcaJHPs3p1dv2Hl5Xb7S2fblwAmVrz+6ah/7z8j8x7Z1xqlgc9svNzYNGW3aWj8sHrXWMay2uVGurfTe+i9+/qr/61ISVWIsIgbV0G8BnjAua4ZU48Iircz7CMc+7a/lhPo1uNYN0k7HiKNpfBajvs8X+44Wax/dinSVr5TnUdPLAFypcny+tKbmJSTMHQ0HGBumTK/TYF2OiOfjtIsv3HJsuzL4MZoojk4THHk/CL5ppwDoKRRI8+6W7LDOIIuQpjAxFVzZ+2nr8y03f84C7GQMlLy3N7+f3no/jmzb9hKbiCy/aZi8xMsacDK1kY1ubtL1I8gRE8DNl48qwP7W/p0rkxSiWLJQ+isuv/4702CUMBPUY9QTBhOk6uS44lP1QHoXaar6wf/8nLzvbW9X6/tk+8GU4We9RmylzDe+9hMqA4+jFPXRmvkRjV1/TWnRKyksuoC0fSfaugni+UhxAZh5qlEBiUqoLeYCWARicBm0p2FiF2bvHjXpbo1WLBRe+ALSlSVmLr6e1jvfR+v23ZgL3oY/IAytPMiKz71V9kcFskYqC/tjtv7JfzN++5jKgipKBZm3Cm3lFQCd3uOO4ufrpuNduNumHmr1cJddNXyYe7fOwBoD52du/DWXApdWFrzjr5Nk1fOw/a/EVM5R02tVfRhI1Ypic8Uk0bzmQ7AAO24wTHDV9yO/bNYy0OM11UPKLeSDI8K6VoRfe1QyZqXtx74BsPFegrsxt468SCXVBBfG+YGKhqaYFKfp3IXRlj3fsbrs5U5TyTvBcqE0AimicbVojvnyGdUdb3U6da3Hq6V6upjyuVbmx6mfTRUfhoBqCD4LglcTIg5MZ/faQc+w2urGtX+Zrf6Hs3XgmMf6xCdYIgyINWFwZUQ+IxBL5j0t44kr8zTi2RQrz9Yi91ztL/+qNcUzg6OluwBITWfqiuYi1smsKiK4uPhn8LFXMyLBpT1vQ49Z/rjnJ/2L/x5fWEbSkbzD3s8ALZ0BYP5gSVIpBYfDhI9vgAhEnY9r0+4BTbm2752bBHO4JdcGnLTv8/xOZ0yr2U+5GrLHggniaZQISHxwne8vdniEOWICuIpbFeCO8Ut2H9d3djJYXhA769WFYQg4PTQKC/LYoHZigcEKLJmFHFd6Kptb35HxfaLv/+yn5U/+6K2kEzHb9mVc8PSXEC8c4huf/xpej6G86PWaTP2I5r5PYmYuJVr+YmThE1A3hfdjaHuX+ESUYh/EDmnE6GxR6SkjM02YAfqrKseeAKc9SVpHWWHTzZi3/BvZ9y+BpaeqPPXt4rfvYehMy8JP/ZkeLJbENVMW9sf4j/2Cu//9OpXF80QbB1WOeSaaRYJLJTR8hYpH1IQEgyI4UZJM6I2R1PkoqXdSdIcx4vN+TSEfQ9UYXbsf+BTwqfLQP5/tbM9rNOq/0EfVefSWZ83eTV9v3br3V6DCxgdbGZi7wQ3ZN1B8+s9KZt5zHKkTFXPIkTxkU4EXEVWlYNt+dP9UcuPPwrPu7f6avLIi7Y9I8aSiYY3UvEsnw5PkF5eaidY7vhtVF+80snhFpk1v8iUEc5NZFOedWrXSf3Yk888O3nSG05pP3UzmpRmBdWhkNS8FlxCQMqoOIWoAXM5ofjGKsnGdjvK1Ws+WM56TnvTKi13PijN8SlvIIo0Oa1g2hAWtjBEES4anlY9RMPkzwnPzHI8XxHgiirTSDMCOT93li/NFPTZ0OEvH2rK0US0OvoRX/J8zSV95PUbmEVdO9pXCyk4WF4MlnyIR1rDKLcHaeHjP+mxFW1rJF3QK39xcPFOVtPXAItTKzFzGWA678wXBfuBavplWhQpB1A2dgQhBcerNcErfI3b4yHDEBHCEEZ+v8LX9MfXX3DVQXHAKMT7NsB3h64QnlLxHWLw4QguUx5D4piyLnshYvEsPJjez9fYxPvbvn+T1b/wjmI65fUfC6Y96us579zF883P/xr67MykOvkAtO0inriTZ8n6kcjRm0XmYeaciPfNVygJxhi+kEBukFIv296kM9IgO9UO1im9NIv/9RfSq78C1N5EVh5CzX4FWToadm3X5q0+i8M4Xm4MZaD2lbyBGP3s9m//828iChWj9ICw4Ha0sg1YNTIFgQmiI+5GXtPg8OOMyT6Enptnen2797s78AN7fSaqESSwEk3G9hfWuOSHXANfMm/fcP58tDi8tNTaNzux++0R43qse0veWu8Hq/Pg3nFn2HK+ZSl7rKiBeQ3tcftUpql4kso6Zi0cZqd2P+zt3ETltl4QERzbnXYUOoBQvrgGwGuz1fLg+IE97R9Ev2OBVvZIiWAlL+IKKCHhxzGRBQAUk84ZS7LWetbj7w2VWvdWTWQ3Gajj0RsAnqOrE/ZyxHtTUajLas2X/M/TYt37V9h93fuZE8S7DGpsvZg3iQ8NNvrQrkmc/O7ZqZ5gCACYkAzKcJK6mgNtyyc9NdWirVoaOIVNH1LnBKIiEkEhcOJFK4cRO5pBZ2sQUJWkcUIkyosLS0FMuMicr9WY47u2sSNsXwv3WB3WV4I6qkCSmUy6z/r6HwdniXAlLZ7uSl8RkMvWAJ47GhblCa5MLs3iIDJrdj+X4CHFEY4BruMwC2a7arT+cF5+2aqDH+KztrfdmzgM8zALEoRoyw4qXEOZItckJxefS9NPg9+nWm/fJJz/5EV785jdh+/tly4GEvkXH6wv/9n1y1cUbufUH15LM9mAWvBxjRtHp63Db/wu3LYHiEpHBlcrAMugZgkoRyhYOivi0pUzuEjmwVTiwG028Mv941ce+Sigdi05OycC8nfR+6kWk55zMzIxTBPoHYuQT17D5bV9VHZgHrVFDdbEyeCY0ZsIF49K5UfzhEjks7pMnRqTcrzK94zqd+PgMw2rZ+JuWWZQ8cjACqIGNMj6+dpbxb29JINSabfwNSy/eD7kbrFl09w8yWViDallDxZKgwaUM6apgBIrgDU3UTnwHYGNejHx/O+xDD4hzmvowASuMtspIcWJrAMeCP5YNdmPtWRuPL3/3/eVo9V85V8eRpGHCq+SDGgRy+xOMN1Isek1J5OY3ZC32ail6p9d64vH28NoL1bZr+1pwFXMv5R67yDpTq42McvPHn9az6sp3Uz7hHb68oE89qMsyMV4RRGw+wyG4oHnPrA+WoTE+hDvCNGkEoYw1SS18qfve1LBTq/6S4hO/6jGGxGd0GttEmRs9FdZT9IClQlFmZ/YWR297aWvRGZ8HPN50em4dipC6IDRhcGJoT+u0WxqjxBjxMtXX9jPTACPrNZw/h+G9huGo3mNw4dAZT4yTdjJ5n5Pp4GXhGRIXfae4U1SwGqQ7QmjJ5K8/644cR1QAOzGlXdnF/9o7e+JbjranR5VKQWs1J96FobedK9Tjg1ucJ0bv+XvhlPJauanxJZw9oDtvG5d///sPcsH/fbn2HruK8YMebRlOf/4fsuhpT5Xbfvw99v18E8lUGSoXIEPPQPwomuyExn50epeSzeYrJSlijIotoJVBtG+5csoapWcZ4gtIVtPKgnHp++Mzsc85h9nYkBxMMIMFigKtv/02o393MQwthrQOhUFl4ROD5SfkJo7mRlPH3jWHZClzKuUK4lUY3fwFYO6kevB0YoUqnYkov1lAH4gRP8wGu7G5du+x5e9dUWDlM51OW8l1J0/7cqg6rxilur8+XvjFJTQB1rv7XFQocHyM2qEwPjuzohFhemNmRSqIT+b2dyNr/TBqNzbl3cdWvzEa64l/E0nfUEaKamhsC6agQSghEpH4/Ttauultu5uv+ubxxStfh5aNSrMoxCHQJiFSCIo3E/eNMhz2+cNxtL62+Zz39i3/8FeaQ0//v9bOfwGl+StV4vDVdaKInTjZXEw0X/A5DOKxRkHaU4mrN65lesePAWH1dVF65VkbzDnXLZD+4z5EcaCknWD4IafTItgwU01hZuyHuuP6N7d6F9VFzTFhaO9c3V0eD7ShFa5QKiGVOBevQ33AAmQUp5PGfUOAmzvZLlmkggVj517j8+0n6f3cTNeEH04GCXN0LJ0hREqEBVrh5na/yZMjzBHOAucXU7L2zoXFcz5qJub9xbxqfzJYHozrLfCZx6uZK4IOi1T6kBhRJYwoFXEalu4+ufIyvb35VRLuprEXvrLuo5z+h09j1QXPpakl9u51uL5FHPXq19E/PMGB666Rxi9vpnn3GL5egPhktHgGFApQiIJuGK9qLYhRrBHRBNGUqKem0erFEj/jfCmdfRK1GFoHnUYlL6WFBbhtVOr/94vauuROZd5iSCahuAAWPBHa7eDmmig31FTngmcC+WS6kD3QxMvgqZGM3X2Xu+nz35mbFvxb0RlsfW8BemjkKQxps/ffFNvvpdVEsRgR1VCzKGpU1HghLqVy4JqZmY9MhGTNvftzw9W8asHL49bswWsSnRlCNAvuszeKqJeJgtr9v6Q9l0DR4Ear2VqXjy4tvffrZR7/Bq+V5xiJjvVoBUWMmhkkuw1f+/ZY6z3/Mc0Vk6CmHX2jlqn8QiVpqkgBn8uLGiMmTYvleIpZgPuxgA4dRxhWO7NR7mI3bxvicX+bnPTeZyTFBU9Dqo/RQu9ygx1Sa2IRaxCfu8rqVHQU1xgVad0cZ7PX2NrOn9c2r90896Vef1bKOjV+RD5ROfW/rmgvXP02Xxh8Mo7lGBOFzLDLQHca2r+Ikv1fal961sUAPOOq42ntvIyatZL3xWDEi7FxlLZ3h9rBlpPa1ivV5QMLrABGsbHFNg9ib79vbqwTJ26Pb+fg7NVkvo21uZJ5R8NWJB0L4ZnNh3kVC8O/fXu8xmR2jTRaDVUJi+wgXpJiUWsTN97ndY8Qj4QCyzpURlhaenrl364tuhWnVivFZEnl+Nh7q40UnPPiVNXlbU8uTGcWT+gT9XjN8syhF8PO5EccTK8GqtT8FINHl/W0P7yQyuOfLFPWMjrtNS0a0iEkLUFjepz21l34vTvQyTH1Yyk0vBgSJYpRW0XmRdiFVvSoJUTHH61y7FLcggJZG2g6MUVLNAiliQT51CXMfOiHZBMpDA0q7VmkshQGz0ZVwhK2YjR4ayJ5PZXOWX8hpylkbZWho1PTs6DI7u8/393xsm/lruvvxeSM3w822ENxT6hU/mhx5AarRUo0242ZGh8YfaDnPjysMwyvl3tb1IODF/U3/AlDOrC8pOVSBZ+lpjHVkGx72tr/w1G4vnGPzYTV5OQeN4h7hDqWl4sr/3yx9i0tJib1zNzVZvvf7KUzHktVkPXSGV7a5bfjETJB1xl4jz+98NqTFtkXXNZu9y8mSpOlfcdFfXYZ4iLJl8rQ1KekOLyGRvnwMyOTTJx6HJ6CqTLmr9Ptze+IF0hdqgkTDJy+lIUvfjr+cefQrPZQm0ZaLUgjcBXQCkghOAwSIZJX+2soJBWiMGOAZijuoGgwA0hcgXj3LPLNq7T96Z9IsmUMKgsg8kpaR3pOhL7TVNWFQH24+2kImIvM1f4JCja3/lqe/qO87T+mYPZ/74Pp7S/6i98/8XsoU08eTH3Xb9reA21jnTmPNeZynpLdN6Spch6X2c4iTw/uvX6bWjQVhjEcRPiZzeZKmh7wLQy82FkOXiZcvsbf1zKe265hmPsI7BzDYZTYPf6uD/DZDq+xe6Dn3Pt599mdX/e6fMn7+/9jnnC5/z/9dsf84ecR9MHDWgVHFV5yyhJ57n/FLHtUPZtykY19JZpve6N5EttehRKqof/Ga5gV4NRrJk6cejINsWFremjaUdnZ/rafSm5DpEA7a4sypcWlg1p+0hkSnf1E8aeuotkbpvQ4l4evDo+JRIQq9wJKEaEnDMIzipqxaeHmLfDDX+Iv3oQ7OKnYQaHao2QNgVil5xQoLETxIBEQGYxRxPo8Xp+vRCH5cL1MEJvRtzyW6jwxYz/7pNvy4rfk1sBDTlr8/x+dOCcEF/aRurDm4q2H/a7z799mvw7fXmc7I52gcZeHiUc0CDnMsN3IRgf0nVb66N9H2eKLjO+1LT9LJkmq4lTCBGcBL511gRwZTtJ7rNzmyMSYsmKMtrID2va7JLM1UbGapakqEwLeFJbOU3PyMcqJJworVmq6YKHQ34f2WSiZcDNMFZ1x0JwQ9uxH7t6pbNqJbtmBTsygFIWoqpQKkKVhJ+IFQvk4Deqpii2ARGFZTDG5CxyFBdA7sTkBSkMxlZUYd2DSTP/ir7Idb/nXvNq/e7J36fI/zCOehem4w6AMRS89e5BT3lpiwbMNg/2KJYwwcvg8BRIWtnT5QCTPIRFUMmnhcRhTQFFSZnFM5qtKJ3jvUd8ZlhbGrwoFRSK0kIlEEZAPbWxbhURCRQEKRcVUIc7bydSDFBTTK8QLwfble2IUW8wTHhHonABCFBtsBWwFojLGgkhrlGTsq+6uL/0TbNzWFb8uXY4cvwcCCIActrwi5fLpy4eyNedbP+/xiBwvWlnmlF6vrqBY8XijokZxonPBZCXTBCcun/cRCsMQvNc2jobx2hQvLQOZqFijikDbqPedUg5DXoovFtF86ThsrKgVoRMcLIW2OVMFW0YlLN+JKQASgok2zn8fhxIIYxRbmFWRGRG3Fdq3ROnoNYX9//yjOtvCoty/dzG/Ll3+v83viwDmrDPDnCob75u5s0CRzkLB9BtYZMFLtVoR6mWhCvV6nSqglCW0pwLU89aAklAeENXY0KqLYq2SWqjbpKASRrKqQAG0ZUjVhP+Og3ubegOlUAYQmfAzA0iEqI9QW1BUaOevifN8XQRx5GNj21ExHW9O/Ockh9bECgyrZeN67Wb0unTpQnCL10XnsS5aNze64v9LqAkThNdFDy2z2qVLl4eT/y0X38Oxn7/DNtYd9u/Nv+V2VuUxvW4mr0uXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26dOnSpUuXLl26/H7x/wPfFrFlocpGxAAAAABJRU5ErkJggg==';

  // ---------- Estado ----------
  let videoEl = null;
  let playlist = [];
  let idxAtual = -1;
  let watchdog = null, ultimoTempo = -1;
  let wakeLock = null;
  let ativo = false;
  let autoSync = true, syncIntervalS = 60, syncTimer = null;
  let loopInfinito = false; try { loopInfinito = (localStorage.getItem('cv-loop') || '0') === '1'; } catch (e) {}
  try { autoSync = (localStorage.getItem('cv-autosync2') || '1') === '1'; } catch (e) {}
  try { syncIntervalS = parseInt(localStorage.getItem('cv-syncint') || '60', 10); } catch (e) {}

  const handedStreams = new Set();
  const nossasTracks = new WeakSet();

  const origGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  const origEnum = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);

  const FAKE_VIDEO_ID = 'a7c3f9e21b8d4a6c9e5f1d3b7a2c8e4f6d9b1a3c5e7f2d4b6a8c1e3f5d7b9a2c';
  const FAKE_AUDIO_ID = 'b2e8d4a6c1f7b3e9d5a1c7f3b9e5d2a8c4f1b7e3d9a5c2f8b4e1d7a3c9f5b2e8';
  const FAKE_GROUP_ID = 'c9f5b1e7d3a8c4f2b6e9d1a7c3f8b5e2d9a4c1f7b3e8d5a2c9f4b1e6d3a7c5f9';
  const FAKE_VIDEO_LABEL = 'HD Camera Virtual (1080p)';
  const FAKE_AUDIO_LABEL = 'Microfone Virtual (HD Camera)';

  function pedirId(c) {
    if (!c || typeof c !== 'object') return null;
    let d = c.deviceId;
    if (!d) return null;
    if (typeof d === 'string') return d;
    if (Array.isArray(d)) return d[0] || null;
    if (typeof d === 'object') {
      const v = d.exact !== undefined ? d.exact : d.ideal;
      return Array.isArray(v) ? v[0] : (v || null);
    }
    return null;
  }

  function trackAtual(kind) {
    if (!videoEl || !videoEl.__cvStream) return null;
    const list = kind === 'video' ? videoEl.__cvStream.getVideoTracks() : videoEl.__cvStream.getAudioTracks();
    return list[0] || null;
  }

  function novoClone(kind) {
    const t = trackAtual(kind);
    if (!t) return null;
    const c = t.clone();
    nossasTracks.add(c);
    return c;
  }

  // ---------- Mixer de áudio: efeitos + microfone (recurso de teste) ----------
  let actx = null, mixDest = null, gVideo = null, gFx = null, gMic = null, gMon = null, gMaster = null, gMonitor = null;
  let monOn = false; try { monOn = localStorage.getItem('cv-mon') === '1'; } catch (e) {}
  let vSrc = null, vSrcTrackId = null;
  let micStream = null, micSrc = null, micOn = false;
  let salaNode = null, salaOn = false;
  let fxVol = 0.2;
  let fxMon = false; try { fxMon = localStorage.getItem('cv-fxmon') === '1'; } catch (e) {}
  let audioSepEl = null, audioSepSrc = null, gAudioSep = null, gAudioSepMon = null, audioSepOn = false, audioSepReady = false, audioSepURL = null, audSepMon = false;
  try { audSepMon = localStorage.getItem('cv-audsepmon') === '1'; } catch (e) {}
  let audSepLoop = false; try { audSepLoop = localStorage.getItem('cv-audseploop') === '1'; } catch (e) {}
  let modoLeve = false; try { modoLeve = localStorage.getItem('cv-leve') === '1'; } catch (e) {}
  let fxAuto = false, fxAutoTimer = null, fxAutoIntervalS = 60, fxSeq = [], fxSeqI = 0;
  try { fxAutoIntervalS = parseInt(localStorage.getItem('cv-fxint') || '60', 10); } catch (e) {}

  function initMix() {
    if (actx) return;
    try {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      mixDest = actx.createMediaStreamDestination();
      gMaster = actx.createGain(); gMaster.gain.value = 1.0; gMaster.connect(mixDest);
      gMonitor = actx.createGain(); gMonitor.gain.value = monOn ? 1 : 0; try { gMaster.connect(gMonitor); gMonitor.connect(actx.destination); } catch (e) {}
      gVideo = actx.createGain(); gVideo.gain.value = 1.0; gVideo.connect(gMaster);
      gFx = actx.createGain(); gFx.gain.value = fxVol; gFx.connect(gMaster);
      gMic = actx.createGain(); gMic.gain.value = 1.0; gMic.connect(gMaster);
      gAudioSep = actx.createGain(); gAudioSep.gain.value = 0; gAudioSep.connect(gMaster);
    } catch (e) { actx = null; }
  }
  function resumeMix() { try { if (actx && actx.state === 'suspended') actx.resume(); } catch (e) {} }
  function conectarVideoNoMix() {
    initMix(); if (!actx) return;
    const t = trackAtual('audio'); if (!t) return;
    if (vSrcTrackId === t.id && vSrc) return;
    try { if (vSrc) vSrc.disconnect(); } catch (e) {}
    try { vSrc = actx.createMediaStreamSource(new MediaStream([t])); vSrc.connect(gVideo); vSrcTrackId = t.id; } catch (e) {}
  }
  // trilha de áudio final entregue à live (vídeo + efeitos + mic)
  function audioParaLive() {
    initMix();
    if (!actx || !mixDest) return novoClone('audio');
    conectarVideoNoMix(); resumeMix();
    const mt = mixDest.stream.getAudioTracks()[0];
    if (!mt) return novoClone('audio');
    const c = mt.clone(); nossasTracks.add(c); return c;
  }

  // -- geradores de som sintéticos --
  function bufRuido(dur) {
    const n = Math.max(1, Math.floor(actx.sampleRate * dur));
    const b = actx.createBuffer(1, n, actx.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < n; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; }
    return b;
  }
  function oneShot(dur, freq, q, vol, atk, dec) {
    if (!actx) return; resumeMix();
    try {
      const src = actx.createBufferSource(); src.buffer = bufRuido(dur);
      const f = actx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q || 1;
      const g = actx.createGain(); const t = actx.currentTime;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + (atk || 0.02));
      g.gain.exponentialRampToValueAtTime(0.0001, t + (atk || 0.02) + (dec || 0.2));
      src.connect(f); f.connect(g); g.connect(gFx);
      src.start(t); src.stop(t + dur + 0.05);
    } catch (e) {}
  }
  function fxRespiracao() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const src = actx.createBufferSource(); src.buffer = bufRuido(10.6);
      const f = actx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1050; f.Q.value = 0.5;
      const g = actx.createGain(); const t = actx.currentTime;
      g.gain.setValueAtTime(0.0001, t);
      let cur = t;
      for (let i = 0; i < 4; i++) {
        g.gain.linearRampToValueAtTime(0.9, cur + 1.0);    // inspira
        g.gain.linearRampToValueAtTime(0.08, cur + 2.4);   // expira até quase silêncio
        cur += 2.5;
      }
      g.gain.linearRampToValueAtTime(0.0001, cur);
      src.connect(f); f.connect(g); g.connect(gFx);
      src.start(t); src.stop(t + 10.6);
    } catch (e) {}
  }
  function fxTelefone() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const t0 = actx.currentTime;
      const master = actx.createGain(); master.gain.value = 0.0001; master.connect(gFx);
      const o1 = actx.createOscillator(); o1.type = 'sine'; o1.frequency.value = 440;
      const o2 = actx.createOscillator(); o2.type = 'sine'; o2.frequency.value = 480;
      const lfo = actx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 22;
      const lfoGain = actx.createGain(); lfoGain.gain.value = 0.5;
      const trem = actx.createGain(); trem.gain.value = 0.5;
      lfo.connect(lfoGain); lfoGain.connect(trem.gain);
      o1.connect(trem); o2.connect(trem); trem.connect(master);
      let cur = t0;
      for (let i = 0; i < 3; i++) {
        master.gain.setValueAtTime(0.0001, cur);
        master.gain.linearRampToValueAtTime(0.8, cur + 0.05);
        master.gain.setValueAtTime(0.8, cur + 1.3);
        master.gain.linearRampToValueAtTime(0.0001, cur + 1.45);
        cur += 3.3;
      }
      const stopT = cur + 0.1;
      o1.start(t0); o2.start(t0); lfo.start(t0);
      o1.stop(stopT); o2.stop(stopT); lfo.stop(stopT);
    } catch (e) {}
  }
  function fxClique() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const t0 = actx.currentTime;
      for (let i = 0; i < 2; i++) {
        const t = t0 + i * 0.11;
        const o = actx.createOscillator(); o.type = 'triangle';
        o.frequency.setValueAtTime(1900, t); o.frequency.exponentialRampToValueAtTime(950, t + 0.03);
        const g = actx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.9, t + 0.002);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
        o.connect(g); g.connect(gFx);
        o.start(t); o.stop(t + 0.07);
      }
    } catch (e) {}
  }
  function fxSalaBurst() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const src = actx.createBufferSource(); src.buffer = bufRuido(10.4);
      const f = actx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900;
      const g = actx.createGain(); const t = actx.currentTime;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.47, t + 0.6);
      g.gain.setValueAtTime(0.47, t + 9.2);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 10.0);
      src.connect(f); f.connect(g); g.connect(gFx);
      src.start(t); src.stop(t + 10.1);
    } catch (e) {}
  }
  function toggleSala() {
    initMix(); if (!actx) return false;
    if (salaOn) {
      try { if (salaNode) { salaNode.stop(); salaNode.disconnect(); } } catch (e) {}
      salaNode = null; salaOn = false;
    } else {
      resumeMix();
      try {
        const src = actx.createBufferSource(); src.buffer = bufRuido(2.2); src.loop = true;
        const f = actx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900;
        const g = actx.createGain(); g.gain.value = 0.5;
        src.connect(f); f.connect(g); g.connect(gFx);
        src.start(); salaNode = src; salaOn = true;
      } catch (e) {}
    }
    return salaOn;
  }
  async function toggleMic() {
    initMix(); if (!actx) return micOn;
    if (micOn) {
      try { if (micSrc) micSrc.disconnect(); } catch (e) {}
      if (micStream) micStream.getTracks().forEach(t => t.stop());
      micStream = null; micSrc = null; micOn = false;
      try { gVideo.gain.setTargetAtTime(audioSepOn ? 0 : 1.0, actx.currentTime, 0.15); } catch (e) {}
    } else {
      try { micStream = await origGUM({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
      catch (e) { return micOn; }
      resumeMix();
      try { micSrc = actx.createMediaStreamSource(micStream); micSrc.connect(gMic); } catch (e) {}
      micOn = true;
      try { gVideo.gain.setTargetAtTime(audioSepOn ? 0 : 0.15, actx.currentTime, 0.15); } catch (e) {}
    }
    return micOn;
  }
  function aplicarAudioSep() {
    initMix(); if (!actx || !gVideo || !gAudioSep) return;
    if (audioSepOn && audioSepReady && audioSepEl) {
      if (!audioSepSrc) { try { audioSepSrc = actx.createMediaElementSource(audioSepEl); audioSepSrc.connect(gAudioSep); } catch (e) {} }
      resumeMix();
      gAudioSep.gain.value = 1;
      try { gVideo.gain.value = 0; } catch (e) {}
      audioSepEl.loop = audSepLoop; try { audioSepEl.play().catch(() => {}); } catch (e) {}
    } else {
      if (gAudioSep) gAudioSep.gain.value = 0;
      if (audioSepEl) { try { audioSepEl.pause(); } catch (e) {} }
      try { gVideo.gain.value = micOn ? 0.15 : 1.0; } catch (e) {}
    }
  }

  // ---------- getUserMedia ----------
  navigator.mediaDevices.getUserMedia = async function (constraints) {
    if (!ativo) return origGUM(constraints);
    const s = new MediaStream();
    let usouFake = false;
    if (constraints && constraints.video) {
      const id = pedirId(constraints.video);
      const ct = (!id || id === FAKE_VIDEO_ID) ? novoClone('video') : null;
      if (ct) { s.addTrack(ct); usouFake = true; }
      else { try { (await origGUM({ video: constraints.video })).getVideoTracks().forEach(t => s.addTrack(t)); } catch (e) {} }
    }
    if (constraints && constraints.audio) {
      const id = pedirId(constraints.audio);
      const ct = (!id || id === FAKE_AUDIO_ID) ? audioParaLive() : null;
      if (ct) { s.addTrack(ct); usouFake = true; }
      else {
        if (id === FAKE_AUDIO_ID) status('⚠️ Esse vídeo não tem trilha de áudio.');
        try { (await origGUM({ audio: constraints.audio })).getAudioTracks().forEach(t => s.addTrack(t)); } catch (e) {}
      }
    }
    if (usouFake) { handedStreams.add(s); status('🔴 No ar! Transmitindo o vídeo.'); }
    return s;
  };

  navigator.mediaDevices.enumerateDevices = async function () {
    const devices = await origEnum();
    if (!ativo) return devices;
    const mk = (id, kind, label) => ({
      deviceId: id, groupId: FAKE_GROUP_ID, kind, label,
      toJSON() { return { deviceId: id, groupId: FAKE_GROUP_ID, kind, label }; }
    });
    const extras = [mk(FAKE_VIDEO_ID, 'videoinput', FAKE_VIDEO_LABEL)];
    if (trackAtual('audio')) extras.push(mk(FAKE_AUDIO_ID, 'audioinput', FAKE_AUDIO_LABEL));
    return [...extras, ...devices];
  };

  function atualizarConsumidores() {
    for (const s of handedStreams) {
      for (const kind of ['video', 'audio']) {
        const olds = kind === 'video' ? s.getVideoTracks() : s.getAudioTracks();
        const mortas = olds.filter(t => nossasTracks.has(t) && t.readyState === 'ended');
        if (mortas.length) {
          mortas.forEach(t => s.removeTrack(t));
          const nt = novoClone(kind);
          if (nt) s.addTrack(nt);
        }
      }
    }
  }

  function recapturar() {
    try { videoEl.__cvStream = videoEl.captureStream(modoLeve ? 24 : 30); atualizarConsumidores(); conectarVideoNoMix(); } catch (e) {}
  }

  // ---------- Sincronizar áudio/vídeo ----------
  function ressincronizar(manual) {
    if (!videoEl || !videoEl.src || !videoEl.duration) return;
    const t = videoEl.currentTime;
    try { videoEl.currentTime = Math.min(videoEl.duration - 0.05, t + 0.06); } catch (e) {}
    if (videoEl.paused) videoEl.play().catch(() => {});
    if (manual) status('🔁 Áudio sincronizado.');
  }

  function reprogramarSync() {
    if (syncTimer) { clearInterval(syncTimer); syncTimer = null; }
    if (autoSync && syncIntervalS > 0) {
      syncTimer = setInterval(() => {
        if (ativo && videoEl && !videoEl.paused && videoEl.src) ressincronizar(false);
      }, syncIntervalS * 1000);
    }
  }

  setInterval(() => {
    if (!ativo || !videoEl || !videoEl.__cvStream || videoEl.paused) return;
    const at = videoEl.__cvStream.getAudioTracks()[0];
    if (at && at.readyState === 'ended') { recapturar(); status('🔊 Áudio reconectado.'); }
  }, 2000);

  // ---------- Playlist ----------
  async function addArquivos(files) {
    for (const f of files) {
      status('⏳ Carregando o vídeo…');
      let url;
      try {
        const buf = await f.arrayBuffer();
        url = URL.createObjectURL(new Blob([buf], { type: f.type || 'video/mp4' }));
      } catch (e) { url = URL.createObjectURL(f); }
      playlist.push({ url, nome: f.name });
    }
    renderPlaylist();
    if (idxAtual === -1 && playlist.length) tocar(0);
  }

  async function tocar(i) {
    if (!playlist[i]) return;
    idxAtual = i;
    videoEl.src = playlist[i].url;
    videoEl.load();
    try {
      await videoEl.play();
    } catch (e) {
      videoEl.muted = true; atualizarAudioBtn();
      try { await videoEl.play(); } catch (e2) { status('❌ Erro ao tocar o vídeo.'); return; }
    }
    videoEl.__cvStream = videoEl.captureStream(modoLeve ? 24 : 30);
    conectarVideoNoMix();
    ativo = true;
    atualizarConsumidores();
    iniciarVigia();
    pedirWakeLock();
    try { navigator.mediaDevices.dispatchEvent(new Event('devicechange')); } catch (e) {}
    renderPlaylist();
    atualizarEstado();
    status('Vídeo pronto para transmitir');
  }

  function ligar() {
    if (playlist.length) tocar(idxAtual >= 0 ? idxAtual : 0);
    else { status('Adicione um vídeo primeiro.'); $('cv-arquivo').click(); }
  }

  function proximo() {
    if (!playlist.length) return;
    const ehUltimo = idxAtual >= playlist.length - 1;
    if (ehUltimo && !loopInfinito) { atualizarToggle(); atualizarEstado(); return; }
    if (playlist.length === 1) { videoEl.currentTime = 0; videoEl.play().catch(() => {}); return; }
    tocar((idxAtual + 1) % playlist.length);
  }

  function pular(seg) {
    if (!videoEl || !videoEl.src || !videoEl.duration) return;
    videoEl.currentTime = Math.min(videoEl.duration, Math.max(0, videoEl.currentTime + seg));
    if (videoEl.paused) videoEl.play().catch(() => {});
  }

  function removerItem(i) {
    URL.revokeObjectURL(playlist[i].url);
    playlist.splice(i, 1);
    if (i === idxAtual) {
      idxAtual = -1;
      if (playlist.length) tocar(Math.min(i, playlist.length - 1));
      else desligar();
    } else if (i < idxAtual) idxAtual--;
    renderPlaylist();
  }

  // ---------- Vigia de reprodução ----------
  function iniciarVigia() {
    if (watchdog) return;
    watchdog = setInterval(() => {
      if (!ativo || !videoEl || !videoEl.src) return;
      if (videoEl.paused || videoEl.ended) return;
      if (videoEl.currentTime === ultimoTempo) { try { videoEl.play().catch(() => {}); } catch (e) {} }
      ultimoTempo = videoEl.currentTime;
    }, 3000);
  }

  async function pedirWakeLock() {
    try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
  }
  document.addEventListener('visibilitychange', () => {
    if (ativo && document.visibilityState === 'visible') {
      pedirWakeLock();
      if (videoEl && videoEl.paused && videoEl.src) videoEl.play().catch(() => {});
    }
  });

  function desligar() {
    ativo = false;
    if (micOn) { try { if (micSrc) micSrc.disconnect(); } catch (e) {} if (micStream) micStream.getTracks().forEach(t => t.stop()); micStream = null; micSrc = null; micOn = false; try { if (gVideo && actx) gVideo.gain.setTargetAtTime(1.0, actx.currentTime, 0.1); } catch (e) {} const mb = document.getElementById('cv-mic'); if (mb) { mb.innerHTML = IC.micOff + ' Abrir microfone (falar)'; mb.style.borderColor = '#3d477a'; mb.style.color = '#e2e8ff'; mb.style.background = '#1c2340'; } }
    if (salaOn) { try { if (salaNode) { salaNode.stop(); salaNode.disconnect(); } } catch (e) {} salaNode = null; salaOn = false; const sb = document.getElementById('cv-sala'); if (sb) { sb.style.borderColor = '#3d477a'; sb.style.color = '#e2e8ff'; sb.style.background = '#1c2340'; } }
    if (fxAuto || fxAutoTimer) { if (fxAutoTimer) { clearTimeout(fxAutoTimer); fxAutoTimer = null; } fxAuto = false; const ab = document.getElementById('cv-auto'); if (ab) { ab.style.borderColor = '#3d477a'; } const asw = document.getElementById('cv-auto-sw'); if (asw) { asw.textContent = 'OFF'; asw.style.background = '#232c58'; asw.style.color = '#8791bd'; } }
    if (audioSepOn) { audioSepOn = false; if (gAudioSep) gAudioSep.gain.value = 0; if (audioSepEl) { try { audioSepEl.pause(); } catch (e) {} } try { if (gVideo && actx) gVideo.gain.value = 1.0; } catch (e) {} const asw2 = document.getElementById('cv-audsep-sw'); if (asw2) { asw2.textContent = 'OFF'; asw2.style.background = '#232c58'; asw2.style.color = '#8791bd'; } const asc = document.getElementById('cv-audsep-card'); if (asc) asc.style.borderColor = '#263056'; }
    if (videoEl) { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); videoEl.__cvStream = null; }
    if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
    atualizarEstado(); atualizarToggle();
    status('Câmera virtual desligada. Clique no ⏻ verde para ligar de novo.');
    renderPlaylist();
  }

  // ---------- Interface ----------
  const $ = (id) => document.getElementById(id);
  const POS_PADRAO = { top: '72px', right: '16px' };

  function criarUI() {
    if ($('cv-painel')) return;
    const painel = document.createElement('div');
    painel.id = 'cv-painel';
    painel.style.cssText = [
      'position:fixed', 'top:' + POS_PADRAO.top, 'right:' + POS_PADRAO.right, 'z-index:2147483000',
      'background:#0b0e1c', 'color:#fff', 'border:1px solid rgba(124,140,255,.18)', 'border-radius:18px',
      'font:13px/1.4 Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif',
      'box-shadow:0 18px 50px rgba(0,0,0,.65)', 'width:320px', 'max-height:min(660px,84vh)', 'overflow-y:auto', 'overflow-x:hidden', 'scrollbar-width:none', 'user-select:none'
    ].join(';');

    painel.innerHTML = `
      <div id="cv-header" style="position:sticky;top:0;z-index:6;display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:#0b0e1c;cursor:grab;gap:6px;">
        <img src="${LOGO_URI}" alt="VidCam" style="height:38px;max-width:112px;object-fit:contain;pointer-events:none;flex:0 0 auto;" />
        <div style="display:flex;align-items:center;gap:6px;flex:0 0 auto;">
          <span id="cv-estado" title="Status da câmera virtual" style="display:flex;align-items:center;gap:5px;font-size:11px;font-weight:600;padding:3px 8px;border-radius:999px;border:1px solid #3a4160;background:#141a2e;color:#9aa;">
            <span id="cv-dot" style="width:8px;height:8px;border-radius:50%;background:#777;display:inline-block;"></span><span id="cv-estado-txt">Inativa</span>
          </span>
          <button id="cv-cfg" title="Configurações" data-tip="Minha assinatura / configurações" style="width:30px;height:30px;border:1px solid #2b3350;border-radius:9px;background:#141a2e;color:#c3cbe8;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;flex:none;">${IC.gear}</button>
          <button id="cv-power" title="Ligar/desligar câmera virtual" data-tip="Ligar/desligar câmera" style="width:30px;height:30px;border:1px solid #2b3350;border-radius:9px;background:#141a2e;color:#c3cbe8;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;flex:none;">${IC.power}</button>
          <button id="cv-min" title="Minimizar" data-tip="Esconder" style="width:30px;height:30px;border:1px solid #2b3350;border-radius:9px;background:#141a2e;color:#c3cbe8;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;flex:none;">${IC.min}</button>
        </div>
      </div>
      <div id="cv-corpo" style="padding:14px;">
        <div id="cv-config" style="display:none;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
            <button id="cv-voltar-cfg" title="Voltar" style="width:30px;height:30px;border:1px solid #2b3350;border-radius:9px;background:#141a2e;color:#c3cbe8;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;">${IC.back}</button>
            <strong style="font-size:15px;display:flex;align-items:center;gap:8px;color:#eef1ff;"><span class="cv-ic">${IC.gear}</span>Configurações</strong>
          </div>
          <div style="background:#11162b;border:1px solid #263056;border-radius:12px;padding:12px;font-size:12px;line-height:1.7;margin-bottom:10px;">
            <div><span style="color:#8791bd;">Status:</span> <b style="color:#7ee2a6;">● Ativa</b></div>
            <div style="margin-top:8px;"><span style="color:#8791bd;">E-mail de compra:</span><br><b style="word-break:break-all;color:#e2e8ff;">${ASSINATURA.email || 'não informado'}</b></div>
            <div style="margin-top:8px;"><span style="color:#8791bd;">Chave:</span><br><b style="font-family:monospace;color:#8fe3c0;word-break:break-all;">${ASSINATURA.key || '—'}</b></div>
            <div style="margin-top:8px;"><span style="color:#8791bd;">Vence em:</span> <b style="color:#12b6ff;">${fmtData(ASSINATURA.exp)}</b></div>
          </div>
          <div style="color:#7ee2a6;font-size:10px;margin-bottom:12px;text-align:center;">Renova automaticamente enquanto a assinatura estiver ativa.</div>
          <div style="text-align:center;color:#5a6390;font-size:11px;margin-top:14px;">VidCam · versão ${VERSAO}</div>
        </div>

        <div id="cv-main">
        <video id="cv-preview" playsinline muted autoplay preload="auto" style="width:100%;max-height:180px;border-radius:12px;background:#05070f;border:1px solid #1b2140;display:block;object-fit:contain;"></video>
        <div id="cv-vazio" style="text-align:center;color:#8791bd;font-size:12px;margin-top:8px;">Adicione um vídeo para começar</div>

        <div id="cv-extra">
          <div id="cv-barra" style="height:8px;background:#1b2140;border-radius:4px;margin:12px 0 4px;cursor:pointer;position:relative;">
            <div id="cv-buf" style="height:100%;width:0%;background:#263056;border-radius:4px;position:absolute;top:0;left:0;pointer-events:none;"></div>
            <div id="cv-prog" style="height:100%;width:0%;background:linear-gradient(90deg,#7b2ff7,#12b6ff);border-radius:4px;position:absolute;top:0;left:0;pointer-events:none;"></div>
            <div id="cv-tip" style="display:none;position:absolute;bottom:16px;transform:translateX(-50%);background:#05070f;color:#fff;font-size:11px;padding:2px 6px;border-radius:6px;white-space:nowrap;pointer-events:none;box-shadow:0 2px 6px rgba(0,0,0,.5);">0:00</div>
          </div>
          <div style="display:flex;justify-content:space-between;color:#8791bd;font-size:11px;">
            <span id="cv-tempo">0:00</span><span id="cv-dur">0:00</span>
          </div>

          <div style="display:flex;gap:6px;margin-top:8px;align-items:stretch;">
            <button id="cv-voltar" class="cv-sec" style="flex:1;" title="Voltar">${IC.rewind}</button>
            <select id="cv-seg" title="Quantos segundos pular" style="flex:0 0 auto;min-width:66px;text-align:center;background:#1c2340;color:#fff;border:1.5px solid #3d477a;border-radius:10px;padding:0 6px;font-size:12px;cursor:pointer;">
              <option value="5">5s</option>
              <option value="10" selected>10s</option>
              <option value="15">15s</option>
              <option value="30">30s</option>
              <option value="60">60s</option>
            </select>
            <button id="cv-avancar" class="cv-sec" style="flex:1;" title="Avançar">${IC.forward}</button>
          </div>

          <button id="cv-toggle" style="width:100%;margin-top:10px;padding:12px;border:0;border-radius:11px;background:linear-gradient(90deg,#7b2ff7,#12b6ff);color:#fff;font-weight:700;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">${IC.play} Iniciar</button>
          <button id="cv-restart" class="cv-sec" style="width:100%;margin-top:8px;">${IC.restart} Reiniciar vídeo do início</button>
          <button id="cv-loop" class="cv-sec" style="width:100%;margin-top:8px;justify-content:space-between;"><span style="display:flex;align-items:center;gap:8px;">${IC.infinito} Loop infinito</span><span id="cv-loop-sw" style="font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span></button>

          <button id="cv-ouvir" class="cv-audio" style="width:100%;margin-top:8px;padding:10px;border:1px solid #263056;border-radius:12px;background:#11162b;color:#ccc;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:8px;">
            <span style="display:flex;align-items:center;gap:8px;"><span id="cv-ouvir-ic" style="display:inline-flex;align-items:center;color:#8791bd;">${IC.volOff}</span><span style="text-align:left;line-height:1.2;">Ouvir áudio no PC<br><span style="font-size:10px;color:#8791bd;">o que está saindo na live</span></span></span>
            <span id="cv-ouvir-sw" style="font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span>
          </button>

          <div id="cv-audsep-card" style="margin-top:8px;border:1px solid #263056;border-radius:12px;background:#11162b;padding:10px;">
            <div id="cv-audsep" style="display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;"><span style="display:flex;align-items:center;gap:8px;text-align:left;">${IC.volOn}<span style="line-height:1.2;">Usar áudio separado<br><span id="cv-audsep-nome" style="font-size:10px;color:#8791bd;font-weight:400;">nenhum áudio carregado</span></span></span><span id="cv-audsep-sw" style="font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span></div>
            <div style="display:flex;gap:6px;margin-top:10px;">
              <button id="cv-audsep-add" class="cv-sec" style="flex:1;">${IC.plus} Adicionar áudio</button>
              <button id="cv-audsep-del" class="cv-sec" style="flex:0 0 auto;width:44px;font-size:14px;" title="Remover áudio">✕</button>
            </div>
            <div id="cv-audsep-loop" style="display:flex;align-items:center;justify-content:center;gap:7px;margin-top:8px;cursor:pointer;font-size:11px;color:#8791bd;font-weight:600;"><span style="display:inline-flex;align-items:center;">${IC.infinito}</span>Loop de áudio<span id="cv-audsep-loop-sw" style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span></div>
            <input id="cv-audsep-file" type="file" accept="audio/*" style="display:none;">
          </div>

          <div id="cv-synccard" style="margin-top:8px;border:1px solid #263056;border-radius:12px;background:#11162b;padding:10px;">
            <div id="cv-autosync" style="display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;"><span style="display:flex;align-items:center;gap:8px;text-align:left;">${IC.sync}<span style="line-height:1.2;">Sincronizar áudio<br><span style="font-size:10px;color:#8791bd;font-weight:400;">só ligue se a voz descolar</span></span></span><span id="cv-autosync-sw" style="font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span></div>
            <div id="cv-syncrow" style="display:flex;align-items:center;gap:8px;margin-top:10px;">
              <span style="font-size:11px;color:#8791bd;white-space:nowrap;">A cada</span>
              <input id="cv-syncint" type="number" min="5" step="5" style="width:52px;background:#1c2340;color:#fff;border:1.5px solid #3d477a;border-radius:9px;padding:5px;font-size:12px;text-align:center;">
              <span style="color:#8791bd;font-size:11px;">seg</span>
              <button id="cv-sync" style="margin-left:auto;display:flex;align-items:center;gap:5px;padding:6px 11px;border:1.5px solid #3d477a;border-radius:9px;background:#1c2340;color:#e2e8ff;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;">${IC.sync} Forçar</button>
            </div>
          </div>

          <div style="margin-top:10px;border:1px solid #263056;border-radius:12px;background:#11162b;padding:10px;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;color:#eef1ff;font-weight:600;font-size:12px;"><span class="cv-ic">${IC.fx}</span>Efeitos & Microfone</div>
            <button id="cv-mic" class="cv-sec" style="width:100%;">${IC.micOff} Abrir microfone (falar)</button>
            <div style="display:flex;align-items:center;gap:8px;margin-top:8px;">
              <span style="font-size:11px;color:#8791bd;white-space:nowrap;">Volume FX</span>
              <input id="cv-fxvol" type="range" min="0" max="100" value="20" style="flex:1;accent-color:#7b2ff7;cursor:pointer;">
              <span id="cv-fxval" style="font-size:11px;color:#8791bd;width:36px;text-align:right;">20%</span>
            </div>
            <div style="display:flex;gap:6px;margin-top:8px;">
              <button id="cv-sala" class="cv-sec" style="flex:1;">Ruído de sala</button>
              <button id="cv-resp" class="cv-sec" style="flex:1;">Respiração</button>
            </div>
            <div style="display:flex;gap:6px;margin-top:6px;">
              <button id="cv-micvar" class="cv-sec" style="flex:1;">Telefone</button>
              <button id="cv-clique" class="cv-sec" style="flex:1;">Cliques</button>
            </div>
            <div style="display:flex;align-items:stretch;gap:6px;margin-top:8px;">
              <button id="cv-auto" class="cv-sec" style="flex:1;justify-content:space-between;"><span style="display:flex;align-items:center;gap:8px;">${IC.sync} Automático</span><span id="cv-auto-sw" style="font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span></button>
              <select id="cv-fxint" title="A cada quanto tempo dispara um efeito" style="flex:0 0 auto;background:#1c2340;color:#fff;border:1.5px solid #3d477a;border-radius:10px;padding:0 6px;font-size:12px;cursor:pointer;">
                <option value="30">30s</option>
                <option value="60" selected>1 min</option>
                <option value="120">2 min</option>
                <option value="180">3 min</option>
                <option value="300">5 min</option>
              </select>
            </div>
            <div style="color:#8791bd;font-size:10px;margin-top:6px;line-height:1.4;">No automático: dispara ruído de sala, respiração, cliques e telefone em tempos aleatórios — cada som toca e para sozinho.</div>
          </div>

          <div id="cv-leve-card" style="margin-top:10px;border:1px solid #263056;border-radius:12px;background:#11162b;padding:10px;">
            <div id="cv-leve" style="display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;"><span style="display:flex;align-items:center;gap:8px;text-align:left;">${IC.fx}<span style="line-height:1.2;">Modo leve<br><span style="font-size:10px;color:#8791bd;font-weight:400;">24fps — mais leve p/ PC fraco. Ligue antes de iniciar.</span></span></span><span id="cv-leve-sw" style="font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;background:#232c58;color:#8791bd;">OFF</span></div>
          </div>

          <button id="cv-add" style="width:100%;margin-top:10px;padding:11px;border:0;border-radius:11px;background:linear-gradient(90deg,#7b2ff7,#12b6ff);color:#fff;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">${IC.plus} Adicionar vídeo(s)…</button>
          <input id="cv-arquivo" type="file" accept="video/*" multiple style="display:none;">
          <div id="cv-lista" style="max-height:110px;overflow-y:auto;margin-top:8px;"></div>
          <div id="cv-status" style="margin-top:10px;color:#8791bd;white-space:pre-wrap;font-size:12px;">Nenhum vídeo carregado.</div>
        </div>
        </div>
      </div>`;

    const st = document.createElement('style');
    st.textContent = '.cv-sec{display:flex;align-items:center;justify-content:center;gap:8px;padding:10px;border:1.5px solid #3d477a;border-radius:10px;background:#1c2340;color:#e2e8ff;cursor:pointer;font-size:12px;font-weight:600}.cv-sec:hover{border-color:#6c8cff;color:#fff}.cv-ic{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:8px;background:#1a2040;color:#8ea2ff;flex:none}#cv-min:hover,#cv-cfg:hover,#cv-voltar-cfg:hover{background:#1c2340}.cv-audio:hover{border-color:#3d477a}#cv-lista::-webkit-scrollbar{width:6px}#cv-lista::-webkit-scrollbar-thumb{background:#2b3350;border-radius:3px}#cv-painel::-webkit-scrollbar{width:0;height:0;display:none}[data-tip]{position:relative}[data-tip]:hover::after{content:attr(data-tip);position:absolute;top:calc(100% + 7px);right:0;background:#05070f;color:#e2e8ff;font-size:11px;font-weight:500;padding:5px 9px;border-radius:8px;white-space:nowrap;box-shadow:0 6px 18px rgba(0,0,0,.55);border:1px solid #263056;z-index:30;pointer-events:none}';
    painel.appendChild(st);
    document.documentElement.appendChild(painel);

    videoEl = $('cv-preview');
    videoEl.addEventListener('ended', proximo);
    videoEl.addEventListener('timeupdate', atualizarBarra);
    videoEl.addEventListener('progress', atualizarBuffer);
    videoEl.addEventListener('playing', () => { const v = $('cv-vazio'); if (v) v.style.display = 'none'; });
    videoEl.addEventListener('play', () => { atualizarToggle(); atualizarEstado(); });
    videoEl.addEventListener('pause', () => { atualizarToggle(); atualizarEstado(); });

    $('cv-syncint').value = String(syncIntervalS);

    try {
      const pos = JSON.parse(localStorage.getItem('cv-pos2') || 'null');
      if (pos) { painel.style.left = pos.left; painel.style.top = pos.top; painel.style.right = 'auto'; painel.style.bottom = 'auto'; }
    } catch (e) {}

    const header = $('cv-header');
    let drag = null;
    header.addEventListener('mousedown', (e) => {
      if (['cv-min', 'cv-power', 'cv-cfg'].includes(e.target.id)) return;
      const r = painel.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      header.style.cursor = 'grabbing'; e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!drag) return;
      let x = Math.min(Math.max(0, e.clientX - drag.dx), window.innerWidth - painel.offsetWidth);
      let y = Math.min(Math.max(0, e.clientY - drag.dy), window.innerHeight - 40);
      painel.style.left = x + 'px'; painel.style.top = y + 'px'; painel.style.right = 'auto'; painel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => {
      if (!drag) return; drag = null; header.style.cursor = 'grab';
      try { localStorage.setItem('cv-pos2', JSON.stringify({ left: painel.style.left, top: painel.style.top })); } catch (e) {}
    });

    $('cv-min').onclick = () => {
      const ex = $('cv-extra'), b = $('cv-min'), prev = $('cv-preview');
      const minimizando = ex.style.display !== 'none';
      ex.style.display = minimizando ? 'none' : '';
      prev.style.maxHeight = minimizando ? '80px' : '180px';
      b.textContent = minimizando ? '+' : '‒';
      b.title = minimizando ? 'Expandir' : 'Minimizar';
      b.setAttribute('data-tip', minimizando ? 'Expandir' : 'Esconder');
    };
    $('cv-power').onclick = () => { if (ativo) desligar(); else ligar(); };
    $('cv-cfg').onclick = () => { $('cv-config').style.display = 'block'; $('cv-main').style.display = 'none'; };
    $('cv-voltar-cfg').onclick = () => { $('cv-config').style.display = 'none'; $('cv-main').style.display = ''; };
    $('cv-add').onclick = () => $('cv-arquivo').click();
    $('cv-arquivo').onchange = (e) => { if (e.target.files.length) addArquivos(e.target.files); e.target.value = ''; };
    $('cv-toggle').onclick = () => {
      if (!videoEl.src) { ligar(); return; }
      if (videoEl.paused) videoEl.play().catch(() => {}); else videoEl.pause();
    };
    $('cv-restart').onclick = () => { if (videoEl.src) { videoEl.currentTime = 0; videoEl.play().catch(() => {}); } };
    $('cv-avancar').onclick = () => pular(parseInt($('cv-seg').value, 10));
    $('cv-voltar').onclick = () => pular(-parseInt($('cv-seg').value, 10));
    $('cv-sync').onclick = () => {
      const b = $('cv-sync'); if (!b) return;
      const temVideo = videoEl && videoEl.src && videoEl.duration;
      ressincronizar(true);
      if (b.__cvT) clearTimeout(b.__cvT);
      if (!b.__cvHtml) b.__cvHtml = b.innerHTML;
      b.innerHTML = IC.sync + (temVideo ? ' Sincronizado!' : ' Sem vídeo tocando');
      b.style.opacity = '0.85';
      b.__cvT = setTimeout(() => { b.innerHTML = b.__cvHtml; b.style.opacity = '1'; }, 1400);
    };
    $('cv-ouvir').onclick = () => { monOn = !monOn; initMix(); try { if (gMonitor) gMonitor.gain.value = monOn ? 1 : 0; } catch (x) {} try { localStorage.setItem('cv-mon', monOn ? '1' : '0'); } catch (x) {} atualizarAudioBtn(); };
    const _mic = $('cv-mic'); if (_mic) _mic.onclick = async () => {
      _mic.disabled = true;
      const on = await toggleMic();
      _mic.disabled = false;
      _mic.innerHTML = on ? IC.micOn + ' Falando… (clique p/ fechar)' : IC.micOff + ' Abrir microfone (falar)';
      _mic.style.borderColor = on ? '#6c8cff' : '#3d477a';
      _mic.style.color = on ? '#fff' : '#e2e8ff';
      _mic.style.background = on ? '#17233f' : '#1c2340';
    };
    const _mkFx = (id, fn) => { const b = $(id); if (b) b.onclick = () => { fn(); b.style.opacity = '0.55'; setTimeout(() => { b.style.opacity = '1'; }, 140); }; };
    _mkFx('cv-sala', fxSalaBurst);
    _mkFx('cv-resp', fxRespiracao);
    _mkFx('cv-micvar', fxTelefone);
    _mkFx('cv-clique', fxClique);
    const _fxv = $('cv-fxvol'); if (_fxv) _fxv.oninput = (e) => { const v = parseInt(e.target.value, 10) || 0; fxVol = v / 100; try { if (gFx) gFx.gain.value = fxVol; } catch (x) {} const l = $('cv-fxval'); if (l) l.textContent = v + '%'; };
    const _asAdd = $('cv-audsep-add'), _asFile = $('cv-audsep-file'), _asTog = $('cv-audsep');
    const pintaAS2 = () => { const sw = $('cv-audsep-sw'); if (sw) { sw.textContent = audioSepOn ? 'ON' : 'OFF'; sw.style.background = audioSepOn ? 'linear-gradient(90deg,#7b2ff7,#12b6ff)' : '#232c58'; sw.style.color = audioSepOn ? '#fff' : '#8791bd'; } const c = $('cv-audsep-card'); if (c) c.style.borderColor = audioSepOn ? '#6c8cff' : '#263056'; };
    if (_asAdd) _asAdd.onclick = () => { if (_asFile) _asFile.click(); };
    if (_asFile) _asFile.onchange = (e) => { const f = e.target.files && e.target.files[0]; if (!f) return; try { if (audioSepURL) URL.revokeObjectURL(audioSepURL); } catch (x) {} audioSepURL = URL.createObjectURL(f); if (!audioSepEl) audioSepEl = new Audio(); audioSepEl.src = audioSepURL; audioSepEl.loop = audSepLoop; audioSepEl.onended = () => { if (!audioSepEl.loop && audioSepOn) { audioSepOn = false; if (gAudioSep) gAudioSep.gain.value = 0; try { if (gVideo && actx) gVideo.gain.value = micOn ? 0.15 : 1.0; } catch (e) {} pintaAS2(); } }; audioSepReady = true; const nm = $('cv-audsep-nome'); if (nm) { nm.style.color = '#8fe3c0'; nm.textContent = f.name.length > 26 ? f.name.slice(0, 24) + '…' : f.name; } if (audioSepOn) aplicarAudioSep(); };
    if (_asTog) _asTog.onclick = () => { if (!audioSepReady) { const nm = $('cv-audsep-nome'); if (nm) { nm.style.color = '#fe5c5c'; nm.textContent = 'adicione um áudio primeiro'; setTimeout(() => { nm.style.color = '#8791bd'; nm.textContent = 'nenhum áudio carregado'; }, 1600); } return; } audioSepOn = !audioSepOn; aplicarAudioSep(); pintaAS2(); };
    pintaAS2();
    const _asDel = $('cv-audsep-del');
    if (_asDel) _asDel.onclick = () => { audioSepOn = false; audioSepReady = false; if (gAudioSep) gAudioSep.gain.value = 0; if (audioSepEl) { try { audioSepEl.pause(); audioSepEl.removeAttribute('src'); audioSepEl.load(); } catch (e) {} } try { if (audioSepURL) URL.revokeObjectURL(audioSepURL); } catch (x) {} audioSepURL = null; try { if (gVideo && actx) gVideo.gain.value = micOn ? 0.15 : 1.0; } catch (e) {} const nm = $('cv-audsep-nome'); if (nm) { nm.style.color = '#8791bd'; nm.textContent = 'nenhum áudio carregado'; } if (_asFile) _asFile.value = ''; pintaAS2(); };
    const _asLoop = $('cv-audsep-loop');
    const pintaLoopAS = () => { const sw = $('cv-audsep-loop-sw'); if (sw) { sw.textContent = audSepLoop ? 'ON' : 'OFF'; sw.style.background = audSepLoop ? 'linear-gradient(90deg,#7b2ff7,#12b6ff)' : '#232c58'; sw.style.color = audSepLoop ? '#fff' : '#8791bd'; } };
    if (_asLoop) _asLoop.onclick = () => { audSepLoop = !audSepLoop; if (audioSepEl) audioSepEl.loop = audSepLoop; try { localStorage.setItem('cv-audseploop', audSepLoop ? '1' : '0'); } catch (x) {} pintaLoopAS(); };
    pintaLoopAS();
    const _leve = $('cv-leve');
    const pintaLeve = () => { const sw = $('cv-leve-sw'); if (sw) { sw.textContent = modoLeve ? 'ON' : 'OFF'; sw.style.background = modoLeve ? 'linear-gradient(90deg,#7b2ff7,#12b6ff)' : '#232c58'; sw.style.color = modoLeve ? '#fff' : '#8791bd'; } const c = $('cv-leve-card'); if (c) c.style.borderColor = modoLeve ? '#6c8cff' : '#263056'; };
    if (_leve) _leve.onclick = () => { modoLeve = !modoLeve; try { localStorage.setItem('cv-leve', modoLeve ? '1' : '0'); } catch (x) {} pintaLeve(); };
    pintaLeve();
    const _auto = $('cv-auto'), _fxint = $('cv-fxint');
    const pintaAuto = () => { const sw = document.getElementById('cv-auto-sw'); if (sw) { sw.textContent = fxAuto ? 'ON' : 'OFF'; sw.style.background = fxAuto ? 'linear-gradient(90deg,#7b2ff7,#12b6ff)' : '#232c58'; sw.style.color = fxAuto ? '#fff' : '#8791bd'; } if (_auto) _auto.style.borderColor = fxAuto ? '#6c8cff' : '#3d477a'; };
    function proxAuto() {
      if (fxAutoTimer) { clearTimeout(fxAutoTimer); fxAutoTimer = null; }
      if (!fxAuto) return;
      const base = fxAutoIntervalS * 1000, jit = base * 0.4;
      const wait = Math.max(3000, base - jit + Math.random() * 2 * jit);
      fxAutoTimer = setTimeout(() => { const pool = [fxSalaBurst, fxRespiracao, fxTelefone, fxClique]; if (fxSeqI >= fxSeq.length) { fxSeq = pool.slice(); for (let i = fxSeq.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const tmp = fxSeq[i]; fxSeq[i] = fxSeq[j]; fxSeq[j] = tmp; } fxSeqI = 0; } fxSeq[fxSeqI++](); proxAuto(); }, wait);
    }
    if (_fxint) { _fxint.value = String(fxAutoIntervalS); _fxint.onchange = (e) => { fxAutoIntervalS = parseInt(e.target.value, 10) || 60; try { localStorage.setItem('cv-fxint', String(fxAutoIntervalS)); } catch (x) {} if (fxAuto) proxAuto(); }; }
    if (_auto) _auto.onclick = () => { fxAuto = !fxAuto; if (fxAuto) { fxSeq = []; fxSeqI = 0; proxAuto(); } else { if (fxAutoTimer) { clearTimeout(fxAutoTimer); fxAutoTimer = null; } } pintaAuto(); };
    pintaAuto();
    const _loop = $('cv-loop'); if (_loop) {
      const pintaLoop = () => { const sw = $('cv-loop-sw'); if (sw) { sw.textContent = loopInfinito ? 'ON' : 'OFF'; sw.style.background = loopInfinito ? 'linear-gradient(90deg,#7b2ff7,#12b6ff)' : '#232c58'; sw.style.color = loopInfinito ? '#fff' : '#8791bd'; } _loop.style.borderColor = loopInfinito ? '#6c8cff' : '#3d477a'; };
      pintaLoop();
      _loop.onclick = () => { loopInfinito = !loopInfinito; try { localStorage.setItem('cv-loop', loopInfinito ? '1' : '0'); } catch (x) {} pintaLoop(); };
    }
    const _as = $('cv-autosync');
    const pintaAS = () => { const sw = $('cv-autosync-sw'); if (sw) { sw.textContent = autoSync ? 'ON' : 'OFF'; sw.style.background = autoSync ? 'linear-gradient(90deg,#7b2ff7,#12b6ff)' : '#232c58'; sw.style.color = autoSync ? '#fff' : '#8791bd'; } const card = $('cv-synccard'); if (card) card.style.borderColor = autoSync ? '#6c8cff' : '#263056'; const row = $('cv-syncrow'); if (row) row.style.opacity = autoSync ? '1' : '0.55'; };
    if (_as) _as.onclick = () => { autoSync = !autoSync; try { localStorage.setItem('cv-autosync2', autoSync ? '1' : '0'); } catch (x) {} reprogramarSync(); pintaAS(); };
    pintaAS();
    const aplicarInt = (e) => {
      let v = parseInt(e.target.value, 10);
      if (!v || v < 5) v = 5;
      syncIntervalS = v; e.target.value = v;
      try { localStorage.setItem('cv-syncint', String(syncIntervalS)); } catch (x) {}
      reprogramarSync();
    };
    $('cv-syncint').onchange = aplicarInt;
    $('cv-syncint').onblur = aplicarInt;
    reprogramarSync();

    const barra = $('cv-barra');
    barra.onclick = (e) => {
      if (!videoEl.duration) return;
      const r = barra.getBoundingClientRect();
      videoEl.currentTime = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)) * videoEl.duration;
    };
    barra.onmousemove = (e) => {
      const tip = $('cv-tip'); if (!tip || !videoEl.duration) return;
      const r = barra.getBoundingClientRect();
      const ratio = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      tip.textContent = fmt(ratio * videoEl.duration);
      tip.style.left = (ratio * r.width) + 'px';
      tip.style.display = 'block';
    };
    barra.onmouseleave = () => { const tip = $('cv-tip'); if (tip) tip.style.display = 'none'; };

    atualizarToggle(); atualizarEstado(); atualizarAudioBtn();
  }

  function atualizarToggle() {
    const b = $('cv-toggle'); if (!b) return;
    const tocando = videoEl && !videoEl.paused && videoEl.src;
    if (tocando) { b.innerHTML = IC.pause + ' Pausar'; b.style.background = '#e6b800'; b.style.color = '#1a1a1a'; }
    else { b.innerHTML = IC.play + ' Iniciar'; b.style.background = 'linear-gradient(90deg,#7b2ff7,#12b6ff)'; b.style.color = '#fff'; }
  }

  function atualizarEstado() {
    const dot = $('cv-dot'), txt = $('cv-estado-txt'), pill = $('cv-estado'), pw = $('cv-power');
    if (!dot) return;
    const on = ativo && videoEl && videoEl.src && !videoEl.paused;
    const pausada = ativo && videoEl && videoEl.src && videoEl.paused;
    if (on) { dot.style.background = '#1db954'; txt.textContent = 'Ativa'; pill.style.color = '#7ee2a6'; }
    else if (pausada) { dot.style.background = '#f5a623'; txt.textContent = 'Pausada'; pill.style.color = '#f0c078'; }
    else { dot.style.background = '#777'; txt.textContent = 'Inativa'; pill.style.color = '#9aa'; }
    if (pw) {
      if (ativo) { pw.style.color = '#fff'; pw.style.background = '#7a1420'; pw.style.borderColor = '#e11d48'; pw.title = 'Desligar câmera virtual'; pw.setAttribute('data-tip', 'Desligar câmera'); }
      else { pw.style.color = '#fff'; pw.style.background = '#0f7a35'; pw.style.borderColor = '#1db954'; pw.title = 'Ligar câmera virtual'; pw.setAttribute('data-tip', 'Ligar câmera'); }
    }
  }

  function atualizarAudioBtn() {
    const ic = $('cv-ouvir-ic'), sw = $('cv-ouvir-sw'), btn = $('cv-ouvir');
    if (!ic) return;
    const ligado = monOn;
    if (ligado) {
      ic.innerHTML = IC.volOn; ic.style.color = '#fff';
      sw.textContent = 'ON'; sw.style.background = 'linear-gradient(90deg,#7b2ff7,#12b6ff)'; sw.style.color = '#fff';
      btn.style.borderColor = '#6c8cff'; btn.style.color = '#fff';
    } else {
      ic.innerHTML = IC.volOff; ic.style.color = '#8791bd';
      sw.textContent = 'OFF'; sw.style.background = '#232c58'; sw.style.color = '#8791bd';
      btn.style.borderColor = '#263056'; btn.style.color = '#ccc';
    }
  }

  function fmtData(ms) { if (!ms) return '—'; try { var d = new Date(ms); return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); } catch (e) { return '—'; } }

  function fmt(s) {
    if (!isFinite(s)) return '0:00';
    const m = Math.floor(s / 60), ss = Math.floor(s % 60);
    return m + ':' + String(ss).padStart(2, '0');
  }

  function atualizarBarra() {
    if (!videoEl || !videoEl.duration) return;
    $('cv-prog').style.width = (videoEl.currentTime / videoEl.duration * 100) + '%';
    $('cv-tempo').textContent = fmt(videoEl.currentTime);
    $('cv-dur').textContent = fmt(videoEl.duration);
  }

  function atualizarBuffer() {
    const buf = $('cv-buf');
    if (!buf || !videoEl || !videoEl.duration || !videoEl.buffered.length) return;
    const fim = videoEl.buffered.end(videoEl.buffered.length - 1);
    buf.style.width = (fim / videoEl.duration * 100) + '%';
  }

  function renderPlaylist() {
    const lista = $('cv-lista');
    if (!lista) return;
    lista.innerHTML = '';
    playlist.forEach((item, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:6px;padding:6px 8px;border-radius:8px;margin-top:4px;cursor:pointer;' +
        (i === idxAtual ? 'background:#2b1218;color:#ff6b8a;' : 'background:#1c1c1c;color:#ccc;');
      const nome = document.createElement('span');
      nome.textContent = (i === idxAtual ? '▶ ' : '') + 'Vídeo ' + (i + 1);
      nome.style.cssText = 'flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;';
      nome.onclick = () => tocar(i);
      const x = document.createElement('span');
      x.textContent = '✕'; x.style.cssText = 'color:#777;padding:0 2px;';
      x.onclick = (e) => { e.stopPropagation(); removerItem(i); };
      row.appendChild(nome); row.appendChild(x);
      lista.appendChild(row);
    });
  }

  function status(msg) { const el = $('cv-status'); if (el) el.textContent = msg; }

  // ---------- Só liga o painel quando o gate confirmar a licença ----------
  let iniciado = false;
  function iniciarPainel() {
    if (iniciado) return; iniciado = true;
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', criarUI);
    else criarUI();
  }
  window.addEventListener('message', function (e) {
    if (e && e.data && e.data.source === 'vidcam-gate' && e.data.licensed) { if (e.data.version) VERSAO = e.data.version; ASSINATURA = { email: e.data.email || '', key: e.data.key || '', exp: e.data.exp || 0 }; iniciarPainel(); }
  });
})();
