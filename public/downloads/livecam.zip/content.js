// Live Infinity - Content Script v9

(function () {
  'use strict';

  // ── GUARDA: verifica se o contexto da extensão ainda está vivo ──
  function ctxOk() {
    try { return !!chrome.runtime?.id; } catch(e) { return false; }
  }

  // Wrapper seguro para sendMessage — silencia o erro se contexto morreu
  function enviar(msg, cb) {
    if (!ctxOk()) return;
    try {
      chrome.runtime.sendMessage(msg, () => {
        if (chrome.runtime.lastError) {} // ignora erro silencioso
        if (cb) cb();
      });
    } catch(e) {}
  }

  let metricasInterval = null;
  let ultimaVenda = 0;
  let somAtivo = false;
  let audioCtx = null;
  let liveAtivaAntes = false;

  // ══════════════════════════════════════
  //  ESTILOS
  // ══════════════════════════════════════
  function injetarEstilos() {
    if (document.getElementById('sl-styles')) return;
    const s = document.createElement('style');
    s.id = 'sl-styles';
    s.textContent = `
      /* ── PUSH DA PÁGINA ── */
      #sl-push-style { }

      /* ── HUD PILLS ── */
      #sl-hud {
        position: fixed !important;
        bottom: 80px !important;
        left: 12px !important;
        z-index: 2147483647 !important;
        display: flex !important;
        flex-direction: column !important;
        align-items: flex-start !important;
        gap: 5px !important;
        pointer-events: none !important;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
      }
      .sl-pill {
        display: inline-flex !important;
        align-items: center !important;
        gap: 6px !important;
        background: rgba(10, 14, 26, 0.92) !important;
        border: 1px solid rgba(0,200,255,0.3) !important;
        border-radius: 20px !important;
        padding: 5px 12px 5px 8px !important;
        backdrop-filter: blur(10px) !important;
        box-shadow: 0 2px 12px rgba(0,0,0,0.5) !important;
        white-space: nowrap !important;
        pointer-events: none !important;
        animation: slIn .3s ease !important;
      }
      .sl-pill-dot {
        width: 7px !important; height: 7px !important;
        border-radius: 50% !important;
        background: #00e5ff !important;
        flex-shrink: 0 !important;
        animation: slBlink .9s infinite !important;
      }
      .sl-pill-txt {
        font-size: 12px !important;
        font-weight: 600 !important;
        color: #fff !important;
      }
      .sl-pill-val {
        font-size: 13px !important;
        font-weight: 800 !important;
        color: #00ff7f !important;
        margin-left: 3px !important;
      }

      /* ── POPUP LIVE ATIVA (igual ao do cara) ── */
      #sl-live-popup {
        position: fixed !important;
        bottom: 20px !important;
        left: 12px !important;
        transform: none !important;
        z-index: 2147483647 !important;
        background: rgba(8, 14, 28, 0.93) !important;
        border: 1px solid rgba(0,229,255,0.45) !important;
        border-radius: 24px !important;
        padding: 7px 12px 7px 10px !important;
        display: none !important;
        align-items: center !important;
        gap: 8px !important;
        backdrop-filter: blur(14px) !important;
        box-shadow: 0 4px 24px rgba(0,0,0,0.6) !important;
        font-family: -apple-system, sans-serif !important;
        white-space: nowrap !important;
        cursor: grab !important;
        user-select: none !important;
      }
      #sl-live-popup.show { display: flex !important; }
      #sl-live-popup.is-dragging { cursor: grabbing !important; opacity: 0.9 !important; }
      .sl-lp-dot {
        width: 7px !important; height: 7px !important;
        border-radius: 50% !important;
        background: #00e5ff !important;
        box-shadow: 0 0 6px #00e5ff !important;
        animation: slBlink .7s infinite !important;
        flex-shrink: 0 !important;
      }
      .sl-lp-main {
        font-size: 11px !important;
        font-weight: 700 !important;
        color: #00e5ff !important;
        letter-spacing: 0.3px !important;
      }
      .sl-lp-sep { width: 1px; height: 16px; background: rgba(255,255,255,0.12); flex-shrink: 0; margin: 0 1px; }
      .sl-lp-actions {
        display: flex !important;
        gap: 4px !important;
      }
      .sl-lp-btn {
        width: 26px !important; height: 26px !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 12px !important;
        cursor: pointer !important;
        pointer-events: auto !important;
        transition: all .15s !important;
        border: none !important;
        outline: none !important;
        background: rgba(0,220,110,0.15) !important;
      }
      .sl-lp-btn:hover { background: rgba(0,220,110,0.3) !important; transform: scale(1.1) !important; }
      .sl-lp-btn.red { background: rgba(255,50,80,0.2) !important; }
      .sl-lp-btn.red:hover { background: rgba(255,50,80,0.4) !important; }
      .sl-lp-btn.gray { background: rgba(150,150,150,0.12) !important; }

      /* ── STATUS PILL ── */
      #sl-status-pill {
        position: fixed !important;
        bottom: 20px !important;
        left: 12px !important;
        z-index: 2147483646 !important;
        display: none !important;
        align-items: center !important;
        gap: 6px !important;
        background: rgba(10,14,26,0.92) !important;
        border-radius: 20px !important;
        padding: 5px 12px 5px 8px !important;
        font-family: -apple-system, sans-serif !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        backdrop-filter: blur(10px) !important;
        animation: slIn .3s ease !important;
        white-space: nowrap !important;
      }
      #sl-status-pill.show { display: flex !important; }

      /* ── STATUSBAR TOPO ── */
      #sl-sb {
        position: fixed !important;
        top: 0 !important; left: 0 !important; right: 0 !important;
        height: 28px !important;
        background: rgba(5,8,18,0.97) !important;
        border-bottom: 1px solid rgba(0,180,255,0.2) !important;
        z-index: 2147483646 !important;
        display: none !important;
        align-items: center !important;
        padding: 0 12px !important;
        gap: 12px !important;
        font-family: -apple-system, sans-serif !important;
        font-size: 10px !important;
        font-weight: 600 !important;
      }
      #sl-sb.on { display: flex !important; }
      .sl-sep { width:1px; height:12px; background:rgba(255,255,255,0.1); flex-shrink:0; }

      @keyframes slIn   { from{transform:translateX(-10px) scale(.95);opacity:0} to{transform:translateX(0) scale(1);opacity:1} }

      /* ── CRONÔMETRO PÓS-VIOLAÇÃO ── */
      /* ── PILL PÓS-VIOLAÇÃO (lado esquerdo, junto com HUD) ── */
      #sl-viol-timer {
        position: fixed !important;
        left: 12px !important;
        bottom: 155px !important;
        z-index: 2147483647 !important;
        display: none !important;
        align-items: center !important;
        gap: 6px !important;
        background: rgba(20, 5, 8, 0.93) !important;
        border: 1px solid rgba(230,57,70,0.55) !important;
        border-radius: 20px !important;
        padding: 5px 12px 5px 8px !important;
        backdrop-filter: blur(10px) !important;
        box-shadow: 0 2px 16px rgba(230,57,70,0.35) !important;
        white-space: nowrap !important;
        pointer-events: auto !important;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
        animation: slIn .3s ease, slViolPulse 2s ease-in-out infinite !important;
      }
      #sl-viol-timer.show { display: flex !important; }
      #sl-viol-dot {
        width: 7px !important; height: 7px !important;
        border-radius: 50% !important;
        background: #e63946 !important;
        box-shadow: 0 0 6px #e63946 !important;
        animation: slBlink .6s infinite !important;
        flex-shrink: 0 !important;
      }
      #sl-viol-label {
        font-size: 11px !important;
        font-weight: 700 !important;
        color: #e63946 !important;
        letter-spacing: .3px !important;
        white-space: nowrap !important;
      }
      #sl-viol-count {
        font-size: 13px !important;
        font-weight: 800 !important;
        color: #ffd600 !important;
        font-family: monospace !important;
        letter-spacing: 1.5px !important;
        margin-left: 2px !important;
      }
      #sl-viol-close {
        width: 18px !important; height: 18px !important;
        border-radius: 50% !important;
        background: rgba(255,255,255,0.08) !important;
        border: none !important;
        color: rgba(255,255,255,0.5) !important;
        font-size: 10px !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        pointer-events: auto !important;
        flex-shrink: 0 !important;
        margin-left: 2px !important;
        transition: all .15s !important;
      }
      #sl-viol-close:hover {
        background: rgba(255,50,80,0.3) !important;
        color: #fff !important;
      }
      @keyframes slViolPulse {
        0%,100% { box-shadow: 0 2px 16px rgba(230,57,70,0.35); }
        50%      { box-shadow: 0 2px 28px rgba(230,57,70,0.65); }
      }
      @keyframes slBlink { 0%,100%{opacity:1} 50%{opacity:.2} }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  // ══════════════════════════════════════
  //  PUSH DA PÁGINA
  // ══════════════════════════════════════
  function aplicarPush() {
    let el = document.getElementById('sl-push-style');
    if (!el) {
      el = document.createElement('style');
      el.id = 'sl-push-style';
      document.head.appendChild(el);

      // Escuta mudanças de storage em tempo real
      chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === 'local') {
          if (changes.ilPushMargin) {
            aplicarPush();
          }
          if (changes.ilAIActive) {
            aiActive = !!changes.ilAIActive.newValue;
            if (aiActive) iniciarLoopIA();
            else if (aiLoopInterval) { clearInterval(aiLoopInterval); aiLoopInterval = null; }
          }
          if (changes.ilAIGeminiKey) aiGeminiKey = changes.ilAIGeminiKey.newValue || '';
          if (changes.ilAISystemPrompt) aiSystemPrompt = changes.ilAISystemPrompt.newValue || '';
          if (changes.ilAIProductDesc) aiProductDesc = changes.ilAIProductDesc.newValue || '';
          if (changes.ilAIResponseDelay) aiResponseDelay = parseInt(changes.ilAIResponseDelay.newValue) || 8;
        }
      });
    }
    
    chrome.storage.local.get(['ilPushMargin'], (d) => {
      const margin = d.ilPushMargin !== undefined ? parseInt(d.ilPushMargin) : 390;
      el.textContent = `html { margin-right: ${margin}px !important; transition: margin-right 0.3s ease !important; } body { overflow-x: hidden !important; }`;
    });
  }

  // ══════════════════════════════════════
  //  HUD PILLS (espectadores + vendas)
  // ══════════════════════════════════════
  function criarHUD() {
    if (document.getElementById('sl-hud')) return;
    injetarEstilos();
    const hud = document.createElement('div');
    hud.id = 'sl-hud';
    hud.innerHTML = `
      <div class="sl-pill" id="sl-p-viewers">
        <div class="sl-pill-dot"></div>
        <span class="sl-pill-txt">👁 Espectadores</span>
        <span class="sl-pill-val" id="sl-viewers">—</span>
      </div>
      <div class="sl-pill" id="sl-p-vendas">
        <div class="sl-pill-dot" style="background:#00bfff;animation:slBlink .9s infinite"></div>
        <span class="sl-pill-txt">🛒 Vendas</span>
        <span class="sl-pill-val" id="sl-vendas" style="color:#00bfff">—</span>
      </div>
    `;
    document.body.appendChild(hud);
  }

  // ══════════════════════════════════════
  //  POPUP "LIVE ATIVA / LIVE DETECTADA"
  //  Igual ao do cara — fica no centro/baixo
  // ══════════════════════════════════════
  function criarLivePopup() {
    if (document.getElementById('sl-live-popup')) return;
    injetarEstilos();
    const popup = document.createElement('div');
    popup.id = 'sl-live-popup';
    popup.innerHTML = `
      <div class="sl-lp-dot"></div>
      <div class="sl-lp-main" id="sl-lp-txt">LIVE ativa&nbsp;&nbsp;LIVE detectada</div>
      <div class="sl-lp-sep"></div>
      <span style="font-size:11px;font-weight:700;color:#fff">👁</span>
      <span id="sl-lp-viewers" style="font-size:12px;font-weight:800;color:#00e676;font-family:monospace">—</span>
      <div class="sl-lp-sep"></div>
      <span style="font-size:11px;font-weight:700;color:#fff">🛒</span>
      <span id="sl-lp-vendas" style="font-size:12px;font-weight:800;color:#00bfff;font-family:monospace">—</span>
      <div class="sl-lp-sep"></div>
      <div class="sl-lp-actions">
        <button class="sl-lp-btn" title="Proteção ativa">🛡</button>
        <button class="sl-lp-btn gray" title="Refresh" id="sl-lp-ref">↻</button>
      </div>
    `;
    document.body.appendChild(popup);

    popup.querySelector('#sl-lp-ref')?.addEventListener('click', () => location.reload());

    // Restaura posição salva
    try {
      chrome.storage.local.get('slPopupPos', (d) => {
        if (d && d.slPopupPos && d.slPopupPos.left) {
          popup.style.left   = d.slPopupPos.left;
          popup.style.top    = d.slPopupPos.top;
          popup.style.bottom = 'auto';
          popup.style.transform = 'none';
        }
      });
    } catch(e) {}

    // ── DRAG ──
    let dragging = false, ox = 0, oy = 0;

    popup.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      dragging = true;
      const rect = popup.getBoundingClientRect();
      popup.style.left   = rect.left + 'px';
      popup.style.top    = rect.top  + 'px';
      popup.style.bottom = 'auto';
      popup.style.transform = 'none';
      ox = e.clientX - rect.left;
      oy = e.clientY - rect.top;
      popup.classList.add('is-dragging');
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      popup.style.left = (e.clientX - ox) + 'px';
      popup.style.top  = (e.clientY - oy) + 'px';
    });

    document.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      popup.classList.remove('is-dragging');
      chrome.storage.local.set({
        slPopupPos: { left: popup.style.left, top: popup.style.top }
      });
    });
  }

    function mostrarLivePopup(msg, permanente) {
    const popup = document.getElementById('sl-live-popup');
    const txt   = document.getElementById('sl-lp-txt');
    if (!popup || !txt) return;
    txt.textContent = msg || 'LIVE ativa   LIVE detectada';
    popup.classList.add('show');
    if (!permanente) {
      clearTimeout(popup._t);
      popup._t = setTimeout(() => popup.classList.remove('show'), 5000);
    }
  }

  function esconderLivePopup() {
    const popup = document.getElementById('sl-live-popup');
    if (popup) popup.classList.remove('show');
  }

  // ══════════════════════════════════════
  //  STATUS PILL (canto esq baixo)
  // ══════════════════════════════════════
  // ── LOG FLUTUANTE ──────────────────────────────────
  let logFlutuanteAberto = false;
  const _logBuffer = [];

  function criarLogFlutuante() {
    if (document.getElementById('il-log-btn')) return;

    // Botão flutuante
    const btn = document.createElement('div');
    btn.id = 'il-log-btn';
    btn.innerHTML = '∞ Log';
    btn.title = 'Log Live Infinity';
    btn.style.cssText = `
      position:fixed!important;bottom:52px!important;left:10px!important;
      z-index:2147483647!important;
      padding:4px 10px!important;height:22px!important;
      border-radius:11px!important;
      background:rgba(5,10,25,0.88)!important;
      border:1px solid rgba(255,23,23,0.35)!important;
      color:#ff1717!important;
      font-size:10px!important;font-family:monospace!important;font-weight:600!important;
      display:flex!important;align-items:center!important;gap:4px!important;
      cursor:pointer!important;
      box-shadow:0 2px 8px rgba(0,0,0,0.4)!important;
      transition:background .2s,border-color .2s!important;
      user-select:none!important;white-space:nowrap!important;
    `;
    btn.addEventListener('click', toggleLogFlutuante);
    document.body.appendChild(btn);

    // Painel de log MÓVEL
    const painel = document.createElement('div');
    painel.id = 'il-log-painel';
    painel.style.cssText = `
      position:fixed!important;bottom:54px!important;left:10px!important;
      z-index:2147483646!important;width:320px!important;
      background:rgba(5,10,25,0.96)!important;
      border:1px solid rgba(255,23,23,0.25)!important;border-radius:12px!important;
      overflow:hidden!important;display:none!important;flex-direction:column!important;
      box-shadow:0 8px 32px rgba(0,0,0,0.6)!important;font-family:monospace!important;
      user-select:none!important;
    `;
    painel.innerHTML = `
      <div id="il-log-header" style="
        display:flex;align-items:center;justify-content:space-between;
        padding:8px 12px;border-bottom:1px solid rgba(255,23,23,0.15);
        background:rgba(255,23,23,0.06);cursor:grab;
      ">
        <div style="display:flex;align-items:center;gap:6px;">
          <span style="font-size:14px;opacity:.5;">⠿</span>
          <span style="font-size:11px;font-weight:700;color:#ff1717;">Live Infinity Log</span>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
          <span id="il-log-limpar" style="font-size:10px;color:rgba(255,23,23,0.5);cursor:pointer;padding:2px 6px;border-radius:4px;border:1px solid rgba(255,23,23,0.2);">Limpar</span>
          <span id="il-log-fechar" style="font-size:16px;color:rgba(255,255,255,0.4);cursor:pointer;line-height:1;padding:0 2px;">✕</span>
        </div>
      </div>
      <div id="il-log-body" style="overflow-y:auto;padding:8px 10px;height:220px;font-size:10px;line-height:1.8;"></div>
    `;
    document.body.appendChild(painel);

    // ── DRAG ──────────────────────────────────────────
    const header = painel.querySelector('#il-log-header');
    let dragging = false, ox = 0, oy = 0;

    header.addEventListener('mousedown', (e) => {
      if (e.target.id === 'il-log-fechar' || e.target.id === 'il-log-limpar') return;
      dragging = true;
      const rect = painel.getBoundingClientRect();
      ox = e.clientX - rect.left;
      oy = e.clientY - rect.top;
      header.style.cursor = 'grabbing';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const x = e.clientX - ox;
      const y = e.clientY - oy;
      const maxX = window.innerWidth  - painel.offsetWidth;
      const maxY = window.innerHeight - painel.offsetHeight;
      painel.style.left   = Math.max(0, Math.min(x, maxX)) + 'px';
      painel.style.top    = Math.max(0, Math.min(y, maxY)) + 'px';
      painel.style.bottom = 'auto';
      painel.style.right  = 'auto';
    });

    document.addEventListener('mouseup', () => {
      if (dragging) { dragging = false; header.style.cursor = 'grab'; }
    });

    // ── BOTÕES ────────────────────────────────────────
    document.getElementById('il-log-fechar')?.addEventListener('click', fecharLogFlutuante);
    document.getElementById('il-log-limpar')?.addEventListener('click', () => {
      const body = document.getElementById('il-log-body');
      if (body) body.innerHTML = '';
      _logBuffer.length = 0;
    });
  }

  function toggleLogFlutuante() {
    const painel = document.getElementById('il-log-painel');
    if (!painel) return;
    logFlutuanteAberto = !logFlutuanteAberto;
    painel.style.display = logFlutuanteAberto ? 'flex' : 'none';
    const btn = document.getElementById('il-log-btn');
    if (btn) {
      btn.style.background = logFlutuanteAberto
        ? 'rgba(0,229,255,0.15)'
        : 'rgba(5,10,25,0.88)';
      btn.style.borderColor = logFlutuanteAberto
        ? 'rgba(0,229,255,0.7)'
        : 'rgba(0,229,255,0.35)';
      btn.innerHTML = logFlutuanteAberto ? '✕ Log' : '∞ Log';
    }
    if (logFlutuanteAberto) {
      // Scroll para o fim
      const body = document.getElementById('il-log-body');
      if (body) body.scrollTop = body.scrollHeight;
    }
  }

  function fecharLogFlutuante() {
    logFlutuanteAberto = false;
    const painel = document.getElementById('il-log-painel');
    if (painel) painel.style.display = 'none';
    const btn = document.getElementById('il-log-btn');
    if (btn) { btn.style.background = 'rgba(5,10,25,0.88)'; btn.style.borderColor = 'rgba(0,229,255,0.35)'; btn.innerHTML = '∞ Log'; }
  }

  function adicionarLogFlutuante(msg, tipo) {
    const body = document.getElementById('il-log-body');
    if (!body) return;
    const hora = new Date().toLocaleTimeString('pt-BR');
    const cor  = tipo === 'err'  ? '#e63946'
               : tipo === 'ok'   ? '#00e676'
               : tipo === 'warn' ? '#ffd600'
               : '#7ab0d4';
    const linha = document.createElement('div');
    linha.style.cssText = `color:${cor};border-bottom:1px solid rgba(255,255,255,0.04);padding:2px 0;`;
    linha.textContent = `[${hora}] ${msg}`;
    body.appendChild(linha);
    // Mantém só últimas 100 linhas
    while (body.children.length > 100) body.removeChild(body.firstChild);
    if (logFlutuanteAberto) body.scrollTop = body.scrollHeight;
  }

  function criarStatusPill() {
    if (document.getElementById('sl-status-pill')) return;
    injetarEstilos();
    const pill = document.createElement('div');
    pill.id = 'sl-status-pill';
    pill.innerHTML = `<div id="sl-sp-dot" style="width:6px;height:6px;border-radius:50%;background:#00ff7f;animation:slBlink .8s infinite;flex-shrink:0"></div><span id="sl-sp-txt"></span>`;
    document.body.appendChild(pill);
  }

  let _spTimer = null;
  function mostrarStatus(msg, tipo, permanente) {
    const pill = document.getElementById('sl-status-pill');
    const txt  = document.getElementById('sl-sp-txt');
    const dot  = document.getElementById('sl-sp-dot');
    if (!pill || !txt || !dot) return;

    const cores = {
      ok:   { border:'rgba(0,200,100,0.4)',  dot:'#00ff7f', txt:'#00ff7f' },
      warn: { border:'rgba(255,200,0,0.4)',  dot:'#ffd600', txt:'#ffd600' },
      err:  { border:'rgba(255,50,80,0.5)',  dot:'#ff3355', txt:'#ff6b6b' },
      info: { border:'rgba(0,180,255,0.4)',  dot:'#00bfff', txt:'#00bfff' },
    };
    const c = cores[tipo] || cores.ok;
    pill.style.cssText = `border: 1px solid ${c.border};`;
    dot.style.background = c.dot;
    txt.style.color = c.txt;
    txt.textContent = msg;
    pill.classList.add('show');
    clearTimeout(_spTimer);
    if (!permanente) _spTimer = setTimeout(() => pill.classList.remove('show'), 4000);
  }

  // ══════════════════════════════════════
  //  STATUSBAR TOPO
  // ══════════════════════════════════════
  function criarStatusbar() {
    if (document.getElementById('sl-sb')) return;
    injetarEstilos();
    const sb = document.createElement('div');
    sb.id = 'sl-sb';
    sb.innerHTML = `
      <div style="display:flex;align-items:center;gap:5px">
        <div style="width:6px;height:6px;border-radius:50%;background:#ff1717;animation:slBlink .8s infinite"></div>
        <span id="sl-sb-st" style="color:#ff1717;letter-spacing:.5px">INFINITY</span>
      </div>
      <div class="sl-sep"></div>
      <span style="color:rgba(255,255,255,.4)">ABA TIKTOK</span>
      <span id="sl-sb-aba" style="color:#888">—</span>
      <div class="sl-sep"></div>
      <span style="color:rgba(255,255,255,.4)">LIVE</span>
      <span id="sl-sb-live" style="color:#888">—</span>
      <div class="sl-sep"></div>
      <span style="color:rgba(255,255,255,.4)">⏱</span>
      <span id="sl-sb-timer" style="color:#00ff7f;font-family:monospace;letter-spacing:1px">--:--:--</span>
      <div class="sl-sep"></div>
      <span id="sl-sb-scan" style="color:rgba(255,255,255,.4)">Scan: 0</span>
      <div class="sl-sep"></div>
      <span id="sl-sb-prot" style="color:#00c864">🛡 Proteção ativa</span>
    `;
    document.body.prepend(sb);
  }

  function ativarStatusbar(ativo) {
    const sb = document.getElementById('sl-sb');
    if (!sb) return;
    if (ativo) {
      sb.classList.add('on');
      document.getElementById('sl-sb-st').textContent = 'MONITORANDO';
      document.body.style.marginTop = '28px';
    } else {
      sb.classList.remove('on');
      document.body.style.marginTop = '';
      clearInterval(metricasInterval);
    }
  }

  function atuStatusbar(campo, valor, cor) {
    const el = document.getElementById('sl-sb-' + campo);
    if (!el) return;
    el.textContent = valor;
    if (cor) el.style.color = cor;
  }

  // Variables and helper functions for session tracking & GMV accumulation
  const sessionId = 'SESS-' + Math.random().toString(36).substring(2, 15).toUpperCase();
  let lastScrapedGmv = 0;
  let lastScrapedVendas = 0;
  let lastScrapedViewers = 0;

  function limparNumero(valStr) {
    if (!valStr || valStr === '-' || valStr === '—') return 0;
    const clean = valStr.replace(/\D/g, "");
    const num = parseInt(clean, 10);
    return isNaN(num) ? 0 : num;
  }

  function limparValorGmv(valStr) {
    if (!valStr || valStr === '-' || valStr === '—') return 0;
    let clean = valStr.replace(/R\$/g, "").replace(/\s/g, "");
    if (clean.includes(",") && clean.includes(".")) {
      clean = clean.replace(/\./g, "").replace(/,/g, ".");
    } else if (clean.includes(",")) {
      clean = clean.replace(/,/g, ".");
    }
    const num = parseFloat(clean);
    return isNaN(num) ? 0 : num;
  }

  // ══════════════════════════════════════
  //  DETECTA SE LIVE ESTÁ AO VIVO
  // ══════════════════════════════════════
  function verificarLiveAtiva() {
    // Indicadores de live ativa no TikTok
    const btns = Array.from(document.querySelectorAll('button'));
    const temEncerrar = btns.some(b => /encerrar|end live|parar live/i.test(b.textContent));

    // Verifica indicador de "ao vivo" na página
    const textos = document.body.innerText.toLowerCase();
    const temAoVivo = textos.includes('ao vivo') || textos.includes('live agora') || textos.includes('transmitindo');

    // Verifica se há espectadores (só aparece durante live)
    const temEspectadores = !!document.querySelector('[class*="viewer"],[class*="spectator"],[class*="audience"]');

    const liveAtiva = temEncerrar || (temAoVivo && temEspectadores);
    const abaConectada = window.location.href.includes('tiktok.com');

    return { liveAtiva, abaConectada };
  }

  // ══════════════════════════════════════
  //  MÉTRICAS
  // ══════════════════════════════════════
  function collectChat() {
    try {
      const input = [...document.querySelectorAll('textarea,[contenteditable="true"]')]
        .find((el) => /digite|coment|mensagem|something|write|escreva/i.test(el.getAttribute("placeholder") || ""));
      if (!input) return [];
      const scope = input.closest("section,main,div") || document.body;
      return [...new Set(
        [...scope.querySelectorAll("p,span,div")]
          .map((el) => el.innerText.trim())
          .filter((t) => t.length >= 3 && t.length <= 180 && !/digite|coment|mensagem|relacionados|todos os com/i.test(t))
      )].slice(-20);
    } catch(e) { return []; }
  }

  function lerMetricas() {
    let viewers = '—', vendas = '—', gmv = '—', ultimaVendaValor = '—';

    const todosEls = Array.from(document.querySelectorAll('*'));

    // ── ESPECTADORES ──
    for (const el of todosEls) {
      if (el.children.length > 0) continue;
      const txt = el.textContent.trim();
      if (/espectadores/i.test(txt) && txt.length < 30) {
        const container = el.closest('div,td,li');
        if (container) {
          const nums = Array.from(container.querySelectorAll('*')).filter(e =>
            e.children.length === 0 && /^\d+$/.test(e.textContent.trim())
          );
          if (nums.length > 0) { viewers = nums[0].textContent.trim(); break; }
          const parentNums = Array.from(container.parentElement?.querySelectorAll('*') || []).filter(e =>
            e.children.length === 0 && /^\d+$/.test(e.textContent.trim()) && e !== el
          );
          if (parentNums.length > 0) { viewers = parentNums[0].textContent.trim(); break; }
        }
      }
    }

    // ── ITENS VENDIDOS / ATRIBUÍDOS ──
    // Log debug confirmou: div[style*="line-clamp"] índice [0] = itens atribuídos
    (function() {
      const painelNums = Array.from(document.querySelectorAll('div[style*="line-clamp"]'))
        .filter(e => e.children.length === 0 && /^\d+$/.test(e.textContent.trim()));
      if (painelNums.length > 0) vendas = painelNums[0].textContent.trim();
    })();

    // ── GMV ──
    for (const el of todosEls) {
      if (el.children.length > 0) continue;
      const txt = el.textContent.trim();
      if (/^gmv/i.test(txt) && txt.length < 25) {
        const container = el.closest('div,td,li');
        if (container) {
          const vals = Array.from(container.querySelectorAll('*')).filter(e =>
            e.children.length === 0 && /R\$[\s\d.,]+/.test(e.textContent.trim())
          );
          if (vals.length > 0) { gmv = vals[0].textContent.trim(); break; }
          const parentVals = Array.from(container.parentElement?.querySelectorAll('*') || []).filter(e =>
            e.children.length === 0 && /R\$[\s\d.,]+/.test(e.textContent.trim())
          );
          if (parentVals.length > 0) { gmv = parentVals[0].textContent.trim(); break; }
        }
      }
    }

    // ── ÚLTIMA VENDA COM VALOR ──
    for (const el of todosEls) {
      if (el.children.length > 0) continue;
      const txt = el.textContent.trim();
      const m = txt.match(/comprou.*?R\$\s*([\d.,]+)/i);
      if (m) { ultimaVendaValor = 'R$ ' + m[1]; break; }
    }

    // Atualiza HUD
    const vEl = document.getElementById('sl-viewers');
    const cEl = document.getElementById('sl-vendas');
    if (vEl) vEl.textContent = viewers;
    if (cEl) cEl.textContent = vendas;

    // Atualiza popup
    const lpV = document.getElementById('sl-lp-viewers');
    const lpC = document.getElementById('sl-lp-vendas');
    if (lpV) lpV.textContent = viewers;
    if (lpC) lpC.textContent = vendas;

    lastScrapedGmv = limparValorGmv(gmv);
    lastScrapedVendas = limparNumero(vendas);
    lastScrapedViewers = limparNumero(viewers);

    enviar({
      action: 'statusUpdate',
      data: { viewers, vendas, gmv, ultimaVendaValor, chatMessages: collectChat() }
    });
    verificarNovaVenda(vendas, ultimaVendaValor, gmv);
  }


  // ══════════════════════════════════════
  //  SOM DE VENDA
  // ══════════════════════════════════════
  // Rastreia últimas atividades vistas para não duplicar
  let ultimasAtividades = new Set();

  function verificarNovaVenda(vendas, ultimaVendaValor, gmv) {
    // Detecção 1: pelo contador de itens
    const num = parseInt((vendas+'').replace(/\D/g,'')) || 0;
    if (num > ultimaVenda && ultimaVenda > 0) {
      const diff = Math.min(num - ultimaVenda, 3);
      for (let i = 0; i < diff; i++) setTimeout(tocarCampainha, i * 700);
      mostrarStatus(`🛒 +${num - ultimaVenda} venda${num-ultimaVenda>1?'s':''}!`, 'ok', false);
      dispararPostSale(num);
    }
    if (num > 0) ultimaVenda = num;

    // Detecção 2: pela seção Atividade (captura mesmo quando contador está em 0)
    detectarVendaPorAtividade();
  }

  function detectarVendaPorAtividade() {
    // Procura textos de venda na seção Atividade
    const ativEls = Array.from(document.querySelectorAll('*')).filter(el => {
      if (el.children.length > 0) return false;
      const txt = el.textContent.trim();
      return txt.includes('comprou o produto') || txt.includes('purchased') || txt.includes('bought');
    });

    for (const el of ativEls) {
      const txt = el.textContent.trim();
      // Usa o texto como chave única para não duplicar
      const chave = txt.slice(0, 60);
      if (ultimasAtividades.has(chave)) continue;
      ultimasAtividades.add(chave);
      // Limpa cache se crescer demais
      if (ultimasAtividades.size > 50) ultimasAtividades.clear();

      // Extrai valor se houver
      const mValor = txt.match(/R\$\s*([\d.,]+)/i);
      const valor = mValor ? 'R$ ' + mValor[1] : '—';

      // Dispara notificação
      if (somAtivo) tocarCampainha();
      mostrarStatus(`🛒 Nova venda! ${valor}`, 'ok', false);
      dispararPostSale(ultimaVenda > 0 ? ultimaVenda : 1);

      // Notifica background para enviar Telegram
      enviar({
        action: 'statusUpdate',
        data: {
          viewers: document.getElementById('sl-viewers')?.textContent || '—',
          vendas: ultimaVenda > 0 ? String(ultimaVenda) : '1',
          gmv: '—',
          ultimaVendaValor: valor,
          novaVendaAtividade: true,
          chatMessages: collectChat()
        }
      });
    }
  }

  function dispararPostSale(salesCount) {
    if (!postSaleEnabled) return;
    clearTimeout(postSaleTimer);
    postSaleTimer = setTimeout(() => {
      if (!postSaleMessages || !postSaleMessages.length) return;
      const template = postSaleMessages[postSaleMessageIndex % postSaleMessages.length];
      postSaleMessageIndex++;
      const message = template
        .replace(/\{salesCount\}/gi, String(salesCount))
        .replace(/\{vendas\}/gi, String(salesCount))
        .trim();
      if (message) {
        const res = sendComment(message);
        if (res.ok) {
          console.log('[Live Infinity] Prova social enviada: ' + message);
        } else {
          console.log('[Live Infinity] Falha ao enviar prova social: ' + res.msg);
        }
      }
    }, postSaleDelaySeconds * 1000);
  }

  function tocarCampainha() {
    if (!somAtivo) return;
    try {
      var url = chrome.runtime.getURL('assets/caixa-registradora-live-infinity.wav');
      var audio = new Audio(url);
      audio.volume = 1.0;
      audio.play().catch(function(e) {
        console.log('[Live Infinity] Erro no som:', e);
      });
    } catch(e) {
      console.log('[Live Infinity] Erro no som:', e);
    }
  }

  // ══════════════════════════════════════
  //  AÇÕES
  // ══════════════════════════════════════
  // ── AUTO-FIX: ciclo desafixar→fixar com timing aleatório humano ──
  let autoFixTimeout = null;
  let modoCupomAtivo = false;

  // Prova Social Pós-Venda
  let postSaleEnabled = false;
  let postSaleMessages = [];
  let postSaleDelaySeconds = 10;
  let postSaleMessageIndex = 0;
  let postSaleTimer = null;

  function aleatorio(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function iniciarAutoFix() {
    pararAutoFix();
    if (!ctxOk()) return;
    try {
      chrome.storage.local.get('infinityFixarAtivo', (d) => {
        if (chrome.runtime.lastError) return;
        if (!d.infinityFixarAtivo) return; // toggle OFF — não faz nada
        const delay = aleatorio(5000, 8000);
        autoFixTimeout = setTimeout(() => executarCicloFix(), delay);
        mostrarStatus('📌 Auto-fix ativo', 'ok', false);
      });
    } catch(e) {}
  }

  function getTodosOsBotoes() {
    // Pega buttons normais + elementos com role="button" que o TikTok usa
    const sels = 'button, [role="button"], [class*="btn"], [class*="Btn"]';
    return Array.from(document.querySelectorAll(sels)).filter(el => el.offsetParent !== null);
  }

  function textoBtn(el) {
    return (el.textContent || el.innerText || el.getAttribute('aria-label') || '').trim().toLowerCase();
  }

  function executarCicloFix() {
    if (autoFixTimeout === null) return;
    if (!ctxOk()) return;

    // Agenda o próximo ciclo antecipadamente para evitar que o loop morra
    // se houver suspensão do Service Worker do Manifest V3
    const proximo = aleatorio(18 * 1000, 30 * 1000);
    autoFixTimeout = setTimeout(() => executarCicloFix(), proximo);

    try { chrome.storage.local.get('infinityFixarAtivo', (d) => {
      if (chrome.runtime.lastError) return;
      
      if (!d.infinityFixarAtivo) {
        pararAutoFix();
        mostrarStatus('📌 Auto-fix desativado', 'warn', false);
        return;
      }

      // Lê modo cupom do storage antes de agir
      chrome.storage.local.get('infinityModoCupom', (ds) => {
        if (chrome.runtime.lastError) return;
        modoCupomAtivo = !!ds.infinityModoCupom;

        if (modoCupomAtivo) {
          // ── MODO CUPOM: pula 1º botão fixar (cupom) e clica no 2º (produto) ──
          _cicloFixarComCupom();
        } else {
          // ── MODO NORMAL (inalterado) ──
          const btns = getTodosOsBotoes();
          const desafixarBtn = btns.find(b => {
            const txt = textoBtn(b);
            return txt === 'desafixar' || txt === 'unpin' || txt === 'desfixar' ||
                   txt.includes('desafix') || txt.includes('unpin');
          });
          if (desafixarBtn) {
            desafixarBtn.click();
            mostrarStatus('🔄 Reafixando produto...', 'info', false);
            setTimeout(() => {
              const btns2 = getTodosOsBotoes();
              const fixarBtn = btns2.find(b => {
                const txt = textoBtn(b);
                return txt === 'fixar' || txt === 'pin' || txt === 'fix' || txt.includes('fixar');
              });
              if (fixarBtn) { fixarBtn.click(); mostrarStatus('✓ Produto reafixado!', 'ok', false); }
              else { mostrarStatus('⚠️ Botão fixar não encontrado após desafixar', 'warn', false); }
            }, aleatorio(1500, 4000));
          } else {
            const fixarBtn = btns.find(b => {
              const txt = textoBtn(b);
              return txt === 'fixar' || txt === 'pin' || txt.includes('fixar');
            });
            if (fixarBtn) { fixarBtn.click(); mostrarStatus('✓ Produto fixado!', 'ok', false); }
            else { mostrarStatus('⚠️ Nenhum produto encontrado para fixar', 'warn', false); }
          }
        }
      });
    }); } catch(e) {}
  }

  function pararAutoFix() {
    clearTimeout(autoFixTimeout);
    autoFixTimeout = null;
  }

  // ── CICLO FIXAR COM CUPOM ──
  // Pega todos os botões "Fixar" ordenados por posição vertical na tela
  // Pula o 1º (cupom) e fixa o 2º (produto real)
  function _cicloFixarComCupom() {
    // Primeiro desafixa se houver algo fixado
    const desafixarBtn = Array.from(document.querySelectorAll('button'))
      .find(b => b.offsetParent && /desafixar|desfixar|unpin/i.test(
        (b.textContent || b.innerText || b.getAttribute('aria-label') || '').trim()
      ));

    if (desafixarBtn) {
      desafixarBtn.click();
      mostrarStatus('🔄 Desafixando...', 'info', false);
      setTimeout(_fixarProdutoAposCupom, aleatorio(1800, 3000));
      return;
    }
    _fixarProdutoAposCupom();
  }

  function _fixarProdutoAposCupom() {
    // Pega botões "Fixar" visíveis ordenados de cima pra baixo
    const fixarBtns = Array.from(document.querySelectorAll('button'))
      .filter(b => {
        if (!b.offsetParent) return false;
        const txt = (b.textContent || b.innerText || b.getAttribute('aria-label') || '').trim().toLowerCase();
        return (txt === 'fixar' || txt === 'pin' || txt === 'fix' || txt.includes('fixar'))
               && !txt.includes('desafix') && !txt.includes('desfixar') && !txt.includes('unpin');
      })
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);

    adicionarLogFlutuante('🏷️ Botões fixar visíveis: ' + fixarBtns.length, 'info');

    if (fixarBtns.length === 0) {
      mostrarStatus('⚠️ Nenhum botão fixar encontrado', 'warn', false);
      return;
    }
    // Com 1 botão → fixa ele (sem cupom na lista)
    if (fixarBtns.length === 1) {
      fixarBtns[0].click();
      mostrarStatus('✓ Produto fixado!', 'ok', false);
      return;
    }
    // Com 2+ botões → pula o 1º (cupom) fixa o 2º (produto)
    fixarBtns[1].click();
    mostrarStatus('✓ Produto fixado (cupom ignorado)!', 'ok', false);
  }

  function fixarProduto() {
    mostrarStatus('Fixando produto...', 'ok', true);
    const btns = getTodosOsBotoes();
    const desafixarBtn = btns.find(b => /desafixar|desfixar|unpin/i.test(textoBtn(b)));
    if (desafixarBtn) {
      desafixarBtn.click();
      setTimeout(() => {
        const btns2 = getTodosOsBotoes();
        const fixarBtn = btns2.find(b => /^fixar$|^pin$|^fix$/i.test(textoBtn(b)) || textoBtn(b).includes('fixar'));
        if (fixarBtn) { fixarBtn.click(); mostrarStatus('✓ Produto reafixado!', 'ok', false); }
        else { mostrarStatus('⚠️ Botão fixar não encontrado', 'warn', false); }
      }, aleatorio(1500, 3000));
      return;
    }
    const fixarBtn = btns.find(b => /^fixar$|^pin$|^fix$/i.test(textoBtn(b)) || textoBtn(b).includes('fixar'));
    if (fixarBtn) { fixarBtn.click(); setTimeout(() => mostrarStatus('✓ Produto fixado!', 'ok', false), 1000); return; }
    mostrarStatus('⚠️ Botão não encontrado — produto selecionado?', 'warn', false);
  }

  // ══════════════════════════════════════
  //  CRONÔMETRO PÓS-VIOLAÇÃO
  // ══════════════════════════════════════
  let violTimerInterval = null;

  function criarViolTimer() {
    if (document.getElementById('sl-viol-timer')) return;
    const el = document.createElement('div');
    el.id = 'sl-viol-timer';
    el.innerHTML = `
      <div id="sl-viol-dot"></div>
      <span id="sl-viol-label">🔴 Violação · encerra em</span>
      <span id="sl-viol-count">00:00</span>
      <button id="sl-viol-close" title="Encerrar live agora">✕</button>
    `;
    document.body.appendChild(el);
    document.getElementById('sl-viol-close')?.addEventListener('click', () => {
      pararViolTimer();
      encerrarLive();
      enviar({ action: 'encerrarLive' });
    });
  }

  function iniciarViolTimer(secsTotal) {
    criarViolTimer();
    let secs = secsTotal;
    const el    = document.getElementById('sl-viol-timer');
    const count = document.getElementById('sl-viol-count');
    if (el) el.classList.add('show');

    if (violTimerInterval) clearInterval(violTimerInterval);
    violTimerInterval = setInterval(() => {
      secs--;
      if (count) {
        const h = Math.floor(secs / 3600);
        const m = Math.floor((secs % 3600) / 60);
        const s = secs % 60;
        count.textContent = h > 0
          ? pad(h)+':'+pad(m)+':'+pad(s)
          : pad(m)+':'+pad(s);
      }
      if (secs <= 0) { pararViolTimer(); }
    }, 1000);
  }

  function pararViolTimer() {
    if (violTimerInterval) { clearInterval(violTimerInterval); violTimerInterval = null; }
    const el = document.getElementById('sl-viol-timer');
    if (el) el.classList.remove('show');
  }

  function pad(n) { return String(n).padStart(2,'0'); }

  function encerrarLive() {
    mostrarStatus('⏹ Encerrando LIVE...', 'err', true);

    // MÉTODO 1: SVG arco-icon-im_close_chat — seletor exato do botão power
    const svgEl = document.querySelector('.arco-icon-im_close_chat');
    if (svgEl) {
      // Sobe na árvore até achar o elemento clicável
      let el = svgEl;
      for (let i = 0; i < 5; i++) {
        el = el.parentElement;
        if (!el) break;
        const tag = el.tagName.toLowerCase();
        const cls = el.className || '';
        if (tag === 'button' || el.getAttribute('role') === 'button' ||
            cls.includes('btn') || cls.includes('button') || cls.includes('icon-btn')) {
          el.click();
          mostrarStatus('⏹ Botão encerrar clicado!', 'err', true);
          setTimeout(() => {
            const confirmBtn = Array.from(document.querySelectorAll('button')).find(b =>
              /encerrar agora|confirmar|end now|sim/i.test(b.textContent.trim())
            );
            if (confirmBtn) { confirmBtn.click(); mostrarStatus('✓ LIVE encerrada!', 'err', false); }
          }, 1500);
          return;
        }
      }
      // Se não achou pai clicável, clica no próprio SVG
      svgEl.parentElement?.click();
      setTimeout(() => {
        const confirmBtn = Array.from(document.querySelectorAll('button')).find(b =>
          /encerrar agora|confirmar|end now/i.test(b.textContent.trim())
        );
        if (confirmBtn) confirmBtn.click();
      }, 1500);
      return;
    }

    // MÉTODO 2: qualquer elemento com close_chat na classe
    const closeEl = document.querySelector('[class*="close_chat"],[class*="im_close"]');
    if (closeEl) {
      (closeEl.closest('button') || closeEl.parentElement)?.click();
      setTimeout(() => {
        const ok = Array.from(document.querySelectorAll('button')).find(b =>
          /encerrar agora|confirmar/i.test(b.textContent.trim())
        );
        if (ok) ok.click();
      }, 1500);
      return;
    }

    // MÉTODO 3: botão pelo texto
    const endBtn = Array.from(document.querySelectorAll('button')).find(b =>
      /encerrar|end live/i.test(b.textContent.trim())
    );
    if (endBtn) {
      endBtn.click();
      setTimeout(() => {
        const ok = Array.from(document.querySelectorAll('button')).find(b =>
          /confirmar|sim|encerrar agora/i.test(b.textContent.trim())
        );
        if (ok) ok.click();
      }, 1500);
      return;
    }

    mostrarStatus('⚠️ Botão encerrar não encontrado', 'warn', false);
  }

  function verificarViolacao() {
    // 1. Ícone vermelho do card de violação — mais direto
    const ico = document.querySelector('.arco-icon-info_error');
    if (ico) {
      const rect = ico.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0 &&
          rect.top >= 0 && rect.top <= window.innerHeight) {
        return { detectado: true, motivo: 'arco-icon-info_error visível' };
      }
    }

    // 2. Background vermelho claro + texto violação
    const todos = Array.from(document.querySelectorAll('div'));
    for (const el of todos) {
      const st = getComputedStyle(el);
      const bg = st.backgroundColor;
      // rgb(255, 242, 240) — fundo do card de violação
      if (!bg.includes('255') || !bg.includes('242') || !bg.includes('240')) continue;
      const rect = el.getBoundingClientRect();
      if (!rect.width || !rect.height) continue;
      if (rect.top < 0 || rect.top > window.innerHeight) continue;
      const txt = (el.innerText || '').toLowerCase();
      if (txt.includes('violação') || txt.includes('violation')) {
        return { detectado: true, motivo: 'fundo vermelho + violação' };
      }
    }

    return { detectado: false };
  }

  // ══════════════════════════════════════
  //  MENSAGENS
  // ══════════════════════════════════════
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (msg.action === 'iniciarCiclo') {
        criarHUD(); criarStatusbar(); criarLivePopup(); criarStatusPill();
        ativarStatusbar(true);
        mostrarLivePopup('LIVE ativa   LIVE detectada', true);
        ultimasAtividades.clear(); // Reseta cache ao iniciar
        metricasInterval = setInterval(lerMetricas, 2000);
        lerMetricas();
        iniciarAutoFix();
        sendResponse({ok:true});
      }

      if (msg.action === 'pararCiclo') {
        ativarStatusbar(false);
        esconderLivePopup();
        pararAutoFix();
        mostrarStatus('■ Monitor parado','warn',false);
        sendResponse({ok:true});
      }

      if (msg.action === 'mostrarPopupLiveAtiva') {
        mostrarLivePopup('LIVE ativa   LIVE detectada', true);
      }

      if (msg.action === 'fixarProduto') { fixarProduto(); sendResponse({ok:true}); }
      if (msg.action === 'encerrarLive') { encerrarLive(); sendResponse({ok:true}); }

      if (msg.action === 'setModoCupom') {
        modoCupomAtivo = !!msg.ativo;
        mostrarStatus(modoCupomAtivo ? '🏷️ Modo Cupom ON' : '🏷️ Modo Cupom OFF', 'info', false);
        sendResponse({ok:true});
      }

      if (msg.action === 'setPostSaleConfig') {
        postSaleEnabled = !!msg.data.ativo;
        postSaleDelaySeconds = parseInt(msg.data.delay) || 10;
        postSaleMessages = Array.isArray(msg.data.messages) ? msg.data.messages : [];
        sendResponse({ok:true});
      }

      if (msg.action === 'updateAIConfig') {
        aiActive = !!msg.data.active;
        chrome.storage.local.get(['ilAIGeminiKey', 'ilAISystemPrompt', 'ilAIProductDesc', 'ilAIResponseDelay'], (d) => {
          aiGeminiKey = d.ilAIGeminiKey || '';
          aiSystemPrompt = d.ilAISystemPrompt || 'Você é o assistente da live. Responda de forma curta e objetiva (máximo 120 caracteres).';
          aiProductDesc = d.ilAIProductDesc || '';
          aiResponseDelay = d.ilAIResponseDelay !== undefined ? parseInt(d.ilAIResponseDelay) : 8;
          if (aiActive) {
            iniciarLoopIA();
          } else {
            if (aiLoopInterval) {
              clearInterval(aiLoopInterval);
              aiLoopInterval = null;
            }
          }
        });
        sendResponse({ok:true});
      }

      if (msg.action === 'setAutoReplyConfig') {
        autoReplyActive = !!msg.data?.active;
        if (msg.data?.rules !== undefined) autoReplyRulesStr = msg.data.rules;
        if (msg.data?.mention !== undefined) autoReplyMention = !!msg.data.mention;
        if (autoReplyActive) iniciarAutoReplyLoop();
        else if (autoReplyInterval) { clearInterval(autoReplyInterval); autoReplyInterval = null; }
        sendResponse({ok:true});
      }

      if (msg.action === 'setIntentCartConfig') {
        intentCartActive = !!msg.data?.active;
        if (msg.data?.msg !== undefined) intentCartMsg = msg.data.msg;
        if (intentCartActive) iniciarIntentCartLoop();
        else if (intentCartInterval) { clearInterval(intentCartInterval); intentCartInterval = null; }
        sendResponse({ok:true});
      }

      if (msg.action === 'setFlashSaleConfig') {
        flashSaleActive = !!msg.data?.active;
        if (flashSaleActive) iniciarFlashSaleLoop();
        else if (flashSaleInterval) { clearInterval(flashSaleInterval); flashSaleInterval = null; }
        sendResponse({ok:true});
      }

      if (msg.action === 'setFixarAtivo') {
        if (msg.ativo) {
          iniciarAutoFix();
          mostrarStatus('📌 Auto-fix ativado', 'ok', false);
        } else {
          pararAutoFix();
          mostrarStatus('📌 Auto-fix desativado', 'warn', false);
        }
        sendResponse({ok:true});
      }

      if (msg.action === 'ativarSom') {
        somAtivo = msg.ativo;
        if (msg.ativo) {
          // Cria AudioContext via clique simulado na página (necessário pra browser permitir)
          try {
            if (!audioCtx) {
              audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            }
            if (audioCtx.state === 'suspended') {
              audioCtx.resume().then(() => tocarCampainha());
            } else {
              tocarCampainha();
            }
          } catch(e) {
            // Fallback: cria novo contexto
            try {
              audioCtx = new (window.AudioContext || window.webkitAudioContext)();
              tocarCampainha();
            } catch(e2) {}
          }
          mostrarStatus('🔔 Som de venda ativado!', 'ok', false);
        } else {
          mostrarStatus('🔕 Som desativado', 'warn', false);
        }
        sendResponse({ok:true});
      }

      if (msg.action === 'checkLive') {
        const r = verificarLiveAtiva();
        // Atualiza statusbar
        atuStatusbar('aba', r.abaConectada ? 'Conectada' : '—', r.abaConectada ? '#00ff7f' : '#888');
        atuStatusbar('live', r.liveAtiva ? 'Detectada' : '—', r.liveAtiva ? '#00bfff' : '#888');
        // Popup automático quando live é detectada
        if (r.liveAtiva && !liveAtivaAntes) {
          mostrarLivePopup('LIVE ativa   LIVE detectada', false);
        }
        liveAtivaAntes = r.liveAtiva;
        sendResponse(r);
      }

      if (msg.action === 'calibrar') {
        const r = verificarViolacao();
        sendResponse({pixels:r.detectado?999:0, detectado:r.detectado});
        return true;
      }

      if (msg.action === 'timerTick') {
        atuStatusbar('timer', msg.data.str, undefined);
      }

      if (msg.action === 'scanTick') {
        atuStatusbar('scan', 'Scan: '+msg.data.n, undefined);
        lerMetricas();
      }

      if (msg.action === 'violacaoDetectada') {
        mostrarStatus('🔴 VIOLAÇÃO DETECTADA!','err',true);
        atuStatusbar('prot','🔴 VIOLAÇÃO!','#e63946');
        esconderLivePopup();
        if (msg.data && msg.data.encerrando === false && msg.data.minutosExtra > 0) {
          // Modo continuar — exibe pill no lado esquerdo com countdown
          iniciarViolTimer(msg.data.minutosExtra * 60);
          mostrarStatus(`⏱ Violação! Encerrando em ${msg.data.minutosExtra} min`, 'warn', true);
        } else {
          // Encerra imediatamente
          pararViolTimer();
          encerrarLive();
          ativarStatusbar(false);
        }
      }

      // Sincroniza pill com o countdown exato vindo do background
      if (msg.action === 'violacaoCountdown') {
        const count = document.getElementById('sl-viol-count');
        if (count && msg.data?.str) count.textContent = msg.data.str;
      }

      if (msg.action === 'violacaoEncerrou') {
        pararViolTimer();
        encerrarLive();
        ativarStatusbar(false);
        mostrarStatus('⏹ Tempo pós-violação esgotado. LIVE encerrada.','warn',false);
      }

      if (msg.action === 'timerZerou') {
        mostrarStatus('⏱ Timer zerou — LIVE encerrada','warn',false);
        esconderLivePopup();
        ativarStatusbar(false);
      }

      if (msg.action === 'relatorioSessao') {
        const r = msg.data;
        mostrarStatus(`📊 ${r.horas}h · ${r.scans} scans · ${r.alertas} alertas`,'info',false);
      }


      if (msg.action === 'startComments')  { sendResponse(startComments(msg.messages, msg.intervalMin, msg.intervalMax)); return true; }
      if (msg.action === 'stopComments')   { sendResponse(stopComments()); return true; }
      if (msg.action === 'startBlock')     {
        sendResponse(startBlockWatch(msg.words));
        return true;
      }
      if (msg.action === 'stopBlock')      { sendResponse(stopBlockWatch()); return true; }

    } catch(e){ sendResponse({ok:false,msg:e.message}); }
    return true;
  });

  // ══════════════════════════════════════
  //  INIT
  // ══════════════════════════════════════
  function init() {
    injetarEstilos();
    aplicarPush();
    criarHUD();
    criarStatusbar();
    criarLogFlutuante();
    criarLivePopup();
    criarStatusPill();
    mostrarStatus('⚡ Live Infinity ativo','info',false);

    chrome.storage.local.get(['ilPostSaleEnabled', 'ilPostSaleMessages', 'ilPostSaleDelay', 'ilAIActive', 'ilAIGeminiKey', 'ilAISystemPrompt', 'ilAIProductDesc', 'ilAIResponseDelay', 'ilAutoReplyActive', 'ilAutoReplyRules', 'ilAutoReplyMention', 'ilIntentCartActive', 'ilIntentCartMsg', 'ilFlashSaleActive'], (d) => {
      postSaleEnabled = !!d.ilPostSaleEnabled;
      postSaleDelaySeconds = parseInt(d.ilPostSaleDelay) || 10;
      postSaleMessages = d.ilPostSaleMessages 
        ? d.ilPostSaleMessages.split('\n').map(m => m.trim()).filter(Boolean)
        : [];

      aiActive = !!d.ilAIActive;
      aiGeminiKey = d.ilAIGeminiKey || '';
      aiSystemPrompt = d.ilAISystemPrompt || 'Você é o assistente da live. Responda de forma curta e objetiva (máximo 120 caracteres).';
      aiProductDesc = d.ilAIProductDesc || '';
      aiResponseDelay = d.ilAIResponseDelay !== undefined ? parseInt(d.ilAIResponseDelay) : 8;
      if (aiActive) iniciarLoopIA();

      autoReplyActive = !!d.ilAutoReplyActive;
      autoReplyRulesStr = d.ilAutoReplyRules || '';
      autoReplyMention = d.ilAutoReplyMention !== undefined ? !!d.ilAutoReplyMention : true;
      if (autoReplyActive) iniciarAutoReplyLoop();

      intentCartActive = !!d.ilIntentCartActive;
      intentCartMsg = d.ilIntentCartMsg || 'garante o seu, finaliza a compra! 🛒';
      if (intentCartActive) iniciarIntentCartLoop();

      flashSaleActive = !!d.ilFlashSaleActive;
      if (flashSaleActive) iniciarFlashSaleLoop();
    });

    // Inicializa AudioContext no primeiro clique do usuário na página
    // Isso é necessário para o Chrome permitir reprodução de áudio
    document.addEventListener('click', function iniciarAudio() {
      if (!audioCtx) {
        try {
          audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        } catch(e) {}
      } else if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      document.removeEventListener('click', iniciarAudio);
    }, { once: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 300);
  }

  // Registra esta aba no background para garantir que mensagens chegam aqui
  setTimeout(function() {
    if (ctxOk()) {
      chrome.runtime.sendMessage({ action: 'registrarAba' }, function() {
        if (chrome.runtime.lastError) {}
      });
    }
  }, 500);

  // ══════════════════════════════════════
  //  COMENTÁRIOS AUTOMÁTICOS
  // ══════════════════════════════════════
  let GL_COMMENT_INTERVAL = null;
  let GL_COMMENT_LIST = [];
  let GL_COMMENT_INDEX = 0;
  let GL_INTERVAL_MIN = 30;
  let GL_INTERVAL_MAX = 90;

  function sendComment(text) {
    try {
      // Tenta múltiplos seletores para o campo de chat do TikTok Shop
      var textarea = 
        document.querySelector('textarea[placeholder*="algo"]') ||
        document.querySelector('textarea[placeholder*="comment"]') ||
        document.querySelector('textarea[placeholder*="Comment"]') ||
        document.querySelector('textarea[placeholder*="Digite"]') ||
        document.querySelector('.chat-input textarea') ||
        document.querySelector('[class*="chat"] textarea') ||
        document.querySelector('[class*="input"] textarea') ||
        document.querySelector('textarea.arco-textarea') ||
        document.querySelector('textarea');

      if (!textarea) return { ok: false, msg: 'Campo de comentário não encontrado.' };

      textarea.focus();
      textarea.click();

      // NativeSetter — força o React a reconhecer a mudança
      var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      nativeSetter.call(textarea, text);
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true }));
      textarea.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
      textarea.dispatchEvent(new CompositionEvent('compositionend', { data: text, bubbles: true }));

      // Aguarda React processar e dispara Enter
      setTimeout(() => {
        textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
        textarea.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
        textarea.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
      }, 300);

      return { ok: true, msg: 'Comentário enviado: ' + text };
    } catch(e) { return { ok: false, msg: 'Erro: ' + e.message }; }
  }

  function scheduleNextComment() {
    if (!GL_COMMENT_LIST || !GL_COMMENT_LIST.length) return;
    var delay = Math.floor(Math.random() * (GL_INTERVAL_MAX - GL_INTERVAL_MIN + 1)) + GL_INTERVAL_MIN;
    GL_COMMENT_INTERVAL = setTimeout(() => {
      sendComment(GL_COMMENT_LIST[GL_COMMENT_INDEX % GL_COMMENT_LIST.length]);
      GL_COMMENT_INDEX++;
      scheduleNextComment();
    }, delay * 1000);
  }

  function startComments(messages, intervalMin, intervalMax) {
    if (GL_COMMENT_INTERVAL) { clearTimeout(GL_COMMENT_INTERVAL); GL_COMMENT_INTERVAL = null; }
    GL_COMMENT_LIST = messages;
    GL_COMMENT_INDEX = 0;
    GL_INTERVAL_MIN = intervalMin;
    GL_INTERVAL_MAX = intervalMax;
    if (!messages || !messages.length) return { ok: false, msg: 'Nenhuma mensagem.' };
    sendComment(GL_COMMENT_LIST[0]);
    GL_COMMENT_INDEX = 1;
    scheduleNextComment();
    return { ok: true, msg: 'Comentários iniciados. Intervalo: ' + intervalMin + 's–' + intervalMax + 's' };
  }

  function stopComments() {
    if (GL_COMMENT_INTERVAL) { clearTimeout(GL_COMMENT_INTERVAL); GL_COMMENT_INTERVAL = null; }
    GL_COMMENT_LIST = [];
    return { ok: true, msg: 'Comentários parados.' };
  }

  // ══════════════════════════════════════
  //  ASSISTENTE DE IA (AUTO-RESPONDER)
  // ══════════════════════════════════════
  let aiActive = false;
  let aiGeminiKey = '';
  let aiSystemPrompt = '';
  let aiProductDesc = '';
  let aiResponseDelay = 8;
  let aiLoopInterval = null;
  const aiProcessedMessages = new Set();

  function parseChatMessage(msg) {
    const parts = msg.split(':');
    if (parts.length >= 2) {
      const user = parts[0].trim();
      const text = parts.slice(1).join(':').trim();
      return { user, text };
    }
    return { user: '', text: msg.trim() };
  }

  async function responderComIA(user, text) {
    if (!aiGeminiKey) return;
    
    const prompt = `${aiSystemPrompt}\n\nDETALHES DO PRODUTO VENDIDO NA LIVE:\n${aiProductDesc}\n\nPergunta do cliente (${user}): ${text}\n\nResponda em português de forma extremamente curta, simpática e objetiva (máximo 120 caracteres para o chat da live):`;

    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${aiGeminiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        })
      });
      
      const data = await res.json();
      const replyText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (replyText) {
        const cleanReply = replyText.trim();
        console.log(`[IA] Resposta gerada para ${user}: ${cleanReply}`);
        
        setTimeout(() => {
          if (!aiActive) return;
          const result = sendComment(cleanReply);
          if (result.ok) {
            console.log(`[IA] Resposta enviada com sucesso: ${cleanReply}`);
          } else {
            console.warn(`[IA] Falha ao enviar comentário: ${result.msg}`);
          }
        }, aiResponseDelay * 1000);
      }
    } catch (err) {
      console.error('[IA] Erro ao chamar API do Gemini:', err);
    }
  }

  function iniciarLoopIA() {
    if (aiLoopInterval) clearInterval(aiLoopInterval);
    
    aiLoopInterval = setInterval(async () => {
      if (!aiActive || !aiGeminiKey) return;
      
      const lastMessages = collectChat();
      for (const rawMsg of lastMessages) {
        if (!rawMsg) continue;
        
        if (aiProcessedMessages.has(rawMsg)) continue;
        aiProcessedMessages.add(rawMsg);
        if (aiProcessedMessages.size > 200) {
          const firstItem = aiProcessedMessages.values().next().value;
          aiProcessedMessages.delete(firstItem);
        }
        
        const { user, text } = parseChatMessage(rawMsg);
        if (!text || text.length < 3) continue;
        if (user.toLowerCase().includes('live infinity') || user.toLowerCase().includes('moderador') || user.toLowerCase().includes('host')) continue;
        
        await responderComIA(user, text);
      }
    }, 5000);
  }

  // ══════════════════════════════════════
  //  BLOQUEIO POR NOME
  // ══════════════════════════════════════
  let GL_BLOCK_INTERVAL = null;
  let GL_BLOCK_WORDS = [];
  let GL_BLOCKED_USERS = [];

  function startBlockWatch(words) {
    // Evita dupla execução (sidebar.js ofuscado + togcupom.js ambos disparam)
    if (GL_BLOCK_INTERVAL) {
      clearInterval(GL_BLOCK_INTERVAL);
      GL_BLOCK_INTERVAL = null;
    }
    GL_BLOCK_WORDS = words.map(function(w){ return w.toLowerCase().trim(); }).filter(function(w){ return w.length > 0; });
    // Mantém lista de bloqueados entre chamadas para não duplicar
    if (!GL_BLOCKED_USERS) GL_BLOCKED_USERS = [];
    if (!GL_BLOCK_WORDS.length) return { ok: false, msg: 'Adicione pelo menos uma palavra.' };

    GL_BLOCK_INTERVAL = setInterval(function() {
      try {
        // Busca itens da lista de atividade que contenham "acabou de entrar"
        var itens = Array.from(document.querySelectorAll('div, li')).filter(function(el) {
          if (el.children.length === 0) return false;
          var txt = (el.innerText || el.textContent || '').trim();
          return /acabou de entrar|just joined|entrou na live/i.test(txt) && txt.length < 150;
        });

        for (var idx = 0; idx < itens.length; idx++) {
          var item = itens[idx];
          var txt = (item.innerText || item.textContent || '').trim();
          var match = txt.match(/^(.+?)(acabou de entrar|just joined|entrou na live)/i);
          if (!match) continue;

          var userName = match[1].trim();
          var nameLower = userName.toLowerCase();
          var matchedWord = null;
          for (var wi = 0; wi < GL_BLOCK_WORDS.length; wi++) {
            var w = GL_BLOCK_WORDS[wi];
            // Divide o nome em palavras e verifica se alguma é igual à palavra buscada
            var partes = nameLower.split(/[\s_.\-@0-9]+/);
            for (var pi = 0; pi < partes.length; pi++) {
              if (partes[pi] === w) { matchedWord = w; break; }
            }
            if (matchedWord) break;
          }
          if (!matchedWord || GL_BLOCKED_USERS.includes(userName)) continue;

          logBloqueio('🔍 Detectado: ' + userName + ' (palavra: ' + matchedWord + ')', 'warn');

          // Simula hover para o botão "..." aparecer
          item.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
          item.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));

          // Marca como bloqueado ANTES de clicar para evitar duplicata
          GL_BLOCKED_USERS.push(userName);
          if (GL_BLOCKED_USERS.length > 100) GL_BLOCKED_USERS.shift();

          (function(uName, wrd, el) {
            setTimeout(function() {
              // Pega o último botão do item (botão "...")
              var btns = Array.from(el.querySelectorAll('button'));
              var moreBtn = btns[btns.length - 1] || null;

              if (!moreBtn) {
                logBloqueio('⚠️ Botão ... não encontrado para: ' + uName, 'warn');
                return;
              }

              logBloqueio('🖱️ Abrindo menu de: ' + uName, 'info');
              moreBtn.click();

              setTimeout(function() {
                // Procura opção "Bloquear" — TikTok usa span.ml-4.truncate
                var bloquearEl = null;
                var spans = Array.from(document.querySelectorAll('span.ml-4, span[class*="truncate"], li span, [role="menuitem"]'));
                for (var mi = 0; mi < spans.length; mi++) {
                  var t = (spans[mi].innerText || spans[mi].textContent || '').trim().toLowerCase();
                  if ((t.startsWith('bloquear') || t.startsWith('block')) && t.length < 80) {
                    bloquearEl = spans[mi];
                    break;
                  }
                }

                if (bloquearEl) {
                  logBloqueio('✅ Bloqueando: ' + uName, 'ok');
                  bloquearEl.click();
                  atualizarPainelBloqueados(uName, wrd);
                  mostrarStatus('🚫 ' + uName + ' bloqueado!', 'warn', false);

                  // Confirma modal se aparecer
                  setTimeout(function() {
                    var confirmBtn = Array.from(document.querySelectorAll('button')).find(function(b) {
                      var t = (b.innerText || '').trim().toLowerCase();
                      return t === 'confirmar' || t === 'confirm' || t === 'ok';
                    });
                    if (confirmBtn) confirmBtn.click();
                  }, 600);
                } else {
                  document.body.click(); // fecha menu
                  logBloqueio('⚠️ Opção bloquear não encontrada no menu', 'warn');
                }
              }, 700);
            }, 400);
          })(userName, matchedWord, item);

          break; // Um bloqueio por vez
        }
      } catch(e) {
        logBloqueio('❌ Erro bloqueio: ' + e.message, 'err');
      }
    }, 2000);

    return { ok: true, msg: 'Monitorando nomes (' + GL_BLOCK_WORDS.length + ' palavras).' };
  }

  function atualizarPainelBloqueados(userName, palavra) {
    const hora = new Date().toLocaleTimeString('pt-BR');
    enviar({ action: 'bloqueioRegistrado', data: { userName, palavra, hora, total: GL_BLOCKED_USERS.length } });
  }

  function logBloqueio(msg, tipo) {
    // Log no ∞ Log da página
    adicionarLogFlutuante(msg, tipo);
    // Log no sidebar
    enviar({ action: 'blockLogUpdate', data: { msg, tipo } });
  }

  function stopBlockWatch() {
    if (GL_BLOCK_INTERVAL) { clearInterval(GL_BLOCK_INTERVAL); GL_BLOCK_INTERVAL = null; }
    GL_BLOCK_WORDS = []; GL_BLOCKED_USERS = [];
    return { ok: true, msg: 'Monitoramento parado.' };
  }

  // ══════════════════════════════════════
  //  RESPOSTAS AUTOMÁTICAS POR PALAVRA-CHAVE
  // ══════════════════════════════════════
  let autoReplyActive = false;
  let autoReplyRulesStr = '';
  let autoReplyMention = true;
  let autoReplyInterval = null;
  const autoReplyProcessedSet = new Set();

  function parseAutoReplyRules(rulesStr) {
    if (!rulesStr) return [];
    return rulesStr.split('\n').map(line => {
      if (!line.includes('=')) return null;
      const parts = line.split('=');
      const kwPart = parts[0].trim().toLowerCase();
      const respPart = parts.slice(1).join('=').trim();
      if (!kwPart || !respPart) return null;
      const keywords = kwPart.split(',').map(k => k.trim()).filter(Boolean);
      return { keywords, response: respPart };
    }).filter(Boolean);
  }

  function iniciarAutoReplyLoop() {
    if (autoReplyInterval) clearInterval(autoReplyInterval);
    autoReplyInterval = setInterval(() => {
      if (!autoReplyActive || !autoReplyRulesStr) return;
      const rules = parseAutoReplyRules(autoReplyRulesStr);
      if (!rules.length) return;

      const chatMsgs = collectChat();
      for (const rawMsg of chatMsgs) {
        if (!rawMsg || autoReplyProcessedSet.has(rawMsg)) continue;
        autoReplyProcessedSet.add(rawMsg);
        if (autoReplyProcessedSet.size > 200) {
          const first = autoReplyProcessedSet.values().next().value;
          autoReplyProcessedSet.delete(first);
        }

        const { user, text } = parseChatMessage(rawMsg);
        if (!text || text.length < 2) continue;

        const lowerText = text.toLowerCase();
        for (const rule of rules) {
          const match = rule.keywords.some(kw => lowerText.includes(kw));
          if (match) {
            let replyText = rule.response;
            if (autoReplyMention && user) {
              const cleanUser = user.startsWith('@') ? user : '@' + user;
              replyText = `${cleanUser} ${rule.response}`;
            }
            mostrarStatus(`🤖 Auto-resposta: ${replyText.substring(0, 35)}...`, 'info', false);
            sendComment(replyText);
            break;
          }
        }
      }
    }, 3500);
  }

  // ══════════════════════════════════════
  //  INTENÇÃO DE COMPRA (ALERTA DE CARRINHO)
  // ══════════════════════════════════════
  let intentCartActive = false;
  let intentCartMsg = 'garante o seu, finaliza a compra! 🛒';
  let intentCartInterval = null;
  const intentCartProcessedSet = new Set();

  function iniciarIntentCartLoop() {
    if (intentCartInterval) clearInterval(intentCartInterval);
    intentCartInterval = setInterval(() => {
      if (!intentCartActive) return;
      try {
        const elements = Array.from(document.querySelectorAll('div, p, span, li'));
        for (const el of elements) {
          if (el.children.length > 2) continue;
          const txt = (el.innerText || el.textContent || '').trim();
          if (!txt || txt.length > 150) continue;
          if (/adicionou ao carrinho|added to cart|colocou no carrinho/i.test(txt)) {
            if (intentCartProcessedSet.has(txt)) continue;
            intentCartProcessedSet.add(txt);
            if (intentCartProcessedSet.size > 100) {
              const f = intentCartProcessedSet.values().next().value;
              intentCartProcessedSet.delete(f);
            }
            const match = txt.match(/^(.+?)(adicionou ao carrinho|added to cart|colocou no carrinho)/i);
            const userName = match ? match[1].trim() : '';
            if (userName) {
              const cleanUser = userName.startsWith('@') ? userName : '@' + userName;
              const finalMsg = `${cleanUser} ${intentCartMsg}`;
              mostrarStatus(`🛒 Alerta de carrinho: ${userName}`, 'ok', false);
              sendComment(finalMsg);
              break;
            }
          }
        }
      } catch(e) {}
    }, 3000);
  }

  // ══════════════════════════════════════
  //  OFERTA RELÂMPAGO AUTOMÁTICA
  // ══════════════════════════════════════
  let flashSaleActive = false;
  let flashSaleInterval = null;

  function iniciarFlashSaleLoop() {
    if (flashSaleInterval) clearInterval(flashSaleInterval);
    flashSaleInterval = setInterval(() => {
      if (!flashSaleActive) return;
      try {
        const buttons = Array.from(document.querySelectorAll('button, a, div[role="button"]'));
        const targetBtn = buttons.find(b => {
          const t = (b.innerText || b.textContent || '').toLowerCase().trim();
          return (t.includes('duplicar') || t.includes('reiniciar oferta') || t.includes('iniciar oferta') || t.includes('recriar')) && b.offsetParent !== null;
        });
        if (targetBtn) {
          targetBtn.click();
          mostrarStatus('⚡ Oferta relâmpago duplicada!', 'ok', false);
        }
      } catch(e) {}
    }, 8000);
  }

  // ══════════════════════════════════════
  //  AUTOLIMPEZA: extensão atualizada/recarregada
  //  Para todos os intervalos para não gerar erro
  //  "Extension context invalidated"
  // Heartbeat periódico (a cada 60 segundos) quando a extensão está ativa na live
  let heartbeatInterval = setInterval(() => {
    if (!ctxOk()) {
      clearInterval(heartbeatInterval);
      return;
    }
    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail', 'ilDevice', 'ilAcessoValido'], (d) => {
      if (!d.ilAcessoValido || !d.ilAcessoToken || !d.ilAcessoEmail) return;
      
      const streamerName = window.location.pathname.split('/')[1] || 'TikTok Live';
      
      chrome.runtime.sendMessage({
        action: 'sendHeartbeat',
        data: {
          key: d.ilAcessoToken,
          email: d.ilAcessoEmail,
          deviceId: d.ilDevice || '',
          sessionId: sessionId,
          streamerName: streamerName,
          platform: 'tiktok',
          viewers: lastScrapedViewers,
          vendas: lastScrapedVendas,
          gmv: lastScrapedGmv
        }
      });
    });
  }, 60000);

  const _cleanupOnInvalidate = setInterval(() => {
    if (!ctxOk()) {
      clearInterval(_cleanupOnInvalidate);
      clearInterval(metricasInterval);
      clearInterval(heartbeatInterval);
      pararAutoFix();
      pararViolTimer();
      if (GL_BLOCK_INTERVAL) { clearInterval(GL_BLOCK_INTERVAL); GL_BLOCK_INTERVAL = null; }
    }
  }, 2000);

})();
