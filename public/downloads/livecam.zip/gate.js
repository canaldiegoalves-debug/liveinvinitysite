'use strict';
/* LiveCam Infinity — Desbloqueado (Acesso Direto Sem Chave) */
(function () {
  if (window.__livecamInfinityGate) return;
  window.__livecamInfinityGate = true;

  function liberar() {
    try {
      window.postMessage({ source: 'livecam-infinity-gate', licensed: true, version: '1.5.0' }, '*');
    } catch (e) {}
    try {
      var g1 = document.getElementById('lic-cam-gate');
      if (g1 && g1.parentNode) g1.parentNode.removeChild(g1);
      var g2 = document.getElementById('livecam-inf-gate');
      if (g2 && g2.parentNode) g2.parentNode.removeChild(g2);
      var g3 = document.getElementById('livecam-license-modal');
      if (g3 && g3.parentNode) g3.parentNode.removeChild(g3);
    } catch (e) {}
  }

  window.addEventListener('message', function (event) {
    if (event.data && event.data.source === 'livecam-infinity-injector-validate') {
      liberar();
      window.postMessage({ source: 'livecam-infinity-gate-reply', ok: true, data: { status: 'active' } }, '*');
    }
  });

  liberar();
  setInterval(liberar, 1000);
})();
