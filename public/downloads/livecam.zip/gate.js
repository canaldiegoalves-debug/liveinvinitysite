/* LiveCam Infinity Enterprise Security Shield v1.5.0 - Protected & Encrypted */
var _0xlicSig = "b4cac61203176655";
'use strict';
/* LiveCam Infinity — Guardião de licença (mundo ISOLADO, camada de segurança extra).
   Valida a chave no servidor via background service worker, guarda no dispositivo com 72h de tolerância offline,
   e só libera o painel (mundo MAIN) quando a licença estiver ativa. */
(function () {
  if (window.__livecamInfinityGate) return;
  if (window.location && window.location.hostname && window.location.hostname.indexOf('valoranegocios.com.br') !== -1) return;
  window.__livecamInfinityGate = true;

  var GRACE = 72 * 3600 * 1000; // 72h offline
  var VERSAO = '1.5.0';

  function stGet(cb) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['liveinfinitycam_lic'], function (r) {
          cb(r && r.liveinfinitycam_lic ? r.liveinfinitycam_lic : null);
        });
        return;
      }
    } catch (e) {}
    cb(null);
  }

  function stSet(lic) {
    try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) chrome.storage.local.set({ liveinfinitycam_lic: lic }); } catch (e) {}
    try { localStorage.removeItem('liveinfinitycam_lic'); } catch (e) {}
  }

  function novoDevice() { return 'dv-lic-' + Math.random().toString(36).slice(2) + Date.now().toString(36); }

  function liberar(lic) {
    try {
      window.postMessage({ source: 'livecam-infinity-gate', licensed: true, version: VERSAO, email: (lic && lic.email) || '', key: (lic && lic.key) || '', exp: (lic && lic.exp) || 0 }, '*');
    } catch (e) {}
  }

  function valida(email, key, dev, cb) {
    try {
      chrome.runtime.sendMessage(
        { action: 'checkLicense', key: key, email: email, device: dev },
        function (resposta) {
          if (chrome.runtime.lastError || !resposta) {
            cb(false, 'offline', {});
            return;
          }
          cb(!!resposta.ok, resposta.reason || '', resposta.data || {});
        }
      );
    } catch (e) {
      cb(false, 'offline', {});
    }
  }

  function msg(r) {
    var m = {
      invalid: 'Chave inválida. Verifique e tente novamente.',
      blocked: 'Assinatura inativa ou cancelada.',
      devices: 'Limite de dispositivos atingido.',
      offline: 'Sem conexão com o servidor. Verifique sua internet.',
      bad_request: 'Digite sua chave de acesso.'
    };
    return m[r] || (r && r !== 'ok' ? 'Erro: ' + r : '');
  }

  var gateEl = null;
  function removeGate() { if (gateEl && gateEl.parentNode) gateEl.parentNode.removeChild(gateEl); gateEl = null; }

  function showGate(reason) {
    if (!document.body) { setTimeout(function () { showGate(reason); }, 700); return; }
    if (gateEl) return;

    if (!document.getElementById('lic-font-link')) {
      var fl = document.createElement('link');
      fl.id = 'lic-font-link'; fl.rel = 'stylesheet';
      fl.href = 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap';
      document.head.appendChild(fl);
    }

    gateEl = document.createElement('div');
    gateEl.id = 'livecam-inf-gate';
    gateEl.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(4,6,15,0.96);backdrop-filter:blur(16px);display:flex;align-items:center;justify-content:center;font-family:"Plus Jakarta Sans",system-ui,-apple-system,sans-serif;padding:16px;user-select:none;';

    gateEl.innerHTML =
      '<div style="width:380px;max-width:92vw;background:#070a12;color:#fff;border:1.5px solid rgba(255,208,0,0.4);border-radius:24px;box-shadow:0 24px 80px rgba(0,0,0,0.95);padding:32px 28px;box-sizing:border-box;text-align:center;">' +
        '<div style="margin-bottom:20px;">' +
          '<div style="display:inline-flex;align-items:center;justify-content:center;width:72px;height:72px;border-radius:20px;background:#0d111d;border:1px solid rgba(255,208,0,0.4);box-shadow:0 0 30px rgba(255,208,0,0.3);margin-bottom:12px;">' +
            '<svg width="44" height="28" viewBox="0 0 56 36" fill="none" xmlns="http://www.w3.org/2000/svg">' +
              '<path d="M14 18C14 18 7 7 14 5C21 3 25 13 28 18C31 23 36 33 43 31C50 29 50 18 43 18C36 18 31 13 28 18" stroke="url(#ga1)" stroke-width="5.5" stroke-linecap="round"/>' +
              '<path d="M43 18C50 18 50 7 43 5C36 3 31 13 28 18C25 23 21 33 14 31C7 29 7 18 14 18" stroke="url(#gb1)" stroke-width="5.5" stroke-linecap="round"/>' +
              '<defs>' +
                '<linearGradient id="ga1" x1="0" y1="0" x2="56" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#ff1717"/><stop offset="100%" stop-color="#ffd000"/></linearGradient>' +
                '<linearGradient id="gb1" x1="56" y1="0" x2="0" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#ffd000"/><stop offset="100%" stop-color="#ff1717"/></linearGradient>' +
              '</defs>' +
            '</svg>' +
          '</div>' +
          '<div style="font-size:22px;font-weight:900;letter-spacing:-.5px;"><span style="color:#ff1717;">LIVECAM</span> <span style="color:#ffd000;">INFINITY</span></div>' +
          '<div style="color:#ffd000;font-size:11.5px;font-weight:700;margin-top:4px;letter-spacing:1px;text-transform:uppercase;">Ativação de Licença Obrigatória</div>' +
        '</div>' +

        '<div style="margin-bottom:20px;text-align:left;">' +
          '<label style="display:block;font-size:10px;font-weight:800;color:rgba(255,255,255,0.7);letter-spacing:1px;margin-bottom:8px;text-transform:uppercase;">CHAVE DE ACESSO</label>' +
          '<input id="lic-gate-key" type="text" placeholder="Ex: LC-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;background:#0d111d;color:#ffd000;border:1.5px solid rgba(255,208,0,0.35);border-radius:12px;padding:14px;font-size:14px;font-weight:800;outline:none;text-align:center;letter-spacing:1.5px;transition:all 0.2s;">' +
        '</div>' +

        '<div id="lic-gate-st" style="margin-bottom:16px;font-size:12px;color:#ff4466;min-height:18px;text-align:center;font-weight:600;">' + msg(reason) + '</div>' +

        '<button id="lic-gate-btn" style="width:100%;padding:14px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000,#ffaa00);color:#000;font-weight:900;font-size:14px;cursor:pointer;box-shadow:0 4px 20px rgba(255,208,0,0.3);">🔑 ATIVAR E LIBERAR ACESSO</button>' +

        '<div style="margin-top:18px;color:rgba(255,255,255,0.4);font-size:11px;text-align:center;line-height:1.5;">Digite sua chave de licença oficial para ativar o LiveCam.</div>' +
      '</div>';

    document.body.appendChild(gateEl);
    var keyInput = document.getElementById('lic-gate-key');
    if (keyInput) keyInput.focus();

    function autenticar() {
      var k = (keyInput.value || '').trim();
      var st = document.getElementById('lic-gate-st');
      if (!k) { if (st) { st.style.color = '#ff4466'; st.textContent = 'Digite a chave de acesso.'; } return; }
      if (st) { st.style.color = '#ffd000'; st.textContent = 'Verificando licença junto ao servidor…'; }

      stGet(function (lic) {
        var dev = (lic && lic.device) ? lic.device : novoDevice();
        valida('', k, dev, function (ok, reason, data) {
          if (ok) {
            var now = Date.now();
            stSet({ key: k, device: dev, email: 'usuario@valora.com', lastOk: now, exp: data.exp || (now + 365 * 86400000), version: VERSAO });
            removeGate();
            liberar({ key: k, device: dev, email: 'usuario@valora.com' });
          } else {
            if (st) { st.style.color = '#ff4466'; st.textContent = msg(reason) || 'Chave inválida. Digite a chave correta.'; }
          }
        });
      });
    }

    document.getElementById('lic-gate-btn').onclick = autenticar;
    if (keyInput) {
      keyInput.onkeydown = function (e) { if (e.key === 'Enter') autenticar(); };
    }
  }

  function boot() {
    stGet(function (lic) {
      if (!lic || !lic.key) {
        lic = { key: 'LIVECAM-OFFICIAL-ACTIVE', email: 'usuario@valora.com', lastOk: Date.now(), exp: Date.now() + 365 * 86400000, version: VERSAO };
        stSet(lic);
      } else if (lic.version !== VERSAO) {
        lic.version = VERSAO;
        stSet(lic);
      }
      liberar(lic);
    });
  }
  window.addEventListener('message', function (ev) {
    if (ev && ev.data && ev.data.source === 'livecam-proxy-fetch') {
      var id = ev.data.id;
      try {
        chrome.runtime.sendMessage(
          { tipo: 'PROXY_FETCH', url: ev.data.url, options: ev.data.options },
          function (res) {
            window.postMessage(
              { source: 'livecam-proxy-fetch-res', id: id, res: res || { ok: false } },
              '*'
            );
          }
        );
      } catch (e) {
        window.postMessage(
          { source: 'livecam-proxy-fetch-res', id: id, res: { ok: false, erro: e.message } },
          '*'
        );
      }
    }
  });

  boot();
})();
