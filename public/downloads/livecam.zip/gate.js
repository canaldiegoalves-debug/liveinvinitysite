'use strict';
/* LiveCam — Guardião de licença (mundo isolado).
   Valida a chave no servidor, guarda no dispositivo com 72h de tolerância offline,
   e só libera o painel (mundo MAIN) quando a licença estiver ativa. */
(function () {
  if (window.__vidcamGate) return;
  window.__vidcamGate = true;

  var API = 'https://api.valoranegocios.com.br';
  var GRACE = 72 * 3600 * 1000; // 72h offline
  var LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAABnCAYAAABxTpuQAABau0lEQVR4nO39d5wkV3m3D1/3OVUdJ2+OymklgcQKBEigFUkEmTwLmJzEg3lssAEbG9u7AxhsDAYeDDbYJphkdsHkJEABJCEJSUhaaaVV2Jwnz3SsqnPu949TPbtKIIG8wr+3Lz7NrGa6q6urq7515wNdunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0qVLly5dunTp0uWRRx7pHfhdUFRYh2zc/Os+x8aHtM3hVcMKsH7uN+tZP7JeoXOwRB/qfnbp0qXLw4YOq9V1ah6R91aVS8/TaN0j9P5dunR5+Ige6R14qKiqiIgD+PHSa+bNe8qC5aaivXEhkppvSerRKIpo+0yyVoZ61FjrU1LUoM4gEJO0U82ylCiK8Wo9BedcEvnMW5+peokl9ZnNWpO0btm9pXnzti1p0055EZkBMi4HXadGRtCuVdily/9O/le5wEFwxO8a3vvi/sG+i8xx9kydz2CxUrRaELyC5lqkCt55vCpePKoCDlADHlyseK+oE7yDJPVkbXCJetdC06b65pRoq65pu+latUaa+kxcLU12tl1y2c7Z7f/9/l+eex3AOtSMIP6RPDZdunR56PyvEcCO+I2+dPR985fPfze9wD7wo6j3Xr1HVQ0q4DPUe8RZ8IJ6RZ1DnAsq5Ty4GDILmUczH/6WadDIxEMKJAkmc0EzU6Dzb4lhyjd0n9vzhW/seedbb9rxramuCHbp8r+P/xUCqMNqZaO4nRfsuWDF8qU/pETi70Z01FuxBq+Icx6vBu9R58EDTiBTcA5N8eK8IRMkAzxoqpAJmoA4IBUvTo2mgiYGMo+kCpnx6jCaAm0cqRWvxphyhWia/Zt2meuf/y9XXLi1K4Jduvzv4n9HIH8VClAtl99BjPN7vNdJb7SEOuvVqfeZ4jPwqXhNxfsE79s+PFrifQt8y3htiacpnqbx0oq8tKyXJIIkQlJrSKyXtvGS4Gmrl7Z6SVXDT++NU6xzxG2X2YMzrh27xafP53Hfv3D1h+azDtax7n/HMe3SpcvvvwXYcX2vP/fmR5256PSbBGAcSMjNvPBIsvCfKeB9cHMzDY9EIc3d20zQ1EPq0MRBgifJN5MSnpcao2rAWyQxSGqdJh5NPZKKkgqSCerEk1iTlKtRaXvzzv/6z5tOfNnwsNqNG0OSpkuXLr/f/F4KYKe+j83I9YPXm9WTq/21+246biAZ/GSxFS+2WJ/4zCTekTmviVdxqqTOkODJfKqperzaxEam1qLlGq20b6beXtHIskEXIXaelXjIEFcLYnospmiClrqI1oxqVhetHzCSTvdKQaoalSOkaiWzSOIFZ1BnPakFZ6xzsYt3yU1PLL/zcdcOTl5vlly02gGMrAdYD+tDLWE44t2scZcuvw/83gigosIwhlWojDxscbTyibziCSdx5rOWDy1fs/jUweNOfMyC/mNOH2LRyirl3iJxFKmPjLhYxFs0s54k8tpMMqZnGrJtc0t2X5Pprl+i6V0liV1MuRxJFEfazow2EWnF1lEoxfuTg1/80e5Fr3xQn1dV1oI5CLJw40bduHZt12rs0uUI83shgJ0kR+e/Jx/9q4HykhVLZ0wyX0piozjSrOVsbCPRyDrSTNpZYlHrU6O+PYvMNBtmRbRQb6/dab6w89KB2Ynmkyz9z3nUWWcc+8Qnn8wJqwdZuNRCjJIBChRRH4MvQ1pCMgvOQhKhqYU0QlwBEovONBK23d6WzVe3uf1Am7aJdEkc0VexZAdSnWlFZrrVGi8+d+o1/Y9ZuWc88e2x6Ua7sdO7Rm02K8y61r6tU43dH/lRG0buI/AdQdwoXfe5S5cjxSMugB3xu4V1haNe/ObhQk/vS6Nq8SwjdgGKxXIouOcIwpUALSBRtNFG6oImlruS/fx05w1smRrnqDOO5kkvWMWjH7soiwyOOpYSQj/GFWAsa7N3ZkKn6pO6b2xGZpqIKSrFimdwXo/2DM3XwaVDUplXFltAWx6tGSSLYGIykRtuafPzLYnfXS7I0hVlWbpAGShbKcYGV1ScaFY03ptIPPhMrDSNNTX1PkmdOoyOTXvdNz2T3Dy1N730p2fP+wXAOlUzIt1McpcuR4JHVAA74jd9we7nlpcMvTceLD+KDDjo8FNNT815Ug+Zw3jAOSHN1DuPOsicx7hYxjXhJ81NevPEbvH9PXrB68/SpzzjFLV1rKsjdgClB7nxwJ1cfsutcsOmndy9e1qnZg2zmScRi4ur4q3iTaYSgTWZDvRE5vhjB3jsY5bqYx9/oi459XjJKjCZIEXjaEx5fnJFUz97TSbTxR5MRYhi9XHFSFRGilUjhaqhUISoCMUSlHugVIByEXp7oLcX4kyZbieXHziYfeCyY3t+pKoSQoXdWGGXLv+TPGIC2BG/5vDk+tKCgXUUgbtaKVvb0HQG9QJeQymzU7wXvAdVvPd4VCLbo7emE/Lj6Rt1a2uc484+Tl74+ieyYn6/95NOzHwr7R78t6+5Qjf88Epz5+0TeAakUO3FFI1636CZzdBsz5Bks+KN4GwBShXV6nxNKoOmZav4ZktL2bieuELkmc87gye96ElSGCwz0cZXi5iJHQ0+/Y0Gl9ersKCspBnERokRYiNE6GEPIQIERbzGsWHZAHbViZi+Koztb33kJ0vK71inyghoVwS7dPmf4xERwDnxe+74e0orhv6Gtk/95oaYscwQ5bvkPXinXp0Y9Yp6wSlOPVYFR5Ff1Pdw9eztciCp85hXncbw8x9PNAkoymL47uar5FP/dbHffmdbe+P5plTwTLd2ycTUNlqMaaGklIdiehbOQwdL0nSJJt7TrLVpjs1oe7Jp1JWIFx6nuvhMZpkH0+NyzMImr3vDY3niy5+hkxbaHgaTTL74+YN8eXdBzdHz0dRBQYSSgQgkRrEwJ4AWNEJVEATFe3/8CsOpxxKN7at/6cqlPa8YVrUPX0xQ5f6yz4r+2nNAHpaMtf7ajTw87/GQEOX+3/Lh2xcVFFi/Xli/PvxqPbA+f+Puje33giMugB3xm3je7j8YXLbs2zSylJvbhjZCpErmwWlo0FWnqMd7L0YJ4ieGWadcNTumd9S2y+5slKe85Wy5YM1ppPsz4kURu5Mpv+4/PsOvrtor/cXlFIp1HZ24gelsr8xfMo/VT320POrcM1hx6gkaLepj1Hp2mUwmsoxJ5/TgbMp0LdED2w+Yseu30PjlTepuv1UlK4o5+sm0+s4UPbCTs05x+sb3vYZFZ6yQvaljcWz1ki9ukU9cDTz+JKXt0YIRLCH5EoRPiAEL2CCKYoECaAorFvv09ONNce+2mXfeeGz/h34nEVSVdZdh16/BSfeCA2ADG+xLeIl7IAH8rVEVQmOBAJ7fFMcVYdh7u/HBPr/L/whHVAA1vyvuPev68rzTT95UrFSP4bqGo2UMRvHOYZwq3hvUK96r915QjypYY2QscXrl5JjuT/fKne27ueCPn8zTn3SqtPclFJcX+Om2m3jfx77oObCQocGSHJz5JRPNu/1JJx0rL/7DF8gzXr6G+ccNCUDDo7unZtl0cJTttbocrLeYTJ3ub7SYRpgpFGQ2qtKoWW3sGNPW5T+T7KcbkTQSs+qlmrj5FGt3yZveuUbXXPQM2dFyLC1ZfvWVW/WDP5hCnnMOrumDAEZGc+E7TAC9Eplw2URgCohv4U45BQarWWPn9/at2r125Z5gJz54AVunak4FWXuYcCrrImEkO/x53z/+jmI8bktb2YrzbTNjGr4sbW1qUZrS1n0Te+TTvGsGfje1+PDyDWUzu6DYnh5VGKTZv1uYjjz0mKOPOprX7jhz6tCzg7X4P2EVKiqd7b6r/5OD0E8/INM1v6J/lVlaODE9f3RR7aFtVIPo3ecmta7AB15UXfb4pdViyZdjJ0ajLGlNtls7bxpr8K6zpu+1nXzcZPdGdSQ5sgJ4nkZyuWQzLzr4xt7lCz7NnS5hTxb5SDCZw3mPeMV4FbxXrw48eO+IjJF9SarXTtZ1Wsfl+tqVcu4bnqDDFzxe2rsTiscX+NIvLuVDH/oaxxZOVyns1z0T10hPNdbXnveH+sLznyWlx/ULpyBpf6aoF1OMtA2M1TP21Buyu5Gwt+XYV0t070ybbeM1OTDbIEkybfqYtDiP5v5ZSb77Obj2G9hlT/J+2YXidtzEC159Ji/7wMvZ3UhlaSXml5/+pX74sqaYFz9Z/JRTCjYI4GEuMFHuFod/IxZR0EJEeubZFBtbZ/9603F9f3eeanS5SPZrDi2oyjCYDeA71t65G+5Y8KonL32+VIuvvHUyaV38H9suvHX9qenGtZi1G8W957irV5/RPP0HzlnnvDfGoOLBiBpFkkhdabcf+8T/GT9m3aVcGp3P+b9+H+69S7ng/Pe88Yv7pLI6waeCkKliRNKqUJ5m5kvPG1381uvQeDV4CW3ZCMJX8XYtD08IoNOn/ZnBbc9eVBx4v3i7BLUIirGk/WIr9Wj2M0/dtfAdl6LR+fzG4x1aHnPLbeWXdgw2H9XzuEJ/6UnlcrQ6juRYpzpYKttiZCjmF1omTlOf+lbTm92Jy+5KZ9pXJVunfrr/aUdvfjg+Z5eHxpGdB7gGz+Ug5fLLaaFMeKFgMA7AICoh9qe+M7ZKvapENmJvK9Xrp9o4cXL97DWc8MxVOvz0x5PsTCiuKPDZy36qn/jIf8vp/Y/TmWwTByd+JatWnMDfPOXtcnSyGPfLcZJlHnt6H3EhBBqb9VQmdtX17h112TraYseUYywTHVPPTMHQigcxOiDaaqqfmdVs7E4xRrBPfyOsfKJm3/8HkaltUjz9T/Qbn7mZLHO86h9fpVubGasveizP33WpfvPbV2Kfew5u1oMx4ZZzeLewIoSopagHYkhqmAOzaDxUfD7w/stDAdD9cri1tzHMf2Dt9tpjTuyJX7+oal48XooWXgdcdTdp38nLlorI9uHhDQjCf9z9g1tHFp/UGooGVrR9OBnEAhoqjyxQ8f4Vq7nofWtY85DEbx3rjCD+o4O3rIyi/vMyYwvhgwa8Dx9qd7rr8lwo0/CX86J/XPSx4jsPnFFfi7jDrbbflnWsM+sRXbby9mMWthZ/vVdKpbo99PfE4J1gRtPpfQ9qg6q2Y/EtuGH8iXF/6U0MFJ9RrdrFpgjOQdIGn0C9ASJgMtQIRbFgCmD7WFwmOqs6r/TS5sJqKqPN6+Tm2mv3PmX+HQSLsusSHwGOmAAqKjIi/uazf7Go0FN4NFMqODFecgEQASQ4QN6qx+NQiU2kO9qpbJpuYW2Zm2Z/gTm2l9e+4mni9mQU5hf4/i2/4OP/9BVO61tDLbuB8dlNnHfME/ibc99BZaKmjW03U6r2U7ijDM+y1K+bZOfF+9m9rcWBFPYYowdjI5NimURkiowZr4zhqOMV68kKkXi3gGTXNvWzP5Vo8QkSPfuDmv307zS97v0UzngH3/nsjfQtqPLMP38RW9uOZ687n1tf+nW58+Nap5wOn7GBYURFSLptMbpXH0j4WJRRWYOIP2L7XE9X9ozryYydg83WFU2gBkO1p4HWH3dRP8ZK6vPXNQjb+iL7ZpGZKIfZrAL0tk7vezfiVkQMQhs37hhWC+V4eh8pDWRvnpjnwz8aaqkGT5CDQZQ9VrHEFM55mUL/uhsGZUrNrDBruXBdaysYb0ZYcTH0rvGGluoKwlKpKAOrwWM3ZdO7//OxJd/8hZG9H1DVy1bZU7+m9hU1+BN9RtD0wf32/GPyaj85+86ZWcN640wkn2xOf+l5ahUGvO0gIKGTar3xk8qkjq3CWD0gVz+dWp4j/GIuMqVk2eaZZWRtBBdmPYY8XVwM7g0w6cOURDUB1PWhBmUdP7fhEdk0FKMj3ujQqY83uypJ8gCZd2vT0x1efg4chbgOoQRdP7gUStjEw9QVwdGDKrhNBRAVVQAEa8QG9H9LeXmmZSYfna2buFO3cmfXfQKqg2rlLxsnjjAe/7pP3lU4WzabgvjtU087qhH6d+d/9e4W28zSdSm8oenKv1G/JiX2b++m4mtDXwxoqe/qtpjsCVLOTZSRbUIGntPIXN4pyKthGajTjKd4NVjSwtFplpk11+LWbiM6Ox3kl35D5Jt+giFU/9Cv/ShS2X5qqP06AvPYhJ41XvP572v+iZu2Txk4dIwiUFyEzBYWxLsP0Dp5GSlPo3a+TIYLysvAcYAWacqHWtvbW4Vvnxv8thlg/blA1ZfZGO7fBy4IkG3tkmdYAfBbr3bqFFjdyWmBMBG5JNsVICDjP3XkFv+NiSONN+zYOoZESWLbWTLfv4wcMUChh/0hdkRkUjLf+AU2uqNqDEKqpisIkhD2z/9ISMzf1n9yaLj7WmXDtneE2YVvIHY9C0/lr7Pf2rw7sKbJuXfN6C/tTvc2Ze2N2c1HJoqFkHAqAMEbF2dTDN5EODW+xPADWpZK26YYfv9Kz/3nvbi4p/byEbJKC7dj1NDhMEguX1vQMSE7cxJtxfy3ymYTKHW9lAS4vHkivRVR2/Lb3Rd6+8IceRGN+ULF1UrxQUSCTjjMQYvAiIoggdxGElBIjGMp8Km2UwsRWpS41eta+TUp5zCo1cu1Ww6k6zPsO6L/8L8xjFoYYrR2q84Zt7RvOdJ62hvuU2yqmr0948X95cD4l/ah99aI7ouobenh/6hKv3livSZAoMaMR/RJSq6HGU5jqVkLCZhXtEwWO6nN65SaINMNBDbK7ayFL/tLnTP7RKd/hbUg7/785hFZ+l//NUX0Ylp2qmToVOGeN4rT1f331dgrQuH3GlQGUf4GbpcNIyjCb93TbSNQRYUKwCrr8eOiPi1Io5bpobePt149Qdb7idnLbDX9JbMW2+P7fJvZ2TfSsi2KVoUor4CUtsFtbHwFWSzh76Ojax1isrfj3/v+nE/ewtgUsWnms9AVDQBU1cQ03vheawrnY/J+A1lMwGVtYh7Jh/rs1J40myYyGPaiiYKiUfqCjPUvwuwJD7+jX30nrDL0Zzx+JrDT6pPpx0+ksF3P375h8vDQUZ+K8voJRgHw9aJObGpSDt8Vtr5pKBMMU3Xro3Wdo4BrL+3AObiN/jRiZXfuObzP2wurvxVNmttew9p0sJoRkyGhKm5QIqSkmmK0wzUY9Rh1BmjDtHwXE9KJs5kAkhTbgXgMixdjhhHTAAvO3iZACTtdBAgZDvA5Ke0SAiOKYIRw6yDm2cUp5EiJd3WvI2JUqYv/INzlTGI5kX6lasu0V3Xj+mivnmMN66HQqbrn/ludGyf1PZPU77gMcIZXgHvZxONJNLqaYtoTSZ6x/aDeuv2/f62/fv0xm13ceMtW9h8651su30r++/eSX3/QczUDD31GXqTKXptRH/PAkoaYWbralykJl6I27kVJvZijnkl2eSNEjVvYWxsAd9931d0QWzZ57ye+5pHyaIoFXfFdWIqQKo6N3+rI4BJ/shFUNuoz0BLlRjg+rMkfcOknrGu7T76kZN6bz6+r/y5maJ56qVi/DdT0hsSfM1j+sD2GMQIWgL2dULrbWDmnmG89WBhxNfczFecQqrGZ6AZkCqSeUzD4YxWj33cwPPOBmWYjb/xnNmQn1dr+p79hILpX9RUXKZG0jCWzCtE02lt/K7kV5cCJM6dWhdcClHbI21F2p6opkjmzMKhseJCQXQd634LAVRRlCfOO6viMQsb+WFuA21FEu/JgJpm05c1vzoG91LZXPyGvjC2auZxPVdkUflpfjcJM0CbKBc7zb8/JcEhGMrEFIilhZGZNJNa2pJ6VjezaSZNh0RYqsSqlGiLSj371UP/bF1+V46YC7yGNQCkKmHuFKH8wytgDeo9TkKeIElFN80qqVq8iEwxw+bkNladdyLHzx+EUS+TPuFz3/wuywurmEi2MOp28ebHvkmO1kVcf+vXdPVxL1O/pylsKsJQItF/tWTKOm6+5pdaeGoJe2qZS75wFTf8cBfG9EO1qC2fkYiQWsiKMa5Uxg70U14wAL0liCuU5q1Q12xLMrtHjLfqTI+muzaJXXYWZv4FpNu/TnTC27nkq7/i3Dfu1sJJy0y7r6jnvmiVfv0zNxOffpIkpQEh84oxc/GguUd+9akBTaDYCmLyT7PNDxZL/h31yMiNwN0p6bRHrCBFgy0K4oKNpKJQKSDtfTA+6kWKJsQZ2vexoDzAtuzOr1fMwpGCqcSuE4sMy6qIguvB2gFZ+Hzg8lUPwg2+Nf8URTPvAkDbihfFaEiu+Ipgp1z90n+tv+ggwKxP7mw6bFNJwUcAXsnKYNvqJ9PWtjEQRlivMPKQzjvND+kTonPL3sWFhGCAdz58ZxmZVGTycj6fzn16CJleEbfkU6Mnj64cuNipXcY4CYZ4znQQBIMCjhKRlDBmNj3gp/xPZCy73ExkN5oDs1MiLpPe2GnkCn5osOjLcpT0m8f6orlQGsWz3MHGzUBIFHY5YhwxAbws/+kMczERf9il5AWMEXWqclsNmt7iJcNpQXcld8qomeS15z0LaghDho2/+Dnje1Pm9xnZP7uFRT1L5A9XvESvue4HHGXOChf7VsV8ZlbTybZecfet3H7ndmlUm3rR37+OaqkkT3z9avnehqv03z54sd7xqzEpFwcp9ZVw3ikuwbVSae2vMX1gL3bePJWBXskqoxSWHEtWr6mbncSYorgsQg/eiPSfpTpxA0xcTktPkh9//Ou86JNv1f3AGc88hu/952aS629VOf8c0RnAerBG8RwSPyXPCXtxqUFT2rAu+s73m285dW1JbnC0nRJFQjQQLryOUGEMioabSgm46zaAPOakkPrsHuI1gvh1qBmZlTv/um/PLxYWK+elYYas7UiAV2wDiEzluc/kY+96D6Z92J7eL+/BZLDOeKJn1EEyDfvX2dm2wpQb/1an5u9V7jv/XnVL/njA9g808kWrjBB7hf26/0M/5sP13zYGuD7f13bbLnGR6XOK+nx/QprCaAS0tb0XcIoaobOKFjz6I5MDW5b1fDvL7DJmSLFEoXYmRBExKBmOAWKZyg7auxr/ULrl7i/UPvCYUYVfp2a3At8XGCl8aPsT+xcWNx0AuvG/I8sRc4HX5D+dzwq0CSe5CbvgBUQMGGTLlDCbWEBoq6Hp27KteQc9S/o5Y+UKaIRFi7572RXMsyuYznYwrnt57srn+ca+GTmwr8aAW6mt2Qb1sVn233BQvvCzH8qVN21mtu5pL1eJrIhPPVYtz3/pk2TDVX8pf/6vz5B4+TRbR7fKTG1KsqxOuzlLljTAJbRHD0hj116yfaMk+27CrFyFRjHqU7A9+Po42p6Evifgx3+F9Axy3cVbqO2dpA3ac+wAj37sYvymXWKmaiHdENxfIQMSL3O+WcuLb4CbhfpoGp8HXHpVsbHlCq9LLXGv86bMnNEosaAFQQuKFICeIiSjsH83EIUOExzgc9PmHmvFX2ZAqPnxL2f55Oz8IYkimXpT87iIvmNX9Z97rqJs4IHXRF6HGkV5R/W5pyGlk2sh7meSMKFbvRJPudr0XXrtT0B0LZgvtJ678w537bP2pnuvaqQzjXo2U59Np266I73rovfPrvroOtQ8BPGTPE4pAJvZGEIvTiopsUkUl+Sxv1b4jJoCLfUT+aHpHCMjIv72eeV/bRWjE5gkwRHNxW5D+EJxOOkhNnua39QfHDgre3n/P9U+8JhRVC2XaoSqYd39PDaEv6tA6x1HX3XgVUvqD/LzdXkYOfLrAgsGB14RLHgfemGNhS3jMJlYRJCWU1KNmdJ97PEHOO2Ek+mLIrCwZXIXe7ZOyOLCQkbb16s1sTy5skau2nGNFrIl7G9OiRdHSxv6gwM/171j4/QX+2S6PYPXJIiPGnGZ0yRVLccVeeObLtQXvORc+cynfsCn/t8l7N6bUi4PImR418JHRc3qmaCpmKaqLw6KWXmmpjd9P0/j9qH1bVA9HT99GVG6S2dny3L7xdex/DVPZxw49bwVXHPpDrhjK5z2qGAKmc5RMcFbMx7UKM6JrwP1zFzOiJrBv5KfXmzkD+Zn2n9yxGyKxrmfajRYIz5vquoHbtjs0cwghVBWiSeMELsXI1zmQdlTuOF7ve64WslUqhkei1FVUIwo+IKxtmIWvhD46a33CpPdCwPii7rgGZHEtu5J1eTnmccXBVPX2pUbG6/dr6jZCDwNjd80K1cD5/xh6YtHQYkvt168h6CZIr+mBCaswbLenAr6EozTYBDnB1VYxbBdx6UybgaqmQqZ5uce4Xh5wk0jQ7dD7r7ncb/qv0y+oN5ffAkHSTHE5HWaHd8Zi6NKbLbOfNy9vP9PALhUI9bg7tsZ8oAIGzYY1q7tbPX+URU2YliAzFkTHS4DRlGG8b+2k0R/TQLr3q9bt86wfv3cjaSzBXhQ73FYMCd/3fr1ysh952A+0hzxBXxMFCsOTKcEWNAogq3TXkYboVC47SHR0Dg36g8yTcLJxy2FRmgju/q222m1I21JnYNul6wsHq3zsnncNrVT1FXZ1RzV7a2DXDtxJ9eN3S7OwL5sgnFqzJKgJi9WbQlZy0ij7qnNZjLUN8Cf/8XL+Nl1f8eb3/YEnJ1manYcrynqGuKzOq45oy6zwq6b0b5+TO98NG2CVNGkAZqJlI5FZ24UigvYdOltWgZqwNJHz6dUKeLu2qGSuXzZurBACYkTUhfMr7YTWh5NIUsiAVQyUV+CS78IPQc9/TFSVCgYtNNZFwtaLKDplGf3NqAImuQWpgcK0f2cuCN+A2o3Trxmz6wbv0wUydS4JGSDJQMyMA0PQv9zhvlweST8+oEuJg+KmPIFzWBpSerzj5Vbl7PZ1LdA2AiyFnFvmiuChi+3XrHjy60X7yCvxnmgImhFZQNqRxjxI0iWF00D2PM4LwKsoowgyQjnZ2XbN+gJIyQzIJWwL5miLWDW12sA+0AYxp933rZSq1D9gNZQOscwo5OoEjK89BDb7bX/dC/v/xNULevUcL5kD7GdTQnTwO/7GlXJrchQA7pWXL79ez7Ol4y14hDRuf24P0T0AR8d1qlB1TIy4hFx93qvQ+9xf/saCsT1fl83MuLD636/ahyPuAXo86/aa7j+4xh2jyF7Z4JL3PL5IkYET2MyGydFOWr5kNAGKnDznduI6JWWn2GGaU4pPkq2z0zqzsasLtQme924SDnm0olrSIBxX8NbJUOpSBRSpBq6EURAXVhPeGbKozgWL1jIRz/yJnnt65/CyPov842v3wbSq+X+XskyR9qKiZOmMrEFWbYKDtwFNgJXFLJp1dKJ+NkfQz/svW0fppaSVWJ6j+5n6fJetu6ZFJmYUK0sgDQ7dPdVDVVkHsT4PBssAqj34iSCGYm4+MsJz3lzhItNx4IOUXiPVCxsugWyxCAxeZWlCdpwrxhgh1u5TAAZc/u/1GtXXJirkRIODyjGC1mB6lHzq888h/rbfzKMmo33cUtVRhD/Ar6+0Ev1sfVQ7ROK/8KZb6eyWm1cr/s+KP/Ap4tvq975jwWNB1FSEwrnREBLxkQH/MGL/6Wx+rP3LoQeRm3eMuf+hHTdyoF4yQug8EREToBCDyLmyZI4IZrKnL+7ztRPUifHJxbSzkgczc0ZQdqAs9EYwJZXb7fIMemNH6j9oS/EJzFLRoSdi3qGeK2jgmU0uXv+h6/6owOqhvUoD99SDod3m2QAla9vX+KP7jvBiZyg1vSZ3mLsxVhTbyfiZFo0uT2+qXHbrMh4/npzj3jiRdfF/e3jqqYxoT6ODLFXs7hf/f5psUenfmLkxJm59xwBvrBrefmUnsdqf/lYLGWT0tLZ2bsKP69dNi0ydY/tH/q36//kzYPNMxc/3gwUT6W3XDaZb2rq7irvGP/lhMieznny+7IuzhEXwExDFbA3EBeR8Sl0+yhqjKGVHlqU3KnRlsJodp44n6p424t/hFm3d7yZ4f+5s0m4+f80x/8R1P7gUp1c6y4YIqUjJqE27/mD/r4x98p95f/gX/nQ9T7z5bZulCee1b3c9s5n7eYy14/8L6v0+U1V76Y3sE3s2l2P7vu2m7u2b1dLd1+q7Q8m6n5n4e0P9W5iI/u3eU++n269/wLh/4+7Pvf4x3tG+TfLz5d2yGimN4HjP9877bY9J3/n+/+0q1Lly6//7x4/w/aW1r/P8S+9AAAAABJRU5ErkJggg==';

  function stGet(cb) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['vcLic'], function (r) { cb(r && r.vcLic ? r.vcLic : null); });
        return;
      }
    } catch (e) {}
    try { var v = localStorage.getItem('vc-lic'); cb(v ? JSON.parse(v) : null); } catch (e) { cb(null); }
  }
  function stSet(lic) {
    try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) chrome.storage.local.set({ vcLic: lic }); } catch (e) {}
    try { localStorage.setItem('vc-lic', JSON.stringify(lic)); } catch (e) {}
  }
  function novoDevice() { return 'dv-' + Math.random().toString(36).slice(2) + Date.now().toString(36); }
  function expRoll(lic) { var now = Date.now(); if (!lic) return lic; if (!lic.activated) lic.activated = now; if (!lic.exp) lic.exp = now + 30 * 86400000; while (lic.exp && now >= lic.exp) lic.exp += 30 * 86400000; return lic; }
  function liberar(lic) { try { var _v = ''; try { _v = chrome.runtime.getManifest().version; } catch (e2) {} lic = lic || {}; window.postMessage({ source: 'vidcam-gate', licensed: true, version: _v, email: lic.email || '', key: lic.key || '', exp: lic.exp || 0 }, '*'); } catch (e) {} }

  function valida(key, dev, cb) {
    fetch(API + '/api/check', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: key, device: dev }) })
      .then(function (r) { return r.json(); })
      .then(function (j) { cb(!!j.ok, j.reason || '', j || {}); })
      .catch(function () { cb(false, 'offline', {}); });
  }

  function msg(r) {
    var m = {
      invalid: 'Chave inválida. Confira e tente de novo.',
      blocked: 'Assinatura inativa ou cancelada.',
      devices: 'Chave já em uso no máximo de 2 computadores.',
      offline: 'Sem conexão com o servidor de licenças. Verifique sua internet.',
      bad_request: 'Digite a sua chave.'
    };
    return m[r] || (r ? 'Erro: ' + r : '');
  }

  var gateEl = null;
  function removeGate() { if (gateEl && gateEl.parentNode) gateEl.parentNode.removeChild(gateEl); gateEl = null; }
  function showGate(reason) {
    if (!document.body) { setTimeout(function () { showGate(reason); }, 700); return; }
    removeGate();
    gateEl = document.createElement('div');
    gateEl.id = 'vc-gate';
    gateEl.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(6,9,20,.92);display:flex;align-items:center;justify-content:center;font-family:-apple-system,Segoe UI,Roboto,sans-serif';
    gateEl.innerHTML =
      '<div style="background:#141414;border:1px solid #333;border-radius:16px;padding:26px;width:340px;box-shadow:0 10px 40px rgba(0,0,0,.6);text-align:center;color:#fff">' +
      '<img src="' + LOGO + '" alt="LiveCam" style="display:block;height:46px;object-fit:contain;margin:0 auto 4px"/>' +
      '<div style="color:#9aa3c7;font-size:13px;margin:8px 0 16px">Ative a LiveCam com a sua chave de acesso.</div>' +
      '<input id="vc-key" type="text" placeholder="LIVECAM-XXXX-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;padding:11px;border:1px solid #444;border-radius:9px;background:#0d0d0d;color:#fff;font-family:monospace;font-size:14px;text-align:center;text-transform:uppercase"/>' +
      '<button id="vc-ativar" style="width:100%;margin-top:10px;padding:12px;border:0;border-radius:10px;background:#1db954;color:#fff;font-weight:700;font-size:14px;cursor:pointer">Ativar</button>' +
      '<div id="vc-erro" style="color:#fe5c5c;font-size:12px;margin-top:10px;min-height:16px">' + (reason ? msg(reason) : '') + '</div>' +
      '<div style="color:#7a86b6;font-size:11px;margin-top:8px;line-height:1.5">Não tem a chave? Recupere pelo e-mail da compra em:<br><a href="https://api.valoranegocios.com.br/ativar-livecam" target="_blank" rel="noopener" style="color:#8fb7ff;font-weight:700;text-decoration:underline;cursor:pointer">api.valoranegocios.com.br/ativar-livecam</a></div>' +
      '</div>';
    document.documentElement.appendChild(gateEl);
    var inp = document.getElementById('vc-key');
    var btn = document.getElementById('vc-ativar');
    var err = document.getElementById('vc-erro');
    function tentar() {
      var key = (inp.value || '').trim().toUpperCase();
      if (!key) { err.textContent = 'Digite a sua chave.'; return; }
      btn.textContent = 'Ativando…'; btn.disabled = true; err.textContent = '';
      var dev = novoDevice();
      valida(key, dev, function (ok, reason, j) {
        if (ok) { var lic2 = expRoll({ key: key, device: dev, email: (j && j.email) || '', activated: Date.now(), lastOk: Date.now() }); stSet(lic2); removeGate(); liberar(lic2); }
        else { btn.textContent = 'Ativar'; btn.disabled = false; err.textContent = msg(reason); }
      });
    }
    btn.onclick = tentar;
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') tentar(); });
    setTimeout(function () { try { inp.focus(); } catch (e) {} }, 100);
  }

  function boot() {
    stGet(function (lic) {
      if (lic && lic.key) {
        var dev = lic.device || novoDevice(); lic.device = dev;
        valida(lic.key, dev, function (ok, reason, j) {
          if (ok) { if (j && j.email) lic.email = j.email; lic.lastOk = Date.now(); expRoll(lic); stSet(lic); liberar(lic); }
          else if (reason === 'offline' && lic.lastOk && (Date.now() - lic.lastOk < GRACE)) { expRoll(lic); liberar(lic); }
          else { stSet(lic); showGate(reason); }
        });
      } else {
        showGate('');
      }
    });
  }
  boot();
})();
