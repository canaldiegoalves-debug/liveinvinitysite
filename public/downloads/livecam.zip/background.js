// Live Infinity Cam v1.2.0 - Background

const TTLF_URL = 'https://shop.tiktok.com/streamer/live/product/dashboard';

function ehTikTok(url) {
  return typeof url === 'string' && url.indexOf('https://shop.tiktok.com') === 0;
}

chrome.action.onClicked.addListener((tab) => {
  try {
    if (tab && ehTikTok(tab.url)) {
      chrome.tabs.sendMessage(tab.id, { action: 'toggleCamUI' }, () => {
        if (chrome.runtime.lastError) {}
      });
      return;
    }
    chrome.tabs.query({ url: 'https://shop.tiktok.com/*' }, (tabs) => {
      if (tabs && tabs.length) {
        const t = tabs[0];
        chrome.tabs.update(t.id, { active: true });
        if (t.windowId != null) { chrome.windows.update(t.windowId, { focused: true }); }
        chrome.tabs.sendMessage(t.id, { action: 'toggleCamUI' }, () => {
          if (chrome.runtime.lastError) {}
        });
      } else {
        chrome.tabs.create({ url: TTLF_URL });
      }
    });
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.tipo === 'PROXY_FETCH') {
    const { url, options } = msg;
    fetch(url, options || {})
      .then(async (r) => {
        const contentType = r.headers.get('content-type') || '';
        const body = contentType.includes('application/json')
          ? await r.json()
          : await r.text();
        sendResponse({ ok: r.ok, status: r.status, body });
      })
      .catch((err) => {
        sendResponse({ ok: false, erro: err.message });
      });
    return true; // mantém o canal aberto pra resposta assíncrona
  }
});
