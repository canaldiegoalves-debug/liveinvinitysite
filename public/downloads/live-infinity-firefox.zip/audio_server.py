"""
Live Infinity - Audio Server v3.0
Usa apenas sounddevice + soundfile (sem ffmpeg externo)
MP3 convertido via winsound ou subprocess ffmpeg se disponivel
Porta: 7892
"""
import http.server, threading, json, time, os, sys, base64, tempfile, subprocess

PORT = 7892

estado = {
    'tocando':     False,  # Sempre inicia parado
    'loop':        True,
    'volume_mp3':  0.8,
    'arquivo_mp3': '',
}

# Garante estado limpo ao iniciar
_player_thread = None
_stop_event    = threading.Event()
_posicao_secs  = 0.0
_duracao_secs  = 0.0
_seek_secs     = -1.0
_lock          = threading.Lock()
_sons_fila     = []
_sons_lock     = threading.Lock()

# Instala dependencias minimas
def pip(pkg):
    subprocess.check_call(
        [sys.executable, '-m', 'pip', 'install', pkg, '-q'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )

print("[Audio] Verificando dependencias...")
try:
    import sounddevice as sd
except:
    print("[Audio] Instalando sounddevice...")
    pip('sounddevice')
    import sounddevice as sd

try:
    import soundfile as sf
except:
    print("[Audio] Instalando soundfile...")
    pip('soundfile')
    import soundfile as sf

try:
    import numpy as np
except:
    print("[Audio] Instalando numpy...")
    pip('numpy')
    import numpy as np

print("[Audio] Dependencias OK!")

def encontrar_vbcable():
    for i, d in enumerate(sd.query_devices()):
        n = d['name'].lower()
        if ('cable' in n or 'vb-audio' in n) and d['max_output_channels'] > 0:
            return i, d['name']
    return None, None

def converter_mp3_wav(mp3_path):
    """Converte MP3 para WAV usando ffmpeg do sistema."""
    wav_path = mp3_path + '.tmp.wav'
    # Tenta varias localizacoes do ffmpeg
    locais = ['ffmpeg', 'ffmpeg.exe',
              r'C:\ffmpeg\bin\ffmpeg.exe',
              r'C:\Program Files\ffmpeg\bin\ffmpeg.exe']
    for ff in locais:
        try:
            r = subprocess.run(
                [ff, '-y', '-i', mp3_path, '-ar', '44100', '-ac', '2',
                 '-acodec', 'pcm_s16le', wav_path],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60
            )
            if r.returncode == 0 and os.path.exists(wav_path):
                print(f"[Audio] Convertido com {ff}")
                return wav_path
        except:
            continue
    return None

def carregar_audio(caminho, sr_alvo=44100):
    """Carrega audio. Tenta WAV direto, MP3 via conversao."""
    ext = os.path.splitext(caminho)[1].lower()

    # Tenta ler direto (WAV, FLAC, OGG funcionam sem conversao)
    try:
        dados, sr = sf.read(caminho, dtype='float32', always_2d=True)
        if sr != sr_alvo:
            fator = sr_alvo / sr
            n = int(len(dados) * fator)
            dados = np.array([
                np.interp(np.linspace(0, len(dados)-1, n),
                          np.arange(len(dados)), dados[:, ch])
                for ch in range(dados.shape[1])
            ]).T.astype(np.float32)
        return dados
    except Exception as e:
        print(f"[Audio] Leitura direta falhou ({e}), tentando converter...")

    # MP3 — converte para WAV
    if ext == '.mp3':
        wav = converter_mp3_wav(caminho)
        if wav:
            try:
                dados, sr = sf.read(wav, dtype='float32', always_2d=True)
                try: os.remove(wav)
                except: pass
                return dados
            except Exception as e2:
                print(f"[Audio] Erro ao ler WAV convertido: {e2}")

    raise Exception(f"Nao foi possivel carregar: {caminho}")

def engine_audio():
    global _posicao_secs, _duracao_secs, _seek_secs, _player_thread

    sr = 44100
    dev_idx, dev_nome = encontrar_vbcable()
    print(f"[Audio] Dispositivo: {dev_nome or 'Saida padrao'}")

    arquivo = estado['arquivo_mp3']
    if not arquivo or not os.path.exists(arquivo):
        print(f"[Audio] ERRO: arquivo nao encontrado: {arquivo}")
        return

    print(f"[Audio] Carregando: {os.path.basename(arquivo)}")
    try:
        dados = carregar_audio(arquivo, sr)
        # Garante estereo
        if dados.ndim == 1:
            dados = np.column_stack([dados, dados])
        elif dados.shape[1] == 1:
            dados = np.column_stack([dados[:,0], dados[:,0]])
    except Exception as e:
        print(f"[Audio] ERRO ao carregar audio: {e}")
        print("[Audio] Instale o ffmpeg: https://ffmpeg.org/download.html")
        return

    _duracao_secs = len(dados) / sr
    pos = 0
    print(f"[Audio] Duracao: {_duracao_secs:.1f}s | Iniciando stream...")

    def callback(outdata, frames, time_info, status):
        global _posicao_secs, _seek_secs
        nonlocal pos
        buf = np.zeros((frames, 2), dtype=np.float32)

        with _lock:
            if _seek_secs >= 0:
                pos = max(0, min(int(_seek_secs * sr), len(dados) - 1))
                _seek_secs = -1.0

        if estado['tocando'] and pos < len(dados):
            fim = min(pos + frames, len(dados))
            n = fim - pos
            buf[:n] += dados[pos:fim] * estado['volume_mp3']
            pos = fim
            if pos >= len(dados):
                pos = 0 if estado['loop'] else len(dados)
                if not estado['loop']:
                    estado['tocando'] = False

        _posicao_secs = pos / sr

        with _sons_lock:
            novos = []
            for (ds, ps, vs) in _sons_fila:
                fim_s = min(ps + frames, len(ds))
                buf[:fim_s-ps] += ds[ps:fim_s] * vs
                if fim_s < len(ds):
                    novos.append((ds, fim_s, vs))
            _sons_fila[:] = novos

        outdata[:] = np.clip(buf, -1.0, 1.0)

    try:
        with sd.OutputStream(samplerate=sr, channels=2, dtype='float32',
                             device=dev_idx, blocksize=2048, callback=callback):
            print("[Audio] *** Stream aberto! Tocando via VB-Cable ***")
            while not _stop_event.is_set():
                time.sleep(0.1)
    except Exception as e:
        print(f"[Audio] ERRO no stream: {e}")

    print("[Audio] Stream encerrado.")

def tocar_som_direto(arquivo, volume):
    """Toca som direto no VB-Cable sem precisar do stream principal."""
    pasta   = os.path.dirname(os.path.abspath(__file__))
    caminho = os.path.join(pasta, arquivo)
    if not os.path.exists(caminho):
        print(f"[Audio] Nao encontrado: {caminho}")
        return
    try:
        dev_idx, _ = encontrar_vbcable()
        dados = carregar_audio(caminho, 44100)
        if dados.ndim == 1:
            dados = np.column_stack([dados, dados])
        elif dados.shape[1] == 1:
            dados = np.column_stack([dados[:,0], dados[:,0]])
        dados = dados * float(volume)
        print(f"[Audio] Tocando direto: {arquivo} vol={volume:.2f}")
        sd.play(dados, 44100, device=dev_idx)
    except Exception as e:
        print(f"[Audio] Erro som direto: {e}")

def tocar_som_natural(arquivo, volume):
    pasta = os.path.dirname(os.path.abspath(__file__))
    caminho = os.path.join(pasta, arquivo)
    if not os.path.exists(caminho):
        print(f"[Audio] Som nao encontrado: {caminho}")
        return
    try:
        dados = carregar_audio(caminho, 44100)
        if dados.ndim == 1:
            dados = np.column_stack([dados, dados])
        elif dados.shape[1] == 1:
            dados = np.column_stack([dados[:,0], dados[:,0]])
        vol = float(volume)
        print(f"[Audio] Som natural: {arquivo} vol={vol:.2f} frames={len(dados)}")
        with _sons_lock:
            _sons_fila.append((dados, 0, vol))
    except Exception as e:
        print(f"[Audio] Erro som natural '{arquivo}': {e}")

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def send_json(self, data, code=200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        if self.path == '/status':
            _, dev = encontrar_vbcable()
            self.send_json({'ok': True, 'estado': estado,
                           'vbcable': dev or 'Nao encontrado'})
        elif self.path == '/progresso':
            self.send_json({'ok': True, 'posicao': _posicao_secs,
                           'duracao': _duracao_secs, 'tocando': estado['tocando']})
        else:
            self.send_json({'ok': True})

    def do_POST(self):
        global _player_thread, _stop_event, _seek_secs
        length = int(self.headers.get('Content-Length', 0))
        body   = json.loads(self.rfile.read(length)) if length else {}

        if self.path == '/upload':
            nome = body.get('nome', 'audio.mp3')
            tmp  = os.path.join(tempfile.gettempdir(), 'il_' + nome)
            with open(tmp, 'wb') as fw:
                fw.write(base64.b64decode(body.get('dados', '')))
            estado['arquivo_mp3'] = tmp
            print(f"[Audio] Upload recebido: {nome}")
            self.send_json({'ok': True, 'arquivo': tmp})

        elif self.path == '/play':
            if body.get('arquivo'):
                estado['arquivo_mp3'] = body['arquivo']
            estado['tocando'] = True
            _stop_event.clear()
            if _player_thread is None or not _player_thread.is_alive():
                _player_thread = threading.Thread(target=engine_audio, daemon=True)
                _player_thread.start()
            self.send_json({'ok': True})

        elif self.path == '/pause':
            estado['tocando'] = not estado['tocando']
            self.send_json({'ok': True, 'tocando': estado['tocando']})

        elif self.path == '/stop':
            estado['tocando'] = False
            _stop_event.set()
            global _player_thread
            _player_thread = None
            # Limpa fila de sons naturais
            with _sons_lock:
                _sons_fila.clear()
            self.send_json({'ok': True})

        elif self.path == '/seek':
            with _lock:
                _seek_secs = float(body.get('secs', 0))
            self.send_json({'ok': True})

        elif self.path == '/config':
            for k, v in body.items():
                if k in estado:
                    estado[k] = v
            self.send_json({'ok': True})

        elif self.path == '/som_natural':
            arq = body.get('arquivo','')
            vol = float(body.get('volume', 0.5))
            # Se stream principal ativo, mistura no buffer; senão toca direto
            if _player_thread and _player_thread.is_alive():
                threading.Thread(target=tocar_som_natural, args=(arq, vol), daemon=True).start()
            else:
                threading.Thread(target=tocar_som_direto, args=(arq, vol), daemon=True).start()
            self.send_json({'ok': True})

        elif self.path == '/kill':
            estado['tocando'] = False
            _stop_event.set()
            self.send_json({'ok': True})
            # Encerra o processo completamente após responder
            threading.Thread(target=lambda: (time.sleep(0.5), os._exit(0)), daemon=True).start()

        else:
            self.send_json({'ok': False})

def main():
    print("=" * 50)
    print("  LIVE INFINITY - Audio Server v3.0")
    print(f"  Python {sys.version.split()[0]} | Porta {PORT}")
    print("=" * 50)
    _, dev = encontrar_vbcable()
    if dev:
        print(f"  OK: {dev}")
    else:
        print("  AVISO: VB-Cable nao encontrado!")
        print("  Execute INSTALAR_VBCABLE.bat primeiro.")
    print("=" * 50)
    print("  Aguardando conexoes...")
    http.server.HTTPServer(('localhost', PORT), Handler).serve_forever()

if __name__ == '__main__':
    main()
