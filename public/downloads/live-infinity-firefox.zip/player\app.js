const p = new URLSearchParams(location.search);
let files = [];
try { files = JSON.parse(decodeURIComponent(p.get("files") || "[]")); } catch (e) {}

const v = document.getElementById("video");
const n = document.getElementById("name");
const prevBtn = document.getElementById("prev");
const nextBtn = document.getElementById("next");
const randomBtn = document.getElementById("random");

let i = 0;

function play(x) {
  if (!files.length) return;
  i = (x + files.length) % files.length;
  v.src = files[i].url;
  n.textContent = "🎬 Rodando: " + files[i].name;
  
  // Otimização de áudio para evitar picotamento e manter sinal contínuo
  v.play().catch(err => {
    console.log("Auto-play ativado via interação do usuário:", err);
  });
}

if (prevBtn) prevBtn.onclick = () => play(i - 1);
if (nextBtn) nextBtn.onclick = () => play(i + 1);
if (randomBtn) randomBtn.onclick = () => play(Math.floor(Math.random() * files.length));

v.onended = () => play(i + 1);

// Inicializa a reprodução
if (files.length > 0) {
  play(0);
}
