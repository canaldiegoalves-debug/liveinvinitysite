@echo off
cd /d "C:\Users\Admin\Desktop\GhostLive"
python painel.py
pause
