@echo off
title Live Infinity - Controlador
color 0A

REM Detecta o caminho atual automaticamente
set "PASTA=%~dp0"
set "PASTA=%PASTA:~0,-1%"

echo.
echo  ========================================
echo   LIVE INFINITY - Controlador v7
echo  ========================================
echo.
echo  Instalando dependencias...

REM Tenta python, py, e caminhos comuns
python --version >nul 2>&1 && set "PY=python" && goto :found
py --version >nul 2>&1 && set "PY=py" && goto :found
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe" && goto :found
"%LOCALAPPDATA%\Programs\Python\Python312\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe" && goto :found
"%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" && goto :found
echo  ERRO: Python nao encontrado! Execute INSTALAR.bat primeiro.
pause
exit

:found
echo  Python encontrado: %PY%
%PY% -m pip install pyautogui numpy pillow opencv-python pygetwindow websocket-client requests -q 2>nul

echo  Iniciando controlador...
echo.
cd /d "%PASTA%"
%PY% reiniciador.py
pause
