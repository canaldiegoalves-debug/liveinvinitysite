'use strict';
/* Live Infinity v8.2.0 — Background Service Worker
   Fora do TikTok Shop: abre o Gerenciador de LIVE.
   Dentro do TikTok Shop: mostra o painel flutuante da extensão. */
var TTLF_URL = 'https://shop.tiktok.com/streamer/live/product/dashboard';

function ehTikTok(url) {
  return typeof url === 'string' && url.indexOf('https://shop.tiktok.com') === 0;
}

/* Alerta de vendas: envia notificação via ntfy.sh */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.tipo === 'PROXY_FETCH') {
    var url = msg.url;
    var options = msg.options;
    fetch(url, options || {})
      .then(async function (r) {
        var contentType = r.headers.get('content-type') || '';
        var body = contentType.includes('application/json')
          ? await r.json()
          : await r.text();
        sendResponse({ ok: r.ok, status: r.status, body: body });
      })
      .catch(function (err) {
        sendResponse({ ok: false, erro: err.message });
      });
    return true;
  }
  if (msg && msg.type === 'ttlf-ntfy') {
    var canal = (msg.canal || '').trim();
    if (!canal) { sendResponse({ ok: false }); return; }
    fetch('https://ntfy.sh', {
      method: 'POST',
      body: JSON.stringify({
        topic: canal,
        title: msg.titulo || 'Live Infinity',
        message: msg.corpo || '',
        tags: (msg.tags || 'bell').split(','),
        priority: 5
      })
    }).then(function (r) { sendResponse({ ok: r.ok }); })
      .catch(function () { sendResponse({ ok: false }); });
    return true;
  }
});

chrome.action.onClicked.addListener(function (tab) {
  try {
    if (tab && ehTikTok(tab.url)) {
      chrome.tabs.sendMessage(tab.id, { type: 'ttlf-show' }, function () {
        if (chrome.runtime.lastError) { /* aba ainda sem content script */ }
      });
      return;
    }
    chrome.tabs.query({ url: 'https://shop.tiktok.com/*' }, function (tabs) {
      if (tabs && tabs.length) {
        var t = tabs[0];
        chrome.tabs.update(t.id, { active: true });
        if (t.windowId != null) { chrome.windows.update(t.windowId, { focused: true }); }
        chrome.tabs.sendMessage(t.id, { type: 'ttlf-show' }, function () {
          if (chrome.runtime.lastError) { /* ignora */ }
        });
      } else {
        chrome.tabs.create({ url: TTLF_URL });
      }
    });
  } catch (e) {
    chrome.tabs.create({ url: TTLF_URL });
  }
});
