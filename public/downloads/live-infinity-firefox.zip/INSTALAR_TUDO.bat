@echo off
title Live Infinity - Instalador Completo
color 0B

:: Solicita administrador
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit
)

set "PASTA=%~dp0"
set "PASTA=%PASTA:~0,-1%"
set "TEMP_DIR=%TEMP%\LiveInfinityInstall"
mkdir "%TEMP_DIR%" 2>nul

cls
echo.
echo  ╔══════════════════════════════════════════╗
echo  ║     LIVE INFINITY — Instalador v2.0    ║
echo  ║      Instalacao completa automatica      ║
echo  ╚══════════════════════════════════════════╝
echo.
echo  [1] Python
echo  [2] Dependencias Python
echo  [3] VB-Cable (audio virtual)
echo  [4] Startup automatico (reiniciador + audio)
echo  [5] Extensao Chrome
echo.
pause

:: ── PASSO 1: Python ──────────────────────────────────
echo.
echo  [1/5] Verificando Python...
python --version >nul 2>&1 && set "PY=python" && goto :python_ok
py --version >nul 2>&1 && set "PY=py" && goto :python_ok
"%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" && goto :python_ok

echo  Python nao encontrado. Baixando...
curl -L -o "%TEMP_DIR%\python_setup.exe" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" --progress-bar
"%TEMP_DIR%\python_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
:: Atualiza PATH
call refreshenv 2>nul
set "PY=python"

:python_ok
echo  Python OK!

:: ── PASSO 2: Dependencias ────────────────────────────
echo.
echo  [2/5] Instalando dependencias Python...
%PY% -m pip install sounddevice soundfile numpy requests -q 2>nul
echo  Dependencias OK!

:: ── PASSO 3: VB-Cable ────────────────────────────────
echo.
echo  [3/5] Instalando VB-Cable...
reg query "HKLM\SYSTEM\CurrentControlSet\Services\VBAudioVACMM" >nul 2>&1
if %errorLevel% == 0 (
    echo  VB-Cable ja instalado!
    goto :vbcable_ok
)
curl -L -o "%TEMP_DIR%\vbcable.zip" "https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack43.zip" --progress-bar
if exist "%TEMP_DIR%\vbcable.zip" (
    powershell -Command "Expand-Archive -Path '%TEMP_DIR%\vbcable.zip' -DestinationPath '%TEMP_DIR%\vbcable' -Force"
    "%TEMP_DIR%\vbcable\VBCABLE_Setup_x64.exe" /S
    echo  VB-Cable instalado!
) else (
    echo  AVISO: Baixe manualmente em https://vb-audio.com/Cable/
)
:vbcable_ok

:: ── PASSO 4: Startup automatico ──────────────────────
echo.
echo  [4/5] Configurando startup automatico...

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

:: Reiniciador (notificacoes Telegram)
echo Set oShell = CreateObject("WScript.Shell") > "%STARTUP%\LiveInfinity_Reiniciador.vbs"
echo oShell.Run "cmd /c cd /d ""%PASTA%"" && %PY% reiniciador.py", 0, False >> "%STARTUP%\LiveInfinity_Reiniciador.vbs"

:: Audio Server (VB-Cable)
echo Set oShell = CreateObject("WScript.Shell") > "%STARTUP%\LiveInfinity_Audio.vbs"
echo oShell.Run "cmd /c cd /d ""%PASTA%"" && %PY% audio_server.py", 0, False >> "%STARTUP%\LiveInfinity_Audio.vbs"

echo  Startup configurado — inicia automaticamente com o Windows!

:: Inicia os dois agora em background
echo  Iniciando servidores em background...
start "" /min cmd /c "cd /d "%PASTA%" && %PY% reiniciador.py"
timeout /t 2 /nobreak >nul
start "" /min cmd /c "cd /d "%PASTA%" && %PY% audio_server.py"
timeout /t 2 /nobreak >nul
echo  Servidores rodando!

:: ── PASSO 5: Extensao Chrome ─────────────────────────
echo.
echo  [5/5] Abrindo Chrome para instalar extensao...
echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   Ultimo passo — extensao Chrome         ║
echo  ║                                          ║
echo  ║  1. No Chrome que vai abrir:             ║
echo  ║     Ative "Modo do desenvolvedor"        ║
echo  ║  2. Clique "Carregar sem compactacao"    ║
echo  ║  3. Selecione a pasta:                   ║
echo  ║                                          ║
echo  ║  %PASTA%
echo  ║                                          ║
echo  ║  4. Pronto!                              ║
echo  ╚══════════════════════════════════════════╝
echo.
start chrome "chrome://extensions"
explorer "%PASTA%"

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   INSTALACAO CONCLUIDA!                  ║
echo  ║                                          ║
echo  ║   Configuracao final no Live Studio:     ║
echo  ║   Configuracoes > Audio > Microfone      ║
echo  ║   Selecione: CABLE Input (VB-Audio)      ║
echo  ╚══════════════════════════════════════════╝
echo.
pause
