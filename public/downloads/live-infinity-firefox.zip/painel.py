"""
Smarth Live - Painel de Controle Visual
"""
import tkinter as tk
from tkinter import font as tkfont
import threading
import time
import subprocess
import sys
import json
import http.server
import datetime

# Instala dependências
try:
    import pyautogui
    import numpy as np
    from PIL import ImageGrab
    import cv2
    import pygetwindow as gw
except:
    subprocess.check_call([sys.executable, "-m", "pip", "install",
        "pyautogui","numpy","pillow","opencv-python","pygetwindow",
        "--break-system-packages", "-q"])
    import pyautogui
    import numpy as np
    from PIL import ImageGrab
    import cv2
    import pygetwindow as gw

pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.2

PORT = 7891

C = {
    'bg':      '#0a0c12',
    'surface': '#12151f',
    'card':    '#181c28',
    'border':  '#252a3a',
    'green':   '#00e676',
    'red':     '#ff1744',
    'blue':    '#00b0ff',
    'yellow':  '#ffd600',
    'text':    '#eef0f6',
    'muted':   '#6b7280',
}

# Estado global
class Estado:
    iniciando  = False
    encerrando = False
    agendado   = False
    hora_agenda = None
    painel = None

E = Estado()

# ════════════════════════════════════
#  AUTOMAÇÃO
# ════════════════════════════════════
def log(msg, tipo='info'):
    if E.painel:
        E.painel.log(msg, tipo)

def focar():
    subprocess.run([
        'powershell', '-Command',
        '$w=New-Object -ComObject wscript.shell;$w.AppActivate("TikTok LIVE Studio")'
    ], shell=True, capture_output=True)
    time.sleep(1)

def encontrar_rosa(regiao=None):
    try:
        if regiao:
            x,y,w,h = regiao
            img = np.array(ImageGrab.grab(bbox=(x,y,x+w,y+h)))
            ox,oy = x,y
        else:
            img = np.array(ImageGrab.grab())
            ox,oy = 0,0
        lower = np.array([220,20,50])
        upper = np.array([255,90,120])
        mask = cv2.inRange(img, lower, upper)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3,3),np.uint8))
        cnts,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cands = []
        for c in cnts:
            bx,by,bw,bh = cv2.boundingRect(c)
            if bw*bh > 800 and bw > bh:
                cands.append((ox+bx+bw//2, oy+by+bh//2, bw*bh))
        if not cands: return None
        cands.sort(key=lambda c: c[2], reverse=True)
        return (cands[0][0], cands[0][1])
    except:
        return None

def iniciar_live():
    if E.iniciando: return
    E.iniciando = True
    log('Iniciando Live Studio...', 'ok')
    try:
        r = subprocess.run(['tasklist','/FI','IMAGENAME eq TikTok LIVE Studio.exe'],
            capture_output=True, text=True, shell=True)
        if 'TikTok' not in r.stdout:
            log('Abrindo Live Studio...', 'info')
            subprocess.Popen(
                r'"C:\Program Files\TikTok LIVE Studio\1.26.0\TikTok LIVE Studio.exe"',
                shell=True)
            time.sleep(12)
        else:
            log('Live Studio já está aberto.', 'info')

        focar()
        time.sleep(1.5)

        BTN1_X, BTN1_Y = 1139, 753
        log(f'Clicando em Iniciar LIVE ({BTN1_X},{BTN1_Y})...', 'info')
        focar()
        time.sleep(0.5)
        pyautogui.moveTo(BTN1_X, BTN1_Y, duration=0.5)
        time.sleep(0.5)
        pyautogui.click(BTN1_X, BTN1_Y)
        log('Clique 1 feito! Aguardando modal...', 'info')
        time.sleep(4)

        BTN2_X, BTN2_Y = 805, 718
        log(f'Confirmando no modal ({BTN2_X},{BTN2_Y})...', 'info')
        focar()
        time.sleep(0.5)
        pyautogui.moveTo(BTN2_X, BTN2_Y, duration=0.5)
        time.sleep(0.5)
        pyautogui.click(BTN2_X, BTN2_Y)
        log('Clique 2 feito!', 'info')

        log('✓ LIVE INICIADA!', 'ok')
        if E.painel:
            E.painel.set_status('LIVE ATIVA', C['green'])
    except Exception as ex:
        log(f'ERRO: {ex}', 'err')
    finally:
        E.iniciando = False

def encerrar_live():
    if E.encerrando: return
    E.encerrando = True
    log('Encerrando live...', 'warn')
    try:
        focar()
        time.sleep(1)
        wins = gw.getWindowsWithTitle('TikTok LIVE Studio')
        if not wins:
            log('Janela não encontrada!', 'err')
            return
        w = wins[0]
        jx,jy,jw,jh = w.left, w.top, w.width, w.height
        tx, ty = jx+jw-150, jy+jh-50
        pyautogui.click(tx, ty)
        time.sleep(1.5)
        pyautogui.click(tx-20, ty-80)
        time.sleep(2)
        pos = encontrar_rosa((jx,jy,jw,jh))
        if pos:
            pyautogui.click(pos[0], pos[1])
        else:
            pyautogui.click(jx+jw//2-80, jy+jh//2+60)
        log('✓ LIVE ENCERRADA!', 'ok')
        if E.painel:
            E.painel.set_status('INATIVO', C['muted'])
    except Exception as ex:
        log(f'ERRO: {ex}', 'err')
    finally:
        E.encerrando = False

# ════════════════════════════════════
#  SERVIDOR HTTP
# ════════════════════════════════════
class Handler(http.server.BaseHTTPRequestHandler):
    def cors(self):
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        self.end_headers()
    def do_OPTIONS(self): self.cors()
    def do_GET(self):
        self.cors()
        self.wfile.write(json.dumps({'status':'ativo','port':PORT}).encode())
    def do_POST(self):
        self.cors()
        if self.path == '/iniciar':
            log('📡 Extensão pediu INICIAR!', 'ok')
            threading.Thread(target=iniciar_live, daemon=True).start()
            self.wfile.write(json.dumps({'ok':True}).encode())
        elif self.path == '/encerrar':
            log('📡 Extensão pediu ENCERRAR!', 'warn')
            threading.Thread(target=encerrar_live, daemon=True).start()
            self.wfile.write(json.dumps({'ok':True}).encode())
        else:
            self.wfile.write(json.dumps({'ok':True}).encode())
    def log_message(self,*a): pass

def start_server():
    s = http.server.HTTPServer(('localhost', PORT), Handler)
    s.serve_forever()

# ════════════════════════════════════
#  PAINEL VISUAL
# ════════════════════════════════════
class Painel:
    def __init__(self):
        E.painel = self
        self.root = tk.Tk()
        self.root.title('Smarth Live')
        self.root.geometry('400x620')
        self.root.resizable(False, False)
        self.root.configure(bg=C['bg'])
        self.root.attributes('-topmost', False)
        self._build()
        threading.Thread(target=start_server, daemon=True).start()
        self.log('✓ Servidor ativo na porta ' + str(PORT), 'ok')
        self._tick()

    def _build(self):
        r = self.root

        # HEADER
        h = tk.Frame(r, bg=C['surface'], height=52)
        h.pack(fill='x')
        h.pack_propagate(False)

        logo_box = tk.Frame(h, bg=C['green'], width=30, height=30)
        logo_box.place(x=12, y=11)
        tk.Label(logo_box, text='S', bg=C['green'], fg='#000',
                 font=('Consolas',13,'bold')).place(x=6,y=4)

        tk.Label(h, text='Smarth', bg=C['surface'], fg=C['text'],
                 font=('Segoe UI',13,'bold')).place(x=50,y=14)
        tk.Label(h, text=' Live', bg=C['surface'], fg=C['green'],
                 font=('Segoe UI',13,'bold')).place(x=99,y=14)

        self.lbl_status = tk.Label(h, text='● INATIVO',
            bg=C['surface'], fg=C['muted'],
            font=('Segoe UI',9,'bold'))
        self.lbl_status.place(x=295, y=17)

        # RELÓGIO
        self.lbl_clock = tk.Label(r, text='--:--:--',
            bg=C['bg'], fg=C['green'],
            font=('Consolas',28,'bold'))
        self.lbl_clock.pack(pady=(18,0))

        tk.Label(r, text='horário atual', bg=C['bg'], fg=C['muted'],
                 font=('Segoe UI',8)).pack()

        # BOTÕES PRINCIPAIS
        btn_frame = tk.Frame(r, bg=C['bg'])
        btn_frame.pack(fill='x', padx=12, pady=14)

        self.btn_ini = tk.Button(btn_frame,
            text='▶  Iniciar LIVE agora',
            bg=C['green'], fg='#000',
            font=('Segoe UI',11,'bold'),
            activebackground='#00ff7f', activeforeground='#000',
            bd=0, relief='flat', cursor='hand2', height=2,
            command=lambda: threading.Thread(target=iniciar_live,daemon=True).start())
        self.btn_ini.pack(fill='x', pady=(0,6))

        self.btn_enc = tk.Button(btn_frame,
            text='■  Encerrar LIVE',
            bg=C['card'], fg=C['red'],
            font=('Segoe UI',10,'bold'),
            activebackground=C['red'], activeforeground='#fff',
            bd=0, relief='flat', cursor='hand2', height=2,
            highlightbackground=C['red'], highlightthickness=1,
            command=lambda: threading.Thread(target=encerrar_live,daemon=True).start())
        self.btn_enc.pack(fill='x')

        # AGENDAMENTO
        tk.Label(r, text='AGENDAMENTO AUTOMÁTICO',
                 bg=C['bg'], fg=C['muted'],
                 font=('Segoe UI',8,'bold')).pack(anchor='w', padx=14, pady=(14,4))

        ag = tk.Frame(r, bg=C['card'], padx=14, pady=14)
        ag.pack(fill='x', padx=12)

        tk.Label(ag, text='Horário de início (HH:MM)',
                 bg=C['card'], fg=C['muted'],
                 font=('Segoe UI',9)).pack(anchor='w')

        row = tk.Frame(ag, bg=C['card'])
        row.pack(fill='x', pady=(6,0))

        self.ent_hora = tk.Entry(row, width=7,
            font=('Consolas',16,'bold'),
            bg=C['bg'], fg=C['green'],
            insertbackground=C['green'],
            relief='flat', justify='center',
            bd=4)
        self.ent_hora.insert(0,'22:00')
        self.ent_hora.pack(side='left')

        self.btn_ag = tk.Button(row, text='Agendar',
            bg=C['green'], fg='#000',
            font=('Segoe UI',9,'bold'),
            activebackground='#00ff7f',
            bd=0, relief='flat', cursor='hand2',
            padx=14, pady=5,
            command=self._agendar)
        self.btn_ag.pack(side='left', padx=(8,4))

        self.btn_cag = tk.Button(row, text='✕',
            bg=C['card'], fg=C['muted'],
            font=('Segoe UI',10,'bold'),
            activebackground=C['border'],
            bd=1, relief='flat', cursor='hand2',
            padx=8, pady=4,
            highlightbackground=C['border'],
            highlightthickness=1,
            command=self._cancelar)
        self.btn_cag.pack(side='left')

        self.lbl_ag_info = tk.Label(ag, text='',
            bg=C['card'], fg=C['muted'],
            font=('Segoe UI',9))
        self.lbl_ag_info.pack(anchor='w', pady=(8,0))

        self.lbl_countdown = tk.Label(r, text='',
            bg=C['bg'], fg=C['yellow'],
            font=('Consolas',13,'bold'))
        self.lbl_countdown.pack(pady=(6,0))

        # LOG
        tk.Label(r, text='LOG DE EVENTOS',
                 bg=C['bg'], fg=C['muted'],
                 font=('Segoe UI',8,'bold')).pack(anchor='w', padx=14, pady=(12,4))

        log_wrap = tk.Frame(r, bg=C['card'])
        log_wrap.pack(fill='both', expand=True, padx=12, pady=(0,12))

        self.txt_log = tk.Text(log_wrap,
            bg=C['bg'], fg=C['muted'],
            font=('Consolas',9),
            relief='flat', state='disabled',
            wrap='word', padx=8, pady=8)
        self.txt_log.pack(fill='both', expand=True)

        self.txt_log.tag_config('ok',   foreground=C['green'])
        self.txt_log.tag_config('err',  foreground=C['red'])
        self.txt_log.tag_config('warn', foreground=C['yellow'])
        self.txt_log.tag_config('info', foreground=C['blue'])
        self.txt_log.tag_config('dim',  foreground=C['muted'])

        # RODAPÉ
        ft = tk.Frame(r, bg=C['surface'], height=26)
        ft.pack(fill='x', side='bottom')
        ft.pack_propagate(False)
        tk.Label(ft, text=f'Smarth Live  ·  Porta {PORT}  ·  Conectado à extensão Chrome',
                 bg=C['surface'], fg=C['muted'],
                 font=('Segoe UI',8)).pack(pady=4)

    def log(self, msg, tipo='info'):
        hora = datetime.datetime.now().strftime('%H:%M:%S')
        def _do():
            self.txt_log.config(state='normal')
            self.txt_log.insert('end', f'[{hora}] ', 'dim')
            self.txt_log.insert('end', msg + '\n', tipo)
            self.txt_log.see('end')
            self.txt_log.config(state='disabled')
        try:
            self.root.after(0, _do)
        except: pass

    def set_status(self, txt, cor):
        try:
            self.root.after(0, lambda: self.lbl_status.config(
                text=f'● {txt}', fg=cor))
        except: pass

    def _agendar(self):
        hora = self.ent_hora.get().strip()
        try:
            h, m = hora.split(':')
            assert 0 <= int(h) <= 23 and 0 <= int(m) <= 59
        except:
            self.lbl_ag_info.config(text='⚠ Formato inválido! Use HH:MM', fg=C['red'])
            return
        E.agendado    = True
        E.hora_agenda = hora
        self.lbl_ag_info.config(text=f'✓ Agendado para {hora}', fg=C['green'])
        self.btn_ag.config(state='disabled', bg=C['muted'])
        self.log(f'Live agendada para {hora}', 'ok')

    def _cancelar(self):
        E.agendado    = False
        E.hora_agenda = None
        self.lbl_ag_info.config(text='Cancelado.', fg=C['muted'])
        self.btn_ag.config(state='normal', bg=C['green'])
        self.lbl_countdown.config(text='')
        self.log('Agendamento cancelado.', 'warn')

    def _tick(self):
        agora = datetime.datetime.now()

        # Relógio
        self.lbl_clock.config(text=agora.strftime('%H:%M:%S'))

        # Countdown do agendamento
        if E.agendado and E.hora_agenda:
            try:
                h, m = E.hora_agenda.split(':')
                alvo = agora.replace(hour=int(h), minute=int(m), second=0, microsecond=0)
                if alvo <= agora:
                    alvo = alvo + datetime.timedelta(days=1)
                diff = (alvo - agora).total_seconds()
                mins = int(diff // 60)
                secs = int(diff % 60)
                cor = C['red'] if diff < 60 else C['yellow']
                self.lbl_countdown.config(
                    text=f'⏰  Live em  {mins:02d}:{secs:02d}', fg=cor)

                if diff <= 1:
                    E.agendado    = False
                    E.hora_agenda = None
                    self.lbl_countdown.config(text='')
                    self.lbl_ag_info.config(text='Disparado!', fg=C['green'])
                    self.btn_ag.config(state='normal', bg=C['green'])
                    self.log('🚀 Agendamento disparou! Iniciando...', 'ok')
                    threading.Thread(target=iniciar_live, daemon=True).start()
            except Exception as ex:
                pass
        else:
            if self.lbl_countdown.cget('text') and not E.agendado:
                self.lbl_countdown.config(text='')

        self.root.after(1000, self._tick)

    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = Painel()
    app.run()
