"""
Live Infinity - Controlador v7
Modo simples: Studio já aberto com debug, só faz os 3 cliques.
"""
import http.server, threading, json, time, subprocess, sys, os, urllib.request, requests

from licenca_utils import ativar_licenca

try:
    import pyautogui, numpy as np
    from PIL import ImageGrab
    import cv2, pygetwindow as gw
except:
    subprocess.check_call([sys.executable, "-m", "pip", "install",
        "pyautogui","numpy","pillow","opencv-python","pygetwindow",
        "websocket-client", "--break-system-packages", "-q"])
    import pyautogui, numpy as np
    from PIL import ImageGrab
    import cv2, pygetwindow as gw

PORT       = 7891

# ── Live Infinity Cloud ─────────────────────────────
CLOUD_URL   = ""
CLOUD_CANAL = ""
CLOUD_ATIVO = False

# ── Telegram Notificações ────────────────────────────
TG_TOKEN   = ""  # Configurado via extensão
TG_CHAT_ID = ""  # Configurado via extensão
TG_ATIVO   = True   # Muda para False para desativar
tg_ultima_venda = 0  # controle de vendas

DEBUG_PORT = 9222
pyautogui.FAILSAFE = False
pyautogui.PAUSE    = 0.1
encerrando = False
iniciando  = False

def enviar_telegram(msg, parse_mode='HTML'):
    """Envia mensagem para o Telegram sem bloquear."""
    if not TG_ATIVO or not TG_TOKEN or not TG_CHAT_ID:
        return
    def _send():
        try:
            requests.post(
                f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
                json={'chat_id': TG_CHAT_ID, 'text': msg, 'parse_mode': parse_mode},
                timeout=5
            )
        except Exception as e:
            print(f"[TG] Erro: {e}")
    threading.Thread(target=_send, daemon=True).start()

def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}")

# ══════════════════════════════════════════════════════
#  DEVTOOLS
# ══════════════════════════════════════════════════════
def get_targets():
    try:
        resp = urllib.request.urlopen(f"http://127.0.0.1:{DEBUG_PORT}/json", timeout=3)
        return json.loads(resp.read())
    except Exception as e:
        log(f"  DevTools offline: {e}"); return []

def devtools_eval(ws, js, msg_id=1):
    ws.send(json.dumps({"id": msg_id, "method": "Runtime.evaluate",
                        "params": {"expression": js, "returnByValue": True}}))
    for _ in range(15):
        try:
            res = json.loads(ws.recv())
            if res.get('id') == msg_id:
                return res.get('result', {}).get('result', {}).get('value', '')
        except: pass
    return ''

JS_LIST = """
Array.from(document.querySelectorAll('button,[role="button"],div,span'))
  .filter(b => b.offsetParent !== null)
  .map(b => (b.innerText||b.textContent||'').trim().slice(0,40))
  .filter(t => t.length > 1 && t.length < 40)
  .join(' || ')
"""

JS_CLICK_MAIN = """
(function() {
    var all = Array.from(document.querySelectorAll(
        'button,[role="button"],div[class*="btn"],span[class*="btn"]'
    )).filter(function(b){ return b.offsetParent !== null; });
    var found = all.find(function(b) {
        var t = (b.innerText || b.textContent || '').trim().toLowerCase();
        return t.includes('iniciar live') || t.includes('start live') || t.includes('go live');
    });
    if (found) { found.click(); return 'CLICOU:' + (found.innerText||found.textContent||'').trim(); }
    var pink = all.find(function(b) {
        var bg = window.getComputedStyle(b).backgroundColor;
        return bg && (bg.includes('231, 0')||bg.includes('255, 0')||bg.includes('238, 29')||bg.includes('254, 44'));
    });
    if (pink) { pink.click(); return 'CLICOU_COR:' + (pink.innerText||'').trim(); }
    return 'NAO_ENCONTRADO:' + all.map(function(b){
        return (b.innerText||b.textContent||'').trim().slice(0,30);
    }).filter(Boolean).join(' | ').slice(0,200);
})()
"""

JS_CLICK_MODAL = """
(function() {
    var all = Array.from(document.querySelectorAll('button,[role="button"]'))
        .filter(function(b){ return b.offsetParent !== null; });
    var candidates = all.filter(function(b){
        var t = (b.innerText||b.textContent||'').trim().toLowerCase();
        return (t.includes('iniciar live')||t.includes('start live')||t.includes('go live'))
            && !t.includes('cancel') && !t.includes('cancelar');
    });
    var found = null;
    if (candidates.length >= 2) {
        candidates.sort(function(a,b){ return a.getBoundingClientRect().top - b.getBoundingClientRect().top; });
        found = candidates.find(function(b){ return b.getBoundingClientRect().top < window.innerHeight*0.85; }) || candidates[0];
    } else if (candidates.length === 1) { found = candidates[0]; }
    if (!found) {
        for (var i=0;i<all.length;i++) {
            var t=(all[i].innerText||all[i].textContent||'').trim().toLowerCase();
            if (t.includes('cancel')||t.includes('cancelar')) {
                var p=all[i].parentElement;
                while(p){
                    var sibs=Array.from(p.querySelectorAll('button,[role="button"]')).filter(function(b){return b.offsetParent!==null;});
                    var sib=sibs.find(function(s){var st=(s.innerText||s.textContent||'').trim().toLowerCase();return !st.includes('cancel')&&st.length>1;});
                    if(sib&&sibs.length>=2){found=sib;break;}
                    p=p.parentElement; if(!p||p===document.body)break;
                }
                if(found)break;
            }
        }
    }
    if (found) {
        var rect=found.getBoundingClientRect(); var cx=rect.left+rect.width/2; var cy=rect.top+rect.height/2;
        ['mouseenter','mouseover','mousemove','mousedown','mouseup','click'].forEach(function(ev){
            found.dispatchEvent(new MouseEvent(ev,{bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy}));
        });
        return 'CLICOU:' + (found.innerText||found.textContent||'').trim().slice(0,50);
    }
    return 'NAO_ENCONTRADO | botoes: ' + all.map(function(b){return (b.innerText||b.textContent||'').trim().slice(0,25);}).filter(Boolean).join(' | ').slice(0,300);
})()
"""

def click_via_devtools():
    try:
        import websocket
    except ImportError:
        os.system("pip install websocket-client -q"); import websocket
    try:
        targets = get_targets()
        if not targets: log("❌ Nenhum target — Studio com debug?"); return False
        log(f"🎯 {len(targets)} target(s)")
        for t in targets:
            if not t.get('webSocketDebuggerUrl'): continue
            try:
                ws = websocket.create_connection(t['webSocketDebuggerUrl'], timeout=4)
                lista = devtools_eval(ws, JS_LIST, msg_id=1)
                log(f"   [{t.get('type','?')}] {t.get('title','?')[:40]}: {str(lista)[:100]}")
                val = devtools_eval(ws, JS_CLICK_MAIN, msg_id=2)
                if 'CLICOU' in str(val):
                    log(f"✅ {val}"); ws.close(); return True
                ws.close()
            except Exception as e: log(f"   ⚠️ {e}")
        log("❌ Botão não encontrado."); return False
    except Exception as e: log(f"❌ {e}"); return False

def click_modal_devtools():
    try:
        import websocket
    except ImportError:
        os.system("pip install websocket-client -q"); import websocket
    try:
        targets = get_targets()
        if not targets: return False
        for t in targets:
            if not t.get('webSocketDebuggerUrl'): continue
            try:
                ws = websocket.create_connection(t['webSocketDebuggerUrl'], timeout=4)
                lista = devtools_eval(ws, JS_LIST, msg_id=20)
                log(f"   [{t.get('type','?')}]: {str(lista)[:120]}")
                val = devtools_eval(ws, JS_CLICK_MODAL, msg_id=21)
                log(f"   Modal: {str(val)[:100]}")
                ws.close()
                if 'CLICOU' in str(val): log("✅ Modal confirmado!"); return True
            except Exception as e: log(f"   ⚠️ {e}")
        return False
    except Exception as e: log(f"❌ {e}"); return False

# ══════════════════════════════════════════════════════
#  INICIAR LIVE — só os 3 cliques (Studio já aberto)
# ══════════════════════════════════════════════════════
def iniciar_live():
    global iniciando
    if iniciando: return
    iniciando = True
    log("="*40)
    log("INICIANDO LIVE — DevTools + pyautogui")
    log("="*40)
    try:
        # Verifica se Studio está rodando com debug
        targets = get_targets()
        if not targets:
            log("❌ Studio sem debug ativo!")
            log("   Use o botão 'Abrir Studio' na extensão.")
            return False

        log(f"✅ {len(targets)} target(s) DevTools")
        for t in targets:
            log(f"   [{t.get('type')}] {t.get('title','')[:50]}")

        # ── 3 tentativas de clique via DevTools ──
        try:
            import websocket
        except ImportError:
            subprocess.check_call([sys.executable, "-m", "pip", "install",
                "websocket-client", "--break-system-packages", "-q"])
            import websocket

        def ws_eval(ws_url, js):
            """Conecta via WebSocket e executa JS."""
            import json as _j
            resultado = [None]
            done = threading.Event()
            def on_open(ws):
                ws.send(_j.dumps({"id":1,"method":"Runtime.evaluate",
                    "params":{"expression":js,"returnByValue":True}}))
            def on_message(ws, msg):
                data = _j.loads(msg)
                if data.get('id') == 1:
                    resultado[0] = data.get('result',{}).get('result',{}).get('value','')
                    ws.close()
                    done.set()
            def on_error(ws, err):
                log(f"  WS erro: {err}")
                done.set()
            try:
                ws = websocket.WebSocketApp(ws_url,
                    on_open=on_open, on_message=on_message, on_error=on_error)
                t = threading.Thread(target=lambda: ws.run_forever(ping_timeout=5), daemon=True)
                t.start()
                done.wait(timeout=8)
            except Exception as e:
                log(f"  WS excecao: {e}")
            return resultado[0]

        JS_CLICAR = """(function(){
            var btns = Array.from(document.querySelectorAll(
                'button,[role="button"],[class*="btn"],[class*="Btn"],a'
            )).filter(function(b){ return b.offsetParent !== null; });
            var alvo = btns.find(function(b){
                var t = (b.innerText||b.textContent||'').trim().toLowerCase();
                return t.includes('iniciar live') || t.includes('go live') || t.includes('start live');
            });
            if(alvo){
                var r = alvo.getBoundingClientRect();
                return JSON.stringify({
                    clicado: true,
                    txt: (alvo.innerText||'').trim(),
                    x: Math.round(r.left + r.width/2),
                    y: Math.round(r.top + r.height/2)
                });
            }
            var visiveis = btns.slice(0,12).map(function(b){
                return (b.innerText||b.textContent||'').trim().slice(0,25);
            }).filter(Boolean);
            return JSON.stringify({clicado:false, botoes: visiveis});
        })()"""

        JS_MODAL = """(function(){
            var all = Array.from(document.querySelectorAll('button,[role="button"]'))
                .filter(function(b){ return b.offsetParent !== null; });
            // Procura botão de confirmar (não cancelar)
            var found = all.find(function(b){
                var t = (b.innerText||b.textContent||'').trim().toLowerCase();
                return (t.includes('iniciar')||t.includes('start')||t.includes('confirmar'))
                    && !t.includes('cancelar') && !t.includes('cancel');
            });
            // Fallback: irmão do cancelar
            if(!found){
                for(var i=0;i<all.length;i++){
                    var t=(all[i].innerText||'').trim().toLowerCase();
                    if(t.includes('cancelar')||t.includes('cancel')){
                        var p=all[i].parentElement;
                        while(p&&p!==document.body){
                            var sibs=Array.from(p.querySelectorAll('button,[role="button"]'))
                                .filter(function(b){return b.offsetParent!==null;});
                            var sib=sibs.find(function(s){
                                var st=(s.innerText||'').trim().toLowerCase();
                                return !st.includes('cancel')&&st.length>1;
                            });
                            if(sib&&sibs.length>=2){found=sib;break;}
                            p=p.parentElement;
                        }
                        if(found)break;
                    }
                }
            }
            if(found){
                var r=found.getBoundingClientRect();
                return JSON.stringify({
                    clicado:true,
                    txt:(found.innerText||'').trim(),
                    x:Math.round(r.left+r.width/2),
                    y:Math.round(r.top+r.height/2)
                });
            }
            var nomes=all.map(function(b){return (b.innerText||'').trim().slice(0,20);}).filter(Boolean);
            return JSON.stringify({clicado:false, botoes:nomes});
        })()"""

        def clicar_no_target(ws_url, js, nome_passo):
            """Executa JS, pega coordenadas e clica com pyautogui."""
            val = ws_eval(ws_url, js)
            if not val:
                log(f"  {nome_passo}: sem resposta do DevTools")
                return False
            try:
                import json as _j
                data = _j.loads(val)
            except:
                log(f"  {nome_passo}: resposta inválida: {str(val)[:80]}")
                return False

            if data.get('clicado') or ('x' in data and 'y' in data):
                # Pega posição absoluta via janela
                import ctypes
                ox, oy = 0, 0
                try:
                    user32 = ctypes.windll.user32
                    for title in ["TikTok LIVE Studio", "LIVE Studio"]:
                        hwnd = user32.FindWindowW(None, title)
                        if hwnd:
                            class RECT(ctypes.Structure):
                                _fields_=[("left",ctypes.c_long),("top",ctypes.c_long),
                                         ("right",ctypes.c_long),("bottom",ctypes.c_long)]
                            rect = RECT()
                            user32.GetWindowRect(hwnd, ctypes.byref(rect))
                            user32.ShowWindow(hwnd, 9)
                            user32.SetForegroundWindow(hwnd)
                            time.sleep(0.5)
                            ox, oy = rect.left, rect.top
                            break
                except: pass

                ax = ox + data['x']
                ay = oy + data['y']
                log(f"  {nome_passo}: '{data.get('txt','')}' → clicando em ({ax},{ay})")
                pyautogui.moveTo(ax, ay, duration=0.3)
                time.sleep(0.2)
                pyautogui.click(ax, ay)
                log(f"  {nome_passo}: ✅ clicado!")
                return True
            else:
                log(f"  {nome_passo}: botão não encontrado")
                log(f"  Botões visíveis: {data.get('botoes', data.get('txt', ''))}")
                return False

        # ── CLIQUE 1: tela de boas-vindas ──
        log("[1/3] Clicando em 'Iniciar LIVE' na tela inicial...")
        clicou1 = False
        for t in targets:
            ws_url = t.get('webSocketDebuggerUrl')
            if not ws_url: continue
            if clicar_no_target(ws_url, JS_CLICAR, "Clique 1"):
                clicou1 = True
                break

        if not clicou1:
            log("❌ Clique 1 falhou — tela inicial não encontrada")
            return False

        # ── Aguarda studio abrir ──
        log("  Aguardando studio carregar (6s)...")
        time.sleep(6)

        # ── CLIQUE 2: botão dentro do studio ──
        log("[2/3] Clicando em 'Iniciar LIVE' no studio...")
        targets2 = get_targets()
        clicou2 = False
        target2_url = None
        for t in targets2:
            ws_url = t.get('webSocketDebuggerUrl')
            if not ws_url: continue
            if clicar_no_target(ws_url, JS_CLICAR, "Clique 2"):
                clicou2 = True
                target2_url = ws_url
                break

        if not clicou2:
            log("❌ Clique 2 falhou")
            return False

        # ── Aguarda modal ──
        log("  Aguardando modal (4s)...")
        time.sleep(4)

        # ── CLIQUE 3: confirma modal ──
        log("[3/3] Confirmando modal...")
        targets3 = get_targets()
        for t in targets3:
            ws_url = t.get('webSocketDebuggerUrl')
            if not ws_url: continue
            if clicar_no_target(ws_url, JS_MODAL, "Clique 3 modal"):
                log("="*40)
                log("✅ LIVE INICIADA COM SUCESSO!")
                log("="*40)
                enviar_telegram(
                    "🎵 <b>LIVE INICIADA!</b>\n"
                    "━━━━━━━━━━━━━━━\n"
                    "▶ Sua TikTok Live está no ar!\n"
                    f"🕐 Início: {time.strftime('%H:%M:%S')}\n"
                    "━━━━━━━━━━━━━━━\n"
                    "<i>Live Infinity • TikTok Shop</i>"
                )
                return True

        log("❌ Modal não confirmado")
        return False

    except Exception as e:
        log(f"ERRO: {e}")
        import traceback
        log(traceback.format_exc()[:300])
        return False
    finally:
        iniciando = False


def encerrar_live():
    global encerrando
    if encerrando: return
    encerrando = True
    log("ENCERRANDO LIVE")
    try:
        focar(); time.sleep(1)
        janela = get_janela()
        if not janela: log("Janela não encontrada!"); return False
        jx,jy,jw,jh = janela
        pyautogui.click(jx+jw-150, jy+jh-50); time.sleep(1.5)
        pyautogui.click(jx+jw-170, jy+jh-130); time.sleep(2)
        pos = encontrar_rosa((jx,jy,jw,jh))
        if pos: pyautogui.click(pos[0], pos[1])
        else: pyautogui.click(jx+jw//2-80, jy+jh//2+60)
        log("ENCERRADO!"); return True
    except Exception as e:
        log(f"ERRO: {e}"); return False
    finally:
        encerrando = False

# ══════════════════════════════════════════════════════
#  SERVIDOR HTTP
# ══════════════════════════════════════════════════════
class Handler(http.server.BaseHTTPRequestHandler):
    def cors(self):
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        self.end_headers()
    def do_OPTIONS(self): self.cors()
    def do_GET(self):
        self.cors()
        self.wfile.write(json.dumps({
            'online':True,'encerrando':encerrando,'iniciando':iniciando
        }).encode())
    def do_POST(self):
        self.cors()
        if self.path=='/iniciar':
            log(">>> INICIAR recebido")
            threading.Thread(target=iniciar_live, daemon=True).start()
            enviar_telegram(
            "🎵 <b>LIVE INICIADA!</b>\n"
            "━━━━━━━━━━━━━━━\n"
            "▶ Sua TikTok Live está no ar!\n"
            f"🕐 Início: {time.strftime('%H:%M:%S')}\n"
            "━━━━━━━━━━━━━━━\n"
            "<i>Live Infinity • TikTok Shop</i>"
        )
            self.wfile.write(json.dumps({'ok':True}).encode())
        elif self.path=='/encerrar':
            log(">>> ENCERRAR recebido")
            threading.Thread(target=encerrar_live, daemon=True).start()
            enviar_telegram(
            "🎵 <b>LIVE ENCERRADA!</b>\n"
            "━━━━━━━━━━━━━━━\n"
            "⏹ Sua TikTok Live foi encerrada\n"
            f"🕐 Horário: {time.strftime('%H:%M:%S')}\n"
            "━━━━━━━━━━━━━━━\n"
            "<i>Live Infinity • TikTok Shop</i>"
        )
            self.wfile.write(json.dumps({'ok':True}).encode())
        elif self.path=='/config_telegram':
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            global TG_TOKEN, TG_CHAT_ID
            TG_TOKEN   = body.get('token', TG_TOKEN)
            TG_CHAT_ID = body.get('chat_id', TG_CHAT_ID)
            log(f"Telegram configurado: chat_id={TG_CHAT_ID[:6]}***")
            self.wfile.write(json.dumps({'ok':True}).encode())
        elif self.path=='/status':
            self.wfile.write(json.dumps({'ok':True,'online':True,'iniciando':iniciando,'encerrando':encerrando}).encode())
        elif self.path=='/venda':
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            vendas  = body.get('vendas','?')
            viewers = body.get('viewers','?')
            hora    = body.get('hora', time.strftime('%H:%M:%S'))
            vendas_val = body.get('ultimaVendaValor', '—')
            gmv        = body.get('gmv', '—')
            msg_venda = (
                f"🔴 <b>NOVA VENDA — {vendas_val}</b>\n"
                "━━━━━━━━━━━━━━━\n"
                f"📦 Total de vendas: <b>{vendas}</b> itens\n"
                f"💰 GMV total: <b>{gmv}</b>\n"
                f"👀 Ao vivo: <b>{viewers}</b> viewers\n"
                f"🕐 Horário: {hora}\n"
                "━━━━━━━━━━━━━━━\n"
                "<i>Live Infinity • TikTok Shop</i>"
            )
            enviar_telegram(msg_venda)
            self.wfile.write(json.dumps({'ok':True}).encode())
        elif self.path=='/violacao_tg':
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            hora = body.get('hora', time.strftime('%H:%M:%S'))
            enviar_telegram(
                f"🚨 <b>ALERTA — VIOLAÇÃO TIKTOK!</b>\n"
                f"━━━━━━━━━━━━━━━\n"
                f"⚠️ Aviso de violação detectado\n"
                f"🕐 Horário: {hora}\n"
                f"⏹ Live encerrada automaticamente\n"
                f"━━━━━━━━━━━━━━━\n"
                f"<i>Live Infinity • TikTok Shop</i>"
            )
            self.wfile.write(json.dumps({'ok':True}).encode())
        elif self.path=='/ativar-licenca':
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            result = ativar_licenca(
                body.get('email', ''),
                body.get('chave', ''),
                body.get('device_id', '')
            )
            if result.get('ok'):
                log(f"Licença ativada: {body.get('email', '')[:3]}***")
            else:
                log(f"Licença recusada: {result.get('msg', '?')}")
            self.wfile.write(json.dumps(result).encode())
        else:
            self.wfile.write(json.dumps({'ok':True}).encode())
    def log_message(self,*a): pass

def main():
    print("="*45)
    print("  LIVE INFINITY - Controlador v7")
    print(f"  Aguardando na porta {PORT}...")
    print("="*45)
    server = http.server.HTTPServer(('localhost', PORT), Handler)
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nEncerrado.")

if __name__=='__main__':
    main()
