@echo off
title Live Infinity - Instalador
color 0B
cls

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║      LIVE INFINITY - INSTALADOR        ║
echo  ║         Instalacao automatica completa   ║
echo  ╚══════════════════════════════════════════╝
echo.

set "PASTA=%~dp0"
set "PASTA=%PASTA:~0,-1%"
set "PY="

echo  [1/4] Verificando Python...

REM Verifica se Python ja esta instalado
python --version >nul 2>&1 && set "PY=python" && goto :py_ok
py --version >nul 2>&1 && set "PY=py" && goto :py_ok
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe" && goto :py_ok
"%LOCALAPPDATA%\Programs\Python\Python312\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe" && goto :py_ok
"%LOCALAPPDATA%\Programs\Python\Python313\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python313\python.exe" && goto :py_ok
"%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" && goto :py_ok

REM Python nao encontrado — baixa e instala automaticamente
echo  Python nao encontrado. Baixando...
echo  (Aguarde, pode demorar alguns minutos)
echo.

REM Baixa o instalador do Python 3.11
curl -L -o "%TEMP%\python_installer.exe" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" --progress-bar

if not exist "%TEMP%\python_installer.exe" (
    echo  ERRO: Nao foi possivel baixar o Python.
    echo  Por favor instale manualmente em: python.org
    pause
    exit
)

echo  Instalando Python silenciosamente...
"%TEMP%\python_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0

REM Aguarda instalacao
timeout /t 5 /nobreak >nul

REM Tenta encontrar de novo
python --version >nul 2>&1 && set "PY=python" && goto :py_ok
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe" && goto :py_ok

echo  ERRO: Instalacao do Python falhou.
echo  Instale manualmente em python.org e execute novamente.
pause
exit

:py_ok
echo  ✅ Python OK: %PY%
echo.

echo  [2/4] Instalando dependencias...
%PY% -m pip install pyautogui numpy pillow opencv-python pygetwindow websocket-client requests --quiet --disable-pip-version-check
echo  ✅ Dependencias instaladas!
echo.

echo  [3/4] Configurando inicializacao automatica...
set "VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\LiveInfinity.vbs"
echo Set oShell = CreateObject("WScript.Shell") > "%VBS%"
echo oShell.Run """%PY%"" ""%PASTA%\reiniciador.py""", 0, False >> "%VBS%"
echo  ✅ Startup configurado!
echo.

echo  [4/4] Abrindo Chrome para instalar a extensao...
timeout /t 2 /nobreak >nul
start "" "chrome.exe" "chrome://extensions"
echo  ✅ Chrome aberto!
echo.

echo  ╔══════════════════════════════════════════╗
echo  ║            INSTALACAO CONCLUIDA!         ║
echo  ╠══════════════════════════════════════════╣
echo  ║                                          ║
echo  ║  Ultimo passo — no Chrome que abriu:    ║
echo  ║                                          ║
echo  ║  1. Ative "Modo desenvolvedor" (canto    ║
echo  ║     superior direito)                    ║
echo  ║                                          ║
echo  ║  2. Clique "Carregar sem compactacao"    ║
echo  ║                                          ║
echo  ║  3. Selecione esta pasta:                ║
echo  ║     %PASTA%
echo  ║                                          ║
echo  ║  4. Pronto! Clique no icone da extensao  ║
echo  ║     na barra do Chrome para comecar.     ║
echo  ║                                          ║
echo  ╚══════════════════════════════════════════╝
echo.
echo  O controlador iniciara automaticamente
echo  quando o Windows ligar.
echo.
pause
