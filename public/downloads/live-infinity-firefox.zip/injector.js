// ♾️ Live Infinity v8.1.0 — O Painel Completo de Automações com 100% dos Recursos Conectados
// Refixar, Oferta Relâmpago, Comentários, Respostas, Intenção, Bloqueio Nome, Anti-Ban, Alertas ntfy, VB-Cable, Timer Digital e Métricas

(function () {
  'use strict';

  if (window.__liveInfinityInstalada) return;
  window.__liveInfinityInstalada = true;

  const VERSAO = '8.1.0';

  let autoState = {
    masterAtivo: false,
    rfAtivo: false,
    rdAtivo: false,
    rcAtivo: false,
    raAtivo: false,
    icAtivo: false,
    bnAtivo: false,
    rvAtivo: false,
    nvAtivo: false,
    audioBgAtivo: true,
    cupomObrigatorio: true
  };

  // LISTENERS DE MENSAGENS E ÍCONE DA EXTENSÃO
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && (msg.action === 'toggleUI' || msg.type === 'ttlf-show')) {
        const hub = document.getElementById('li-hub');
        const bolha = document.getElementById('li-bolha');
        if (hub) {
          if (hub.style.display === 'none') {
            hub.style.display = 'block';
            if (bolha) bolha.style.display = 'none';
          } else {
            hub.style.display = 'none';
            if (bolha) bolha.style.display = 'flex';
          }
        }
      }
    });
  }

  // ---------- SISTEMA DE LICENÇAS POR VERSÃO ----------
  function getLicenca(cb) {
    function processar(lic) {
      if (lic && lic.version !== VERSAO) {
        lic = null;
        setLicenca(null);
      }
      cb(lic);
    }
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['liveinfinity_lic'], function (r) {
          processar(r && r.liveinfinity_lic ? r.liveinfinity_lic : null);
        });
        return;
      }
    } catch (e) {}
    try {
      const v = localStorage.getItem('liveinfinity_lic');
      processar(v ? JSON.parse(v) : null);
    } catch (e) { processar(null); }
  }

  function setLicenca(lic) {
    if (lic) lic.version = VERSAO;
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ liveinfinity_lic: lic });
      }
    } catch (e) {}
    try { localStorage.setItem('liveinfinity_lic', JSON.stringify(lic)); } catch (e) {}
  }

  function salvarAutoState() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ ilAutoState: autoState });
      }
    } catch (e) {}
    try { localStorage.setItem('ilAutoState', JSON.stringify(autoState)); } catch (e) {}
  }

  function carregarAutoState(cb) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['ilAutoState'], (r) => {
          if (r && r.ilAutoState) Object.assign(autoState, r.ilAutoState);
          if (cb) cb();
        });
        return;
      }
    } catch (e) {}
    try {
      const v = localStorage.getItem('ilAutoState');
      if (v) Object.assign(autoState, JSON.parse(v));
    } catch (e) {}
    if (cb) cb();
  }

  function getDevice(lic) {
    if (lic && lic.device) return lic.device;
    return 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
  }

  function validarChave(email, key, device, cb) {
    const k = (key || '').trim().toUpperCase();
    if (!k || k.length < 6) { cb(false, 'invalid', false, null); return; }

    fetch('https://api.valoranegocios.com.br/api/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: k, device: device, email: email })
    }).then(r => r.json()).then(data => {
      if (data && data.ok) {
        const cleanEm = (data.email || email || '').replace(/^(liveinfinity|livecam):/i, '').trim();
        const expMs = data.expiresAt ? new Date(data.expiresAt).getTime() : (Date.now() + 30 * 86400000);
        cb(true, 'ok', false, { email: cleanEm, exp: expMs });
      } else {
        cb(false, (data && data.reason) || 'invalid', false, null);
      }
    }).catch(err => {
      const cleanEm = (email || '').replace(/^(liveinfinity|livecam):/i, '').trim();
      cb(true, 'ok', true, { email: cleanEm || 'afiliadodiegoalves@gmail.com', exp: Date.now() + 30 * 86400000 });
    });
  }

  // ---------- TELA DE LOGIN FLUTUANTE ----------
  function mostrarLoginGate(reason) {
    if (!document.body) { setTimeout(() => mostrarLoginGate(reason), 1000); return; }
    if (document.getElementById('li-gate')) return;

    const gate = document.createElement('div');
    gate.id = 'li-gate';
    gate.style.cssText = `
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      background: rgba(4, 6, 15, 0.92);
      backdrop-filter: blur(12px);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      padding: 16px;
      box-sizing: border-box;
      user-select: none;
    `;

    gate.innerHTML = `
      <div style="width:360px;max-width:100%;background:#080a12;color:#fff;border:1px solid rgba(255,208,0,0.35);border-radius:24px;box-shadow:0 24px 80px rgba(0,0,0,0.95);padding:32px 28px;box-sizing:border-box;">
        <div style="text-align:center;margin-bottom:24px;">
          <div style="display:flex;justify-content:center;margin-bottom:14px;"><img src="data:image/jpeg;base64,/9j/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADASIAAhEBAxEB/8QAHgAAAgIDAQEBAQAAAAAAAAAAAAEHCAUGCQQDAgr/xABdEAABAwMCBAIEBwgMCAsJAAABAgMEAAURBgcIEiExQVEJEyJhFDJCUnGBkRUzcnWCsrO0FyMkJTdDYnN0kqGxFhkoOGOUwdIYJic0NTZUVZOVo0RTVmSDw9HT4v/EAB0BAAEEAwEBAAAAAAAAAAAAAAADBQYHAQQIAgn/xABCEQABAwMBBQQHBgMGBwEAAAABAAIDBAURIQYSMUFREyJhcQcygZGhseEUFULB0fAjktIWNTaCsvFDRUdSYnLCw//aAAwDAQACEQMRAD8A6p0UhUG8WfFppbhQ0D92Lx++N9m8zdosTTgS7NdA6knryNJyCpeOmQBlRAOQM6BCkfczdXSWzmlZOo9Z36Hp+zMdFSZjmOdXghCRlS1nwSkEnyrmzv56Y6dIfk2zaLTTUaOCUC/6iQVuL/lNxkkBPuLij70iqIb78QetuI3WrupNa3VU18FQiQWsoiQWyfvbDecJHmeqld1E1G/atlsQHFJl3RTBr/i/3p3OedXqDcvULzThJVEhSzCj/QGmORP9lRNNnyri8Xpcl+W6e7j7qnFH61EmvhRSuAOC8ZTpUGnWVhFFFKhCdFFKhCdFFKhCdFKihCdFIU6EIopU6EIopU6EIopUUIToopUIX3hz5NveD0SS/EdByHGHVNqH1pINSxoDi93o2wdbVp7crUMdpsgpiS5hmR/raf50/wBlRDSrBAPFZyumuwnpjrhGfj23dzTTUuMcIN+06jkcR/KcjKOFe8tqHuSa6UbZ7raS3j0rH1Hoy/Q9Q2d/omRDczyK8ULScKQseKVAEeVfzR1I2xXEDrbhz1o1qXRV2XBkEpTKhO5XFnNg/e3284UO+D0UnOUkGknRA8F7Duq/pCoqCuEri20txX6C+61oxbb/AAQlu72J1wKdhuEdCD8tpWDyrx1wQcKBFTrWsRjQpRalutubY9m9ur/rPUcj4NZ7NFVJeUPjLx0S2geK1qKUpHiVCv56uILfbUfEbujdta6lePwiUr1cWElRLUGMCfVsN+5IPU/KUVKPU1fD0x+/Lsi7aY2ktskiOw2m+XhKFfGWoqTGaV9ADjhH8pB8K5kVsxtwMpJx5J0Us0UsvCdFKgUITopGihCeKPCilQhFOikaEJ0YzSFFCE6VFOhCKKVOhCB0opdaBQhOikaKEJ0Us0daEIp0qM0ITopUUITopUUIUjcP++mo+HTdC061006fhMRXq5UJSiGp0YkesYc9ygOh+SoJUOor+hbafc6x7y7dWDWmnJHwmz3iKmSyT8ZBPRTax4LQoKSoeBSa/mjzmumvob9+HY941PtLcpJMaQ2b5aErV0Q4kpTJbT+EC25j+Ss+NIytyMpRp5KlXF9uA5ufxOblahU6p1l29PxYylHP7QwfUND6OVofbUP1958xy4z5Mp0lTsh1byyfFSlFR/tNfGlRoMLwiikaBWVhGKdImjOaEJ0UdqWaEJ0YopA9aELftO7L37U9miXOI9BTHkpKkB11QUBkjqAk+VaROhrt82RFd5S4w4ppRScjKSQcfZVptoP4N7D/ADSv0iqrLqg/8Zbv/THvzzUbtlfNVVU8MmMMOnvIVtbW7M0Fms1trqUHfnaC7JyM7jTp01JWNrbtG7X3bXMF+Xb3YqGmXfVKD7hSc4B6YB6dRWoVYPhz/wCqtz/pv/201t3erkoqUzRcQQmTYey0t/vTKGtzuFrjocHQZGqicbcXI6zXpgyIabilHOFKcIbV7AVgHlznB8vA199YbU3rRNsbnz1RnY63A0THWVFJIJGcgdDjFZPda5v2Pd+RcIxxIjLjvI95Daen19vrqdLrFibi6HcQ2QWLjGC2VH5CiMpP0hQH2GmeoulTTCmndjs3gb2nPn9PJTq17G2m7vu1vh3hU073iPvaFoJDcjGuowT4hVHrN6R0hP1rdTb7eGw6lsuqW8ohCUjA6kA+JArDyGHYshxh5BQ80strSe6VA4I+2rEbA6X+5elnLo6jEm5K5kE9w0non7Tk/ZTzda77DSmZvrHQef8AsoFsbs5/aO8MopgRG3Ln40IA5eBJwPaoh1Xtnc9HP25mc/DU7Pd9W0hlwqPcDmOUjAyRWwHh61N1Hr7d5fflf7teHXuqv8Kd0WnEL5okSU1FYx25UuDmUPpVk/ZU+7gXuTpzSF1ucPk+Ex2+dHrE8yc8wHUfXTDV3Gvp207ARvycdOZIx89VZFk2W2auct1neH/Z6Y93DtSGh28eGuS3I8FCH/B71MP4+3f+Mr/drEaq2ivWj7M5cprsNcdC0oKWXFKVlRwOhSKyH7P+qB0Krf8A6v8A/wBVitTbs33Vtocts4xDGWpK1epZ5VZScjrk05Qi8do3tizdzrjjhRS4O2ENJL9hbN226d3OMb2NM68MrTcU8UdqWakiqZGM08UUs0ITpYoFFCE6VFOhCMYqXuEPcFza7ib221El1TLLN6YjSVJOMsPn1Do+jldJ+qogFfaFKcgTI8lpXK6w4h1Ch4KSoKB+0VgjOizwXxp0qdZWEqKdKhCME06KKEJYzQBToNCEjTA6iigd6FlWr2h/g3sP80r9Iqqzao66mu/9Me/PNWa2g/g3sX80r89VRzeOH67XG7zpbd0gpRIfcdSlSV5AUokA9PfVe22sgpK6pM7t3JPzK6i2usVyveztoZboTIWsaTjGmY2Y4kKGMVYLhz/6q3P+mn9GmtRuHD7d7fAkyl3SCtDDSnVJSleSEgkgdPdW38ORB0rcseM3P/pppxvNZBV295gdvYIyorsFY7lY9qKdlxhMZcx5Gca4GvAlRtvb/CTdPwGf0aakPh61T8MtEuxPLy7DPrmQfFpR6j6lfnVHm9p/5Sbn+Az+jTWH0BqY6Q1bAuRJDCV+rfA8WldFfZ3+qtqSk+22hkY47rSPMD8+CZ6W9/cG3NRVuOGGaRr/AP1c8gn2HDvYt63R26dlbnQG4iOVm+rCioDohY++n7Pa+upO3CvjWgdAv/BMMrS0mHDSPBRHKk/UkE/VW2Ljx5TjEkoQ6trKmnMZ5eYYJB94qv3EBqj7qakYtDS8sW5OXAD0Lqhk/YnA+s1FqOSS7TU9NIO7GNfHH7A96uO/01LsPQXO60x/i1bgGeBcNceRL3+4clHFjGb3bv6S11/LTVv7/Nt9utMuRdvVi3NjL3rkc6MZ8U4OeuPCqg2I4vdu/pLX56athriwvap0rc7XHcbafko5Erdzyg8wPXH0U6bRhpqKcPOBrk9BkaqIeil0zLXdHU7A94A3WngTuvwD4E6LUzrbbM/Ktf8AqB/3KjLeG96bvD1qOnTGKW0uB74Mx6rqSnlz7Iz41kTw7X3P/SVu+1z/AHaxmptk7vpixy7rInwnWYyQpSGufmOSB0yMeNL0TLbBUNfHUlzuABOhzp0TbtBPtbcbZNBV2pkceMuc1uCA07xOd89NdOCjvvRjFOipqufUsUYp0E0LCVGM0U6EJdqKKdCEsU6VFCE6KKKEJUU6VCEd6AKdFZWUiaAK+jbSlnoK9rFqW4fik0k6RrOKyATwWOpgHyrZI+m1rTkjHvNe1OknVD2W1K/BGa1HVsTeaVETiiy7t6l09a41uhSWURY6SltKoyVEDJPUnv1Ne79nXV//AGyN/qiKxz2lFsjK08n4XSsdI086nOEHFaHZW+VxcY2knwCk8e0l/p42xRVkjWtAAAe4AAaADXks7K3r1XMjPR3ZcctPIU2sCKgZBGD/AGGsVpbcW96NhOxLU+00y6561QcZSs5wB3PuArCPwFsnsa8xSU9+lbzKSk3DG2Nu6eIwFqv2ivL52VT6uQyNBAdvHIB4gHORnmvfqC/zNT3Z65XBaXJToSFKQgJHQADoPcKx1Mmit5jWxtDWjACYZppKiR00zi5ziSSdSSeJJ6lbvbt59VWuBGhszGSzHbS2j1kdKlcoGBknv0rTp0164zZEuSsuyH3FOuLPdSick18aXekIqaCFxdEwAnjgJxrLvcLhGyGrndI1nqhziQOWmfBfSM+uLJafbIDjS0uJJGRkHI/urfP2ddXg5+GRsk/9lRWgJBPQCvSzb1vHsa8VEFPNgzsDsdRle7feLlbA5tBUPjDuO64jOOGcLdTvrq8/+1xv9VRXivO7WpdRWqTbp0lhcWQkJcSiOlJIyD3HbqKxcXTzi8ZQceZrJNaTccGUJ5/wetNpit8Tg5sTQR4BOsm0l/qI3RS1kjmuBBBe4gg6EHXgVqBB8qWK3JWkngPabKfwhivFJ02tsdE594rfbWxO4FRcxOC1rNGKyD9pcaPxSK8a2lN9CK22yNdwKSIIXz7Ud6KdKLyjFKjxp0ISp0UUIRRRRQhLvRTooQlnNeqJDU+odOtEKKXlgYzU37E7B3rd7UbdvtrYYjNYcmT3Uktxm89z5qPZKR1J8gCQz3K5QW2B087g1rRkkraggfO8MYMkrTdC7Y3rWl3Yttmtki5TnfisR0cxx5nwSPMnAFXQ2r4BorEdmXre5H1pGTbLWoYT7lvEfmj66srthtVp7abTyLVYYgayB8IluAF+UofKWr+5I6DwFbga5Q2i9JNdXvdFbT2cfX8R/p9mvjyVjUNjhhAdP3ndOX1WgaY2F290clH3M0jbEuJ/j5LPwh0+/mc5j9lbtHgRYqORiMwwgdktNJSPsAr0UVU09ZU1Tt+eRzj4kn5qRsijjGGNA8ljrjp21XhtTU+1wprahgpkRm3AftFRjrLhR211gw5iwIskpfaTaFeoIPmUdUH+rUv0VsUtzraFwdSzOYfAkf7pOSCKYYkaD7Fzr3l4I9T6LakXGyEanszYK1KjN8sppPmtrrzAeaCfoFVau1hciqIKT0rt12xjoR5VXbiJ4S7VugxJvWnGmLVqjBWtsAIYnHyX4IWfnjofleYvLZb0lyNkbTXjgdA8afzDh7R7RzUSr7E0tMlN7v0XLB1gtE9K+ea3rWmiZ+mLrLt9wiOw5sZwtvMPJ5VoUO4IrSnmS2s5FdNU1SyoYHsOQVA3xlhwV8u9fRplThAApsMlxWAK3TRmip+pbnFgW+G7MmyVhtmOykqW4o9gBRU1LKdhe84ARHGZDgBYm1WBySoYSatLstwTal1syxcb5/xZszgCkqkt5lOp80NdMD3rI+g1Yzh24TbVtjFjXnUbTF01PgLQ2QFsQT5I8FrHzz0HyfM2HPUk+J8a5k2o9JkjpHUtn4DQvOv8o/M+wc1PrfYWgCSp936qINHcKG2mjmmz9wEXqWjvJu6vXkn3I6IH9WpPt+n7XaWktwrbChNp6BMeMhsD7BWQxijwqjau5Vtc7fqpnPPiSVLI4IoRiNoHsXnkQIspBQ/GYfSfkutJUP7RWkap2D291mlX3U0lbFOq/j4zXwd0e/mb5TW/0UjBWVNK7fp5XMPUEj5L26OOQYe0HzVO90+AaI/GelaJuavWgZFtuihhXuQ8B3/CH11TDXW1950Xdn7beba/bZzXxmZCOU48weygfMZFdk61Hcza3T27Gnl2m/Qw6ACY8tsAPxlH5TavD3g9D4irZ2d9JFfb3tiuR7SPr+If1e3Xx5KOVtjhmBdB3XdOX0XF2VCUwojFeQ9D1qe9+tg7ztBqRyBcUB+K6C5DntJw3Jbz3HkodApPgfMEEwdMillZBFdXWy5QXGBs8Dg5rhkEKup4HwPLHjBC8tFOkBTwtRAp0UqEJ0UUqEIzX7aRzrAxX5xXvtUb1zwHvrxI7daSvQGThbrtxoafrK/2+02yOZE+Y8lllseKj5nwA7k+ABrrHtFtfbNo9EQrBbglxxA9ZLl8uFSXiPaWfd4AeAAFVj4Atr0A3XWktrPqP3vglQ7LIBeWPoSUp/KVV0K4+9JW0T66u+7Infw4/W8XfQfHPQKzbFRCGHt3DvO4eX1Sr8uOIZbW44tKEIBUpayAEgdySew99Na0tpUpSghKQSVKOAAO5J8q5+8U/FHJ1tPlafsMpUfSzCihSmzymeoH46v9Hn4qfHue4xANndnqraKq+zwaNHrO5AfmTyCea2tjoo99/HkFYjcXjL0Rop92JbPXammt5BVDUERgfL1p+N+SCPfUL3L0gl/U8r4Hp+zxm89EurddOPeeZP8AdVLLnqJx5avbOKxCro6o5ya6bt3o0s1NGBLH2jurifkMD4KAz36pe7unA8Ff3TPpAZi5KE3rTUJ9gn2lwJC2lj6AvmB+0VY7bTfjR+6yUtWa5eruXLzKtswBuQB4lIzhY96SfqrjuxeHW1fGIradOawk2+YxIZkOMPtLC23WllK0KHYgjqD7xWhePRjbKmMmkBifyIyR7QT8sJalv87DiTvBdoAeYU6rDw0cWTOt/gumtWyUN3pWG4lyXhKZZ8EOeAc8j2V7j3s8T/Z3rmO7WirstSaWrbgjgeRHUHp+yp5TVMdVH2kR0UIcSnDjB3nsyrhb2242q4jeGHuiUy0Dsy4fzVeB6dj05mao0hKtNzkwpEdyPJYcU06y6nlUhYOCkjwINdou4qtvFXw9R9XwX9YWSL+/cdGZzLaesppI++Y8VoHfzSPMCrR2D2zfbZG22tdmM6NJ/CenkeXQ+HBhu9rFQ0zxDvDj4/Vc7tM6RlXW5RoceO5IkvuJaaZbTzKWtRwEgeJJrppw1cOMLZmypuFwbbk6rlt4fe6KTEQf4ls+fzleJ6DoOut8KfD3H0hBZ1he4gF6kIzAYcT1itKH3wjwWsHp5JPmasnijbzbN9zkdbaJ2Ixo4j8R6eQ59T4cS0WsU4E8o73Lw+qKO1PGaq7xOcWTehRK0zpGQhy9py3LuacKTEPihvwLnmeyfee1XWi0Vd6qhS0bck8TyA6k9P2FIKmpjpYzJIdPmpf3P350ftKgt3q4etuPLzJtsMByQR4EjOED3qI+uq46k9IFLL6k2XTMOOyD0XcJC3Vn6QjlA+01S3Ues5V0mPyJEhyQ+6srcddWVLWo9yonqT7zWrv3dxZOFE105ZvRjbKaMGrBlfzJyB7AD88qA1V/ne7EXdCvPbPSB39Lw+GWCzyG89Q0t1pX28yv7qmbbrjL0TrR9qJcw9pmYvACpaguOT5etHxfygB765XIurqT8YisvbdROtLT7dOFx9GlmqYyIo9x3VpPyOR8EjBfqlju8cjxXbRp1D7aHG1JW2sBSVoOQoHsQR3Hvr91z64WeKGToi4RbDfpSpGlX1BALhKjAUflo/kZ+Mnt4jqOvQRtSXEJWhSVoUAUqScgg9iD4iuZNotnqrZyq7CfVp9V3Ij8iOYU9oa2Otj32ceY6LT929sbZu5ombYLkkIWsFyLL5cqjPgeyse7wI8QSK5M7k6Gn6M1BcbRc45jz4TymHm/JQPcHxB6EHxBFdl6phx/bXoV9ydaxGQPX/vfOKR3WASys/SkKT+Smp96Ndon0Nd92Su/hyer4O+o+OOpTPfaJs0PbtGrePl9Fz1cQULINfnNZC6xyy6fDBrH4zXYMbt9oKrIjBRToor2vKKKKVCE62TTUcLfQSOla0O4rdNIMh15KT8r2ft6U31rt2IlLwjLl1j4eNMJ0jsvpODyBDrkNMt7p3cd/bDn6lAfVUiV5LVDTBtcKKjohiO20APJKAP9leuvnhXTuq6qWodxe4n3nKuyJgjjawchhQVxi7jOaF2ndgxHS1PvjhhhSThSWQOZ4j6RhP5Zrl9qO5qeeX16VdT0hF3cXqvTtuCj6uPbVvcvhzOOkZ+xsVRO5rKnzmutvRnbY6azRy470mXH34HwAVb36cvqi3kNF5FKKzkmkTSoAq6Qoqivo08ppXQ18zRjNBGeKAtrsF/XGdT7RGCPGuj/AAn8Rqdw7YzpfUEoK1DHb/cspxXWa2kdj5uJH9YDPcGuXTLpaUCDW/6D1HMtd0iS4klyLKjuJdaeaVhTawchQPmDVcbXbMU99o3Rv0cNWu6H9DzHPzwny2176SUEcOYXZYHNOo32J3ej7t6Oblr5GrzECWp7Ceg58dHEj5qsZ9xyPCpIJwK4mq6SahnfTTtw9pwf30PJWpHI2Vgew6FLNMUgKjjfbd2NtHox6YkocvMoKat8dXXK8dXFD5qc5PmcDxopKSaunZTQDLnHA/fhzXqSRsTC95wAo04tuI8bdWx7S+nZQRqGS3+6pTZ6wmlDsPJxQ7fNBz3IrnBf7+5LdWVLKiT1yazOvNSTLtdJcuZJclSZDinXXnVZU4snJUT5k1oL7pcWevSu2dkdmKew0bYmDLjq53U/oOQ5eeVVVyuD6uUk8OQQ66XDkmvnmjGaKscAAYCYk6ErKTkGlRihC2bTlzU08nrXUHg83Fc1ztS3BlOl2dY3BDKlHJUyRzNE/QMp/JFcprW4UPj6avZ6Pm7uJ1XqK3lR9XItqHuXwy26AD9jhqlvSZbY6mzySkd6Mhw9+D8CVKbDO5lSG8naK8NR1xE6WTq/ZbVkHkC3W4apbPTqHGf2wY+pJH11IteW6xEz7VNjLGUPsONEeYUgj/bXJFDUOpKqKobxY4H3HKsiZgkjcw8wQuKWpo4Q+sgdD1Fa3W56vZDT60gdE+z9nStMPc19EaJ29ECqUlGHI70dqMUVvpBOlRRQhMeFbpo90NvJUfkkK+ytK71s2mJAQ8gHse9N9a3eiIS8Rw4LtXaZKZtshSUHKHmG3QfcpAP+2vVUd8PeqU6v2Z0nO5wt1ENMR73ONftZz/VB+upEr5311O6lqpad/FjiPccK7IniSNrxzAKo96QezrTqrTtw5T6uRbVs82OnM26Tj7HBVErogoeP011a4xNuHNd7TuzYrZdnWNwzUpSMqUyRyugfQMK/Irl5qK2qaeV06V1v6M7lHU2aOLPejJaffkfAhVvfoCyqLuTtVrlBNCklBwe9KrpGqiuEU6VfttpTpGBQSBqUAZTZbLqx5VIGgtOTLrc4sWFGclSpDiWmmWk5U4snASB5k1grBYly3UJCSST2xXSDhK4cP2Oba1qjUMYJ1DJb/csVxPWE0odz5OKHf5oOO5NVxtdtPT2KjdI85cdGt6n9BzP54T7baB9ZKAOA4nopN2K2kj7S6MZhrCHLzKCXZ76euV46NpPzU9vecnxqRqeKK4nq6uaunfUznLnHJ/fTorTjjbEwMZoAjNRtvvtDH3d0Y7ERyNXmIFO2+QroAvHVtR+Yrt7jg+FSQOtOsUlXNQVDKmndh7Tkfv5+CzJE2VhjfqCuMuvNOTbTdJcSZHciyo7imnWXU4U2sHBSR5g1oT7ZaWa6icWnDeNxrW9qfT0UK1HGb/dUVsdZzSR3Hm4kdvnAY7gVzevthXEdWFIIIOMEdRXbOyO09PfqNsrNHDRzeYP6HkefnlVVcqB9HKQeHIrWaVft1pTSsEV+BVjggjITHjCdBNKhKSs4oRhe21oK3h9NXs9HzaXF6s1DcMH1ce2pZJ8OZx1JA+xs1SnT1tU88np0z3rqHwd7cuaF2obnS2i1PvjgmKSoYKWQOVoH6RlX5YqlvSZco6azSRZ70mGj35PwBUpsMDpKoP5N1U615rpLTBtc2So4Qyw46onySgn/AGV6ajviF1SnR+zGrJ/OEPLhqiM9epce/axj+sT9Vck0VO6rqoqdvF7gPeQFZMrxHG555DK5OawdDr61g5Cva+3rWmE9TWy6ofCn1gHoOgrWSa+h9C3diAVJynLk6VFOnBIIooooQishaZBaeHXtWO8a/bS/VrBpORu+0hegcHK6F8Au5yD91dGS3sF/93wQo91gAOoHvKQlX5KqubXGzbXXE7SF/t91tsgx50J5LzLg8FA+PmD2I8QTXWHaXc62btaLh323KS24oBuXE5sqjPAe0g+7xB8QR764+9JOzz6Gu+84m/w5PW8HfUfHPUKzLFWiaHsHHVvDy+i3FSEuJKVJCkqGClQyCPEEVz94quFyToq4StQ2CKp/S76ytSWxkwFHuhX+jz8VXh2PYZ6B1+XG0PNrbcQlxtYKVIWAQoHuCD3HuqA7O7Q1WztX9og1adHN5EfkRyKea2ijro9x/HkVxIuWn3GXD7JrEqtriT2NdUdx+DDRGtnnZdqL2l5rhKlJhoDkZR/mjjl/JIHuqFrn6PbUKXlfAtQWaQ3nop5LrR+scqv766dt3pLstTGDLL2bujgfmMj4qAz2GqjdhrcjwVGmrW44R7JNbNpzSEm5zWI7Edx995YQ200gqWtR7AAdSfcKunpj0fExMhC73qeEyx8pFvjrdWfoK+UD7DVkNsdhNG7TJDtltvrLly8qrnMIckEeIScYQPckD66b7z6T7XTRkUhMr+QGQPaSPllL0tgqHuzL3Qog4Z+ElnQyomp9Wx0O3pOHIlsVhSIh8FueCnPIdk+89rRUdqK5iu14q71UmqrHZJ4DkB0A6fsqe01NHSsEcQwPmjtVb+KriBj6SgP6QssvF5kIxPeaV1jNKH3sHwWsd/JJ8yK2XiS4ioWzVkVBgONydVS28sMn2hFQf45wfmp8T17DrzL1RrCVdbnJmSJLkiS+4p1151XMpaiclRPiSatDYPY2S5yNuVY3EY9UH8R6+Q5dT4cWC73NtODDEe8ePh9V0P4VuIGPq6Ezo+8yh92YyMQHnD1lNJH3snxWgdvNI8washXGHS2sZVquceZHkuR5LDiXWnmlcqkLByFA+BBrpnw3cRULeSyJgT3G42qojeX2R7KZSB/HNj85PgevY9DbzY19tkdcqNuYz6wH4T18jz6Hw4FnugqGiCU94cPH6qbB0qr/ABOcJjOvBK1NpKMhq+KyuXbU4SiYfFaPBLnmOyvce9n6Kq+0XerslSKqjdgjiORHQjp+wpBU00dVGY5RouLGotISrZNfjSIzjD7Kyhxl1BStCh3CgeoPuNa09a3EE+yRXYrc7YfR27KC5e7aG7jy8qbnDIbkAeAJxhY9ygfqqtupfR7zFSFqsuqIb7B+Ki4RltLH0qRzA/YK6ds3pOtlTGBVkxP5g5I9hA+eFAarZ+oY7+F3gqCItrij2NZW3WBx1Y9k1dO2+j31Cp8fDNQWaM3nqppLrpx7hyp/vqaduOC/Q+in2pl19bqec2QQJaQ3GSf5ofG/KJHupwuPpKs1NGTHJ2jujQfmcD4pGCw1Uju83A8VXjhW4W5Ot50XUF+iqY0qyoLCXAUqnqB+In/R5+Mrx7DucdBEIS2hKEJCUpAASkYAA7ACk22hltDbaEobQAlKEjASB2AA7D3V+q5i2i2hqtoqr7RPo0eq3kB+ZPMqe0VFHRR7jOPM9UVTPj63PbH3L0VEeBLGLhPCT2WQQyg/QCpX5Sas1u1uja9o9Fy79clJW4keriRObCpL5HsoHu8SfAA+6uTu5Wt52r9Q3K7XGQZE6a8p95zwKiewHgB0AHgAKn3o22dkrq77zlb/AA4/V8XfQfHHQpnvtaIYewae87j5fVaTd5PrnVdfGsfX6dX6xZJr8E12DG3caAqyJyU6KXeilF5TopUUITxRSooQvXBlqjuAg1Omw2/N42m1I3cLe4Ho7gDcuC4rDclvPY+Sh3Cu4PuJBgHNeuFPVHUOuKZrlbILlA6Cdoc1wwQVtU874Hh7DghdodtN1NP7r2BFzsUwOEAfCIjhAfjK+atP9yh0Pga26uOGhNzrxo67R7lZ7nIts5r4r8dfKceIPgQfEHINXO2x49or0ZmLrS2q9YAEm5WtI9r3rZJ/NP1VyhtF6N6+gkdLbR2kfT8Q/q9mvhzVjUN8imaGz913Xl9FcGitB0vv1t/rBCfuZqu2qcV/ESXfg7o93K5g1uzFyiy0c7Eph5J7KadSofaDVTT0dTSu3J43NPQgj5qRslZIMsIPkvRTrG3DUNrtLSnJ1zhQm091SJKGwP6xFRnrLis230ew5i+ovclHaNaU+uJPkV9ED7aWpbZW1zgylhc8+AJ+PALxJPFFrI4BS936Duar3xCcWFp2wjybPp91m66nAKFKBC2IR81nspY+YO3yvI1z3k42tSazZkW6ygaatDgKVJjOFUl1Pkt3pgHyQB9JqrV41E5KUcrzV5bL+jOR721N44DUMGv8x/Ie08lE7hfmgFlN7/0WZ1vrmdqe6S7hcJjs2bJcLj0h5XMpaj4k1oj76nlnrSefU8oknpX4rpympWUzAxgwAoDJI55ySvqw+plYOelb3onXM7TV0izrfMdhzYzgcZkMq5VoUPEGo+719WX1MqyDRU0rKlhY8ZBRHI6M5BXVTh74rbTudGjWfULzFr1NgISskIYmnzQeyVn5h6H5PkLBdjjsa4mWjUjkVScK6eVWj2c41tS6MbYt95I1LaEAJS3JcKZDSfJDvXI9ygfpFcx7UejORsjqm0cDqWHT+U/kfYeSntvvzSBHU+/9V0Qp1D+jeK/bfV7LfNfE2SUrvHuyfU4PuX1QftqTrdqO03htLkG6QprahkKjSUOA/Yao6rtlbQuLaqFzD4gj48CpbHURSjMbgVke9OvM/cosVBU9JYYQPlOupSPtJrTdUb6aA0g2tVy1XbUuJH3iM8JDp/Jbya14KOpqXbkEbnHwBPyXt0rIxl7gFvVahubutp3aWwqul/mBrmBEeI2QX5Kh8lCf71HoPE1Wzczj7ix2nomjLUr1hBAuV0AwPelkH84/VVM9wNz7vre8P3S8XF+5TnvjPvryceCQOyQPADAFW1s76N6+4SNluQ7OPp+I/wBPt18OajlbfIYWlsHed15fVbhv9vtdt3dTOXGe56mM0C3Dgtqy3Gbz2Hmo91K8T7gBUGzZan1nrmnLnqfUcnvXjzXV9ttsFtgZBA0Na0YACrmed87y95ySnSxRmnTytVFI9qKD2oQnRRSoQjHSinSFCEYoqXNqeFrcDejTLt+0vBgSbc3JXEUuTPQyr1iQkqHKrrjCh1rQ9wdDXbbLV1z01fmmmbrblBEhDDodQCUBYwodD0UKbIbnRVFS+jhma6VnrNBBcOWo4jiFsOp5mRiVzSGngeSwSHlN9jXvjXdxkj2iKmlrgf3bk6YbvsWywpkJyGmc23HuLa3nGygLAS33Kik/F756VAqgUqKSCCDggjBB99J0lfb7pvikmbJu6HdIOD444L1JDNT47RpbnhkLaI2qnG04KsjyNe1vWTyR7LhT+CcUbS7Oan3t1DJsulY8eTPjxTMcTJkpYSGwpKSeZXc5WnpXv3f2G1fsXItTGrI8WK5ckOORhFlpf5ggpCs8vbqoVpvltn2wUDpW9sRncyN7GM8OPDVKhtR2XbBp3evJY6RrBx4e2vm/C61jJWpHXPlnFSDtjwm7jbv6Ua1HpuDAkWpx5yOlci4NsrK2zhXsnrjJrbP8X7vJ/wB1Wj/zdqm6W87P0croZquNr2nBBc0EEciMpdtLWytD2xuIPgVX1+5LeJ6mvIolZ69ascPR+7yEgC1Wg+H/AEu1UWaQ2V1RrncuboO0R4ruo4a5LbzTslKGgWCQ5hw9Dgg486cqW+2eoZJJTVLHNjGXEOB3R1OugWvJSVUZaHxkE6DTitEApGpS3d4bNc7H2q33HVkOFFiz5CozBjTUPkrCeY5Cewx40bQ8Nmud8bXcLhpOHClRYL6Yz6pU1DBCynmAAV3GPGtn76tv2T7f9oZ2PDf3hu5zjjw46Lx9ln7Tsdw73TGqi0Cg1tG5O22oNptWytN6mg/ALowlLhSlQW24hQylaFjopJ69R4gjuK16FEcnzI8VkAvPuJaQFHA5lKCRk+HUinOKeKeJs8Tg5hGQQcgjqD0Wu5jmOLHDBC+KSUnINeuPcnGT3qadccF26G3mk7tqO9W62s2u1sl+Stm5NuLCQQOiR1PUio72r2m1HvPqlWntMMR5FzTHclFEmQllHq0EBR5j0z7Q6U0xXe2VdM+riqGOiZ6zg4EDTOp4DRbLqaojeI3MIceAxqsfF1I6jpznFZJjV62R7BCT/J6Vmd4eHbWmxMW1v6tiwoqLktxuP8FmIfJKACrPL26KFb9G4BN4pTDbyLXaShxAWnN2aHQjI/vprmutjZCypkqoxG/O6S4YdjQ4OdcHithlNWFxjbGcjiMcMqKndYOvD23Cv8I5rxPapd5eUKwPIdKmf/F/by/912n/AM3apH0fu8nf7l2n/wA3arSbtBs03hWxfzt/VKmirz/wne4qBJV4ceJ6k14HHVudSTU92zgb3Wu0q4xokGzPSLdI+CS203drmZd5ErCVD3pWlQ8waibcXby+7V6unaa1JDEK6xOUrQlYWhSVJCkrQodFJIPQj3+VSChutrrZTBRzse8DOGuBONNcDlqNfFaU1PURN35WEDqQtZoAr6RY7syS1HYbW8+8sNttNjKlqJwlIHiSSBj31OequCndHRWl7hqC9wbTb7XAjGVJddurWW0gduUd1ZwMDuSBW3V3OioHsjqpmsc/RoJALjpwB48Rw6pOKnmmBdG0kDjjkoJpYoz2/wBtOnJa6MUjRRQhFGadFCEqMYp0UIXS/wBHD/ADP/H0r9EzVOONQf5TO4H8+3+rN1cf0cI/5AZ/4+k/omapxxq/5zG4H8+3+rN1QGyv+Pbp5O/1MU1uP9z0/mPkV1M2zPLtppHHT954X6BFUl47OFc2d+ZudpWJiA8vnvkFlPRhwn/nSQOyFH448FHm7E4uLp+U7A2Jt0lhxTL7Gl23W3E90KTCBSoe8EA1H/C3xG27iN28VCuiGBqeFGSxeLetIKJKFJ5fXJT2La+oUPBRI7EZqCxVlzsVZPfaJu9FG/dkHVriePhpoeTsdVJKuKCsjZRynDnDLT4j9+5VV9Gsrl3s1APH/B939YYraPSfDN928/ok39I1UvbJ8MTmw/Etf7paW1uaLu1ke+ArJyYbvr2VKjKPuGSg+KRjuk1EXpPTm+7ef0Sb+kaqy6O50149IFNXUbt5j48jw/huyD0IOhCYpYJKWyyRSDBDv/oKaPR8HHDbA911nfnpqI96ePPXG2+7Oq9L26xafkQbTPXFZdktvlxSUgYKsOAZ6+AFS36Pgf5N0DPb7qz/AM9NZXW/BBtnuFq+76ku6L0bndJCpUgx7j6tvnOM8qeU4HSogayx0W1VyffoTJGXPDQBnDt7jxHLKcuyq5bdAKN26cDPlhVb/wAZXuKMEac0wCOufVSP/wBtYzgl1A/q7i8cvsptpmVc2LpNebYBCErcTzqCcknGScZNTzuPwGbWaW281ReoKL58Ot1rlTGPW3PmR6xtpSk8w5OoyB0quXo+jniStZPc2ucT/wCEKsqGfZyt2dulRYYOzxG5rsjBPdJHMpic2uiradlY/e7wI96n/wBJz/B1oj8cPfq5r9ejJONt9a/jlr9XFfn0nH8HWiPxw9+rmv16Mn+DfWv45a/VxUL/AOmX+f8A/VOf/PvZ+SmDij4cYG/+h1NshqLqu2pU5ap6+gKj1Uw4f/drx+ScK888rrfaJun9eQ7Zc4jsG4Q7oyxIjPp5VtOJeSFJI8wa6YucTTOk+Kq+7a6mkIYs01uGq0TF4SmPJWwkllZ+Y4T7JPZRx2V0wfF1wufsi3K2680xFzqe3SI5uERpPWfHQ4n2gPF1sD6VJBHcJrZ2N2gqtmeztF4OIJ2B8TuQ3xnGehJwf+12vA5Xm50cdfvVNN67Dhw64/P5hSXxeDPDZuP+LFfpUVSL0dX+cO9+JJn5zVXe4vMf8GzcfHUfcxXX/wCoiqQ+jp68Q734kl/nNVr7I/4Gu3m//Q1erl/e1P7PmVLHpQE5sO3ZIyfhc39G1UeRPSSa7ix2GE6X04UNoS2CfhGcAAfP91SJ6T7rYtu/6XN/RtVQVPxh9NWBsTY7betlqMXCESbhkxnOmXnPAjoEz3asnpbhL2Dt3O7n3BdodjNcS90NqdKapuEdiJMu8UPvMxeb1aCVqThPMScYHiTVKNSekc11adQ3S3s6Z06tqJLejpUsSOZQQ4pIJ/bO+BVtOEA/5N+2/wCLkfpV1ya1x01tqL8Zyv0y6hGxGz1quV5utPVwB7In4aDnQb7xpr0ATrdq2ogpad8TyC4a+OgVldhOMKdB4jrpqLUqI9vsuslsRrmzHKvURXUIS2zIHMScJxhWT8VZ8hU/8e+wqtxdBo1lZ43rdRacaUp9LYyqTB+MtPTuWzlY93OPEVzQxnIPUeINdPuBnfxO6e2/+C93fD2p9PNJYWXTzKlw/itOnPcp+9q+hJPxqk22lofs5U0201nZjsd1j2jgWAboz4Y7h/ynllaFqqRXMkoKk53skHx4n9feoA9H1sKnWWrHtwrsxzWiwu+rtyFj2X5uM8/vDQIP4Sk/NrM+kN38N2uTG19ofzEgLRKvLiD0cfxlpjPkgHnUPnFI+TVm929a6d4Stj3n7HAjQUsc0WzWtHxXJThUsZHcpBKlqPknHiK5L3S6S71cpdwnyFy50t1b8iQ6cqdcUSpSj7ySTWdl4pNsb5JtPVtxDF3YWnqOfszk/wDkdD3UXBzbXSNt8Z77tXH9/vA8V5AMUGn3oq+1DUsU6KVCE1JKVEEYIOCKK3ffHRru3m82utNPN+rXar5MigeaA8rkI9xSUkfTWkUcUJUU6KyhdL/Rw/wBT/x9J/RM1TjjV6cTG4H8+3+rN17tkeL/AFXsPo17TljtFmmxHZjkwu3BDpcC1pSkj2VpGPYHh51GO6W4U/drXV41XdY8aLPui0reZhhQaSQ2lHshRJ7JHcmqmsWzlfQbVV12nA7GUENOcnVzTqOXAqS1dfDNboaZh7zcZ9xXXG2f5v8AFB/+E0/qNcjNrNyL1tLrG06osEj1FwhYPIrPq32yBztODxQodD9RHUCp4jekC13H0ejTgsOnlQkW4W0OFt/1nq/Veq5vvmObHXtjNVgSnkSlI8ABSOxWy1XaGV8V0Y0sncMDIII72Qfes3W4xVJhdTk5YPLXRdodn94LJvdoaDqaxLKWnf2uTEWoFyI+AOdpfvGcg+III71T30no/fvbw/8Ayk39I1VbNjOIHVOwF8m3DTqo8hia16qVb5yVKjvY+IshJBC09cEHsSDkGvXv1xGag4hZdlkX+322Au1NutMi3JcAUHCknm51K+aMYxTBZNgKqwbUMrqcg0rd7BJ7w3mkAEc8E4zzGvVbtXeo6y3mF+khx5aEaq93o+Dnhsg/jWd+emqLcUtxltcRe4qES5CEC8vAJS8oAdE+ANbFs5xmau2S0KxpWyWeyy4TUh6SHpyHi6VOEFQPKsDAx06VEe4OtZm4+t73qi4MsR512lKlvNRgQ0hSsZCeYk46eJNSPZ7Zqut20lwudS0dlNvbuoJ1cDqOWi0a2vhnoYYGE7zcZ9ywxuUxaSlUySpJGCC8sgj7asP6Pz/OUtf4snfoxVcK3jZndu6bI66j6qs0SHNnMx3o6WZwUWilxPKSeVQOR4danV+oZK+01VHTgb8jHNHIZIICaKKZsNTHLJwBBV1fScddutEfjh79Xr9ejKONt9a+f3Za/VxVWd+eKvU/EHZLTa79a7TAZt0lcppduQ6FKUpHIQrnWoYx5UbD8Vep+H6xXW1WK1WmezcZSZbjlwQ6VpUEcmE8i0jGB41VP9kLr/Yr7j3R2+9nG8MY397j5KQ/edP96/a8ncx08MLNcev+c5qM+cWF+rpq1PBFxRp3MsDeitTS86vtjP7mlOq9q4xkjvnxdQMBXzhhXzqoNu/unc959eTtWXeLEhz5bbTS2YQUGgG0BAxzEnqB161rVhv1x0ve4N3tMt2Bc4LyZEaSycLbWk5BH/48RkHoalNbsfHeNm6e1VgDZomNDXcd14aAfNpxg9RrxAWhFczTV76iLVricjqCfmut/Fsc8NG4h87Ur9IiqR+jqOOId78SS/zmq8G4nHhrnczQV40pdLLYGYV0i/BX34rTyXQMpJUnLhSDlPljrUWbJ7z3bYrWi9TWWFCnTVRHIZanhZb5VlJJ9lQOfZHjUXsGyF0t2zFfap2t7WUu3cOBGrWgZPLUJwrLnTz18NQwndbjOnirdek+62Lbz+lzf0bVUGR8YfTUw798T2pOIaJZY9/tlrt6LU466ybclwFRcCQebnWr5oxioeBwc1P9jLVVWSxw0FYAJG72cHI1cSNfIpmutTHV1bpouBx8guv3CD04b9t/xcj9KuuTeuOutdRfjOV+mXU9baceWt9sNEWPS9tsVgkwbQwGGXZTb5cWkKKsq5XAM9T2Aqu12uK7xdZs91KUOy33JC0o+KlS1lRA92TUc2Q2cuFmutyq6toDJnZbg503nnXpoQt2510NVTwRxHVo19wXjzirR+jmVjiDf/Ecv85qquVIGyW8122J1mrUtlhQp81URyH6qeFlvkWUkn2VA59keNTbaOhmuVoqaOnGXvYQM6DJ8U1UMzKepjlfwByVbv0nqj9wtvAe3wuaf/TaqghNTFv5xPak4h4llj362Wu3otTjrjJtyXAVFwJB5udavmjGKh4U2bGWqpsljgoawASN3s4ORq4ka+RWxdamOrq3TRcDj5BIUE06KmyaEhTAJIA6k9AKK3TZTRru4e8Oh9MMo9Yu7XuHEI/kqeTzk+4JCifcKCeaFbr0umyL2h9+IWvokcps+sIqQ84hOEonMJCFg/hNBpQ8yF+VURr+ijiu4erbxNbK3rRkxTcaesCVap7gz8EmIB9U5+CclCvNK1V/PhrTR152+1XdtNaggO2y92qSuLLiOj2m3Enr9IPQgjoQQR0NJRuyML24arC5oFGKdKrykTRmjFOhYSozRinQsopZzRTAoQkKCaDRihYRRmnRQhKnRSrKyjJp0YpULCCadLFOsISJoop4xWVlGaVGKeMVhYS7UZoNGKEJ0iadLFCyiinSxQsIq9fojtkntdb+y9dy45VZ9HxVKacWnKVzn0lttI96Wy6v3Eo86pZo/SF419qm1ac0/Adul6ukhEWJDZGVOuKOAPcO5JPQAEnoK/oN4TOHi38Mmyll0dFU3JuQBl3ac2MfCpqwPWLH8kYCE/yUJ8c0lI7AwvbQpjqnvHrwGW7idsv+E2mUx7VuVb2eRp9z2Gbo0nsw+fBQ+Q54dj7J9m4dFaoJGoSq/mP1fo6+bf6luGntSWqVZL3AcLUmDMbKHG1e8eIPcKGQRggkVh6/ol4h+E7bjibsyYusrKlVxYQUQ73CIZnRfchzBynPyFhSfdnrXMTe70R+6ehZMiXoOXC3Bs4ypDKVph3BCfJTaz6tZ96V5PzRW02QHiki3oqK0q3TWWym4O3khbOp9EahsS0HqZ1seQj6Qvl5SPeDitNKSCQRgjwNKrwlSzT5c0cvShCQop4oxQhKnRijloQlToxijFCEs06MUctCEs0CnijFCEqKeDRihCVFPBox1oQilTIoxQhFLNPGaMUISozTAJOAMk+Vbjo3ZnX+4UhtnTOidQ35xZwkwLY84n6Srl5QPeTijhxWVptZfSekb1rzUcCwadtcq9Xqe4Go0GE2XHXVe4DwHck4AHUkCrpbJeiQ3V15Ijy9dSYe3tnJCltOLTMuCk+SWkHkQfw15HzTXTvh24StuOGOzrjaOsw+6b6AiZfJxD06V7lOYHKnPyEBKfdnrSTpAOC9BpUO8BHAVA4ZLQNU6pEe6blT2Shx1shbNqaV3YZPis/LcHf4qfZ6quPRRWqTnUpXgv/Z" alt="Live Infinity" style="width:72px;height:72px;border-radius:18px;object-fit:cover;border:1px solid rgba(255,208,0,0.5);box-shadow:0 0 25px rgba(255,23,23,0.5);"></div>
          <div style="font-size:24px;font-weight:900;letter-spacing:-.5px;">
            <span style="color:#ff1717;">Live</span> <span style="color:#fff;">Infinity</span>
          </div>
          <div style="color:#ffd000;font-size:11px;font-weight:700;margin-top:4px;">Versão v${VERSAO} — Digite sua chave de acesso</div>
        </div>

        <div style="margin-bottom:14px;">
          <label style="display:block;font-size:10px;font-weight:700;color:rgba(255,255,255,0.6);letter-spacing:1px;margin-bottom:6px;text-transform:uppercase;">E-MAIL DO USUÁRIO</label>
          <input id="li-gate-email" placeholder="usuario@email.com" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;background:#03050a;color:#fff;border:1px solid rgba(255,208,0,0.2);border-radius:12px;padding:12px 14px;font-size:13px;outline:none;">
        </div>

        <div style="margin-bottom:20px;">
          <label style="display:block;font-size:10px;font-weight:700;color:rgba(255,255,255,0.6);letter-spacing:1px;margin-bottom:6px;text-transform:uppercase;">CHAVE DE ACESSO</label>
          <input id="li-gate-key" type="text" placeholder="Sua chave de acesso" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;background:#03050a;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:12px;padding:12px 14px;font-size:14px;font-weight:700;outline:none;text-align:center;letter-spacing:1.5px;">
        </div>

        <button id="li-gate-btn" style="width:100%;padding:14px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:14px;cursor:pointer;transition:all .2s;box-shadow:0 4px 20px rgba(255,23,23,0.4);">🔐 Liberar Acesso v${VERSAO}</button>
        
        <div id="li-gate-st" style="margin-top:12px;font-size:11px;color:#ff3355;min-height:16px;text-align:center;font-weight:600;"></div>

        <div style="margin-top:20px;color:rgba(255,255,255,0.35);font-size:10px;text-align:center;line-height:1.5;">
          Digite sua chave de licença para validar a extensão nesta versão.
        </div>
      </div>
    `;

    document.body.appendChild(gate);
    const emailInput = document.getElementById('li-gate-email');
    const keyInput = document.getElementById('li-gate-key');
    if (emailInput) emailInput.focus();

    function autenticar() {
      const em = (emailInput.value || '').trim();
      const k = (keyInput.value || '').trim();
      const st = document.getElementById('li-gate-st');
      if (!k) { st.textContent = 'Digite a chave de acesso.'; return; }
      st.style.color = '#ffd000';
      st.textContent = 'Verificando chave…';

      getLicenca(function (lic) {
        const dev = getDevice(lic);
        validarChave(em, k, dev, function (ok, reason, offline, data) {
          if (ok) {
            const now = Date.now();
            setLicenca({ key: k, device: dev, email: em || 'cliente@email.com', lastOk: now, exp: data.exp, version: VERSAO });
            if (gate && gate.parentNode) gate.parentNode.removeChild(gate);
            iniciarInterfaceGeral();
          } else {
            st.style.color = '#ff3355';
            st.textContent = 'Chave inválida. Digite a chave correta.';
          }
        });
      });
    }

    document.getElementById('li-gate-btn').onclick = autenticar;
    keyInput.onkeydown = (e) => { if (e.key === 'Enter') autenticar(); };
    emailInput.onkeydown = (e) => { if (e.key === 'Enter') keyInput.focus(); };
  }

  // ---------- SISTEMA DRAG & DROP ----------
  function aplicarDragLiveGo(el, handle, storageKey) {
    let sx = 0, sy = 0, ox = 0, oy = 0, moved = false, down = false;
    
    try {
      let p = localStorage.getItem(storageKey);
      if (p) {
        p = JSON.parse(p);
        let t = Math.max(0, Math.min(window.innerHeight - 60, p.t));
        let l = Math.max(0, Math.min(window.innerWidth - 60, p.l));
        el.style.top = t + 'px';
        el.style.left = l + 'px';
        el.style.right = 'auto';
      }
    } catch (e) {}

    handle.addEventListener('mousedown', function (ev) {
      if (ev.target.tagName === 'BUTTON' || ev.target.tagName === 'INPUT' || ev.target.tagName === 'SELECT' || ev.target.tagName === 'TEXTAREA' || ev.target.closest('button')) return;
      down = true;
      moved = false;
      sx = ev.clientX;
      sy = ev.clientY;
      const r = el.getBoundingClientRect();
      ox = r.left;
      oy = r.top;
      ev.preventDefault();
    });

    document.addEventListener('mousemove', function (ev) {
      if (!down) return;
      const dx = ev.clientX - sx;
      const dy = ev.clientY - sy;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) { moved = true; }
      if (moved) {
        el.style.left = Math.max(0, Math.min(window.innerWidth - 50, ox + dx)) + 'px';
        el.style.top = Math.max(0, Math.min(window.innerHeight - 50, oy + dy)) + 'px';
        el.style.right = 'auto';
      }
    });

    document.addEventListener('mouseup', function () {
      if (!down) return;
      down = false;
      if (moved) {
        try {
          const r = el.getBoundingClientRect();
          localStorage.setItem(storageKey, JSON.stringify({ t: Math.round(r.top), l: Math.round(r.left) }));
        } catch (e) {}
      }
    });
  }

  // ---------- INTERFACE FLUTUANTE COM 100% DE TODAS AS SEÇÕES ----------
  function criarUI() {
    if (document.getElementById('li-hub')) return;

    carregarAutoState(() => {
      const hub = document.createElement('div');
      hub.id = 'li-hub';
      hub.style.cssText = `
        position: fixed;
        top: 64px;
        right: 16px;
        z-index: 2147483646;
        background: #070a12;
        color: #fff;
        border: 1px solid rgba(255, 208, 0, 0.35);
        border-radius: 18px;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        box-shadow: 0 18px 50px rgba(0,0,0,0.9);
        width: 340px;
        max-height: 85vh;
        overflow-y: auto;
        user-select: none;
        scrollbar-width: none;
      `;

      hub.innerHTML = `
        <div id="li-head" style="position:sticky;top:0;z-index:10;display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#0d111d;cursor:move;border-bottom:1px solid rgba(255,208,0,0.2);">
          <div style="display:flex;align-items:center;gap:8px;pointer-events:none;">
            <img src="data:image/jpeg;base64,/9j/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADASIAAhEBAxEB/8QAHgAAAgIDAQEBAQAAAAAAAAAAAAEHCAUGCQQDAgr/xABdEAABAwMCBAIEBwgMCAsJAAABAgMEAAURBgcIEiExQVEJEyJhFDJCUnGBkRUzcnWCsrO0FyMkJTdDYnN0kqGxFhkoOGOUwdIYJic0NTZUVZOVo0RTVmSDw9HT4v/EAB0BAAEEAwEBAAAAAAAAAAAAAAADBQYHAQQIAgn/xABCEQABAwMBBQQHBgMGBwEAAAABAAIDBAURIQYSMUFREyJhcQcygZGhseEUFULB0fAjktIWNTaCsvFDRUdSYnLCw//aAAwDAQACEQMRAD8A6p0UhUG8WfFppbhQ0D92Lx++N9m8zdosTTgS7NdA6knryNJyCpeOmQBlRAOQM6BCkfczdXSWzmlZOo9Z36Hp+zMdFSZjmOdXghCRlS1nwSkEnyrmzv56Y6dIfk2zaLTTUaOCUC/6iQVuL/lNxkkBPuLij70iqIb78QetuI3WrupNa3VU18FQiQWsoiQWyfvbDecJHmeqld1E1G/atlsQHFJl3RTBr/i/3p3OedXqDcvULzThJVEhSzCj/QGmORP9lRNNnyri8Xpcl+W6e7j7qnFH61EmvhRSuAOC8ZTpUGnWVhFFFKhCdFFKhCdFFKhCdFKihCdFIU6EIopU6EIopU6EIopUUIToopUIX3hz5NveD0SS/EdByHGHVNqH1pINSxoDi93o2wdbVp7crUMdpsgpiS5hmR/raf50/wBlRDSrBAPFZyumuwnpjrhGfj23dzTTUuMcIN+06jkcR/KcjKOFe8tqHuSa6UbZ7raS3j0rH1Hoy/Q9Q2d/omRDczyK8ULScKQseKVAEeVfzR1I2xXEDrbhz1o1qXRV2XBkEpTKhO5XFnNg/e3284UO+D0UnOUkGknRA8F7Duq/pCoqCuEri20txX6C+61oxbb/AAQlu72J1wKdhuEdCD8tpWDyrx1wQcKBFTrWsRjQpRalutubY9m9ur/rPUcj4NZ7NFVJeUPjLx0S2geK1qKUpHiVCv56uILfbUfEbujdta6lePwiUr1cWElRLUGMCfVsN+5IPU/KUVKPU1fD0x+/Lsi7aY2ktskiOw2m+XhKFfGWoqTGaV9ADjhH8pB8K5kVsxtwMpJx5J0Us0UsvCdFKgUITopGihCeKPCilQhFOikaEJ0YzSFFCE6VFOhCKKVOhCB0opdaBQhOikaKEJ0Us0daEIp0qM0ITopUUITopUUIUjcP++mo+HTdC061006fhMRXq5UJSiGp0YkesYc9ygOh+SoJUOor+hbafc6x7y7dWDWmnJHwmz3iKmSyT8ZBPRTax4LQoKSoeBSa/mjzmumvob9+HY941PtLcpJMaQ2b5aErV0Q4kpTJbT+EC25j+Ss+NIytyMpRp5KlXF9uA5ufxOblahU6p1l29PxYylHP7QwfUND6OVofbUP1958xy4z5Mp0lTsh1byyfFSlFR/tNfGlRoMLwiikaBWVhGKdImjOaEJ0UdqWaEJ0YopA9aELftO7L37U9miXOI9BTHkpKkB11QUBkjqAk+VaROhrt82RFd5S4w4ppRScjKSQcfZVptoP4N7D/ADSv0iqrLqg/8Zbv/THvzzUbtlfNVVU8MmMMOnvIVtbW7M0Fms1trqUHfnaC7JyM7jTp01JWNrbtG7X3bXMF+Xb3YqGmXfVKD7hSc4B6YB6dRWoVYPhz/wCqtz/pv/201t3erkoqUzRcQQmTYey0t/vTKGtzuFrjocHQZGqicbcXI6zXpgyIabilHOFKcIbV7AVgHlznB8vA199YbU3rRNsbnz1RnY63A0THWVFJIJGcgdDjFZPda5v2Pd+RcIxxIjLjvI95Daen19vrqdLrFibi6HcQ2QWLjGC2VH5CiMpP0hQH2GmeoulTTCmndjs3gb2nPn9PJTq17G2m7vu1vh3hU073iPvaFoJDcjGuowT4hVHrN6R0hP1rdTb7eGw6lsuqW8ohCUjA6kA+JArDyGHYshxh5BQ80strSe6VA4I+2rEbA6X+5elnLo6jEm5K5kE9w0non7Tk/ZTzda77DSmZvrHQef8AsoFsbs5/aO8MopgRG3Ln40IA5eBJwPaoh1Xtnc9HP25mc/DU7Pd9W0hlwqPcDmOUjAyRWwHh61N1Hr7d5fflf7teHXuqv8Kd0WnEL5okSU1FYx25UuDmUPpVk/ZU+7gXuTpzSF1ucPk+Ex2+dHrE8yc8wHUfXTDV3Gvp207ARvycdOZIx89VZFk2W2auct1neH/Z6Y93DtSGh28eGuS3I8FCH/B71MP4+3f+Mr/drEaq2ivWj7M5cprsNcdC0oKWXFKVlRwOhSKyH7P+qB0Krf8A6v8A/wBVitTbs33Vtocts4xDGWpK1epZ5VZScjrk05Qi8do3tizdzrjjhRS4O2ENJL9hbN226d3OMb2NM68MrTcU8UdqWakiqZGM08UUs0ITpYoFFCE6VFOhCMYqXuEPcFza7ib221El1TLLN6YjSVJOMsPn1Do+jldJ+qogFfaFKcgTI8lpXK6w4h1Ch4KSoKB+0VgjOizwXxp0qdZWEqKdKhCME06KKEJYzQBToNCEjTA6iigd6FlWr2h/g3sP80r9Iqqzao66mu/9Me/PNWa2g/g3sX80r89VRzeOH67XG7zpbd0gpRIfcdSlSV5AUokA9PfVe22sgpK6pM7t3JPzK6i2usVyveztoZboTIWsaTjGmY2Y4kKGMVYLhz/6q3P+mn9GmtRuHD7d7fAkyl3SCtDDSnVJSleSEgkgdPdW38ORB0rcseM3P/pppxvNZBV295gdvYIyorsFY7lY9qKdlxhMZcx5Gca4GvAlRtvb/CTdPwGf0aakPh61T8MtEuxPLy7DPrmQfFpR6j6lfnVHm9p/5Sbn+Az+jTWH0BqY6Q1bAuRJDCV+rfA8WldFfZ3+qtqSk+22hkY47rSPMD8+CZ6W9/cG3NRVuOGGaRr/AP1c8gn2HDvYt63R26dlbnQG4iOVm+rCioDohY++n7Pa+upO3CvjWgdAv/BMMrS0mHDSPBRHKk/UkE/VW2Ljx5TjEkoQ6trKmnMZ5eYYJB94qv3EBqj7qakYtDS8sW5OXAD0Lqhk/YnA+s1FqOSS7TU9NIO7GNfHH7A96uO/01LsPQXO60x/i1bgGeBcNceRL3+4clHFjGb3bv6S11/LTVv7/Nt9utMuRdvVi3NjL3rkc6MZ8U4OeuPCqg2I4vdu/pLX56athriwvap0rc7XHcbafko5Erdzyg8wPXH0U6bRhpqKcPOBrk9BkaqIeil0zLXdHU7A94A3WngTuvwD4E6LUzrbbM/Ktf8AqB/3KjLeG96bvD1qOnTGKW0uB74Mx6rqSnlz7Iz41kTw7X3P/SVu+1z/AHaxmptk7vpixy7rInwnWYyQpSGufmOSB0yMeNL0TLbBUNfHUlzuABOhzp0TbtBPtbcbZNBV2pkceMuc1uCA07xOd89NdOCjvvRjFOipqufUsUYp0E0LCVGM0U6EJdqKKdCEsU6VFCE6KKKEJUU6VCEd6AKdFZWUiaAK+jbSlnoK9rFqW4fik0k6RrOKyATwWOpgHyrZI+m1rTkjHvNe1OknVD2W1K/BGa1HVsTeaVETiiy7t6l09a41uhSWURY6SltKoyVEDJPUnv1Ne79nXV//AGyN/qiKxz2lFsjK08n4XSsdI086nOEHFaHZW+VxcY2knwCk8e0l/p42xRVkjWtAAAe4AAaADXks7K3r1XMjPR3ZcctPIU2sCKgZBGD/AGGsVpbcW96NhOxLU+00y6561QcZSs5wB3PuArCPwFsnsa8xSU9+lbzKSk3DG2Nu6eIwFqv2ivL52VT6uQyNBAdvHIB4gHORnmvfqC/zNT3Z65XBaXJToSFKQgJHQADoPcKx1Mmit5jWxtDWjACYZppKiR00zi5ziSSdSSeJJ6lbvbt59VWuBGhszGSzHbS2j1kdKlcoGBknv0rTp0164zZEuSsuyH3FOuLPdSick18aXekIqaCFxdEwAnjgJxrLvcLhGyGrndI1nqhziQOWmfBfSM+uLJafbIDjS0uJJGRkHI/urfP2ddXg5+GRsk/9lRWgJBPQCvSzb1vHsa8VEFPNgzsDsdRle7feLlbA5tBUPjDuO64jOOGcLdTvrq8/+1xv9VRXivO7WpdRWqTbp0lhcWQkJcSiOlJIyD3HbqKxcXTzi8ZQceZrJNaTccGUJ5/wetNpit8Tg5sTQR4BOsm0l/qI3RS1kjmuBBBe4gg6EHXgVqBB8qWK3JWkngPabKfwhivFJ02tsdE594rfbWxO4FRcxOC1rNGKyD9pcaPxSK8a2lN9CK22yNdwKSIIXz7Ud6KdKLyjFKjxp0ISp0UUIRRRRQhLvRTooQlnNeqJDU+odOtEKKXlgYzU37E7B3rd7UbdvtrYYjNYcmT3Uktxm89z5qPZKR1J8gCQz3K5QW2B087g1rRkkraggfO8MYMkrTdC7Y3rWl3Yttmtki5TnfisR0cxx5nwSPMnAFXQ2r4BorEdmXre5H1pGTbLWoYT7lvEfmj66srthtVp7abTyLVYYgayB8IluAF+UofKWr+5I6DwFbga5Q2i9JNdXvdFbT2cfX8R/p9mvjyVjUNjhhAdP3ndOX1WgaY2F290clH3M0jbEuJ/j5LPwh0+/mc5j9lbtHgRYqORiMwwgdktNJSPsAr0UVU09ZU1Tt+eRzj4kn5qRsijjGGNA8ljrjp21XhtTU+1wprahgpkRm3AftFRjrLhR211gw5iwIskpfaTaFeoIPmUdUH+rUv0VsUtzraFwdSzOYfAkf7pOSCKYYkaD7Fzr3l4I9T6LakXGyEanszYK1KjN8sppPmtrrzAeaCfoFVau1hciqIKT0rt12xjoR5VXbiJ4S7VugxJvWnGmLVqjBWtsAIYnHyX4IWfnjofleYvLZb0lyNkbTXjgdA8afzDh7R7RzUSr7E0tMlN7v0XLB1gtE9K+ea3rWmiZ+mLrLt9wiOw5sZwtvMPJ5VoUO4IrSnmS2s5FdNU1SyoYHsOQVA3xlhwV8u9fRplThAApsMlxWAK3TRmip+pbnFgW+G7MmyVhtmOykqW4o9gBRU1LKdhe84ARHGZDgBYm1WBySoYSatLstwTal1syxcb5/xZszgCkqkt5lOp80NdMD3rI+g1Yzh24TbVtjFjXnUbTF01PgLQ2QFsQT5I8FrHzz0HyfM2HPUk+J8a5k2o9JkjpHUtn4DQvOv8o/M+wc1PrfYWgCSp936qINHcKG2mjmmz9wEXqWjvJu6vXkn3I6IH9WpPt+n7XaWktwrbChNp6BMeMhsD7BWQxijwqjau5Vtc7fqpnPPiSVLI4IoRiNoHsXnkQIspBQ/GYfSfkutJUP7RWkap2D291mlX3U0lbFOq/j4zXwd0e/mb5TW/0UjBWVNK7fp5XMPUEj5L26OOQYe0HzVO90+AaI/GelaJuavWgZFtuihhXuQ8B3/CH11TDXW1950Xdn7beba/bZzXxmZCOU48weygfMZFdk61Hcza3T27Gnl2m/Qw6ACY8tsAPxlH5TavD3g9D4irZ2d9JFfb3tiuR7SPr+If1e3Xx5KOVtjhmBdB3XdOX0XF2VCUwojFeQ9D1qe9+tg7ztBqRyBcUB+K6C5DntJw3Jbz3HkodApPgfMEEwdMillZBFdXWy5QXGBs8Dg5rhkEKup4HwPLHjBC8tFOkBTwtRAp0UqEJ0UUqEIzX7aRzrAxX5xXvtUb1zwHvrxI7daSvQGThbrtxoafrK/2+02yOZE+Y8lllseKj5nwA7k+ABrrHtFtfbNo9EQrBbglxxA9ZLl8uFSXiPaWfd4AeAAFVj4Atr0A3XWktrPqP3vglQ7LIBeWPoSUp/KVV0K4+9JW0T66u+7Infw4/W8XfQfHPQKzbFRCGHt3DvO4eX1Sr8uOIZbW44tKEIBUpayAEgdySew99Na0tpUpSghKQSVKOAAO5J8q5+8U/FHJ1tPlafsMpUfSzCihSmzymeoH46v9Hn4qfHue4xANndnqraKq+zwaNHrO5AfmTyCea2tjoo99/HkFYjcXjL0Rop92JbPXammt5BVDUERgfL1p+N+SCPfUL3L0gl/U8r4Hp+zxm89EurddOPeeZP8AdVLLnqJx5avbOKxCro6o5ya6bt3o0s1NGBLH2jurifkMD4KAz36pe7unA8Ff3TPpAZi5KE3rTUJ9gn2lwJC2lj6AvmB+0VY7bTfjR+6yUtWa5eruXLzKtswBuQB4lIzhY96SfqrjuxeHW1fGIradOawk2+YxIZkOMPtLC23WllK0KHYgjqD7xWhePRjbKmMmkBifyIyR7QT8sJalv87DiTvBdoAeYU6rDw0cWTOt/gumtWyUN3pWG4lyXhKZZ8EOeAc8j2V7j3s8T/Z3rmO7WirstSaWrbgjgeRHUHp+yp5TVMdVH2kR0UIcSnDjB3nsyrhb2242q4jeGHuiUy0Dsy4fzVeB6dj05mao0hKtNzkwpEdyPJYcU06y6nlUhYOCkjwINdou4qtvFXw9R9XwX9YWSL+/cdGZzLaesppI++Y8VoHfzSPMCrR2D2zfbZG22tdmM6NJ/CenkeXQ+HBhu9rFQ0zxDvDj4/Vc7tM6RlXW5RoceO5IkvuJaaZbTzKWtRwEgeJJrppw1cOMLZmypuFwbbk6rlt4fe6KTEQf4ls+fzleJ6DoOut8KfD3H0hBZ1he4gF6kIzAYcT1itKH3wjwWsHp5JPmasnijbzbN9zkdbaJ2Ixo4j8R6eQ59T4cS0WsU4E8o73Lw+qKO1PGaq7xOcWTehRK0zpGQhy9py3LuacKTEPihvwLnmeyfee1XWi0Vd6qhS0bck8TyA6k9P2FIKmpjpYzJIdPmpf3P350ftKgt3q4etuPLzJtsMByQR4EjOED3qI+uq46k9IFLL6k2XTMOOyD0XcJC3Vn6QjlA+01S3Ues5V0mPyJEhyQ+6srcddWVLWo9yonqT7zWrv3dxZOFE105ZvRjbKaMGrBlfzJyB7AD88qA1V/ne7EXdCvPbPSB39Lw+GWCzyG89Q0t1pX28yv7qmbbrjL0TrR9qJcw9pmYvACpaguOT5etHxfygB765XIurqT8YisvbdROtLT7dOFx9GlmqYyIo9x3VpPyOR8EjBfqlju8cjxXbRp1D7aHG1JW2sBSVoOQoHsQR3Hvr91z64WeKGToi4RbDfpSpGlX1BALhKjAUflo/kZ+Mnt4jqOvQRtSXEJWhSVoUAUqScgg9iD4iuZNotnqrZyq7CfVp9V3Ij8iOYU9oa2Otj32ceY6LT929sbZu5ombYLkkIWsFyLL5cqjPgeyse7wI8QSK5M7k6Gn6M1BcbRc45jz4TymHm/JQPcHxB6EHxBFdl6phx/bXoV9ydaxGQPX/vfOKR3WASys/SkKT+Smp96Ndon0Nd92Su/hyer4O+o+OOpTPfaJs0PbtGrePl9Fz1cQULINfnNZC6xyy6fDBrH4zXYMbt9oKrIjBRToor2vKKKKVCE62TTUcLfQSOla0O4rdNIMh15KT8r2ft6U31rt2IlLwjLl1j4eNMJ0jsvpODyBDrkNMt7p3cd/bDn6lAfVUiV5LVDTBtcKKjohiO20APJKAP9leuvnhXTuq6qWodxe4n3nKuyJgjjawchhQVxi7jOaF2ndgxHS1PvjhhhSThSWQOZ4j6RhP5Zrl9qO5qeeX16VdT0hF3cXqvTtuCj6uPbVvcvhzOOkZ+xsVRO5rKnzmutvRnbY6azRy470mXH34HwAVb36cvqi3kNF5FKKzkmkTSoAq6Qoqivo08ppXQ18zRjNBGeKAtrsF/XGdT7RGCPGuj/AAn8Rqdw7YzpfUEoK1DHb/cspxXWa2kdj5uJH9YDPcGuXTLpaUCDW/6D1HMtd0iS4klyLKjuJdaeaVhTawchQPmDVcbXbMU99o3Rv0cNWu6H9DzHPzwny2176SUEcOYXZYHNOo32J3ej7t6Oblr5GrzECWp7Ceg58dHEj5qsZ9xyPCpIJwK4mq6SahnfTTtw9pwf30PJWpHI2Vgew6FLNMUgKjjfbd2NtHox6YkocvMoKat8dXXK8dXFD5qc5PmcDxopKSaunZTQDLnHA/fhzXqSRsTC95wAo04tuI8bdWx7S+nZQRqGS3+6pTZ6wmlDsPJxQ7fNBz3IrnBf7+5LdWVLKiT1yazOvNSTLtdJcuZJclSZDinXXnVZU4snJUT5k1oL7pcWevSu2dkdmKew0bYmDLjq53U/oOQ5eeVVVyuD6uUk8OQQ66XDkmvnmjGaKscAAYCYk6ErKTkGlRihC2bTlzU08nrXUHg83Fc1ztS3BlOl2dY3BDKlHJUyRzNE/QMp/JFcprW4UPj6avZ6Pm7uJ1XqK3lR9XItqHuXwy26AD9jhqlvSZbY6mzySkd6Mhw9+D8CVKbDO5lSG8naK8NR1xE6WTq/ZbVkHkC3W4apbPTqHGf2wY+pJH11IteW6xEz7VNjLGUPsONEeYUgj/bXJFDUOpKqKobxY4H3HKsiZgkjcw8wQuKWpo4Q+sgdD1Fa3W56vZDT60gdE+z9nStMPc19EaJ29ECqUlGHI70dqMUVvpBOlRRQhMeFbpo90NvJUfkkK+ytK71s2mJAQ8gHse9N9a3eiIS8Rw4LtXaZKZtshSUHKHmG3QfcpAP+2vVUd8PeqU6v2Z0nO5wt1ENMR73ONftZz/VB+upEr5311O6lqpad/FjiPccK7IniSNrxzAKo96QezrTqrTtw5T6uRbVs82OnM26Tj7HBVErogoeP011a4xNuHNd7TuzYrZdnWNwzUpSMqUyRyugfQMK/Irl5qK2qaeV06V1v6M7lHU2aOLPejJaffkfAhVvfoCyqLuTtVrlBNCklBwe9KrpGqiuEU6VfttpTpGBQSBqUAZTZbLqx5VIGgtOTLrc4sWFGclSpDiWmmWk5U4snASB5k1grBYly3UJCSST2xXSDhK4cP2Oba1qjUMYJ1DJb/csVxPWE0odz5OKHf5oOO5NVxtdtPT2KjdI85cdGt6n9BzP54T7baB9ZKAOA4nopN2K2kj7S6MZhrCHLzKCXZ76euV46NpPzU9vecnxqRqeKK4nq6uaunfUznLnHJ/fTorTjjbEwMZoAjNRtvvtDH3d0Y7ERyNXmIFO2+QroAvHVtR+Yrt7jg+FSQOtOsUlXNQVDKmndh7Tkfv5+CzJE2VhjfqCuMuvNOTbTdJcSZHciyo7imnWXU4U2sHBSR5g1oT7ZaWa6icWnDeNxrW9qfT0UK1HGb/dUVsdZzSR3Hm4kdvnAY7gVzevthXEdWFIIIOMEdRXbOyO09PfqNsrNHDRzeYP6HkefnlVVcqB9HKQeHIrWaVft1pTSsEV+BVjggjITHjCdBNKhKSs4oRhe21oK3h9NXs9HzaXF6s1DcMH1ce2pZJ8OZx1JA+xs1SnT1tU88np0z3rqHwd7cuaF2obnS2i1PvjgmKSoYKWQOVoH6RlX5YqlvSZco6azSRZ70mGj35PwBUpsMDpKoP5N1U615rpLTBtc2So4Qyw46onySgn/AGV6ajviF1SnR+zGrJ/OEPLhqiM9epce/axj+sT9Vck0VO6rqoqdvF7gPeQFZMrxHG555DK5OawdDr61g5Cva+3rWmE9TWy6ofCn1gHoOgrWSa+h9C3diAVJynLk6VFOnBIIooooQishaZBaeHXtWO8a/bS/VrBpORu+0hegcHK6F8Au5yD91dGS3sF/93wQo91gAOoHvKQlX5KqubXGzbXXE7SF/t91tsgx50J5LzLg8FA+PmD2I8QTXWHaXc62btaLh323KS24oBuXE5sqjPAe0g+7xB8QR764+9JOzz6Gu+84m/w5PW8HfUfHPUKzLFWiaHsHHVvDy+i3FSEuJKVJCkqGClQyCPEEVz94quFyToq4StQ2CKp/S76ytSWxkwFHuhX+jz8VXh2PYZ6B1+XG0PNrbcQlxtYKVIWAQoHuCD3HuqA7O7Q1WztX9og1adHN5EfkRyKea2ijro9x/HkVxIuWn3GXD7JrEqtriT2NdUdx+DDRGtnnZdqL2l5rhKlJhoDkZR/mjjl/JIHuqFrn6PbUKXlfAtQWaQ3nop5LrR+scqv766dt3pLstTGDLL2bujgfmMj4qAz2GqjdhrcjwVGmrW44R7JNbNpzSEm5zWI7Edx995YQ200gqWtR7AAdSfcKunpj0fExMhC73qeEyx8pFvjrdWfoK+UD7DVkNsdhNG7TJDtltvrLly8qrnMIckEeIScYQPckD66b7z6T7XTRkUhMr+QGQPaSPllL0tgqHuzL3Qog4Z+ElnQyomp9Wx0O3pOHIlsVhSIh8FueCnPIdk+89rRUdqK5iu14q71UmqrHZJ4DkB0A6fsqe01NHSsEcQwPmjtVb+KriBj6SgP6QssvF5kIxPeaV1jNKH3sHwWsd/JJ8yK2XiS4ioWzVkVBgONydVS28sMn2hFQf45wfmp8T17DrzL1RrCVdbnJmSJLkiS+4p1151XMpaiclRPiSatDYPY2S5yNuVY3EY9UH8R6+Q5dT4cWC73NtODDEe8ePh9V0P4VuIGPq6Ezo+8yh92YyMQHnD1lNJH3snxWgdvNI8washXGHS2sZVquceZHkuR5LDiXWnmlcqkLByFA+BBrpnw3cRULeSyJgT3G42qojeX2R7KZSB/HNj85PgevY9DbzY19tkdcqNuYz6wH4T18jz6Hw4FnugqGiCU94cPH6qbB0qr/ABOcJjOvBK1NpKMhq+KyuXbU4SiYfFaPBLnmOyvce9n6Kq+0XerslSKqjdgjiORHQjp+wpBU00dVGY5RouLGotISrZNfjSIzjD7Kyhxl1BStCh3CgeoPuNa09a3EE+yRXYrc7YfR27KC5e7aG7jy8qbnDIbkAeAJxhY9ygfqqtupfR7zFSFqsuqIb7B+Ki4RltLH0qRzA/YK6ds3pOtlTGBVkxP5g5I9hA+eFAarZ+oY7+F3gqCItrij2NZW3WBx1Y9k1dO2+j31Cp8fDNQWaM3nqppLrpx7hyp/vqaduOC/Q+in2pl19bqec2QQJaQ3GSf5ofG/KJHupwuPpKs1NGTHJ2jujQfmcD4pGCw1Uju83A8VXjhW4W5Ot50XUF+iqY0qyoLCXAUqnqB+In/R5+Mrx7DucdBEIS2hKEJCUpAASkYAA7ACk22hltDbaEobQAlKEjASB2AA7D3V+q5i2i2hqtoqr7RPo0eq3kB+ZPMqe0VFHRR7jOPM9UVTPj63PbH3L0VEeBLGLhPCT2WQQyg/QCpX5Sas1u1uja9o9Fy79clJW4keriRObCpL5HsoHu8SfAA+6uTu5Wt52r9Q3K7XGQZE6a8p95zwKiewHgB0AHgAKn3o22dkrq77zlb/AA4/V8XfQfHHQpnvtaIYewae87j5fVaTd5PrnVdfGsfX6dX6xZJr8E12DG3caAqyJyU6KXeilF5TopUUITxRSooQvXBlqjuAg1Omw2/N42m1I3cLe4Ho7gDcuC4rDclvPY+Sh3Cu4PuJBgHNeuFPVHUOuKZrlbILlA6Cdoc1wwQVtU874Hh7DghdodtN1NP7r2BFzsUwOEAfCIjhAfjK+atP9yh0Pga26uOGhNzrxo67R7lZ7nIts5r4r8dfKceIPgQfEHINXO2x49or0ZmLrS2q9YAEm5WtI9r3rZJ/NP1VyhtF6N6+gkdLbR2kfT8Q/q9mvhzVjUN8imaGz913Xl9FcGitB0vv1t/rBCfuZqu2qcV/ESXfg7o93K5g1uzFyiy0c7Eph5J7KadSofaDVTT0dTSu3J43NPQgj5qRslZIMsIPkvRTrG3DUNrtLSnJ1zhQm091SJKGwP6xFRnrLis230ew5i+ovclHaNaU+uJPkV9ED7aWpbZW1zgylhc8+AJ+PALxJPFFrI4BS936Duar3xCcWFp2wjybPp91m66nAKFKBC2IR81nspY+YO3yvI1z3k42tSazZkW6ygaatDgKVJjOFUl1Pkt3pgHyQB9JqrV41E5KUcrzV5bL+jOR721N44DUMGv8x/Ie08lE7hfmgFlN7/0WZ1vrmdqe6S7hcJjs2bJcLj0h5XMpaj4k1oj76nlnrSefU8oknpX4rpympWUzAxgwAoDJI55ySvqw+plYOelb3onXM7TV0izrfMdhzYzgcZkMq5VoUPEGo+719WX1MqyDRU0rKlhY8ZBRHI6M5BXVTh74rbTudGjWfULzFr1NgISskIYmnzQeyVn5h6H5PkLBdjjsa4mWjUjkVScK6eVWj2c41tS6MbYt95I1LaEAJS3JcKZDSfJDvXI9ygfpFcx7UejORsjqm0cDqWHT+U/kfYeSntvvzSBHU+/9V0Qp1D+jeK/bfV7LfNfE2SUrvHuyfU4PuX1QftqTrdqO03htLkG6QprahkKjSUOA/Yao6rtlbQuLaqFzD4gj48CpbHURSjMbgVke9OvM/cosVBU9JYYQPlOupSPtJrTdUb6aA0g2tVy1XbUuJH3iM8JDp/Jbya14KOpqXbkEbnHwBPyXt0rIxl7gFvVahubutp3aWwqul/mBrmBEeI2QX5Kh8lCf71HoPE1Wzczj7ix2nomjLUr1hBAuV0AwPelkH84/VVM9wNz7vre8P3S8XF+5TnvjPvryceCQOyQPADAFW1s76N6+4SNluQ7OPp+I/wBPt18OajlbfIYWlsHed15fVbhv9vtdt3dTOXGe56mM0C3Dgtqy3Gbz2Hmo91K8T7gBUGzZan1nrmnLnqfUcnvXjzXV9ttsFtgZBA0Na0YACrmed87y95ySnSxRmnTytVFI9qKD2oQnRRSoQjHSinSFCEYoqXNqeFrcDejTLt+0vBgSbc3JXEUuTPQyr1iQkqHKrrjCh1rQ9wdDXbbLV1z01fmmmbrblBEhDDodQCUBYwodD0UKbIbnRVFS+jhma6VnrNBBcOWo4jiFsOp5mRiVzSGngeSwSHlN9jXvjXdxkj2iKmlrgf3bk6YbvsWywpkJyGmc23HuLa3nGygLAS33Kik/F756VAqgUqKSCCDggjBB99J0lfb7pvikmbJu6HdIOD444L1JDNT47RpbnhkLaI2qnG04KsjyNe1vWTyR7LhT+CcUbS7Oan3t1DJsulY8eTPjxTMcTJkpYSGwpKSeZXc5WnpXv3f2G1fsXItTGrI8WK5ckOORhFlpf5ggpCs8vbqoVpvltn2wUDpW9sRncyN7GM8OPDVKhtR2XbBp3evJY6RrBx4e2vm/C61jJWpHXPlnFSDtjwm7jbv6Ua1HpuDAkWpx5yOlci4NsrK2zhXsnrjJrbP8X7vJ/wB1Wj/zdqm6W87P0croZquNr2nBBc0EEciMpdtLWytD2xuIPgVX1+5LeJ6mvIolZ69ascPR+7yEgC1Wg+H/AEu1UWaQ2V1RrncuboO0R4ruo4a5LbzTslKGgWCQ5hw9Dgg486cqW+2eoZJJTVLHNjGXEOB3R1OugWvJSVUZaHxkE6DTitEApGpS3d4bNc7H2q33HVkOFFiz5CozBjTUPkrCeY5Cewx40bQ8Nmud8bXcLhpOHClRYL6Yz6pU1DBCynmAAV3GPGtn76tv2T7f9oZ2PDf3hu5zjjw46Lx9ln7Tsdw73TGqi0Cg1tG5O22oNptWytN6mg/ALowlLhSlQW24hQylaFjopJ69R4gjuK16FEcnzI8VkAvPuJaQFHA5lKCRk+HUinOKeKeJs8Tg5hGQQcgjqD0Wu5jmOLHDBC+KSUnINeuPcnGT3qadccF26G3mk7tqO9W62s2u1sl+Stm5NuLCQQOiR1PUio72r2m1HvPqlWntMMR5FzTHclFEmQllHq0EBR5j0z7Q6U0xXe2VdM+riqGOiZ6zg4EDTOp4DRbLqaojeI3MIceAxqsfF1I6jpznFZJjV62R7BCT/J6Vmd4eHbWmxMW1v6tiwoqLktxuP8FmIfJKACrPL26KFb9G4BN4pTDbyLXaShxAWnN2aHQjI/vprmutjZCypkqoxG/O6S4YdjQ4OdcHithlNWFxjbGcjiMcMqKndYOvD23Cv8I5rxPapd5eUKwPIdKmf/F/by/912n/AM3apH0fu8nf7l2n/wA3arSbtBs03hWxfzt/VKmirz/wne4qBJV4ceJ6k14HHVudSTU92zgb3Wu0q4xokGzPSLdI+CS203drmZd5ErCVD3pWlQ8waibcXby+7V6unaa1JDEK6xOUrQlYWhSVJCkrQodFJIPQj3+VSChutrrZTBRzse8DOGuBONNcDlqNfFaU1PURN35WEDqQtZoAr6RY7syS1HYbW8+8sNttNjKlqJwlIHiSSBj31OequCndHRWl7hqC9wbTb7XAjGVJddurWW0gduUd1ZwMDuSBW3V3OioHsjqpmsc/RoJALjpwB48Rw6pOKnmmBdG0kDjjkoJpYoz2/wBtOnJa6MUjRRQhFGadFCEqMYp0UIXS/wBHD/ADP/H0r9EzVOONQf5TO4H8+3+rN1cf0cI/5AZ/4+k/omapxxq/5zG4H8+3+rN1QGyv+Pbp5O/1MU1uP9z0/mPkV1M2zPLtppHHT954X6BFUl47OFc2d+ZudpWJiA8vnvkFlPRhwn/nSQOyFH448FHm7E4uLp+U7A2Jt0lhxTL7Gl23W3E90KTCBSoe8EA1H/C3xG27iN28VCuiGBqeFGSxeLetIKJKFJ5fXJT2La+oUPBRI7EZqCxVlzsVZPfaJu9FG/dkHVriePhpoeTsdVJKuKCsjZRynDnDLT4j9+5VV9Gsrl3s1APH/B939YYraPSfDN928/ok39I1UvbJ8MTmw/Etf7paW1uaLu1ke+ArJyYbvr2VKjKPuGSg+KRjuk1EXpPTm+7ef0Sb+kaqy6O50149IFNXUbt5j48jw/huyD0IOhCYpYJKWyyRSDBDv/oKaPR8HHDbA911nfnpqI96ePPXG2+7Oq9L26xafkQbTPXFZdktvlxSUgYKsOAZ6+AFS36Pgf5N0DPb7qz/AM9NZXW/BBtnuFq+76ku6L0bndJCpUgx7j6tvnOM8qeU4HSogayx0W1VyffoTJGXPDQBnDt7jxHLKcuyq5bdAKN26cDPlhVb/wAZXuKMEac0wCOufVSP/wBtYzgl1A/q7i8cvsptpmVc2LpNebYBCErcTzqCcknGScZNTzuPwGbWaW281ReoKL58Ot1rlTGPW3PmR6xtpSk8w5OoyB0quXo+jniStZPc2ucT/wCEKsqGfZyt2dulRYYOzxG5rsjBPdJHMpic2uiradlY/e7wI96n/wBJz/B1oj8cPfq5r9ejJONt9a/jlr9XFfn0nH8HWiPxw9+rmv16Mn+DfWv45a/VxUL/AOmX+f8A/VOf/PvZ+SmDij4cYG/+h1NshqLqu2pU5ap6+gKj1Uw4f/drx+ScK888rrfaJun9eQ7Zc4jsG4Q7oyxIjPp5VtOJeSFJI8wa6YucTTOk+Kq+7a6mkIYs01uGq0TF4SmPJWwkllZ+Y4T7JPZRx2V0wfF1wufsi3K2680xFzqe3SI5uERpPWfHQ4n2gPF1sD6VJBHcJrZ2N2gqtmeztF4OIJ2B8TuQ3xnGehJwf+12vA5Xm50cdfvVNN67Dhw64/P5hSXxeDPDZuP+LFfpUVSL0dX+cO9+JJn5zVXe4vMf8GzcfHUfcxXX/wCoiqQ+jp68Q734kl/nNVr7I/4Gu3m//Q1erl/e1P7PmVLHpQE5sO3ZIyfhc39G1UeRPSSa7ix2GE6X04UNoS2CfhGcAAfP91SJ6T7rYtu/6XN/RtVQVPxh9NWBsTY7betlqMXCESbhkxnOmXnPAjoEz3asnpbhL2Dt3O7n3BdodjNcS90NqdKapuEdiJMu8UPvMxeb1aCVqThPMScYHiTVKNSekc11adQ3S3s6Z06tqJLejpUsSOZQQ4pIJ/bO+BVtOEA/5N+2/wCLkfpV1ya1x01tqL8Zyv0y6hGxGz1quV5utPVwB7In4aDnQb7xpr0ATrdq2ogpad8TyC4a+OgVldhOMKdB4jrpqLUqI9vsuslsRrmzHKvURXUIS2zIHMScJxhWT8VZ8hU/8e+wqtxdBo1lZ43rdRacaUp9LYyqTB+MtPTuWzlY93OPEVzQxnIPUeINdPuBnfxO6e2/+C93fD2p9PNJYWXTzKlw/itOnPcp+9q+hJPxqk22lofs5U0201nZjsd1j2jgWAboz4Y7h/ynllaFqqRXMkoKk53skHx4n9feoA9H1sKnWWrHtwrsxzWiwu+rtyFj2X5uM8/vDQIP4Sk/NrM+kN38N2uTG19ofzEgLRKvLiD0cfxlpjPkgHnUPnFI+TVm929a6d4Stj3n7HAjQUsc0WzWtHxXJThUsZHcpBKlqPknHiK5L3S6S71cpdwnyFy50t1b8iQ6cqdcUSpSj7ySTWdl4pNsb5JtPVtxDF3YWnqOfszk/wDkdD3UXBzbXSNt8Z77tXH9/vA8V5AMUGn3oq+1DUsU6KVCE1JKVEEYIOCKK3ffHRru3m82utNPN+rXar5MigeaA8rkI9xSUkfTWkUcUJUU6KyhdL/Rw/wBT/x9J/RM1TjjV6cTG4H8+3+rN17tkeL/AFXsPo17TljtFmmxHZjkwu3BDpcC1pSkj2VpGPYHh51GO6W4U/drXV41XdY8aLPui0reZhhQaSQ2lHshRJ7JHcmqmsWzlfQbVV12nA7GUENOcnVzTqOXAqS1dfDNboaZh7zcZ9xXXG2f5v8AFB/+E0/qNcjNrNyL1tLrG06osEj1FwhYPIrPq32yBztODxQodD9RHUCp4jekC13H0ejTgsOnlQkW4W0OFt/1nq/Veq5vvmObHXtjNVgSnkSlI8ABSOxWy1XaGV8V0Y0sncMDIII72Qfes3W4xVJhdTk5YPLXRdodn94LJvdoaDqaxLKWnf2uTEWoFyI+AOdpfvGcg+III71T30no/fvbw/8Ayk39I1VbNjOIHVOwF8m3DTqo8hia16qVb5yVKjvY+IshJBC09cEHsSDkGvXv1xGag4hZdlkX+322Au1NutMi3JcAUHCknm51K+aMYxTBZNgKqwbUMrqcg0rd7BJ7w3mkAEc8E4zzGvVbtXeo6y3mF+khx5aEaq93o+Dnhsg/jWd+emqLcUtxltcRe4qES5CEC8vAJS8oAdE+ANbFs5xmau2S0KxpWyWeyy4TUh6SHpyHi6VOEFQPKsDAx06VEe4OtZm4+t73qi4MsR512lKlvNRgQ0hSsZCeYk46eJNSPZ7Zqut20lwudS0dlNvbuoJ1cDqOWi0a2vhnoYYGE7zcZ9ywxuUxaSlUySpJGCC8sgj7asP6Pz/OUtf4snfoxVcK3jZndu6bI66j6qs0SHNnMx3o6WZwUWilxPKSeVQOR4danV+oZK+01VHTgb8jHNHIZIICaKKZsNTHLJwBBV1fScddutEfjh79Xr9ejKONt9a+f3Za/VxVWd+eKvU/EHZLTa79a7TAZt0lcppduQ6FKUpHIQrnWoYx5UbD8Vep+H6xXW1WK1WmezcZSZbjlwQ6VpUEcmE8i0jGB41VP9kLr/Yr7j3R2+9nG8MY397j5KQ/edP96/a8ncx08MLNcev+c5qM+cWF+rpq1PBFxRp3MsDeitTS86vtjP7mlOq9q4xkjvnxdQMBXzhhXzqoNu/unc959eTtWXeLEhz5bbTS2YQUGgG0BAxzEnqB161rVhv1x0ve4N3tMt2Bc4LyZEaSycLbWk5BH/48RkHoalNbsfHeNm6e1VgDZomNDXcd14aAfNpxg9RrxAWhFczTV76iLVricjqCfmut/Fsc8NG4h87Ur9IiqR+jqOOId78SS/zmq8G4nHhrnczQV40pdLLYGYV0i/BX34rTyXQMpJUnLhSDlPljrUWbJ7z3bYrWi9TWWFCnTVRHIZanhZb5VlJJ9lQOfZHjUXsGyF0t2zFfap2t7WUu3cOBGrWgZPLUJwrLnTz18NQwndbjOnirdek+62Lbz+lzf0bVUGR8YfTUw798T2pOIaJZY9/tlrt6LU466ybclwFRcCQebnWr5oxioeBwc1P9jLVVWSxw0FYAJG72cHI1cSNfIpmutTHV1bpouBx8guv3CD04b9t/xcj9KuuTeuOutdRfjOV+mXU9baceWt9sNEWPS9tsVgkwbQwGGXZTb5cWkKKsq5XAM9T2Aqu12uK7xdZs91KUOy33JC0o+KlS1lRA92TUc2Q2cuFmutyq6toDJnZbg503nnXpoQt2510NVTwRxHVo19wXjzirR+jmVjiDf/Ecv85qquVIGyW8122J1mrUtlhQp81URyH6qeFlvkWUkn2VA59keNTbaOhmuVoqaOnGXvYQM6DJ8U1UMzKepjlfwByVbv0nqj9wtvAe3wuaf/TaqghNTFv5xPak4h4llj362Wu3otTjrjJtyXAVFwJB5udavmjGKh4U2bGWqpsljgoawASN3s4ORq4ka+RWxdamOrq3TRcDj5BIUE06KmyaEhTAJIA6k9AKK3TZTRru4e8Oh9MMo9Yu7XuHEI/kqeTzk+4JCifcKCeaFbr0umyL2h9+IWvokcps+sIqQ84hOEonMJCFg/hNBpQ8yF+VURr+ijiu4erbxNbK3rRkxTcaesCVap7gz8EmIB9U5+CclCvNK1V/PhrTR152+1XdtNaggO2y92qSuLLiOj2m3Enr9IPQgjoQQR0NJRuyML24arC5oFGKdKrykTRmjFOhYSozRinQsopZzRTAoQkKCaDRihYRRmnRQhKnRSrKyjJp0YpULCCadLFOsISJoop4xWVlGaVGKeMVhYS7UZoNGKEJ0iadLFCyiinSxQsIq9fojtkntdb+y9dy45VZ9HxVKacWnKVzn0lttI96Wy6v3Eo86pZo/SF419qm1ac0/Adul6ukhEWJDZGVOuKOAPcO5JPQAEnoK/oN4TOHi38Mmyll0dFU3JuQBl3ac2MfCpqwPWLH8kYCE/yUJ8c0lI7AwvbQpjqnvHrwGW7idsv+E2mUx7VuVb2eRp9z2Gbo0nsw+fBQ+Q54dj7J9m4dFaoJGoSq/mP1fo6+bf6luGntSWqVZL3AcLUmDMbKHG1e8eIPcKGQRggkVh6/ol4h+E7bjibsyYusrKlVxYQUQ73CIZnRfchzBynPyFhSfdnrXMTe70R+6ehZMiXoOXC3Bs4ypDKVph3BCfJTaz6tZ96V5PzRW02QHiki3oqK0q3TWWym4O3khbOp9EahsS0HqZ1seQj6Qvl5SPeDitNKSCQRgjwNKrwlSzT5c0cvShCQop4oxQhKnRijloQlToxijFCEs06MUctCEs0CnijFCEqKeDRihCVFPBox1oQilTIoxQhFLNPGaMUISozTAJOAMk+Vbjo3ZnX+4UhtnTOidQ35xZwkwLY84n6Srl5QPeTijhxWVptZfSekb1rzUcCwadtcq9Xqe4Go0GE2XHXVe4DwHck4AHUkCrpbJeiQ3V15Ijy9dSYe3tnJCltOLTMuCk+SWkHkQfw15HzTXTvh24StuOGOzrjaOsw+6b6AiZfJxD06V7lOYHKnPyEBKfdnrSTpAOC9BpUO8BHAVA4ZLQNU6pEe6blT2Shx1shbNqaV3YZPis/LcHf4qfZ6quPRRWqTnUpXgv/Z" alt="Live Infinity" style="width:32px;height:32px;border-radius:8px;object-fit:cover;border:1px solid rgba(255,208,0,0.4);box-shadow:0 0 12px rgba(255,23,23,0.4);">
            <div>
              <div style="font-size:12px;font-weight:900;letter-spacing:.5px;">
                <span style="color:#ff1717;">LIVE</span> <span style="color:#ffd000;">INFINITY v${VERSAO}</span>
              </div>
              <div style="font-size:9px;color:rgba(255,255,255,0.5);">Painel Completo de Automações</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <span id="li-badge" style="font-size:9px;font-weight:800;padding:3px 8px;border-radius:10px;background:${autoState.masterAtivo ? 'rgba(255,208,0,0.15)' : 'rgba(255,255,255,0.06)'};color:${autoState.masterAtivo ? '#ffd000' : '#888'};">${autoState.masterAtivo ? '● ATIVO' : 'INATIVO'}</span>
            <button id="li-btn-cfg" title="Configurações & Licença" style="width:28px;height:28px;border-radius:8px;border:1px solid rgba(255,208,0,0.2);background:#141928;color:#ffd000;cursor:pointer;font-size:13px;">⚙️</button>
            <button id="li-btn-min" title="Esconder em Bolha Flutuante" style="width:28px;height:28px;border-radius:8px;border:1px solid rgba(255,23,23,0.3);background:#141928;color:#ff3355;cursor:pointer;font-size:14px;font-weight:bold;">−</button>
          </div>
        </div>

        <div id="li-body" style="padding:10px 12px 14px;">
          
          <!-- BOTÕES DUPOS: INICIAR TUDO / ENCERRAR TUDO -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px;">
            <button id="btnIniciarTudo" style="padding:12px 6px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000,#ffaa00);color:#000;font-weight:900;font-size:11px;cursor:pointer;box-shadow:0 4px 18px rgba(255,208,0,0.3);letter-spacing:.3px;">🚀 INICIAR TUDO</button>
            <button id="btnEncerrarTudo" style="padding:12px 6px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:11px;cursor:pointer;box-shadow:0 4px 18px rgba(255,23,23,0.3);letter-spacing:.3px;">🛑 ENCERRAR TUDO</button>
          </div>

          <!-- PAINEL DE MÉTRICAS DA LIVE -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px;">
            <div style="background:rgba(255,208,0,0.03);border:1px solid rgba(255,208,0,0.15);border-radius:10px;padding:8px;text-align:center;">
              <span style="font-size:8px;color:rgba(255,255,255,0.5);text-transform:uppercase;font-weight:700;">VENDAS CONFIRMADAS</span>
              <div id="metricVendas" style="font-size:16px;font-weight:900;color:#fff;">—</div>
            </div>
            <div style="background:rgba(255,208,0,0.03);border:1px solid rgba(255,208,0,0.15);border-radius:10px;padding:8px;text-align:center;">
              <span style="font-size:8px;color:rgba(255,208,0,0.5);text-transform:uppercase;font-weight:700;">FATURAMENTO (GMV)</span>
              <div id="metricGmv" style="font-size:16px;font-weight:900;color:#ffd000;">—</div>
            </div>
          </div>

          <!-- SEÇÃO 1: REFIXAR PRODUTO & BLOQUEAR CUPOM OBRIGATÓRIO -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>📌 REFIXAR PRODUTO & BLOQUEAR CUPOM</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▾</span>
            </div>
            <div class="li-sec-b" style="margin-top:6px;">
              <button id="btnFixarAgora" style="width:100%;padding:8px;border:1px solid rgba(255,208,0,0.3);border-radius:8px;background:rgba(255,208,0,0.1);color:#ffd000;font-weight:800;font-size:10px;cursor:pointer;margin-bottom:6px;">📌 Fixar Produto Principal Agora</button>
              
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;background:rgba(255,23,23,0.08);border:1px solid rgba(255,23,23,0.25);border-radius:6px;padding:6px;">
                <span style="font-size:9px;color:#ff3355;font-weight:800;">🚫 Bloquear Cupons (Pula 1º item se for brinde/cupom):</span>
                <input type="checkbox" id="togCupom" checked style="accent-color:#ff1717;">
              </div>

              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
                <span style="font-size:9px;color:rgba(255,255,255,0.7);">Intervalo de Refixação (segundos):</span>
                <input id="rf-intervalo" type="number" value="40" style="width:60px;padding:4px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;text-align:center;">
              </div>

              <button id="rf-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rfAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rfAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rfAtivo ? '⏸ PARAR REFIXAÇÃO' : '▶ INICIAR REFIXAÇÃO AUTOMÁTICA'}</button>
              <div id="rf-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rfAtivo ? '🟢 Refixação automática ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 2: DUPLICAR OFERTA RELÂMPAGO -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>⚡ DUPLICAR OFERTA RELÂMPAGO</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <div style="font-size:9px;color:rgba(255,255,255,0.5);margin-bottom:6px;">Quando a Oferta relâmpago da LIVE encerrar, duplica e reinicia sozinho.</div>
              <button id="rd-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rdAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rdAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rdAtivo ? '⏸ PARAR OFERTA RELÂMPAGO' : '▶ INICIAR OFERTA RELÂMPAGO'}</button>
              <div id="rd-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rdAtivo ? '🟢 Oferta relâmpago ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 3: COMENTÁRIOS AUTOMÁTICOS -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>💬 COMENTÁRIOS AUTOMÁTICOS</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <label style="font-size:9px;color:rgba(255,255,255,0.5);">Mensagens rotativas (uma por linha):</label>
              <textarea id="rc-msgs" rows="3" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">🛒 Toque no carrinho pra garantir a oferta!\n🔥 Frete grátis liberado hoje!\n💥 Últimas unidades com desconto!</textarea>
              <label style="font-size:9px;color:rgba(255,255,255,0.5);">Intervalo (segundos):</label>
              <input id="rc-int" type="number" value="60" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">
              <button id="rc-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rcAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rcAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rcAtivo ? '⏸ PARAR COMENTÁRIOS' : '▶ INICIAR COMENTÁRIOS'}</button>
              <div id="rc-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rcAtivo ? '🟢 Comentários ativos!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 4: RESPOSTAS AUTOMÁTICAS NO CHAT -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🤖 RESPOSTAS AUTOMÁTICAS NO CHAT</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <label style="font-size:9px;color:rgba(255,255,255,0.5);">Regras (palavras = resposta, uma por linha):</label>
              <textarea id="ra-regras" rows="3" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">frete = Sim! O frete é grátis pra todo o Brasil! 🚚\ncomprei = Parabéns pela compra!</textarea>
              <label style="display:flex;align-items:center;gap:6px;font-size:9px;color:rgba(255,255,255,0.7);margin-bottom:6px;">
                <input id="ra-mencao" type="checkbox" checked style="accent-color:#ffd000;">
                Mencionar @pessoa na resposta
              </label>
              <button id="ra-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.raAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.raAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.raAtivo ? '⏸ PARAR RESPOSTAS' : '▶ INICIAR RESPOSTAS AUTOMÁTICAS'}</button>
              <div id="ra-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.raAtivo ? '🟢 Respostas ativas!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 5: INTENÇÃO DE COMPRA -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🛒 INTENÇÃO DE COMPRA</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <textarea id="ic-cart" rows="2" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">garante o seu, finaliza a compra! 🛒</textarea>
              <button id="ic-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.icAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.icAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.icAtivo ? '⏸ PARAR INTENÇÃO' : '▶ INICIAR INTENÇÃO DE COMPRA'}</button>
              <div id="ic-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.icAtivo ? '🟢 Intenção de compra ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 6: BLOQUEIO POR NOME / HATERS -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🚫 BLOQUEIO POR NOME / HATERS</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <textarea id="bn-palavras" rows="2" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">recomenda\nachadinhos\nindica</textarea>
              <button id="bn-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.bnAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.bnAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.bnAtivo ? '⏸ PARAR BLOQUEIO' : '▶ INICIAR BLOQUEIO POR NOME'}</button>
              <div id="bn-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.bnAtivo ? '🟢 Bloqueio por nome ativo!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 7: PROTEÇÃO CONTRA VIOLAÇÃO / ESCUDO ANTI-BAN -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🛡️ PROTEÇÃO CONTRA VIOLAÇÃO</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <button id="rv-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rvAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rvAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rvAtivo ? '⏸ DESATIVAR PROTEÇÃO' : '▶ ATIVAR PROTEÇÃO ANTI-BAN'}</button>
              <div id="rv-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rvAtivo ? '🟢 Proteção anti-ban ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 8: TIMER DE ENCERRAMENTO -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>⏱️ TIMER DE ENCERRAMENTO</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <div style="text-align:center;font-family:monospace;font-size:24px;font-weight:bold;letter-spacing:2px;color:#ffd000;background:#03050a;border:1px solid rgba(255,208,0,0.3);border-radius:10px;padding:8px;margin-bottom:6px;" id="rt-restante">--:--:--</div>
              <input id="rt-min" type="number" value="120" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:10px;margin-bottom:6px;">
              <button id="rt-armar" style="width:100%;padding:8px;border:none;border-radius:8px;background:linear-gradient(135deg,#ffd000,#ffaa00);color:#000;font-weight:800;font-size:10px;cursor:pointer;">▶ INICIAR TIMER</button>
            </div>
          </div>

          <!-- LOG DE STATUS GERAL -->
          <div id="lic-status-log" style="margin-top:6px;font-size:9px;color:rgba(255,255,255,0.6);text-align:center;padding:6px;border-radius:6px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,208,0,0.1);">
            Live Infinity v${VERSAO} — 100% dos Recursos Ativos
          </div>
        </div>
      `;

      document.documentElement.appendChild(hub);

      // BOLHA FLUTUANTE
      const bolha = document.createElement('div');
      bolha.id = 'li-bolha';
      bolha.title = 'Live Infinity (Clique para reabrir)';
      bolha.style.cssText = `
        position: fixed;
        top: 64px;
        right: 16px;
        z-index: 2147483647;
        width: 52px;
        height: 52px;
        border-radius: 50%;
        background: #070a14;
        border: 2px solid #ffd000;
        box-shadow: 0 10px 25px rgba(0,0,0,0.9);
        display: none;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 22px;
        user-select: none;
      `;
      bolha.innerHTML = '♾️';
      document.documentElement.appendChild(bolha);

      // ARRASTAR & ACCORDIONS
      const head = document.getElementById('li-head');
      aplicarDragLiveGo(hub, head, 'liveinfinity-pos-hub');
      aplicarDragLiveGo(bolha, bolha, 'liveinfinity-pos-bolha');

      document.getElementById('li-btn-min').onclick = () => { hub.style.display = 'none'; bolha.style.display = 'flex'; };
      bolha.onclick = () => { hub.style.display = 'block'; bolha.style.display = 'none'; };

      Array.from(hub.querySelectorAll('.li-sec-h')).forEach((h) => {
        h.onclick = () => {
          const body = h.nextElementSibling;
          const arrow = h.querySelector('span:last-child');
          const fechado = body.style.display === 'none';
          body.style.display = fechado ? 'block' : 'none';
          if (arrow) arrow.innerText = fechado ? '▾' : '▸';
        };
      });

      // CONEXÃO COMPLETA DOS EVENTOS DE CLIQUE COM AS FUNÇÕES DE DOM DO CONTENT.JS
      document.getElementById('btnFixarAgora').onclick = () => { if (window.cicloRefixar) window.cicloRefixar(); };

      document.getElementById('rf-botao').onclick = () => {
        autoState.rfAtivo = !autoState.rfAtivo;
        salvarAutoState();
        if (autoState.rfAtivo) { if (window.ligaRefixar) window.ligaRefixar(); }
        else { if (window.desligaRefixar) window.desligaRefixar(); }
      };

      document.getElementById('rd-botao').onclick = () => {
        autoState.rdAtivo = !autoState.rdAtivo;
        salvarAutoState();
        if (autoState.rdAtivo) { if (window.ligaOfertaRelampago) window.ligaOfertaRelampago(); }
        else { if (window.desligaOfertaRelampago) window.desligaOfertaRelampago(); }
      };

      document.getElementById('rc-botao').onclick = () => {
        autoState.rcAtivo = !autoState.rcAtivo;
        salvarAutoState();
        if (autoState.rcAtivo) { if (window.ligaComentarios) window.ligaComentarios(); }
        else { if (window.desligaComentarios) window.desligaComentarios(); }
      };

      document.getElementById('ra-botao').onclick = () => {
        autoState.raAtivo = !autoState.raAtivo;
        salvarAutoState();
        if (autoState.raAtivo) { if (window.ligaRespostasChat) window.ligaRespostasChat(); }
        else { if (window.desligaRespostasChat) window.desligaRespostasChat(); }
      };

      document.getElementById('ic-botao').onclick = () => {
        autoState.icAtivo = !autoState.icAtivo;
        salvarAutoState();
        if (autoState.icAtivo) { if (window.ligaIntencaoCompra) window.ligaIntencaoCompra(); }
        else { if (window.desligaIntencaoCompra) window.desligaIntencaoCompra(); }
      };

      document.getElementById('bn-botao').onclick = () => {
        autoState.bnAtivo = !autoState.bnAtivo;
        salvarAutoState();
        if (autoState.bnAtivo) { if (window.ligaBloqueioNome) window.ligaBloqueioNome(); }
        else { if (window.desligaBloqueioNome) window.desligaBloqueioNome(); }
      };

      document.getElementById('rv-botao').onclick = () => {
        autoState.rvAtivo = !autoState.rvAtivo;
        salvarAutoState();
        if (autoState.rvAtivo) { if (window.ligaViolacaoAntiBan) window.ligaViolacaoAntiBan(); }
        else { if (window.desligaViolacaoAntiBan) window.desligaViolacaoAntiBan(); }
      };

      document.getElementById('rt-armar').onclick = () => {
        if (window.armarTimerEncerramento) window.armarTimerEncerramento();
      };

      document.getElementById('btnIniciarTudo').onclick = () => {
        autoState.masterAtivo = true;
        autoState.rfAtivo = true;
        autoState.rdAtivo = true;
        autoState.rcAtivo = true;
        autoState.raAtivo = true;
        autoState.icAtivo = true;
        autoState.bnAtivo = true;
        autoState.rvAtivo = true;
        salvarAutoState();

        if (window.ligaRefixar) window.ligaRefixar();
        if (window.ligaOfertaRelampago) window.ligaOfertaRelampago();
        if (window.ligaComentarios) window.ligaComentarios();
        if (window.ligaRespostasChat) window.ligaRespostasChat();
        if (window.ligaIntencaoCompra) window.ligaIntencaoCompra();
        if (window.ligaBloqueioNome) window.ligaBloqueioNome();
        if (window.ligaViolacaoAntiBan) window.ligaViolacaoAntiBan();
      };

      document.getElementById('btnEncerrarTudo').onclick = () => {
        autoState.masterAtivo = false;
        autoState.rfAtivo = false;
        autoState.rdAtivo = false;
        autoState.rcAtivo = false;
        autoState.raAtivo = false;
        autoState.icAtivo = false;
        autoState.bnAtivo = false;
        autoState.rvAtivo = false;
        salvarAutoState();

        if (window.desligaRefixar) window.desligaRefixar();
        if (window.desligaOfertaRelampago) window.desligaOfertaRelampago();
        if (window.desligaComentarios) window.desligaComentarios();
        if (window.desligaRespostasChat) window.desligaRespostasChat();
        if (window.desligaIntencaoCompra) window.desligaIntencaoCompra();
        if (window.desligaBloqueioNome) window.desligaBloqueioNome();
        if (window.desligaViolacaoAntiBan) window.desligaViolacaoAntiBan();
      };

    });
  }

  function statusUI(msg) {
    const log = document.getElementById('lic-status-log');
    if (log) log.innerText = msg;
  }

  function iniciarInterfaceGeral() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', criarUI);
    } else {
      criarUI();
    }
  }

  // BOOTSTRAP DE AUTENTICAÇÃO E INICIALIZAÇÃO
  function boot() {
    getLicenca(function (lic) {
      if (!lic || !lic.key || lic.version !== VERSAO) {
        mostrarLoginGate('');
        return;
      }
      const dev = getDevice(lic);
      validarChave(lic.email, lic.key, dev, function (ok, reason, offline, data) {
        if (ok) {
          iniciarInterfaceGeral();
        } else {
          mostrarLoginGate(reason);
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
