"""Utilitários de licença Live Infinity — 1 chave = 1 usuário (e-mail)."""
import hashlib
import hmac
import json
import os
import re
import secrets
from datetime import date, datetime, timedelta

SECRET = 'InfinityLive2026IlSecret'
LICENCAS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'licencas.json')
KEY_RE = re.compile(r'^LF-([A-F0-9]{8})-([A-F0-9]{4})-(\d{8})-([A-F0-9]{8})$', re.I)


def normalizar_email(email):
    return (email or '').strip().lower()


def hash_usuario(email):
    return hashlib.sha256(normalizar_email(email).encode()).hexdigest()[:8].upper()


def _sig(usr, uid, expiry_str):
    payload = f'{usr}{uid}{expiry_str}'
    return hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()[:8].upper()


def gerar_chave(email, dias=30):
    email_norm = normalizar_email(email)
    if not email_norm or '@' not in email_norm:
        raise ValueError('Informe um e-mail válido.')

    usr = hash_usuario(email_norm)
    uid = secrets.token_hex(2).upper()
    expiry = date.today() + timedelta(days=dias)
    expiry_str = expiry.strftime('%Y%m%d')
    sig = _sig(usr, uid, expiry_str)
    chave = f'LF-{usr}-{uid}-{expiry_str}-{sig}'
    return chave, expiry, email_norm


def validar_chave(email, chave):
    chave = (chave or '').strip().upper()
    m = KEY_RE.match(chave)
    if not m:
        return False, 'Formato inválido. Use: LF-XXXXXXXX-XXXX-AAAAMMDD-XXXXXXXX'

    usr, uid, expiry_str, sig = m.groups()
    usr = usr.upper()
    uid = uid.upper()
    sig = sig.upper()

    if hash_usuario(email) != usr:
        return False, 'E-mail não corresponde a esta chave.'

    if sig != _sig(usr, uid, expiry_str):
        return False, 'Chave inválida.'

    y = int(expiry_str[:4])
    mo = int(expiry_str[4:6])
    d = int(expiry_str[6:8])
    expiry = date(y, mo, d)
    if date.today() > expiry:
        return False, f'Chave expirada em {expiry.strftime("%d/%m/%Y")}.'

    expira_ms = int(datetime(y, mo, d, 23, 59, 59).timestamp() * 1000)
    return True, expira_ms


def carregar_licencas():
    if not os.path.isfile(LICENCAS_FILE):
        return {}
    try:
        with open(LICENCAS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def salvar_licencas(data):
    with open(LICENCAS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def registrar_chave(chave, email, expira):
    licencas = carregar_licencas()
    chave = chave.upper()
    licencas[chave] = {
        'email': normalizar_email(email),
        'criada_em': datetime.now().isoformat(timespec='seconds'),
        'expira_em': expira.strftime('%Y-%m-%d'),
        'device_id': None,
        'ativada_em': None
    }
    salvar_licencas(licencas)


def ativar_licenca(email, chave, device_id):
    ok, result = validar_chave(email, chave)
    if not ok:
        return {'ok': False, 'msg': result}

    chave = chave.strip().upper()
    email_norm = normalizar_email(email)
    device_id = (device_id or '').strip()
    if not device_id:
        return {'ok': False, 'msg': 'Identificador do dispositivo inválido.'}

    licencas = carregar_licencas()
    entry = licencas.get(chave)

    if entry is None:
        y = int(chave.split('-')[3][:4])
        mo = int(chave.split('-')[3][4:6])
        d = int(chave.split('-')[3][6:8])
        licencas[chave] = {
            'email': email_norm,
            'criada_em': datetime.now().isoformat(timespec='seconds'),
            'expira_em': date(y, mo, d).isoformat(),
            'device_id': device_id,
            'ativada_em': datetime.now().isoformat(timespec='seconds')
        }
        salvar_licencas(licencas)
        return {'ok': True, 'expira': result, 'msg': 'Acesso liberado.'}

    if entry.get('email') != email_norm:
        return {'ok': False, 'msg': 'E-mail não corresponde a esta chave.'}

    stored = entry.get('device_id')
    if stored and stored != device_id:
        return {
            'ok': False,
            'msg': 'Esta chave já está em uso em outro dispositivo. Cada chave permite apenas 1 usuário.'
        }

    if not stored:
        entry['device_id'] = device_id
        entry['ativada_em'] = datetime.now().isoformat(timespec='seconds')
        salvar_licencas(licencas)

    return {'ok': True, 'expira': result, 'msg': 'Acesso liberado.'}
