@echo off
title Live Infinity - Instalando startup...

set "PASTA=%~dp0"
set "PASTA=%PASTA:~0,-1%"

REM Detecta Python
python --version >nul 2>&1 && set "PY=python" && goto :found
py --version >nul 2>&1 && set "PY=py" && goto :found
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe" && goto :found
"%LOCALAPPDATA%\Programs\Python\Python312\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe" && goto :found
"%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" --version >nul 2>&1 && set "PY=%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" && goto :found
echo ERRO: Python nao encontrado!
pause
exit

:found
set "VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\LiveInfinity.vbs"
echo Set oShell = CreateObject("WScript.Shell") > "%VBS%"
echo oShell.Run """%PY%"" ""%PASTA%\reiniciador.py""", 0, False >> "%VBS%"

echo.
echo  ✅ Startup instalado com sucesso!
echo  O Live Infinity iniciara automaticamente com o Windows.
echo.
pause
