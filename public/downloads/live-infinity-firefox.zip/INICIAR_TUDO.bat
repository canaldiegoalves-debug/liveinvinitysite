@echo off
title Live Infinity
cd /d "%~dp0"

echo.
echo  ========================================
echo   LIVE INFINITY - Iniciando sistema...
echo  ========================================
echo.
echo  [1/2] Iniciando controlador Python...
echo  Para garantir o áudio, inicie também o audio_server.py
start /MIN "Live Infinity Controlador" python reiniciador.py

timeout /t 2 /nobreak >nul

echo  [2/2] Abrindo TikTok Shop no Chrome...
start "" "chrome.exe" "https://shop.tiktok.com/streamer/live/product/dashboard"

echo.
echo  ========================================
echo   Sistema pronto!
echo.
echo   O controlador esta rodando em background
echo   (icone na barra de tarefas).
echo.
echo   Funcoes automaticas disponiveis:
echo   - Iniciar live no horario agendado
echo   - Encerrar live ao detectar violacao
echo   - Encerrar live quando timer zerar
echo  ========================================
echo.
timeout /t 4 /nobreak >nul
