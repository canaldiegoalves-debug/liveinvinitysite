// Live Infinity — Controle de acesso online
(function () {
  'use strict';

  var STORAGE_TOKEN   = 'ilAcessoToken';
  var STORAGE_VALIDO  = 'ilAcessoValidado';
  var STORAGE_EXPIRA  = 'ilAcessoExpira';
  var STORAGE_EMAIL   = 'ilAcessoEmail';
  var STORAGE_DEVICE  = 'ilDeviceId';
  var STORAGE_PLAN    = 'ilAcessoPlano';
  
  var VALIDATE_URL    = 'https://api.valoranegocios.com.br/api/validate';
  var ACTIVATE_URL    = 'https://api.valoranegocios.com.br/api/activate';

  function syncLegacyKeys(token, email, expiraMs, plan, isLegacy) {
    chrome.storage.local.get(['ilIsLegacySubscriber'], function(d) {
      const isLegacyVal = isLegacy !== undefined ? Boolean(isLegacy) : (d.ilIsLegacySubscriber !== undefined ? d.ilIsLegacySubscriber : true);
      chrome.storage.local.set({
        ilChaveAtiva: token,
        ilChaveValidada: true,
        [STORAGE_EMAIL]: email,
        [STORAGE_TOKEN]: token,
        [STORAGE_VALIDO]: true,
        [STORAGE_EXPIRA]: expiraMs,
        [STORAGE_PLAN]: plan || 'basic',
        ilIsLegacySubscriber: isLegacyVal
      });
    });
  }

  function limparAcesso() {
    chrome.storage.local.remove([
      STORAGE_TOKEN, STORAGE_VALIDO, STORAGE_EXPIRA, STORAGE_EMAIL, STORAGE_PLAN,
      'ilChaveAtiva', 'ilChaveValidada'
    ]);
  }

  function formatDate(d) {
    return ('0' + d.getDate()).slice(-2) + '/' +
           ('0' + (d.getMonth() + 1)).slice(-2) + '/' +
           d.getFullYear();
  }

  function normalizarEmail(email) {
    return (email || '').trim().toLowerCase();
  }

  // Fingerprint do computador
  function sha256Hex(value) {
    var enc = new TextEncoder();
    return crypto.subtle.digest('SHA-256', enc.encode(value)).then(function (buf) {
      var arr = Array.from(new Uint8Array(buf));
      return arr.map(function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    });
  }

  function webglIdentity() {
    try {
      var canvas = document.createElement('canvas');
      var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) return '';
      var extension = gl.getExtension('WEBGL_debug_renderer_info');
      var vendor = extension ? gl.getParameter(extension.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR);
      var renderer = extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
      return (vendor || '') + '|' + (renderer || '');
    } catch (e) {
      return '';
    }
  }

  function computerFingerprint(callback) {
    var platform = navigator.userAgentData && navigator.userAgentData.platform || navigator.platform || '';
    var languages = navigator.languages ? navigator.languages.join(',') : navigator.language || '';
    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    
    var signals = [
      platform,
      navigator.hardwareConcurrency || 0,
      navigator.deviceMemory || 0,
      screen.width || 0,
      screen.height || 0,
      screen.colorDepth || 0,
      tz,
      languages,
      webglIdentity()
    ];

    sha256Hex(signals.join('||')).then(callback).catch(function () {
      callback('0000000000000000000000000000000000000000000000000000000000000000');
    });
  }

  function obterDeviceId(callback) {
    chrome.storage.local.get([STORAGE_DEVICE], function (d) {
      if (d[STORAGE_DEVICE]) {
        callback(d[STORAGE_DEVICE]);
        return;
      }
      var id = 'LI-' + crypto.randomUUID().replace(/-/g, '').slice(0, 16).toUpperCase();
      chrome.storage.local.set({ [STORAGE_DEVICE]: id }, function () {
        callback(id);
      });
    });
  }

  function validarOnline(email, token, callback) {
    obterDeviceId(function (deviceId) {
      computerFingerprint(function (fingerprint) {
        fetch(VALIDATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: normalizarEmail(email),
            key: token.trim().toUpperCase(),
            deviceId: deviceId,
            deviceFingerprint: fingerprint
          })
        }).then(function (r) {
          if (!r.ok) {
            return r.json().then(function (errData) {
              throw new Error(errData.error || 'Erro na validação do servidor.');
            }).catch(function (e) {
              throw new Error(e.message || 'Erro HTTP ' + r.status);
            });
          }
          return r.json();
        }).then(function (data) {
          if (data && data.ok) {
            var expiresAtStr = data.license && data.license.expiresAt;
            var expiresDate = expiresAtStr ? new Date(expiresAtStr) : new Date(Date.now() + 30 * 86400000);
            var expiraMs = expiresDate.getTime();
            callback(true, 'Acesso liberado até ' + formatDate(expiresDate) + '.', expiraMs, data.plan);
          } else {
            callback(false, (data && data.error) || 'Não foi possível validar a licença.');
          }
        }).catch(function (err) {
          callback(false, err.message || 'Erro de rede ou servidor indisponível.');
        });
      });
    });
  }

  function ativarOnline(email, token, callback) {
    obterDeviceId(function (deviceId) {
      computerFingerprint(function (fingerprint) {
        fetch(ACTIVATE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: normalizarEmail(email),
            key: token.trim().toUpperCase(),
            deviceId: deviceId,
            deviceFingerprint: fingerprint
          })
        }).then(function (r) {
          if (!r.ok) {
            return r.json().then(function (errData) {
              throw new Error(errData.error || 'Erro na ativação do servidor.');
            }).catch(function (e) {
              throw new Error(e.message || 'Erro HTTP ' + r.status);
            });
          }
          return r.json();
        }).then(function (data) {
          if (data && data.ok) {
            var expiresAtStr = data.license && data.license.expiresAt;
            var expiresDate = expiresAtStr ? new Date(expiresAtStr) : new Date(Date.now() + 30 * 86400000);
            var expiraMs = expiresDate.getTime();
            callback(true, 'Acesso liberado até ' + formatDate(expiresDate) + '.', expiraMs, data.plan);
          } else {
            callback(false, (data && data.error) || 'Não foi possível ativar a licença.');
          }
        }).catch(function (err) {
          callback(false, err.message || 'Erro de rede ou servidor indisponível.');
        });
      });
    });
  }

  function sessaoExpirada(expiraMs) {
    return !expiraMs || Date.now() > expiraMs;
  }

  function ocultarTela() {
    var el = document.getElementById('accessScreen');
    if (!el) return;
    el.style.opacity = '0';
    el.style.pointerEvents = 'none';
    setTimeout(function () { el.style.display = 'none'; }, 400);
  }

  function mostrarTela() {
    var el = document.getElementById('accessScreen');
    if (el) el.style.display = 'flex';
  }

  function revalidarSessao(callback) {
    chrome.storage.local.get([STORAGE_TOKEN, STORAGE_VALIDO, STORAGE_EXPIRA, STORAGE_EMAIL], function (d) {
      if (!d[STORAGE_VALIDO] || !d[STORAGE_TOKEN] || !d[STORAGE_EMAIL]) {
        callback(false, 'Sessão não encontrada.');
        return;
      }
      // Revalida online
      validarOnline(d[STORAGE_EMAIL], d[STORAGE_TOKEN], function (ok, msg, expiraMs, plan) {
        if (ok && expiraMs) {
          syncLegacyKeys(d[STORAGE_TOKEN], d[STORAGE_EMAIL], expiraMs, plan);
          callback(true, msg);
        } else {
          // Se for erro de rede/servidor offline, aceitamos a validação local por tempo restante
          if (msg.indexOf('rede') > -1 || msg.indexOf('servidor') > -1 || msg.indexOf('HTTP') > -1) {
            if (!sessaoExpirada(d[STORAGE_EXPIRA])) {
              callback(true, 'Validado localmente (servidor offline).');
            } else {
              callback(false, 'Chave expirada e servidor offline.');
            }
          } else {
            callback(false, msg || 'Licença revogada ou inválida.');
          }
        }
      });
    });
  }

  function liberarAcesso() {
    var emailEl = document.getElementById('accessEmail');
    var tokenEl = document.getElementById('accessToken');
    var btn     = document.getElementById('accessBtn');
    var errEl   = document.getElementById('accessErr');
    var okEl    = document.getElementById('accessOk');

    var email = normalizarEmail(emailEl && emailEl.value);
    var token = (tokenEl && tokenEl.value || '').trim();

    if (errEl) errEl.textContent = '';
    if (okEl)  okEl.textContent  = '';

    if (!email || email.indexOf('@') < 1) {
      if (errEl) errEl.textContent = 'Informe o e-mail do usuário.';
      return;
    }
    if (!token || token.length < 5) {
      if (errEl) errEl.textContent = 'Informe a chave de acesso.';
      return;
    }

    if (btn) { btn.disabled = true; btn.textContent = 'Verificando...'; }

    ativarOnline(email, token, function (ok, msg, expiraMs, plan) {
      if (btn) { btn.disabled = false; btn.textContent = '🔓 Liberar acesso'; }

      if (!ok) {
        if (errEl) errEl.textContent = msg || 'Chave inválida.';
        return;
      }

      syncLegacyKeys(token.trim().toUpperCase(), email, expiraMs, plan);
      if (okEl) okEl.textContent = '✅ ' + msg;
      setTimeout(ocultarTela, 800);
    });
  }

  function mostrarOverlayRevogado(motivo) {
    var anterior = document.getElementById('ilOverlayRevogado');
    if (anterior) anterior.remove();

    limparAcesso();
    mostrarTela();

    var overlay = document.createElement('div');
    overlay.id = 'ilOverlayRevogado';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(5,10,25,0.97);display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:Inter,sans-serif;gap:12px;';

    overlay.innerHTML =
      '<div style="font-size:36px">🔒</div>' +
      '<div style="color:#ff3355;font-size:15px;font-weight:800">Acesso encerrado</div>' +
      '<div style="color:#ff8fa0;font-size:12px;text-align:center;max-width:260px;line-height:1.6">' + (motivo || 'Sua chave expirou.') + '</div>' +
      '<div style="color:rgba(255,255,255,0.35);font-size:11px">Informe e-mail e chave abaixo.</div>';

    document.body.appendChild(overlay);
    setTimeout(function () { overlay.remove(); }, 3500);
  }

  function init() {
    var btn = document.getElementById('accessBtn');
    if (btn) btn.addEventListener('click', liberarAcesso);

    ['accessEmail', 'accessToken'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') liberarAcesso();
        });
      }
    });

    (function vigiarBotoes() {
      ['#btnCiclo', '#btnFixar'].forEach(function (sel) {
        var el = document.querySelector(sel);
        if (el && !el._accessGuard) {
          el._accessGuard = true;
          el.addEventListener('click', function (e) {
            chrome.storage.local.get([STORAGE_VALIDO, STORAGE_EXPIRA], function (d) {
              if (!d[STORAGE_VALIDO] || sessaoExpirada(d[STORAGE_EXPIRA])) {
                e.stopImmediatePropagation();
                e.preventDefault();
                mostrarTela();
                var errEl = document.getElementById('accessErr');
                if (errEl) errEl.textContent = 'Libere o acesso com e-mail e chave válidos.';
              }
            });
          }, true);
        }
      });
      setTimeout(vigiarBotoes, 1500);
    })();

    chrome.storage.local.get([STORAGE_TOKEN, STORAGE_VALIDO, STORAGE_EXPIRA, STORAGE_EMAIL], function (d) {
      if (d[STORAGE_VALIDO] && d[STORAGE_TOKEN] && d[STORAGE_EMAIL] && !sessaoExpirada(d[STORAGE_EXPIRA])) {
        // Inicializa com chave salva
        ocultarTela();
        revalidarSessao(function (ok, msg) {
          if (!ok) mostrarOverlayRevogado(msg || 'Acesso expirado.');
        });
      } else {
        if (d[STORAGE_VALIDO]) limparAcesso();
        mostrarTela();
      }
      // Heartbeat periódico (a cada 60 segundos) para manter o status de uso ativo no painel de controle
      setInterval(function () {
        revalidarSessao(function (ok, msg) {
          if (!ok) mostrarOverlayRevogado(msg || 'Acesso expirado.');
        });
      }, 60000);
    });
  }

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg.action === 'acessoRevogado' || msg.action === 'licencaRevogada') {
      mostrarOverlayRevogado(msg.msg || msg.data && msg.data.msg || 'Acesso expirado.');
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
