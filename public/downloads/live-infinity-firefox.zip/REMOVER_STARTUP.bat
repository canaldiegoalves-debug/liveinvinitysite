@echo off
set "VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\LiveInfinity.vbs"
if exist "%VBS%" (
    del "%VBS%"
    echo ✅ Startup removido com sucesso.
) else (
    echo ⚠️ Startup nao estava instalado.
)
pause
