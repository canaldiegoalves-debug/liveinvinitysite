// Toggle Modo Cupom — carrega após sidebar.js
(function() {
  var tog = document.getElementById('togCupom');
  var lbl = document.getElementById('togCupomLbl');
  if (!tog || !lbl) return;

  // Restaura estado salvo
  chrome.storage.local.get('infinityModoCupom', function(d) {
    if (d.infinityModoCupom) {
      tog.classList.add('on');
      lbl.textContent = 'ON';
      lbl.style.color = '#ffd600';
    }
  });

  tog.addEventListener('click', function() {
    var ativo = !tog.classList.contains('on');
    if (ativo) {
      tog.classList.add('on');
      lbl.textContent = 'ON';
      lbl.style.color = '#ffd600';
    } else {
      tog.classList.remove('on');
      lbl.textContent = 'OFF';
      lbl.style.color = '';
    }
    chrome.storage.local.set({ infinityModoCupom: ativo });
    chrome.runtime.sendMessage({ action: 'setModoCupom', ativo: ativo }, function() {
      if (chrome.runtime.lastError) {}
    });
  });
})();

// ── PAINEL BLOQUEADOS NO SIDEBAR ──
var _jaExibidoNoPainel = [];
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.action !== 'bloqueioRegistrado') return;
  var d = msg.data;

  if (_jaExibidoNoPainel.includes(d.userName)) return;
  _jaExibidoNoPainel.push(d.userName);

  var painel = document.getElementById('painelBloqueadosSidebar');
  var lista  = document.getElementById('sidebarBlockList');
  var count  = document.getElementById('sidebarBlockCount');
  if (!painel || !lista) return;

  painel.style.display = 'block';

  var ph = lista.querySelector('span[style*="italic"]');
  if (ph) ph.remove();

  var item = document.createElement('div');
  item.style.cssText = 'padding:3px 0;border-bottom:1px solid rgba(255,255,255,0.05);display:flex;justify-content:space-between;align-items:center;';
  item.innerHTML = '<span style="color:#ff3355;font-weight:700;">🚫 ' + d.userName + '</span>' +
                   '<span style="color:rgba(255,255,255,0.35);font-size:9px;">' + d.hora + '</span>';
  lista.appendChild(item);
  lista.scrollTop = lista.scrollHeight;

  if (count) count.textContent = _jaExibidoNoPainel.length;
});

// ── LOG DE BLOQUEIO NO SIDEBAR ──
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.action !== 'blockLogUpdate') return;
  var logEl = document.getElementById('blockLog');
  if (!logEl) return;

  var d = msg.data;
  var hora = new Date().toLocaleTimeString('pt-BR');
  var cor = d.tipo === 'ok' ? '#00e676' : d.tipo === 'err' ? '#ff3355' : d.tipo === 'warn' ? '#ffd600' : '#7ab0d4';

  if (logEl.getAttribute('data-logmode') !== '1') {
    logEl.setAttribute('data-logmode', '1');
    logEl.style.cssText = 'margin-top:6px;font-size:9px;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:6px 8px;max-height:100px;overflow-y:auto;font-family:monospace;';
    logEl.innerHTML = '';
  }

  var linha = document.createElement('div');
  linha.style.cssText = 'color:' + cor + ';padding:1px 0;border-bottom:1px solid rgba(255,255,255,0.04);';
  linha.textContent = '[' + hora + '] ' + d.msg;
  logEl.appendChild(linha);
  while (logEl.children.length > 50) logEl.removeChild(logEl.firstChild);
  logEl.scrollTop = logEl.scrollHeight;
});

// ── DOWNLOAD LISTA DE BLOQUEADOS ──
var _bloqueadosParaDownload = [];

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.action !== 'bloqueioRegistrado') return;
  if (!_bloqueadosParaDownload.includes(msg.data.userName)) {
    _bloqueadosParaDownload.push(msg.data.userName);
  }
});

(function vincularDownload() {
  var btn = document.getElementById('btnDownloadBloqueados');
  if (!btn) { setTimeout(vincularDownload, 500); return; }
  btn.addEventListener('click', function() {
    if (!_bloqueadosParaDownload.length) {
      alert('Nenhum bloqueio registrado ainda.');
      return;
    }
    var data = new Date().toLocaleDateString('pt-BR').replace(/\//g, '-');
    var texto = '# Bloqueados na sessão — ' + data + '\n' +
                '# Total: ' + _bloqueadosParaDownload.length + ' usuários\n\n' +
                _bloqueadosParaDownload.join('\n');
    var blob = new Blob([texto], { type: 'text/plain' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    a.href     = url;
    a.download = 'bloqueados_' + data + '.txt';
    a.click();
    URL.revokeObjectURL(url);
  });
})();

// ── INTERCEPTA TOGGLE DE BLOQUEIO ──
(function interceptarBloqueio() {
  var togBlock = document.getElementById('tog-block');
  var blockNames = document.getElementById('blockNames');
  if (!togBlock || !blockNames) { setTimeout(interceptarBloqueio, 300); return; }

  togBlock.addEventListener('click', function() {
    setTimeout(function() {
      var ativo = togBlock.classList.contains('on');
      var words = blockNames.value.split('\n')
        .map(function(w){ return w.trim(); })
        .filter(function(w){ return w.length > 0; });

      var statusEl = document.getElementById('blockStatus');
      var statusTxt = document.getElementById('blockStatusTxt');

      if (ativo && words.length > 0) {
        chrome.runtime.sendMessage({ action: 'startBlock', words: words }, function() {
          if (chrome.runtime.lastError) {}
        });
        if (statusEl) statusEl.style.display = 'flex';
        if (statusTxt) statusTxt.textContent = 'Monitorando entradas na live';
      } else if (!ativo) {
        chrome.runtime.sendMessage({ action: 'stopBlock' }, function() {
          if (chrome.runtime.lastError) {}
        });
        if (statusEl) {
          statusEl.style.display = 'flex';
          statusEl.style.background = 'rgba(255,50,80,0.08)';
          statusEl.style.borderColor = 'rgba(255,50,80,0.25)';
          var dot = statusEl.querySelector('div');
          if (dot) { dot.style.background = '#ff3355'; dot.style.animation = 'none'; }
          if (statusTxt) { statusTxt.style.color = '#ff3355'; statusTxt.textContent = 'Monitoramento parado.'; }
          setTimeout(function() { statusEl.style.display = 'none'; }, 2000);
        }
      }
    }, 100);
  });
})();

// ── SALVA ESTADO DOS TOGGLES DE NOTIFICAÇÃO ──
(function vincularToglesNotificacao() {
  var mapa = {
    'togTgVendas':   'ilTgVendas',
    'togTgViolacao': 'ilTgViolacao',
    'togTgStatus':   'ilTgInicio'   // sidebar usa togTgStatus para início/fim
  };

  function vincular() {
    var todos = true;
    Object.keys(mapa).forEach(function(id) {
      var el = document.getElementById(id);
      if (!el) { todos = false; return; }
      if (el._notifBound) return;
      el._notifBound = true;

      // Salva estado inicial
      var ativo = el.classList.contains('on');
      var obj = {};
      obj[mapa[id]] = ativo;
      // Para início/fim salva também ilTgEncerramento
      if (id === 'togTgStatus') obj['ilTgEncerramento'] = ativo;
      chrome.storage.local.set(obj);

      // Ouve mudanças
      el.addEventListener('click', function() {
        setTimeout(function() {
          var novoAtivo = el.classList.contains('on');
          var save = {};
          save[mapa[id]] = novoAtivo;
          if (id === 'togTgStatus') save['ilTgEncerramento'] = novoAtivo;
          chrome.storage.local.set(save);
        }, 100);
      });
    });

    if (!todos) setTimeout(vincular, 500);
  }

  vincular();
})();

// ── TOGGLE SOM DE VENDA ──
(function vincularTogSom() {
  var tog = document.getElementById('togSom');
  if (!tog) { setTimeout(vincularTogSom, 500); return; }
  if (tog._somBound) return;
  tog._somBound = true;

  tog.addEventListener('click', function() {
    setTimeout(function() {
      var ativo = tog.classList.contains('on');
      chrome.storage.local.set({ infinitySomVenda: ativo });
      chrome.runtime.sendMessage({ action: 'ativarSom', ativo: ativo }, function() {
        if (chrome.runtime.lastError) {}
      });
    }, 100);
  });
})();

// ── PREVIEW SOM DE VENDA — substitui pelo som correto ──
(function vincularPreviewSom() {
  var btn = document.getElementById('btnPlaySom');
  if (!btn) { setTimeout(vincularPreviewSom, 500); return; }
  if (btn._previewBound) return;
  btn._previewBound = true;

  btn.addEventListener('click', function(e) {
    e.stopImmediatePropagation();
    e.preventDefault();
    try {
      var url = chrome.runtime.getURL('assets/caixa-registradora-live-infinity.wav');
      var audio = new Audio(url);
      audio.volume = 1.0;
      audio.play().catch(function(err) {
        console.log('[Live Infinity] Erro preview som:', err);
      });
    } catch(e2) {
      console.log('[Live Infinity] Erro preview som:', e2);
    }
  }, true);
})();
