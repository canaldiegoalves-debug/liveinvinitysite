(function() {
  // Elementos do DOM das Abas Estáticas
  const tabInicio = document.getElementById('tab-inicio');
  const tabCentral = document.getElementById('tab-central');
  const tabAudio = document.getElementById('tab-audio');

  const paneInicio = document.getElementById('pane-inicio');
  const paneCentral = document.getElementById('pane-central');
  const paneAudio = document.getElementById('pane-audio');
  const paneAi = document.getElementById('pane-ai');
  const paneVideo = document.getElementById('pane-video');

  // Cria os botões dinamicamente após o carregamento para evitar interceptação de clique pelo sidebar.js
  const tabBar = document.querySelector('.tab-bar');
  let tabAutomacoes = null;
  let tabAi = null;
  let tabVideo = null;
  let tabSuporte = null;

  // Carrega e redefine os titles das abas estáticas para a barra lateral compacta
  if (tabInicio) { tabInicio.innerHTML = '🏠'; tabInicio.setAttribute('data-title', 'Monitor'); }
  if (tabCentral) { tabCentral.innerHTML = '🔔'; tabCentral.setAttribute('data-title', 'Alertas'); }
  if (tabAudio) { tabAudio.innerHTML = '🎙️'; tabAudio.setAttribute('data-title', 'Mídia'); }

  const paneAutomacoes = document.getElementById('pane-automacoes');
  const paneSuporte = document.getElementById('pane-suporte');

  if (tabBar) {
    // 1. Painel de Automações
    tabAutomacoes = document.createElement('button');
    tabAutomacoes.className = 'tab-btn';
    tabAutomacoes.id = 'tab-automacoes';
    tabAutomacoes.setAttribute('data-title', 'Painel');
    tabAutomacoes.innerHTML = '⚙️';
    tabBar.insertBefore(tabAutomacoes, tabCentral); // Insere após o Início

    // 2. IA Chat
    tabAi = document.createElement('button');
    tabAi.className = 'tab-btn';
    tabAi.id = 'tab-ai';
    tabAi.setAttribute('data-title', 'IA Chat');
    tabAi.innerHTML = '🤖';
    tabBar.appendChild(tabAi);

    // 3. Player de Vídeos
    tabVideo = document.createElement('button');
    tabVideo.className = 'tab-btn';
    tabVideo.id = 'tab-video';
    tabVideo.setAttribute('data-title', 'Player');
    tabVideo.innerHTML = '🎬';
    tabBar.appendChild(tabVideo);

    // 4. Central de Suporte
    tabSuporte = document.createElement('button');
    tabSuporte.className = 'tab-btn';
    tabSuporte.id = 'tab-suporte';
    tabSuporte.setAttribute('data-title', 'Suporte');
    tabSuporte.innerHTML = '🎫';
    tabBar.appendChild(tabSuporte);
  }

  // Estado local para vídeos e HTML original
  let videoFiles = [];
  const originalAiHtml = paneAi ? paneAi.querySelector('.main')?.innerHTML || '' : '';
  const originalVideoHtml = paneVideo ? paneVideo.querySelector('.main')?.innerHTML || '' : '';
  const originalAudioHtml = paneAudio ? paneAudio.querySelector('.main')?.innerHTML || paneAudio.innerHTML : '';

  // Alternador de Abas Personalizado
  function deactivateAll() {
    [tabInicio, tabCentral, tabAudio, tabAutomacoes, tabAi, tabVideo, tabSuporte].forEach(t => t?.classList.remove('active'));
    [paneInicio, paneCentral, paneAudio, paneAutomacoes, paneAi, paneVideo, paneSuporte].forEach(p => p?.classList.remove('active'));
  }

  if (tabAutomacoes) {
    tabAutomacoes.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      deactivateAll();
      tabAutomacoes.classList.add('active');
      paneAutomacoes.classList.add('active');
    });
  }

  if (tabAi) {
    tabAi.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      deactivateAll();
      tabAi.classList.add('active');
      paneAi.classList.add('active');
      checkFeatureLock();
    });
  }

  if (tabVideo) {
    tabVideo.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      deactivateAll();
      tabVideo.classList.add('active');
      paneVideo.classList.add('active');
      checkFeatureLock();
    });
  }

  if (tabAudio) {
    tabAudio.addEventListener('click', () => {
      checkFeatureLock();
    });
  }

  if (tabSuporte) {
    tabSuporte.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      deactivateAll();
      tabSuporte.classList.add('active');
      paneSuporte.classList.add('active');
      // Garante que sempre abre na tela de lista ao clicar na aba
      clearInterval(chatPollInterval);
      activeTicketId = null;
      if (suporteTelaChat) suporteTelaChat.style.display = 'none';
      if (suporteTelaForm) suporteTelaForm.style.display = 'none';
      if (suporteTelaLista) suporteTelaLista.style.display = 'block';
      loadTicketsList();
    });
  }

  // Se o usuário clicar nas abas originais do sidebar.js, garante que as customizadas fechem
  [tabInicio, tabCentral, tabAudio].forEach(tab => {
    tab?.addEventListener('click', () => {
      [tabAutomacoes, tabAi, tabVideo, tabSuporte].forEach(t => t?.classList.remove('active'));
      [paneAutomacoes, paneAi, paneVideo, paneSuporte].forEach(p => p?.classList.remove('active'));
    });
  });

  // Verificação de bloqueio por plano (Basic novo não acessa Áudio / Basic nenhum acessa IA e Vídeos)
  function checkFeatureLock() {
    chrome.storage.local.get(['ilAcessoPlano', 'ilIsLegacySubscriber', 'ilAcessoToken'], (d) => {
      const plan = (d.ilAcessoPlano || 'basic').toLowerCase();
      const isProOrPremium = plan === 'pro' || plan === 'premium';
      // Considera assinante antigo se tiver ilIsLegacySubscriber != false ou já possuir token ativado no dispositivo
      const isLegacySubscriber = d.ilIsLegacySubscriber !== false && (d.ilIsLegacySubscriber === true || !!d.ilAcessoToken);
      
      const upgradeButtonsHtml = `
        <div style="display:flex;flex-direction:column;gap:8px;width:100%;max-width:260px;margin-top:14px;">
          <a href="https://app.cakto.com.br/affiliate/invite/ff1139b3-2a70-4e72-aeb6-8a17b3caa720" target="_blank" style="display:flex;align-items:center;justify-content:center;gap:6px;background:linear-gradient(135deg,#ffd000,#ffaa00);color:#050507;text-decoration:none;padding:10px 12px;border-radius:8px;font-size:11px;font-weight:800;box-shadow:0 4px 12px rgba(255,208,0,0.2);transition:transform 0.2s;">
            ⚡ Upgrade para Plano PRO
          </a>
          <a href="https://app.cakto.com.br/affiliate/invite/f6467a03-fe9d-4cab-ae7a-01034717dbec" target="_blank" style="display:flex;align-items:center;justify-content:center;gap:6px;background:linear-gradient(135deg,#e10000,#ff2626);color:#fff;text-decoration:none;padding:10px 12px;border-radius:8px;font-size:11px;font-weight:800;box-shadow:0 4px 14px rgba(255,23,23,0.3);transition:transform 0.2s;">
            🚀 Upgrade para Plano PREMIUM
          </a>
        </div>
      `;

      if (!isProOrPremium) {
        if (paneAi) {
          const mainAi = paneAi.querySelector('.main') || paneAi;
          mainAi.innerHTML = `
            <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:320px;text-align:center;padding:16px;box-sizing:border-box;">
              <span style="font-size:40px;margin-bottom:10px;">🔒</span>
              <h3 style="margin:0 0 6px 0;font-size:14px;color:#fff;">Recurso Avançado</h3>
              <p style="font-size:10px;color:var(--muted);line-height:1.4;margin:0 0 4px 0;">O Assistente de IA está disponível apenas para parceiros dos planos <strong>Pro</strong> e <strong>Premium</strong>.</p>
              ${upgradeButtonsHtml}
            </div>
          `;
        }
        if (paneVideo) {
          const mainVid = paneVideo.querySelector('.main') || paneVideo;
          mainVid.innerHTML = `
            <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:320px;text-align:center;padding:16px;box-sizing:border-box;">
              <span style="font-size:40px;margin-bottom:10px;">🔒</span>
              <h3 style="margin:0 0 6px 0;font-size:14px;color:#fff;">Recurso Avançado</h3>
              <p style="font-size:10px;color:var(--muted);line-height:1.4;margin:0 0 4px 0;">O Player de Vídeos está disponível apenas para parceiros dos planos <strong>Pro</strong> e <strong>Premium</strong>.</p>
              ${upgradeButtonsHtml}
            </div>
          `;
        }
        // 🎵 ÁUDIO: Liberado para assinantes antigos! Bloqueado apenas para novos assinantes do plano Básico
        if (paneAudio && !isLegacySubscriber) {
          const mainAud = paneAudio.querySelector('.main') || paneAudio;
          mainAud.innerHTML = `
            <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:320px;text-align:center;padding:16px;box-sizing:border-box;">
              <span style="font-size:40px;margin-bottom:10px;">🔒</span>
              <h3 style="margin:0 0 6px 0;font-size:14px;color:#fff;">Recurso Avançado</h3>
              <p style="font-size:10px;color:var(--muted);line-height:1.4;margin:0 0 4px 0;">O Painel de Áudio está disponível apenas para novos assinantes dos planos <strong>Pro</strong> e <strong>Premium</strong>.</p>
              ${upgradeButtonsHtml}
            </div>
          `;
        } else if (paneAudio && isLegacySubscriber && originalAudioHtml) {
          const mainAud = paneAudio.querySelector('.main') || paneAudio;
          if (!paneAudio.querySelector('.card')) {
            mainAud.innerHTML = originalAudioHtml;
          }
        }
      } else {
        // Restaura HTML original se for Pro/Premium e não estiver no DOM
        if (paneAi && originalAiHtml && !paneAi.querySelector('#cAI')) {
          const mainAi = paneAi.querySelector('.main') || paneAi;
          mainAi.innerHTML = originalAiHtml;
        }
        if (paneVideo && originalVideoHtml && !paneVideo.querySelector('#cVideo')) {
          const mainVid = paneVideo.querySelector('.main') || paneVideo;
          mainVid.innerHTML = originalVideoHtml;
          bindVideoEvents();
        }
        if (paneAudio && originalAudioHtml && !paneAudio.querySelector('.card')) {
          const mainAud = paneAudio.querySelector('.main') || paneAudio;
          mainAud.innerHTML = originalAudioHtml;
        }
      }
    });
  }

  // 🎬 CONTROLE DO PLAYER DE VÍDEO
  const videoListEl = document.getElementById('video-file-list');

  function bindVideoEvents() {
    const videoInput = document.getElementById('video-files');
    const btnVideoOpen = document.getElementById('video-open');
    const btnVideoClear = document.getElementById('video-clear');

    if (videoInput) {
      videoInput.onchange = (e) => {
        const files = Array.from(e.target.files || []);
        files.forEach(f => {
          videoFiles.push({
            name: f.name,
            url: URL.createObjectURL(f)
          });
        });
        renderVideoFiles();
      };
    }

    if (btnVideoClear) {
      btnVideoClear.onclick = () => {
        videoFiles.forEach(f => URL.revokeObjectURL(f.url));
        videoFiles = [];
        renderVideoFiles();
      };
    }

    if (btnVideoOpen) {
      btnVideoOpen.onclick = () => {
        if (!videoFiles.length) {
          alert('Selecione pelo menos um vídeo para a fila.');
          return;
        }
        // Abre a janela do player
        const filesJson = JSON.stringify(videoFiles);
        window.open(
          `player/index.html?files=${encodeURIComponent(filesJson)}`,
          'infinity-player',
          'width=520,height=900'
        );
      };
    }

    renderVideoFiles();
  }

  // Inicializa binds de vídeo
  bindVideoEvents();

  function renderVideoFiles() {
    if (!videoListEl) return;
    if (!videoFiles.length) {
      videoListEl.innerHTML = `<p class="helper" style="font-size:10px;color:var(--muted);text-align:center;">Nenhum vídeo selecionado.</p>`;
      return;
    }
    videoListEl.innerHTML = videoFiles.map((file, idx) => {
      return `
        <div style="display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:6px;padding:6px 10px;font-size:10px;color:var(--text);">
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:210px;">🎬 ${file.name}</span>
          <span class="remove-vid-btn" data-index="${idx}" style="color:var(--red);cursor:pointer;font-weight:700;font-size:14px;padding:0 4px;">×</span>
        </div>
      `;
    }).join('');

    // Bind botões de remover
    videoListEl.querySelectorAll('.remove-vid-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.index);
        const removed = videoFiles.splice(idx, 1)[0];
        if (removed) URL.revokeObjectURL(removed.url);
        renderVideoFiles();
      });
    });
  }

  // 🛒 PROVA SOCIAL (MENSAGENS PÓS-VENDA)
  const togPostSale = document.getElementById('togPostSale');
  const bProvaSocial = document.getElementById('bProvaSocial');
  const postSaleMessages = document.getElementById('postSaleMessages');
  const postSaleDelay = document.getElementById('postSaleDelay');

  // Carrega configurações salvas
  chrome.storage.local.get(['ilPostSaleEnabled', 'ilPostSaleMessages', 'ilPostSaleDelay'], (d) => {
    const enabled = !!d.ilPostSaleEnabled;
    const defaultMsgs = 'Parabéns pela compra! 🎉 {salesCount} pessoas já garantiram o produto nesta live!\n🔥 Excelente escolha! Já temos {salesCount} compras confirmadas ao vivo!\n👏 Parabéns! {salesCount} pessoas já aproveitaram a promoção especial hoje!\n⚡ Incrível! O estoque está acabando e já são {salesCount} vendas finalizadas!\n🛒 Mais uma venda confirmada! {salesCount} pessoas já compraram nesta live!';
    const messages = (d.ilPostSaleMessages && d.ilPostSaleMessages.trim()) ? d.ilPostSaleMessages : defaultMsgs;
    const delay = d.ilPostSaleDelay || 10;

    if (togPostSale) {
      togPostSale.className = enabled ? 'tog on' : 'tog';
      togPostSale.title = enabled ? 'Desativar Prova Social' : 'Ativar Prova Social';
    }
    if (bProvaSocial) {
      bProvaSocial.textContent = enabled ? 'Ativo' : 'Inativo';
      bProvaSocial.className = enabled ? 'cbadge bon' : 'cbadge boff';
    }
    if (postSaleMessages) {
      postSaleMessages.value = messages;
    }
    if (postSaleDelay) {
      postSaleDelay.value = delay;
    }
  });

  // Eventos de alteração nas configurações
  function salvarConfigPostSale() {
    const enabled = togPostSale ? togPostSale.classList.contains('on') : false;
    const messages = postSaleMessages ? postSaleMessages.value : '';
    const delay = postSaleDelay ? parseInt(postSaleDelay.value) || 10 : 10;

    chrome.storage.local.set({
      ilPostSaleEnabled: enabled,
      ilPostSaleMessages: messages,
      ilPostSaleDelay: delay
    }, () => {
      // Notifica o background
      const msgList = messages.split('\n').map(m => m.trim()).filter(Boolean);
      chrome.runtime.sendMessage({
        action: 'updatePostSaleConfig',
        ativo: enabled,
        delay: delay,
        messages: msgList
      });
    });
  }

  if (togPostSale) {
    togPostSale.addEventListener('click', () => {
      togPostSale.classList.toggle('on');
      const isOn = togPostSale.classList.contains('on');
      togPostSale.title = isOn ? 'Desativar Prova Social' : 'Ativar Prova Social';
      if (bProvaSocial) {
        bProvaSocial.textContent = isOn ? 'Ativo' : 'Inativo';
        bProvaSocial.className = isOn ? 'cbadge bon' : 'cbadge boff';
      }
      salvarConfigPostSale();
    });
  }

  if (postSaleMessages) {
    postSaleMessages.addEventListener('input', salvarConfigPostSale);
  }

  if (postSaleDelay) {
    postSaleDelay.addEventListener('change', salvarConfigPostSale);
  }

  // 📡 SINCRONIZAÇÃO DE MÉTRICAS E CHAT
  const metricVendas = document.getElementById('metricVendas');
  const metricGmv = document.getElementById('metricGmv');
  const aiChatLog = document.getElementById('aiChatLog');

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'statusFromContent') {
      const d = msg.data || {};
      if (metricVendas && d.vendas !== undefined) {
        metricVendas.textContent = d.vendas;
      }
      if (metricGmv && d.gmv !== undefined) {
        metricGmv.textContent = d.gmv;
      }

      // Atualiza Log do Chat da IA
      if (aiChatLog && d.chatMessages && Array.isArray(d.chatMessages)) {
        if (!d.chatMessages.length) {
          aiChatLog.innerHTML = `<div style="color:var(--muted);text-align:center;padding:20px 0;">Nenhuma mensagem de chat detectada ainda.</div>`;
        } else {
          aiChatLog.innerHTML = d.chatMessages.map(m => {
            return `
              <div style="border-bottom:1px solid rgba(255,255,255,0.02);padding:4px 0;word-break:break-word;">
                <span style="color:var(--yellow);font-weight:700;">💬 Chat:</span> ${escapeHtml(m)}
              </div>
            `;
          }).join('');
        }
      }
    }
  });

  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  // ── ASSISTENTE DE IA ──
  const togAIActive = document.getElementById('togAIActive');
  const aiGeminiKey = document.getElementById('aiGeminiKey');
  const aiSystemPrompt = document.getElementById('aiSystemPrompt');
  const aiProductDesc = document.getElementById('aiProductDesc');
  const aiResponseDelay = document.getElementById('aiResponseDelay');

  if (togAIActive && aiGeminiKey && aiSystemPrompt && aiProductDesc && aiResponseDelay) {
    // Carrega configurações da IA salvas
    chrome.storage.local.get(['ilAIActive', 'ilAIGeminiKey', 'ilAISystemPrompt', 'ilAIProductDesc', 'ilAIResponseDelay'], (d) => {
      const active = !!d.ilAIActive;
      const key = d.ilAIGeminiKey || '';
      const prompt = d.ilAISystemPrompt || 'Você é o assistente da live. Responda de forma curta e objetiva (máximo 120 caracteres).';
      const prodDesc = d.ilAIProductDesc || '';
      const delay = d.ilAIResponseDelay !== undefined ? d.ilAIResponseDelay : 8;

      if (active) togAIActive.classList.add('on'); else togAIActive.classList.remove('on');
      aiGeminiKey.value = key;
      aiSystemPrompt.value = prompt;
      aiProductDesc.value = prodDesc;
      aiResponseDelay.value = delay;
    });

    // Eventos de alteração
    togAIActive.addEventListener('click', () => {
      const active = !togAIActive.classList.contains('on');
      if (active) togAIActive.classList.add('on'); else togAIActive.classList.remove('on');
      chrome.storage.local.set({ ilAIActive: active });
      // Envia mensagem ao content script para ativar/desativar em tempo real
      chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
        tabs.forEach(t => {
          chrome.tabs.sendMessage(t.id, { action: 'updateAIConfig', data: { active } }, () => {
            if (chrome.runtime.lastError) {}
          });
        });
      });
    });

    aiGeminiKey.addEventListener('input', () => {
      chrome.storage.local.set({ ilAIGeminiKey: aiGeminiKey.value.trim() });
    });

    aiSystemPrompt.addEventListener('input', () => {
      chrome.storage.local.set({ ilAISystemPrompt: aiSystemPrompt.value });
    });

    aiProductDesc.addEventListener('input', () => {
      chrome.storage.local.set({ ilAIProductDesc: aiProductDesc.value });
    });

    aiResponseDelay.addEventListener('input', () => {
      const delay = parseInt(aiResponseDelay.value) || 8;
      chrome.storage.local.set({ ilAIResponseDelay: delay });
    });
  }

  // ↔️ MARGEM DA TELA (PUSH MARGIN)
  const sliderPushMargin = document.getElementById('sliderPushMargin');
  const valPushMargin = document.getElementById('valPushMargin');

  if (sliderPushMargin && valPushMargin) {
    // Carrega margem salva
    chrome.storage.local.get(['ilPushMargin'], (d) => {
      const margin = d.ilPushMargin !== undefined ? d.ilPushMargin : 390;
      sliderPushMargin.value = margin;
      valPushMargin.textContent = margin + 'px';
    });

    // Salva ao arrastar
    sliderPushMargin.addEventListener('input', () => {
      const margin = parseInt(sliderPushMargin.value);
      valPushMargin.textContent = margin + 'px';
      chrome.storage.local.set({ ilPushMargin: margin });
    });
  }

  // 🎫 CENTRAL DE SUPORTE
  const btnNovoChamado = document.getElementById('btnNovoChamado');
  const btnCancelarNovo = document.getElementById('btnCancelarNovo');
  const btnVoltarLista = document.getElementById('btnVoltarLista');
  const btnChatEnviar = document.getElementById('btnChatEnviar');

  const suporteTelaLista = document.getElementById('suporteTelaLista');
  const suporteTelaForm = document.getElementById('suporteTelaForm');
  const suporteTelaChat = document.getElementById('suporteTelaChat');

  const suporteListaItens = document.getElementById('suporteListaItens');
  const chatMensagensBox = document.getElementById('chatMensagensBox');
  const chatMensagemInput = document.getElementById('chatMensagemInput');
  const chatTicketSubject = document.getElementById('chatTicketSubject');
  const chatTicketStatus = document.getElementById('chatTicketStatus');

  const btnSuporteEnviar = document.getElementById('suporteEnviar');
  const inputSuporteAssunto = document.getElementById('suporteAssunto');
  const txtSuporteMensagem = document.getElementById('suporteMensagem');
  const labelSuporteStatus = document.getElementById('suporteMsgStatus');

  let activeTicketId = null;
  let chatPollInterval = null;

  function loadTicketsList() {
    if (!suporteListaItens) return;
    suporteListaItens.innerHTML = '<div style="color:var(--muted);text-align:center;padding:20px 0;font-size:11px;">Carregando chamados...</div>';

    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
      const key = d.ilAcessoToken || '';
      const email = d.ilAcessoEmail || '';

      if (!key || !email) {
        suporteListaItens.innerHTML = '<div style="color:#ff1717;text-align:center;padding:20px 0;font-size:11px;">Erro: Login não detectado.</div>';
        return;
      }

      fetch(`https://api.valoranegocios.com.br/api/support/tickets?key=${encodeURIComponent(key)}&email=${encodeURIComponent(email)}`)
        .then(res => {
          if (!res.ok) {
            return res.text().then(txt => {
              console.error('[Suporte] Resposta do servidor:', res.status, txt);
              throw new Error(`Servidor retornou ${res.status}: ${txt.substring(0, 120)}`);
            });
          }
          return res.json();
        })
        .then(data => {
          if (data && data.ok) {
            if (!data.tickets.length) {
              suporteListaItens.innerHTML = '<div style="color:var(--muted);text-align:center;padding:20px 0;font-size:11px;">Nenhum chamado registrado. Crie um novo chamado no botão acima!</div>';
              return;
            }

            suporteListaItens.innerHTML = data.tickets.map(t => {
              const dateStr = t.createdAt ? new Date(t.createdAt).toLocaleString('pt-BR', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '';
              const isResolved = t.status === 'resolved';
              const statusBg = isResolved ? 'rgba(0,230,118,0.12)' : 'rgba(255,208,0,0.12)';
              const statusColor = isResolved ? '#00e676' : '#ffd000';
              return `
                <div class="ticket-row-btn" data-id="${t.id}" data-subject="${escapeHtml(t.subject)}" data-status="${t.status}" style="background:rgba(255,255,255,0.02); border:1px solid var(--border); border-radius:8px; padding:10px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; transition: all 0.2s;">
                  <div>
                    <div style="font-weight:700; color:#fff; font-size:11px;">${escapeHtml(t.subject)}</div>
                    <span style="font-size:9px; color:var(--muted);">${dateStr}</span>
                  </div>
                  <span style="font-size:9px; font-weight:800; padding:2px 6px; border-radius:4px; text-transform:uppercase; background:${statusBg}; color:${statusColor};">${t.status}</span>
                </div>
              `;
            }).join('');

            // Bind click rows
            suporteListaItens.querySelectorAll('.ticket-row-btn').forEach(row => {
              row.addEventListener('click', () => {
                const id = row.getAttribute('data-id');
                const subject = row.getAttribute('data-subject');
                const status = row.getAttribute('data-status');
                openTicketChat(id, subject, status);
              });
            });
          } else {
            suporteListaItens.innerHTML = `<div style="color:#ff1717;text-align:center;padding:20px 0;font-size:11px;">Erro: ${data.error || 'Erro na listagem.'}</div>`;
          }
        })
        .catch(err => {
          console.error('[Suporte] Erro ao carregar chamados:', err);
          suporteListaItens.innerHTML = `<div style="color:#ff1717;text-align:center;padding:20px 0;font-size:11px;">Erro: ${err.message}</div>`;
        });
    });
  }

  function openTicketChat(ticketId, subject, status) {
    activeTicketId = ticketId;
    chatTicketSubject.textContent = subject;
    chatTicketStatus.textContent = 'Status: ' + status;
    chatTicketStatus.style.color = status === 'resolved' ? '#00e676' : '#ffd000';

    suporteTelaLista.style.display = 'none';
    suporteTelaForm.style.display = 'none';
    suporteTelaChat.style.display = 'flex';

    loadChatMessages();

    // Inicia polling a cada 5 segundos
    clearInterval(chatPollInterval);
    chatPollInterval = setInterval(loadChatMessages, 5000);
  }

  function loadChatMessages() {
    if (!activeTicketId || !chatMensagensBox) return;

    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
      const key = d.ilAcessoToken || '';
      const email = d.ilAcessoEmail || '';

      fetch(`https://api.valoranegocios.com.br/api/support/tickets/${activeTicketId}/messages?key=${encodeURIComponent(key)}&email=${encodeURIComponent(email)}`)
        .then(res => res.json())
        .then(data => {
          if (data && data.ok) {
            const scrollAtBottom = chatMensagensBox.scrollHeight - chatMensagensBox.scrollTop <= chatMensagensBox.clientHeight + 40;
            
            chatMensagensBox.innerHTML = data.messages.length ? "" : '<div style="color:var(--muted); text-align:center; font-size:11px; padding:20px 0;">Nenhuma mensagem de suporte ainda. Descreva sua dúvida abaixo!</div>';
            
            data.messages.forEach(m => {
              const div = document.createElement("div");
              if (m.sender === "agent") {
                div.style.cssText = "align-self: flex-start; background: rgba(255,208,0,0.12); border: 1px solid rgba(255,208,0,0.25); color: #ffd000; border-radius: 8px 8px 8px 0px; padding: 6px 10px; font-size: 11px; max-width: 85%; word-break: break-word;";
                div.innerHTML = `<strong>Suporte:</strong> ${escapeHtml(m.message)}`;
              } else {
                div.style.cssText = "align-self: flex-end; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px 8px 0px 8px; padding: 6px 10px; font-size: 11px; max-width: 85%; word-break: break-word;";
                div.innerHTML = `${escapeHtml(m.message)}`;
              }
              chatMensagensBox.appendChild(div);
            });

            if (scrollAtBottom) {
              chatMensagensBox.scrollTop = chatMensagensBox.scrollHeight;
            }
          }
        })
        .catch(err => {
          console.error('[Chat Suporte] Erro ao carregar mensagens:', err);
        });
    });
  }

  function sendChatMessage() {
    if (!activeTicketId || !chatMensagemInput) return;
    const msg = chatMensagemInput.value.trim();
    if (!msg) return;

    chatMensagemInput.disabled = true;

    chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
      const key = d.ilAcessoToken || '';
      const email = d.ilAcessoEmail || '';

      fetch(`https://api.valoranegocios.com.br/api/support/tickets/${activeTicketId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: key,
          email: email,
          message: msg
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data && data.ok) {
          chatMensagemInput.value = '';
          loadChatMessages();
        }
      })
      .catch(err => {
        console.error('[Chat Suporte] Erro ao enviar mensagem:', err);
      })
      .finally(() => {
        chatMensagemInput.disabled = false;
        chatMensagemInput.focus();
      });
    });
  }

  if (btnNovoChamado) {
    btnNovoChamado.addEventListener('click', () => {
      suporteTelaLista.style.display = 'none';
      suporteTelaChat.style.display = 'none';
      suporteTelaForm.style.display = 'block';
    });
  }

  if (btnCancelarNovo) {
    btnCancelarNovo.addEventListener('click', () => {
      suporteTelaForm.style.display = 'none';
      suporteTelaChat.style.display = 'none';
      suporteTelaLista.style.display = 'block';
      loadTicketsList();
    });
  }

  if (btnVoltarLista) {
    btnVoltarLista.addEventListener('click', () => {
      clearInterval(chatPollInterval);
      activeTicketId = null;
      suporteTelaChat.style.display = 'none';
      suporteTelaForm.style.display = 'none';
      suporteTelaLista.style.display = 'block';
      loadTicketsList();
    });
  }

  if (btnChatEnviar) {
    btnChatEnviar.addEventListener('click', sendChatMessage);
  }

  if (chatMensagemInput) {
    chatMensagemInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') sendChatMessage();
    });
  }

  // (Listener da aba de Suporte já está no bloco de inicialização das tabs acima)

  if (btnSuporteEnviar && inputSuporteAssunto && txtSuporteMensagem && labelSuporteStatus) {
    btnSuporteEnviar.addEventListener('click', () => {
      const assunto = inputSuporteAssunto.value.trim();
      const mensagem = txtSuporteMensagem.value.trim();

      if (!assunto || !mensagem) {
        labelSuporteStatus.style.color = '#ff1717';
        labelSuporteStatus.textContent = '❌ Preencha todos os campos.';
        return;
      }

      labelSuporteStatus.style.color = '#ffd000';
      labelSuporteStatus.textContent = '⏳ Enviando chamado...';
      btnSuporteEnviar.disabled = true;

      // Obtém chave e e-mail salvos do storage
      chrome.storage.local.get(['ilAcessoToken', 'ilAcessoEmail'], (d) => {
        const key = d.ilAcessoToken || '';
        const email = d.ilAcessoEmail || '';

        if (!key || !email) {
          labelSuporteStatus.style.color = '#ff1717';
          labelSuporteStatus.textContent = '❌ Erro: Chave de acesso não encontrada.';
          btnSuporteEnviar.disabled = false;
          return;
        }

        // Faz o POST para a rota de criação de chamados no servidor
        fetch('https://api.valoranegocios.com.br/api/support/tickets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            key: key,
            email: email,
            subject: assunto,
            message: mensagem
          })
        })
        .then(res => {
          if (!res.ok) {
            return res.json().then(errData => {
              throw new Error(errData.error || 'Erro ao registrar chamado.');
            });
          }
          return res.json();
        })
        .then(data => {
          if (data && data.ok) {
            labelSuporteStatus.style.color = '#00e676';
            labelSuporteStatus.textContent = '✅ Chamado enviado com sucesso!';
            inputSuporteAssunto.value = '';
            txtSuporteMensagem.value = '';
            
            // Retorna para a lista de tickets após 1.5s
            setTimeout(() => {
              suporteTelaForm.style.display = 'none';
              suporteTelaChat.style.display = 'none';
              suporteTelaLista.style.display = 'block';
              loadTicketsList();
            }, 1500);
          } else {
            labelSuporteStatus.style.color = '#ff1717';
            labelSuporteStatus.textContent = '❌ ' + (data.error || 'Erro ao enviar chamado.');
          }
        })
        .catch(err => {
          labelSuporteStatus.style.color = '#ff1717';
          labelSuporteStatus.textContent = '❌ ' + err.message;
        })
        .finally(() => {
          btnSuporteEnviar.disabled = false;
        });
      });
    });
  }

  // Intercepta e traduz erros de conexão de mensagens do Chrome para orientar o usuário em português
  const commentLog = document.getElementById('commentLog');
  if (commentLog) {
    const observer = new MutationObserver(() => {
      const text = commentLog.textContent || '';
      if (text.includes('Could not establish connection') || text.includes('Receiving end does not exist')) {
        commentLog.style.color = '#ff4a4a';
        commentLog.innerHTML = '⚠️ <strong>Atualize a página da Live no TikTok (F5)</strong> para conectar!';
        
        // Tenta injetar o script content.js automaticamente na aba do TikTok
        try {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs[0] && tabs[0].id) {
              chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ['content.js']
              }, () => {
                if (chrome.runtime.lastError) {}
              });
            }
          });
        } catch (e) {}
      }
    });

    observer.observe(commentLog, { childList: true, characterData: true, subtree: true });
  }

  // 🚀 CHECAGEM E EXIBIÇÃO DO BANNER DE ATUALIZAÇÃO DA EXTENSÃO (VERSÃO REAL DA API)
  function initUpdateBanner() {
    const updateBanner = document.getElementById('updateBanner');
    const updateBannerText = document.getElementById('updateBannerText');
    const updateBannerLink = document.getElementById('updateBannerLink');
    const updateBannerClose = document.getElementById('updateBannerClose');

    if (!updateBanner) return;

    if (updateBannerClose) {
      updateBannerClose.onclick = () => {
        updateBanner.style.display = 'none';
      };
    }

    const currentVersion = chrome.runtime.getManifest().version;

    function exibirBanner(versao, url) {
      if (updateBannerText) updateBannerText.textContent = `Nova versão v${versao} disponível!`;
      if (updateBannerLink) updateBannerLink.href = url || '#';
      updateBanner.style.display = 'flex';
    }

    // Consulta direta na API de produção sem cache para sempre pegar a versão publicada mais recente
    fetch(`https://api.valoranegocios.com.br/api/updates/latest?currentVersion=${encodeURIComponent(currentVersion)}&_t=${Date.now()}`, { cache: 'no-store' })
      .then(res => res.json())
      .then(data => {
        if (data && data.ok && data.update && data.update.version) {
          const newVer = data.update.version;
          const downloadUrl = data.update.downloadUrl || 'https://api.valoranegocios.com.br/api/updates/latest';
          
          // Só exibe o banner se a versão da API for maior/diferente da instalada
          if (newVer !== currentVersion && data.updateRequired) {
            chrome.storage.local.set({
              ilUpdateDisponivel: true,
              ilUpdateVersao: newVer,
              ilUpdateUrl: downloadUrl
            });
            exibirBanner(newVer, downloadUrl);
          } else {
            // Se o usuário já estiver na versão mais recente, oculta o banner
            chrome.storage.local.set({ ilUpdateDisponivel: false });
            updateBanner.style.display = 'none';
          }
        }
      })
      .catch((err) => {
        console.error('[UpdateBanner] Erro ao consultar API:', err);
      });
  }

  initUpdateBanner();

  // Verifica plano na inicialização
  checkFeatureLock();
})();
