#!/usr/bin/env python3
"""Gera chaves de acesso Live Infinity — 1 chave por usuário (e-mail)."""
import argparse

from licenca_utils import gerar_chave, registrar_chave


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Gerar chave de acesso Live Infinity (1 usuário por chave)')
    parser.add_argument('-e', '--email', required=True, help='E-mail do usuário (obrigatório)')
    parser.add_argument('-d', '--dias', type=int, default=30, help='Dias de validade (padrão: 30)')
    args = parser.parse_args()

    try:
        chave, expira, email = gerar_chave(args.email, args.dias)
    except ValueError as err:
        print(f'Erro: {err}')
        raise SystemExit(1)

    registrar_chave(chave, email, expira)

    print(f'Usuário: {email}')
    print(f'Chave: {chave}')
    print(f'Válida até: {expira.strftime("%d/%m/%Y")}')
    print('Cada chave funciona em apenas 1 dispositivo.')
