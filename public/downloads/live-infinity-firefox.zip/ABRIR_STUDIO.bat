@echo off
title Abrindo TikTok LIVE Studio...

REM Fecha se já estiver aberto
taskkill /F /IM "TikTok LIVE Studio.exe" >nul 2>&1
timeout /t 2 /nobreak >nul

REM Busca dinâmica pela pasta de versão instalada
for /d %%i in ("C:\Program Files\TikTok LIVE Studio\*") do (
    if exist "%%i\TikTok LIVE Studio.exe" (
        start "" "%%i\TikTok LIVE Studio.exe" --remote-debugging-port=9222 --remote-allow-origins=*
        goto fim
    )
)
for /d %%i in ("C:\Arquivos de Programas\TikTok LIVE Studio\*") do (
    if exist "%%i\TikTok LIVE Studio.exe" (
        start "" "%%i\TikTok LIVE Studio.exe" --remote-debugging-port=9222 --remote-allow-origins=*
        goto fim
    )
)

REM Tenta também no AppData do usuário (caminho padrão para instalações por usuário)
if exist "%LocalAppData%\Programs\tiktok-live-studio\TikTok LIVE Studio.exe" (
    start "" "%LocalAppData%\Programs\tiktok-live-studio\TikTok LIVE Studio.exe" --remote-debugging-port=9222 --remote-allow-origins=*
    goto fim
)

echo ERRO: TikTok LIVE Studio nao encontrado!
echo Verifique se o TikTok LIVE Studio esta instalado no computador.
pause
:fim
