# MANUAL DE INSTALAÇÃO — CHROMIUM

====================================================
GUIA DE INSTALAÇÃO E USO COMERCIAL
====================================================

1. COMO INSTALAR:
   - Extraia o arquivo ZIP ("LIVE_INFINITY_v11.0.4_OFFICIAL.zip" ou "LIVECAM_INFINITY_v3.6.4_OFFICIAL.zip") em uma pasta no computador.

2. ATIVAR MODO DESENVOLVEDOR:
   - Abra o navegador Chromium e acesse: chrome://extensions
   - Ative a chave "Modo do desenvolvedor" no canto superior direito.

3. CARREGAR A EXTENSÃO:
   - Clique em "Carregar sem compactação" e selecione a pasta extraída.

4. COMO ATUALIZAR:
   - Substitua os arquivos na mesma pasta e clique no ícone de recarregar em chrome://extensions.

5. COMO REMOVER:
   - Clique no botão "Remover" no card da extensão em chrome://extensions.

6. ATIVAR A LICENÇA:
   - Abra o TikTok Studio ou painel de live, informe a sua Chave de Licença oficial e o acesso será liberado.
