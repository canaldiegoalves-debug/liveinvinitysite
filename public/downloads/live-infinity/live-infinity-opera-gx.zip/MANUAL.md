# MANUAL DE INSTALAÇÃO — OPERA / OPERA GX

====================================================
GUIA DE INSTALAÇÃO E USO COMERCIAL
====================================================

1. COMO INSTALAR:
   - Extraia o arquivo ZIP ("LIVE_INFINITY_v11.0.4_OFFICIAL.zip" ou "LIVECAM_INFINITY_v3.6.4_OFFICIAL.zip") em uma pasta no computador.

2. ATIVAR MODO DESENVOLVEDOR:
   - Abra o navegador Opera / Opera GX e acesse: opera://extensions
   - Ative a chave "Modo do desenvolvedor" no canto superior direito.

3. CARREGAR A EXTENSÃO:
   - Clique em "Carregar extensão descompactada" e selecione a pasta extraída.

4. COMO ATUALIZAR:
   - Substitua os arquivos na mesma pasta e clique no ícone de recarregar em opera://extensions.

5. COMO REMOVER:
   - Clique no botão "Remover" no card da extensão em opera://extensions.

6. ATIVAR A LICENÇA:
   - Abra o TikTok Studio ou painel de live, informe a sua Chave de Licença oficial e o acesso será liberado.
