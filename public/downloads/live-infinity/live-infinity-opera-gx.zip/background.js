/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "6b0476011a4f8cb6";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "86f52eec62bd7ba3";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "bf96098d03e0e48a";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "9a7eee6f3e1b126d";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
'use strict';
/* Live Infinity v8.2.0 — Background Service Worker
   Fora do TikTok Shop: abre o Gerenciador de LIVE.
   Dentro do TikTok Shop: mostra o painel flutuante da extensão. */
var TTLF_URL = 'https://shop.tiktok.com/streamer/live/product/dashboard';

function ehTikTok(url) {
  return typeof url === 'string' && url.indexOf('https://shop.tiktok.com') === 0;
}

// Gerenciador de Heartbeat e Prevenção de Descarte de Aba (autoDiscardable: false)
var lastHeartbeatMap = {};

function protegerAbaAntiDescarte(tabId) {
  try {
    if (chrome.tabs && chrome.tabs.update) {
      chrome.tabs.update(tabId, { autoDiscardable: false }, function () {
        if (chrome.runtime.lastError) { /* ignora se API nao suportada */ }
      });
    }
  } catch (e) {}
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg) return;

  if (msg.type === 'ttlf-heartbeat') {
    var tabId = sender && sender.tab ? sender.tab.id : msg.tabId;
    if (tabId) {
      lastHeartbeatMap[tabId] = {
        timestamp: Date.now(),
        visibilityState: msg.visibilityState,
        sessionId: msg.sessionId
      };
      protegerAbaAntiDescarte(tabId);
    }
    sendResponse({ ok: true, ackAt: Date.now() });
    return true;
  }

  if (msg.type === 'ttlf-ntfy') {
    var canal = (msg.canal || '').trim();
    if (!canal) { sendResponse({ ok: false }); return; }
    fetch('https://ntfy.sh', {
      method: 'POST',
      body: JSON.stringify({
        topic: canal,
        title: msg.titulo || 'Live Infinity',
        message: msg.corpo || '',
        tags: (msg.tags || 'bell').split(','),
        priority: 5
      })
    }).then(function (r) { sendResponse({ ok: r.ok }); })
      .catch(function () { sendResponse({ ok: false }); });
    return true;
  }
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (tab && ehTikTok(tab.url)) {
    protegerAbaAntiDescarte(tabId);
  }
});

chrome.tabs.onActivated.addListener(function (activeInfo) {
  if (activeInfo && activeInfo.tabId) {
    chrome.tabs.get(activeInfo.tabId, function (tab) {
      if (chrome.runtime.lastError || !tab) return;
      if (ehTikTok(tab.url)) {
        protegerAbaAntiDescarte(tab.id);
      }
    });
  }
});

chrome.action.onClicked.addListener(function (tab) {
  try {
    if (tab && ehTikTok(tab.url)) {
      protegerAbaAntiDescarte(tab.id);
      chrome.tabs.sendMessage(tab.id, { type: 'ttlf-show' }, function () {
        if (chrome.runtime.lastError) { /* aba ainda sem content script */ }
      });
      return;
    }
    chrome.tabs.query({ url: 'https://shop.tiktok.com/*' }, function (tabs) {
      if (tabs && tabs.length) {
        var t = tabs[0];
        protegerAbaAntiDescarte(t.id);
        chrome.tabs.update(t.id, { active: true });
        if (t.windowId != null) { chrome.windows.update(t.windowId, { focused: true }); }
        chrome.tabs.sendMessage(t.id, { type: 'ttlf-show' }, function () {
          if (chrome.runtime.lastError) { /* ignora */ }
        });
      } else {
        chrome.tabs.create({ url: TTLF_URL });
      }
    });
  } catch (e) {
    chrome.tabs.create({ url: TTLF_URL });
  }
});
