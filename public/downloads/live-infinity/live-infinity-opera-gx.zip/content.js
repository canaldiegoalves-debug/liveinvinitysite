
// ============================================================================
// LIVE INFINITY ANTI-CLONE ENGINE (v11.0.4-dev)
// ============================================================================
(function () {
  const ANTI_CLONE_CONFIG = {
    product: 'live-infinity',
    minVersion: '11.0.4',
    shadowMode: true,
    storageKey: 'ttlf_installation_id'
  };

  async function getOrCreateInstallationId() {
    return new Promise((resolve) => {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get([ANTI_CLONE_CONFIG.storageKey], (res) => {
            if (res && res[ANTI_CLONE_CONFIG.storageKey]) {
              resolve(res[ANTI_CLONE_CONFIG.storageKey]);
            } else {
              const array = new Uint8Array(16);
              if (window.crypto && window.crypto.getRandomValues) {
                window.crypto.getRandomValues(array);
              }
              const newId = 'inst_' + Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
              chrome.storage.local.set({ [ANTI_CLONE_CONFIG.storageKey]: newId }, () => resolve(newId));
            }
          });
        } else {
          resolve('inst_fallback_' + Math.random().toString(36).substring(2));
        }
      } catch (e) {
        resolve('inst_err_' + Date.now());
      }
    });
  }

  window.ttlfAntiCloneEngine = {
    config: ANTI_CLONE_CONFIG,
    getInstallationId: getOrCreateInstallationId,
    validateSession: async function (licenseKey) {
      const instId = await getOrCreateInstallationId();
      return {
        valid: true,
        shadowBlocked: false,
        installationId: instId,
        features: { pinning: true, comments: true, dashboard: true }
      };
    }
  };
})();

/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "e1657f86a0428093";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "7ec07b564008c8b7";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "90a6d478d9909e1b";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "6ee03d5dd850410a";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
'use strict';
/* ============================================================================
   ♾️ LIVE INFINITY v11.0.0-dev — CONTROLE DE LIVES ENXUTO,
   GMV, VENDAS EM TEMPO REAL, TIMER, REFIXAÇÃO E PROTEÇÃO ON-AIR
   ============================================================================ */

var TTLF_API = 'https://licencas.liveinfinity.online';
var TTLF_GRACE = 72 * 3600 * 1000;
window.ttlfLogArr = window.ttlfLogArr || [];
window.ttlfAudioHistory = window.ttlfAudioHistory || [];

window.ttlfIsExtensionContextValid = function () {
  try {
    return !!(
      typeof chrome !== 'undefined' &&
      chrome.runtime &&
      chrome.runtime.id
    );
  } catch (e) {
    return false;
  }
};

window.ttlfHaltInvalidatedContext = function () {
  if (window.__ttlfInvalidatedLogged) return;
  window.__ttlfInvalidatedLogged = true;

  try {
    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_INFINITY] extension-context-invalidated — Extensão recarregada. Atualize a página do TikTok para ativar a nova versão.');
    } else {
      console.warn('[LIVE_INFINITY] extension-context-invalidated — Extensão recarregada. Atualize a página do TikTok para ativar a nova versão.');
    }
  } catch (e) {}

  var timerNames = [
    'ttlfVcTimer', 'icTimer', 'dashTimer', 'raVarre', 'raFila', 
    'bnTimer', 'nvTimer', 'rvTick', 'rtTick', 'ttlfCommentsSendTimer'
  ];
  timerNames.forEach(function (tName) {
    try {
      if (window[tName]) {
        clearInterval(window[tName]);
        clearTimeout(window[tName]);
        window[tName] = null;
      }
    } catch (e) {}
  });
};

window.ttlfSafeStorageGet = function (keys, cb) {
  if (!window.ttlfIsExtensionContextValid()) {
    window.ttlfHaltInvalidatedContext();
    return;
  }
  try {
    chrome.storage.local.get(keys, function (res) {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError) {
        window.ttlfHaltInvalidatedContext();
        return;
      }
      if (cb) cb(res);
    });
  } catch (err) {
    window.ttlfHaltInvalidatedContext();
  }
};

window.ttlfSafeStorageSet = function (obj, cb) {
  if (!window.ttlfIsExtensionContextValid()) {
    window.ttlfHaltInvalidatedContext();
    return;
  }
  try {
    chrome.storage.local.set(obj, function () {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError) {
        window.ttlfHaltInvalidatedContext();
        return;
      }
      if (cb) cb();
    });
  } catch (err) {
    window.ttlfHaltInvalidatedContext();
  }
};

window.ttlfSafeRuntimeSendMessage = function (msg, cb) {
  if (!window.ttlfIsExtensionContextValid()) {
    window.ttlfHaltInvalidatedContext();
    return;
  }
  try {
    chrome.runtime.sendMessage(msg, function (res) {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError) {
        window.ttlfHaltInvalidatedContext();
        return;
      }
      if (cb) cb(res);
    });
  } catch (err) {
    window.ttlfHaltInvalidatedContext();
  }
};

function ttlfStGet(cb) {
  try {
    window.ttlfSafeStorageGet(['liveinfinity_lic', 'ilChaveAtiva', 'ilAcessoToken', 'ilAcessoValidado'], function (r) {
      var lic = r && r.liveinfinity_lic ? r.liveinfinity_lic : null;
      if (!lic && r && r.ilAcessoValidado && (r.ilChaveAtiva || r.ilAcessoToken)) {
        var k = (r.ilChaveAtiva || r.ilAcessoToken).trim().toUpperCase();
        lic = {
          key: k,
          device: 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36),
          lastOk: Date.now(),
          activated: Date.now(),
          exp: Date.now() + 30 * 86400000,
          version: '11.0.0-dev'
        };
        ttlfStSet(lic);
      }
      cb(lic);
    });
  } catch (e) {
    try { var v = localStorage.getItem('liveinfinity_lic'); cb(v ? JSON.parse(v) : null); } catch (_) { cb(null); }
  }
}

function ttlfStSet(lic) {
  if (lic) {
    var k = (lic.key || '').trim().toUpperCase();
    lic.version = '11.0.0-dev';
    window.ttlfSafeStorageSet({
      liveinfinity_lic: lic,
      ilChaveAtiva: k,
      ilChaveValidada: true,
      ilAcessoToken: k,
      ilAcessoValidado: true,
      ilStatusLicenca: 'Ativo',
      ilMensagemLicenca: 'Licença ativa'
    });
    try { localStorage.setItem('liveinfinity_lic', JSON.stringify(lic)); } catch (e) {}
  }
}

function ttlfDevice(lic) {
  if (lic && lic.device) { return lic.device; }
  return 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function ttlfValida(key, device, cb) {
  var k = (key || '').trim().toUpperCase();
  if (!k || k.length < 5) { cb(false, 'invalid', false, null); return; }

  fetch('https://api.valoranegocios.com.br/api/check', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: k, device: device })
  }).then(function(r) {
    if (!r.ok && r.status !== 404 && r.status !== 400) {
      throw new Error('HTTP ' + r.status);
    }
    return r.json();
  }).then(function(data) {
    if (data && data.ok) {
      var cleanEm = (data.email || '').replace(/^(liveinfinity|livecam):/i, '').trim();
      var expMs = data.expiresAt ? new Date(data.expiresAt).getTime() : (Date.now() + 30 * 86400000);
      cb(true, 'ok', false, { email: cleanEm, exp: expMs });
    } else {
      cb(false, (data && (data.error || data.reason)) || 'invalid', false, null);
    }
  }).catch(function(err) {
    // FIX DE SEGURANÇA (Passo 9): Não dar fail-open na primeira ativação sem licença salva se offline
    cb(false, 'offline', true, null);
  });
}

function ttlfMsg(r) {
  if (!r) { return ''; }
  var m = {
    invalid: 'Chave inválida. Confira e tente de novo.',
    blocked: 'Assinatura inativa ou cancelada.',
    devices: 'Chave já em uso no máximo de dispositivos.',
    offline: 'Sem conexão com o servidor de licenças.'
  };
  return m[r] || ('Erro: ' + r);
}

function ttlfRollExp(lic) {
  var now = Date.now();
  if (!lic) { return lic; }
  if (!lic.activated) { lic.activated = now; }
  if (!lic.exp) { lic.exp = now + 30 * 86400000; }
  while (lic.exp && now >= lic.exp) { lic.exp += 30 * 86400000; }
  return lic;
}

function ttlfShowGate(reason) {
  console.info('[BOOT 04] ttlfShowGate executado');
  if (!document.body) { setTimeout(function () { ttlfShowGate(reason); }, 1500); return; }
  var ex = document.getElementById('ttlf-gate');
  if (ex) {
    var s0 = document.getElementById('ttlf-gate-st');
    if (s0 && reason) { s0.textContent = ttlfMsg(reason); }
    return;
  }
  var d = document.createElement('div');
  d.id = 'ttlf-gate';
  d.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(4,6,15,.92);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:center;font-family:Inter,system-ui,sans-serif;font-size:13px;padding:16px;box-sizing:border-box';

  d.innerHTML =
    '<div style="width:360px;max-width:100%;background:#080a12;color:#fff;border:1px solid rgba(255,208,0,0.35);border-radius:24px;box-shadow:0 24px 80px rgba(0,0,0,0.95);padding:32px 28px;box-sizing:border-box;text-align:center;">' +
    '<div style="font-size:42px;margin-bottom:10px;filter:drop-shadow(0 0 14px rgba(255,153,0,0.65))">♾️</div>' +
    '<div style="font-size:24px;font-weight:900;margin-bottom:6px;display:flex;align-items:center;justify-content:center;gap:6px;letter-spacing:0.5px">' +
    '<span style="color:#ff1717;text-shadow:0 0 14px rgba(255,23,23,0.5)">Live</span>' +
    '<span style="background:linear-gradient(180deg,#ffffff 25%,#bfc0c4 100%);-webkit-background-clip:text;color:transparent">Infinity</span>' +
    '</div>' +
    '<div style="font-size:12px;color:#a8acb7;margin-bottom:24px;font-weight:600">Digite a sua chave de acesso para liberar.</div>' +
    '<div style="text-align:left;margin-bottom:22px">' +
    '<label style="display:block;font-size:10.5px;color:#a8acb7;text-transform:uppercase;letter-spacing:0.9px;font-weight:700;margin-bottom:6px">CHAVE DE ACESSO</label>' +
    '<input id="ttlf-gate-key" type="text" placeholder="Sua chave de acesso" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;background:#050507;color:#ffd000;border:1px solid rgba(255,208,0,0.35);border-radius:12px;padding:13px 14px;font-size:14px;font-weight:700;outline:none;text-align:center;letter-spacing:1.5px;"/>' +
    '</div>' +
    '<button id="ttlf-gate-btn" style="width:100%;padding:14px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717 0%,#ff8800 100%);color:#fff;font-weight:900;font-size:14px;cursor:pointer;transition:all .2s;box-shadow:0 4px 20px rgba(255,23,23,0.4);">🚀 Liberar Acesso</button>' +
    '<div id="ttlf-gate-st" style="margin-top:14px;font-size:11.5px;color:#ff3355;min-height:16px;text-align:center;font-weight:600;">' + (reason ? ttlfMsg(reason) : '') + '</div>' +
    '</div>';

  document.body.appendChild(d);
  console.info('[BOOT 05] gate inserido no DOM');

  var btn = document.getElementById('ttlf-gate-btn');
  if (btn) btn.addEventListener('click', ttlfGateGo);

  var inputEl = document.getElementById('ttlf-gate-key');
  if (inputEl) {
    inputEl.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') ttlfGateGo();
    });
  }
  console.info('[BOOT 06] listeners do gate registrados');
}

window.ttlfDebugBindings = window.ttlfDebugBindings || {
  global: 0,
  timer: 0,
  plus60: 0,
  comments: 0,
  replies: 0,
  intent: 0,
  blockName: 0,
  ntfy: 0
};

function ttlfBindOnce(el, eventName, bindKey, handler) {
  if (!el) {
    console.warn('[HUD BIND] elemento ausente:', bindKey);
    return false;
  }
  var property = 'ttlfBound' + bindKey.replace(/[^a-z0-9]/gi, '');
  if (el.dataset && el.dataset[property] === '1') {
    return true;
  }
  el.addEventListener(eventName, handler);
  if (el.dataset) el.dataset[property] = '1';
  return true;
}

function initHudGlobalControls() {
  var bOn = document.getElementById('ttlf-on');
  if (bOn) {
    ttlfBindOnce(bOn, 'click', 'globalOn', function () {
      var cbAuto = document.getElementById('rf-auto-initial');
      if (cbAuto && !cbAuto.checked) {
        cbAuto.checked = true;
        cbAuto.dispatchEvent(new Event('change', { bubbles: true }));
      }
      ['rf-plus60-toggle', 'rf-botao', 'rd-botao', 'rc-botao', 'ra-botao', 'bn-botao', 'ic-botao', 'nv-botao'].forEach(function (id) {
        var b = document.getElementById(id);
        var txt = b ? (b.textContent || '') : '';
        if (b && (txt.indexOf('▶') >= 0 || txt.indexOf('Iniciar') >= 0)) { b.click(); }
      });
      var cv = document.getElementById('rv-ativo');
      if (cv && !cv.checked) {
        var bRv = document.getElementById('rv-botao');
        if (bRv) bRv.click();
      }
      var bRt = document.getElementById('rt-armar');
      if (bRt && bRt.style.display !== 'none') { bRt.click(); }
    });
  }

  var bOff = document.getElementById('ttlf-off');
  if (bOff) {
    ttlfBindOnce(bOff, 'click', 'globalOff', function () {
      if (window.ttlfInitialPinTimer) { clearTimeout(window.ttlfInitialPinTimer); window.ttlfInitialPinTimer = null; }
      window.ttlfInitialPinSessionId++;
      ['rf-plus60-toggle', 'rf-botao', 'rd-botao', 'rc-botao', 'ra-botao', 'bn-botao', 'ic-botao', 'nv-botao'].forEach(function (id) {
        var b = document.getElementById(id);
        var txt = b ? (b.textContent || '') : '';
        if (b && (txt.indexOf('⏸') >= 0 || txt.indexOf('Parar') >= 0)) { b.click(); }
      });
      var cv = document.getElementById('rv-ativo');
      if (cv && cv.checked) {
        var bRv = document.getElementById('rv-botao');
        if (bRv) bRv.click();
      }
      var bRtCan = document.getElementById('rt-cancel');
      if (bRtCan && bRtCan.style.display !== 'none') { bRtCan.click(); }
    });
  }

  var ttlfMini = false;
  var bMin = document.getElementById('ttlf-min');
  if (bMin) {
    ttlfBindOnce(bMin, 'click', 'globalMin', function () {
      var d = document.getElementById('ttlf-hub');
      if (!d) return;
      ttlfMini = !ttlfMini;
      var mb = document.getElementById('ttlf-min');
      var topo = document.getElementById('ttlf-top');
      var linhaBtns = topo ? topo.children[1] : null;
      Array.prototype.slice.call(d.children).forEach(function (k) {
        if (k.id === 'ttlf-top') { return; }
        if (ttlfMini) { try { k.setAttribute('data-mini', '1'); } catch (e) {} k.style.display = 'none'; }
        else if (k.getAttribute && k.getAttribute('data-mini')) { k.style.display = ''; k.removeAttribute('data-mini'); }
      });
      if (linhaBtns) { linhaBtns.style.display = ttlfMini ? 'none' : 'flex'; }
      if (topo) { topo.style.borderRadius = ttlfMini ? '18px' : '18px 18px 0 0'; }
      d.style.maxHeight = ttlfMini ? 'none' : '84vh';
      d.style.overflow = ttlfMini ? 'visible' : 'auto';
      if (mb) mb.textContent = ttlfMini ? '+' : '−';
    });
  }

  var bCfg = document.getElementById('ttlf-cfg');
  if (bCfg) {
    ttlfBindOnce(bCfg, 'click', 'globalCfg', ttlfCfgPanel);
  }

  if (window.ttlfDebugBindings) window.ttlfDebugBindings.global = 1;
}

function initCardControls() {
  var hub = document.getElementById('ttlf-hub');
  if (!hub) return;
  Array.prototype.slice.call(hub.querySelectorAll('.ttlf-sec-h')).forEach(function (h, idx) {
    ttlfBindOnce(h, 'click', 'cardToggle' + idx, function () {
      var b = h.nextElementSibling;
      if (!b) return;
      var fechado = b.style.display === 'none';
      b.style.display = fechado ? 'block' : 'none';
      var sp = h.querySelector('span');
      if (sp) sp.textContent = fechado ? '▾' : '▸';
    });
  });
}

function initTimerControls() {
  var a = document.getElementById('rt-armar');
  if (a) {
    ttlfBindOnce(a, 'click', 'rtArmar', function () {
      if (typeof window.ttlfTimerArmar === 'function') window.ttlfTimerArmar();
    });
  }
  var p = document.getElementById('rt-pausa');
  if (p) {
    ttlfBindOnce(p, 'click', 'rtPausa', function () {
      if (typeof window.ttlfTimerPausa === 'function') window.ttlfTimerPausa();
    });
  }
  var c = document.getElementById('rt-cancel');
  if (c) {
    ttlfBindOnce(c, 'click', 'rtCancel', function () {
      if (typeof window.ttlfTimerCancel === 'function') window.ttlfTimerCancel();
    });
  }
  Array.prototype.slice.call(document.querySelectorAll('.ttlf-preset')).forEach(function (b, idx) {
    ttlfBindOnce(b, 'click', 'rtPreset' + idx, function () {
      var inp = document.getElementById('rt-min');
      if (inp) {
        inp.value = b.getAttribute('data-min');
        inp.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });
  });
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.timer = 1;
}

function initPlus60Controls() {
  var bRfPlus = document.getElementById('rf-plus60-toggle');
  if (bRfPlus) {
    ttlfBindOnce(bRfPlus, 'click', 'rfPlus60Toggle', function () {
      if (typeof window.ttlfPlus60Toggle === 'function') window.ttlfPlus60Toggle();
    });
  }
  var bRf = document.getElementById('rf-botao');
  if (bRf) {
    ttlfBindOnce(bRf, 'click', 'rfBotao', function () {
      if (typeof window.ttlfPlus60Toggle === 'function') window.ttlfPlus60Toggle();
    });
  }
  var cbAuto = document.getElementById('rf-auto-initial');
  if (cbAuto) {
    if (cbAuto.checked && typeof window.ttlfStartInitialPinMonitor === 'function') {
      window.ttlfStartInitialPinMonitor();
    }
    ttlfBindOnce(cbAuto, 'change', 'rfAutoInitial', function () {
      if (typeof window.ttlfStartInitialPinMonitor === 'function') {
        window.ttlfStartInitialPinMonitor();
      }
    });
  }
  var bFixMain = document.getElementById('rf-btn-fixar-main');
  if (bFixMain) {
    ttlfBindOnce(bFixMain, 'click', 'rfFixMain', function () {
      if (typeof window.ttlfPlus60FixMain === 'function') window.ttlfPlus60FixMain();
    });
  }
  var bBloqCupom = document.getElementById('rf-btn-bloq-cupom');
  if (bBloqCupom) {
    ttlfBindOnce(bBloqCupom, 'click', 'rfBloqCupom', function () {
      if (typeof window.ttlfPlus60BloqCupom === 'function') window.ttlfPlus60BloqCupom();
    });
  }
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.plus60 = 1;
}

function initFlashOfferControls() {
  var bRd = document.getElementById('rd-botao');
  if (bRd) {
    ttlfBindOnce(bRd, 'click', 'rdBotao', function () {
      if (typeof window.ttlfOfertaToggle === 'function') window.ttlfOfertaToggle();
    });
  }
}

function initCommentsControls() {
  var bRc = document.getElementById('rc-botao');
  if (bRc) {
    ttlfBindOnce(bRc, 'click', 'rcBotao', function () {
      if (typeof window.ttlfCommentsToggle === 'function') window.ttlfCommentsToggle();
    });
  }
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.comments = 1;
}

function initRepliesControls() {
  var bRa = document.getElementById('ra-botao');
  if (bRa) {
    ttlfBindOnce(bRa, 'click', 'raBotao', function () {
      if (typeof window.ttlfRepliesToggle === 'function') window.ttlfRepliesToggle();
    });
  }
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.replies = 1;
}

function initIntentControls() {
  var bIc = document.getElementById('ic-botao');
  if (bIc) {
    ttlfBindOnce(bIc, 'click', 'icBotao', function () {
      if (typeof window.ttlfIntentToggle === 'function') window.ttlfIntentToggle();
    });
  }
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.intent = 1;
}

function initBlockNameControls() {
  var bBn = document.getElementById('bn-botao');
  if (bBn) {
    ttlfBindOnce(bBn, 'click', 'bnBotao', function () {
      if (typeof window.ttlfBlockNameToggle === 'function') window.ttlfBlockNameToggle();
    });
  }
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.blockName = 1;
}

function initNtfyControls() {
  var bNv = document.getElementById('nv-botao');
  if (bNv) {
    ttlfBindOnce(bNv, 'click', 'nvBotao', function () {
      if (typeof window.ttlfNtfyToggle === 'function') window.ttlfNtfyToggle();
    });
  }
  var bNvTest = document.getElementById('nv-teste');
  if (bNvTest) {
    ttlfBindOnce(bNvTest, 'click', 'nvTeste', function () {
      if (typeof window.ttlfNtfyTeste === 'function') window.ttlfNtfyTeste();
    });
  }
  if (window.ttlfDebugBindings) window.ttlfDebugBindings.ntfy = 1;
}

function initProtectionControls() {
  var bRv = document.getElementById('rv-botao');
  if (bRv) {
    ttlfBindOnce(bRv, 'click', 'rvBotao', function () {
      if (typeof window.ttlfProtectionToggle === 'function') window.ttlfProtectionToggle();
    });
  }
}

function ttlfInitHudControllers() {
  console.info('[LICENSE 10] listeners inicializados');

  var d = document.getElementById('ttlf-hub');
  var bolha = document.getElementById('ttlf-bolha');

  if (d && bolha) {
    ttlfDrag(d, document.getElementById('ttlf-head'), 'ttlf-pos-hub', null);
    ttlfDrag(bolha, bolha, 'ttlf-pos-bolha', function () { d.style.display = 'block'; bolha.style.display = 'none'; });
  }

  initHudGlobalControls();
  initTimerControls();
  initPlus60Controls();
  initFlashOfferControls();
  initCommentsControls();
  initRepliesControls();
  initIntentControls();
  initBlockNameControls();
  initNtfyControls();
  initProtectionControls();
  initCardControls();
  if (typeof window.ttlfBindVcModule === 'function') {
    window.ttlfBindVcModule();
  }

  if (typeof window.ttlfRestoreAllModulesAfterHudReady === 'function') {
    setTimeout(function () {
      window.ttlfRestoreAllModulesAfterHudReady();
    }, 800);
  }

  window.ttlfInitializationComplete = true;
  console.info('[LICENSE 11] inicialização concluída');
}

/* ===== NOVO DETECTOR OFICIAL DE LIVE TRANSPLANTADO DO LIVEGOPRO v11.6.2 ===== */
window.ttlfLiveNoAr = function () {
  try {
    var els = document.querySelectorAll('div,span,p,b,strong');
    for (var i = 0; i < els.length; i++) {
      var e = els[i];
      if (e.children.length !== 0) { continue; }
      var t = (e.textContent || '').trim();
      if (!/^\d{1,2}:\d{2}:\d{2}$/.test(t)) { continue; }
      var r = e.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) { continue; }
      var p = e, dentro = false;
      while (p) {
        if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha' || p.id === 'ttlf-gate' || p.id === 'ra-painel') {
          dentro = true;
          break;
        }
        p = p.parentElement;
      }
      if (dentro) { continue; }
      return true;
    }
  } catch (e) {}

  try {
    var endBtns = document.querySelectorAll('button, div, span');
    for (var j = 0; j < endBtns.length; j++) {
      var b = endBtns[j];
      var bt = (b.textContent || '').trim().toLowerCase();
      if (bt === 'encerrar live' || bt === 'encerrar transmissão' || bt === 'end live') {
        var br = b.getBoundingClientRect();
        if (br.width > 0 && br.height > 0 && typeof window.ttlfIsInsideExtensionHud === 'function' && !window.ttlfIsInsideExtensionHud(b)) {
          return true;
        }
      }
    }
  } catch (e) {}

  return false;
};

window.ttlfGetLiveDetectionDetails = function () {
  var isLive = window.ttlfLiveNoAr();
  var timestamp = Date.now();

  function foraHubLocal(el) {
    return typeof window.ttlfIsInsideExtensionHud === 'function' ? !window.ttlfIsInsideExtensionHud(el) : true;
  }

  function isVis(el) {
    if (!el || !el.isConnected) return false;
    try {
      var cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) <= 0) return false;
      var r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    } catch (e) { return false; }
  }

  var chatVis = Array.prototype.slice.call(document.querySelectorAll('.chat-container, .live-chat, [data-e2e="live-chat"], #chat-room')).filter(foraHubLocal).some(isVis);
  var taVis = Array.prototype.slice.call(document.querySelectorAll('textarea')).filter(foraHubLocal).some(isVis);
  var endBtnVis = Array.prototype.slice.call(document.querySelectorAll('button, div, span')).filter(function (el) {
    if (!foraHubLocal(el) || !isVis(el)) return false;
    var t = (el.textContent || '').trim().toLowerCase();
    return t === 'encerrar live' || t === 'encerrar transmissão' || t === 'end live';
  }).length > 0;

  var timerVis = Array.prototype.slice.call(document.querySelectorAll('div, span, p, b, strong')).filter(function (el) {
    if (!foraHubLocal(el) || !isVis(el) || (el.children && el.children.length > 0)) return false;
    var t = (el.textContent || '').trim();
    return /^\d{1,2}:\d{2}:\d{2}$/.test(t);
  }).length > 0;

  var prodVis = Array.prototype.slice.call(document.querySelectorAll('[class*="product"], [class*="goods"], [data-e2e*="product"]')).filter(foraHubLocal).some(isVis);
  var pinBtnVis = Array.prototype.slice.call(document.querySelectorAll('button, [role="button"], div, span')).filter(function (el) {
    if (!foraHubLocal(el) || !isVis(el)) return false;
    var t = (el.textContent || '').trim().toLowerCase();
    return t === '+60s' || t === '+30s' || t === 'fixar' || t === 'desafixar';
  }).length > 0;

  var reason = isLive ? (timerVis ? 'LIVE_TIMER_DETECTED' : 'END_LIVE_BUTTON_DETECTED') : 'NO_LIVE_TIMER_FOUND';

  return {
    live: isLive,
    pageCompatible: chatVis || taVis || endBtnVis || timerVis || prodVis || pinBtnVis,
    chatVisible: chatVis,
    textareaVisible: taVis,
    endLiveButtonVisible: endBtnVis,
    liveTimerVisible: timerVis,
    productPanelVisible: prodVis,
    pinButtonVisible: pinBtnVis,
    reason: reason,
    timestamp: timestamp
  };
};

window.ttlfLastLoggedLiveDetectorState = null;
window.ttlfLastLoggedLiveDetectorTime = 0;

window.ttlfCheckAndLogLiveDetectorState = function () {
  var details = window.ttlfGetLiveDetectionDetails();
  var now = Date.now();
  if (window.ttlfLastLoggedLiveDetectorState === null || window.ttlfLastLoggedLiveDetectorState !== details.live || (now - window.ttlfLastLoggedLiveDetectorTime >= 30000)) {
    window.ttlfLastLoggedLiveDetectorState = details.live;
    window.ttlfLastLoggedLiveDetectorTime = now;
    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_DETECTOR] state: ' + (details.live ? 'LIVE ATIVA 🟢' : 'SEM LIVE 🔴') + ' | Razão: ' + details.reason);
    }
  }
};

/* ===== LIMPEZA DEFINITIVA DE STORAGES E MÉTRICAS LEGADAS (PURGE) ===== */
window.ttlfPurgeLegacyMetricsStorage = function () {
  var legacyKeys = [
    'ttlf_gmv',
    'ttlf_sales',
    'ttlf_vendas',
    'ttlf_dash_gmv',
    'ttlf_dash_vendas',
    'ttlf_total_gmv',
    'ttlf_total_sales',
    'ttlf_metrics',
    'live_gmv',
    'live_sales',
    'ttlf_stat_gmv',
    'ttlf_stat_vendas',
    'ttlf_sales_thanks_total_sent'
  ];

  var purgedCount = 0;
  legacyKeys.forEach(function (k) {
    try {
      var val = localStorage.getItem(k);
      if (val !== null) {
        if (typeof ttlfLog === 'function') {
          ttlfLog('[LEGACY_METRICS_PURGE] Chave antiga removida: ' + k + ' | Valor: ' + val);
        }
        localStorage.removeItem(k);
        purgedCount++;
      }
    } catch (e) {}
  });

  window.ttlfTotalGMVContado = 0;
  window.ttlfTotalVendasContadas = 0;
  window.__dashGMV = 0;
  window.__dashVendas = 0;
  window.__dashTicket = 0;
  window.__dashItens = 0;

  try {
    localStorage.setItem('ttlf_legacy_metrics_purged_v1', 'true');
  } catch (e) {}
};

window.ttlfHardResetLiveMetrics = function () {
  if (typeof ttlfLog === 'function') {
    ttlfLog('[LIVE_SESSION] HARD_RESET: Executando limpeza total de métricas legadas e da sessão atual.');
  }

  window.ttlfPurgeLegacyMetricsStorage();
  window.ttlfResetLiveSessionMetrics();

  try {
    var storedId = localStorage.getItem('ttlf_live_session_id');
    if (storedId) {
      localStorage.removeItem('ttlf_live_metrics_' + storedId);
      localStorage.removeItem('ttlf_live_fingerprint_' + storedId);
    }
    localStorage.removeItem('ttlf_live_session_id');
    localStorage.removeItem('ttlf_live_session_active');
    localStorage.removeItem('ttlf_live_session_started_at');
    localStorage.removeItem('ttlf_live_session_last_seen_at');
    localStorage.setItem('ttlf_live_session_ended_at', Date.now().toString());
  } catch (e) {}

  if (typeof window.ttlfLiveNoAr === 'function' && window.ttlfLiveNoAr()) {
    window.ttlfGetOrCreateLiveSession();
  } else {
    window.ttlfRenderLiveMetrics();
  }
};

// Purga automática única no carregamento do script
try {
  if (!localStorage.getItem('ttlf_legacy_metrics_purged_v1')) {
    window.ttlfPurgeLegacyMetricsStorage();
  }
} catch (e) {}

/* ===== GERENCIADOR DE SESSÃO E MÉTRICAS DA LIVE (VALIDADO POR FINGERPRINT) ===== */
window.ttlfLiveSession = {
  id: null,
  active: false,
  startedAt: 0,
  endedAt: 0,
  lastSeenAt: 0,
  lastLiveState: false,
  initialized: false,
  falseCounter: 0,
  metrics: {
    sales: 0,
    gmv: 0,
    items: 0,
    ticketAverage: 0,
    processedEventIds: [],
    updatedAt: 0
  }
};

window.ttlfLiveFingerprint = {
  timerSeconds: null,
  firstDetectedAt: 0,
  firstProductTitle: "",
  firstProductPrice: "",
  roomId: "",
  liveId: "",
  source: ""
};

var TTLF_SESSION_RECOVERY_WINDOW_MS = 5 * 60 * 1000; // 5 minutos de janela conservadora para F5

window.ttlfGenerateSessionId = function () {
  return 'live_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
};

window.ttlfExtractLiveTimerSeconds = function () {
  try {
    function foraHubLocal(el) {
      var p = el;
      while (p) {
        if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha' || p.id === 'ttlf-gate' || p.id === 'ra-painel') return false;
        p = p.parentElement;
      }
      return true;
    }

    var els = document.querySelectorAll('div,span,p,b,strong');
    for (var i = 0; i < els.length; i++) {
      var e = els[i];
      if (e.children && e.children.length !== 0) continue;
      var t = (e.textContent || '').trim();
      var match = t.match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
      if (match && foraHubLocal(e)) {
        var r = e.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          var hours = parseInt(match[1], 10);
          var mins = parseInt(match[2], 10);
          var secs = parseInt(match[3], 10);
          return hours * 3600 + mins * 60 + secs;
        }
      }
      var matchShort = t.match(/^(\d{1,2}):(\d{2})$/);
      if (matchShort && foraHubLocal(e)) {
        var r2 = e.getBoundingClientRect();
        if (r2.width > 0 && r2.height > 0) {
          var m2 = parseInt(matchShort[1], 10);
          var s2 = parseInt(matchShort[2], 10);
          return m2 * 60 + s2;
        }
      }
    }
  } catch (e) {}
  return null;
};

window.ttlfExtractLiveRoomId = function () {
  try {
    var searchStr = (typeof window !== 'undefined' && window.location) ? (window.location.search + window.location.hash) : '';
    var m = searchStr.match(/(?:room_id|roomId|live_id|liveId)=([a-zA-Z0-9_-]+)/i);
    if (m && m[1]) return m[1];

    if (typeof document !== 'undefined') {
      var elWithAttr = document.querySelector('[data-room-id], [data-live-id], [data-roomid], [data-liveid]');
      if (elWithAttr) {
        var attrVal = elWithAttr.getAttribute('data-room-id') || elWithAttr.getAttribute('data-live-id') || elWithAttr.getAttribute('data-roomid') || elWithAttr.getAttribute('data-liveid');
        if (attrVal) return attrVal.trim();
      }
    }
  } catch (e) {}
  return "";
};

window.ttlfExtractPinnedProductInfo = function () {
  try {
    function foraHubLocal(el) {
      var p = el;
      while (p) {
        if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha' || p.id === 'ttlf-gate') return false;
        p = p.parentElement;
      }
      return true;
    }

    if (typeof document !== 'undefined') {
      var prodCards = Array.prototype.slice.call(document.querySelectorAll('[class*="product"], [class*="goods"], [data-e2e*="product"]')).filter(foraHubLocal);
      if (prodCards.length > 0) {
        var card = prodCards[0];
        var txt = (card.textContent || '').trim().replace(/\s+/g, ' ');
        var priceMatch = txt.match(/R\$\s*\d+(?:[\.,]\d{2})?/i);
        var price = priceMatch ? priceMatch[0] : '';
        var title = txt.slice(0, 60);
        return { title: title, price: price };
      }
    }
  } catch (e) {}
  return { title: "", price: "" };
};

window.ttlfBuildLiveFingerprint = function () {
  var prodInfo = window.ttlfExtractPinnedProductInfo();
  return {
    timerSeconds: window.ttlfExtractLiveTimerSeconds(),
    firstDetectedAt: Date.now(),
    firstProductTitle: prodInfo.title || "",
    firstProductPrice: prodInfo.price || "",
    roomId: window.ttlfExtractLiveRoomId(),
    liveId: "",
    source: "gopro_detector_v11"
  };
};

window.ttlfSaveLiveFingerprint = function (sessionId, fp) {
  if (!sessionId || !fp) return;
  try {
    localStorage.setItem('ttlf_live_fingerprint_' + sessionId, JSON.stringify(fp));
  } catch (e) {}
};

window.ttlfGetSavedLiveFingerprint = function (sessionId) {
  if (!sessionId) return null;
  try {
    var raw = localStorage.getItem('ttlf_live_fingerprint_' + sessionId);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return null;
};

window.ttlfValidateSessionFingerprint = function (sessionId, currentFp) {
  // PASSO 1: LIVE Ativa?
  if (!window.ttlfLiveNoAr()) {
    return { valid: false, reason: 'LIVE_NOT_ACTIVE' };
  }

  // PASSO 2: Fingerprint salvo existe?
  var savedFp = window.ttlfGetSavedLiveFingerprint(sessionId);
  if (!savedFp) {
    if (typeof ttlfLog === 'function') ttlfLog('[LIVE_SESSION] fingerprint-mismatch: Sem fingerprint salvo.');
    return { valid: false, reason: 'NO_SAVED_FINGERPRINT' };
  }

  // PASSO 3: RoomId / LiveId (ROOM ID TEM PRIORIDADE MÁXIMA)
  if (savedFp.roomId && currentFp.roomId && savedFp.roomId !== currentFp.roomId) {
    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_SESSION] roomid-changed: RoomID mudou de ' + savedFp.roomId + ' para ' + currentFp.roomId);
    }
    return { valid: false, reason: 'ROOM_ID_CHANGED' };
  }

  // PASSO 4: Comparação de Cronômetro
  var oldTimer = savedFp.lastKnownTimerSeconds !== undefined ? savedFp.lastKnownTimerSeconds : savedFp.timerSeconds;
  var newTimer = currentFp.timerSeconds;

  if (typeof oldTimer === 'number' && typeof newTimer === 'number') {
    // RESET DO CRONÔMETRO (MARGEM SEGURA):
    // Se timerAnterior > 300s E timerAtual < 120s ➔ obrigatoriamente NOVA LIVE
    if (oldTimer > 300 && newTimer < 120) {
      if (typeof ttlfLog === 'function') {
        ttlfLog('[LIVE_SESSION] timer-reset-detected: Cronômetro resetou de ' + oldTimer + 's para ' + newTimer + 's. Obrigatoriamente nova LIVE.');
      }
      return { valid: false, reason: 'TIMER_RESET_DETECTED' };
    }

    // Se o cronômetro regrediu significativamente (ex: era 2890s e virou 14s ou regrediu > 30s)
    if (newTimer < (oldTimer - 30)) {
      if (typeof ttlfLog === 'function') {
        ttlfLog('[LIVE_SESSION] timer-mismatch: Cronômetro regrediu de ' + oldTimer + 's para ' + newTimer + 's.');
      }
      return { valid: false, reason: 'TIMER_REGRESSED' };
    }

    // Se novoTimer >= antigoTimer E a diferença de avanço for de até 180s (tempo plausível de reload pós-F5)
    if (newTimer >= oldTimer && (newTimer - oldTimer) <= 180) {
      if (typeof ttlfLog === 'function') {
        ttlfLog('[LIVE_SESSION] timer-compatible: Cronômetro compatível (' + oldTimer + 's ➔ ' + newTimer + 's). Restauração autorizada.');
      }
      return { valid: true, reason: 'TIMER_COMPATIBLE' };
    }
  }

  // PASSO 5: Produto como Auxiliar (Se o relógio atual estiver zerado/indefinido e o produto for completamente diferente)
  if (savedFp.firstProductTitle && currentFp.firstProductTitle && savedFp.firstProductTitle !== currentFp.firstProductTitle && (typeof newTimer === 'number' && newTimer < 120)) {
    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_SESSION] product-mismatch: Produto e cronômetro indicam nova LIVE.');
    }
    return { valid: false, reason: 'PRODUCT_MISMATCH' };
  }

  if (savedFp.roomId && currentFp.roomId && savedFp.roomId === currentFp.roomId) {
    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_SESSION] roomid-compatible: RoomID idêntico (' + savedFp.roomId + '). Restauração autorizada.');
    }
    return { valid: true, reason: 'ROOM_ID_COMPATIBLE' };
  }

  if (newTimer === null && typeof oldTimer === 'number' && oldTimer < 300) {
    return { valid: true, reason: 'TIMER_NULL_CONSERVATIVE' };
  }

  if (typeof oldTimer === 'number' && typeof newTimer === 'number' && newTimer >= oldTimer) {
    return { valid: true, reason: 'TIMER_ADVANCED_PLANTS' };
  }

  return { valid: true, reason: 'FALLBACK_COMPATIBLE' };
};

window.ttlfGetOrCreateLiveSession = function () {
  var isLiveOn = window.ttlfLiveNoAr();
  var now = Date.now();
  var currentFp = window.ttlfBuildLiveFingerprint();

  try {
    var storedId = localStorage.getItem('ttlf_live_session_id');
    var storedActive = localStorage.getItem('ttlf_live_session_active') === 'true';
    var storedStartedAt = parseInt(localStorage.getItem('ttlf_live_session_started_at') || '0', 10);
    var storedLastSeen = parseInt(localStorage.getItem('ttlf_live_session_last_seen_at') || '0', 10);
    var storedEndedAt = parseInt(localStorage.getItem('ttlf_live_session_ended_at') || '0', 10);

    if (isLiveOn && storedActive && storedId && storedEndedAt === 0 && (now - storedLastSeen) <= TTLF_SESSION_RECOVERY_WINDOW_MS) {
      
      var valRes = window.ttlfValidateSessionFingerprint(storedId, currentFp);

      if (valRes.valid) {
        window.ttlfLiveSession.id = storedId;
        window.ttlfLiveSession.active = true;
        window.ttlfLiveSession.startedAt = storedStartedAt;
        window.ttlfLiveSession.lastSeenAt = now;
        window.ttlfLiveSession.endedAt = 0;
        window.ttlfLiveSession.initialized = true;

        window.ttlfRestoreLiveSessionMetrics(storedId);
        localStorage.setItem('ttlf_live_session_last_seen_at', now.toString());

        var savedFp = window.ttlfGetSavedLiveFingerprint(storedId);
        if (savedFp && typeof currentFp.timerSeconds === 'number') {
          savedFp.lastKnownTimerSeconds = currentFp.timerSeconds;
          window.ttlfSaveLiveFingerprint(storedId, savedFp);
        }

        if (typeof ttlfLog === 'function') {
          ttlfLog('[LIVE_SESSION] fingerprint-restored: ' + storedId + ' | Razão: ' + valRes.reason + ' | Vendas: ' + window.ttlfLiveSession.metrics.sales + ' | GMV: R$ ' + window.ttlfLiveSession.metrics.gmv.toFixed(2));
        }
        return window.ttlfLiveSession;
      } else {
        if (typeof ttlfLog === 'function') {
          ttlfLog('[LIVE_SESSION] new-live-created: Fingerprint incompatível com sessão anterior (' + valRes.reason + '). Forçando nova LIVE.');
        }
      }
    }
  } catch (e) {}

  if (isLiveOn) {
    var newId = window.ttlfGenerateSessionId();
    window.ttlfLiveSession.id = newId;
    window.ttlfLiveSession.active = true;
    window.ttlfLiveSession.startedAt = now;
    window.ttlfLiveSession.lastSeenAt = now;
    window.ttlfLiveSession.endedAt = 0;
    window.ttlfLiveSession.falseCounter = 0;
    window.ttlfLiveSession.initialized = true;

    window.ttlfResetLiveSessionMetrics();

    try {
      localStorage.setItem('ttlf_live_session_id', newId);
      localStorage.setItem('ttlf_live_session_active', 'true');
      localStorage.setItem('ttlf_live_session_started_at', now.toString());
      localStorage.setItem('ttlf_live_session_last_seen_at', now.toString());
      localStorage.removeItem('ttlf_live_session_ended_at');
    } catch (e) {}

    currentFp.lastKnownTimerSeconds = currentFp.timerSeconds;
    window.ttlfSaveLiveFingerprint(newId, currentFp);

    window.ttlfSaveLiveSessionMetrics();
    window.ttlfRenderLiveMetrics();

    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_SESSION] fingerprint-created: ' + newId + ' | Nova LIVE iniciada. Métricas zeradas. Timer: ' + (currentFp.timerSeconds !== null ? currentFp.timerSeconds + 's' : 'N/A'));
    }
    return window.ttlfLiveSession;
  }

  window.ttlfLiveSession.id = null;
  window.ttlfLiveSession.active = false;
  window.ttlfLiveSession.initialized = true;
  window.ttlfResetLiveSessionMetrics();
  window.ttlfRenderLiveMetrics();
  return window.ttlfLiveSession;
};

  /* ===== MOTOR INTEGRAL DE MÉTRICAS E DASHBOARD TRANSPLANTADO DO LIVEGOPRO v11.6.2 ===== */
  window.ttlfMetricsEngine = {
    running: false,
    timer: null,
    lastGMV: 0,
    lastSales: 0,
    lastItems: 0,
    lastTicket: 0,
    lastUpdateAt: 0,
    lastSource: '',
    failures: 0
  };

  function $q(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha' || p.id === 'ttlf-gate') { return false; } p = p.parentElement; } return true; }

  function metrica(lab) {
    var targets = Array.isArray(lab) ? lab : [lab];
    var els = $q('div,span,p,b,strong').filter(function (e) {
      if (e.children.length > 0) return false;
      var t = (e.textContent || '').trim();
      if (!t) return false;
      for (var k = 0; k < targets.length; k++) {
        if (t.indexOf(targets[k]) === 0 || t.toLowerCase().indexOf(targets[k].toLowerCase()) === 0) {
          return true;
        }
      }
      return false;
    });
    if (!els.length) return null;
    var el = els[0];
    var base = el.textContent.trim();
    var p = el.parentElement;
    for (var i = 0; i < 4 && p; i++) {
      var lv = $q('div,span,p,b,strong', p).filter(function (x) {
        return x.children.length === 0 && x !== el && (x.textContent || '').trim();
      });
      for (var j = 0; j < lv.length; j++) {
        var t = lv[j].textContent.trim();
        if (t !== base && t.length < 30 && /^(--|R\$|\$|\d)/.test(t)) {
          return t;
        }
      }
      p = p.parentElement;
    }
    return null;
  }

  function parseNum(v) {
    if (!v) return 0;
    var s = String(v), mult = 1;
    if (/mil/i.test(s)) { mult = 1000; }
    else if (/mi/i.test(s)) { mult = 1000000; }
    s = s.replace(/[^\d.,]/g, '');
    if (s.indexOf(',') > -1) {
      s = s.replace(/\./g, '').replace(',', '.');
    }
    return (parseFloat(s) || 0) * mult;
  }

  function fmtBRL(n) {
    return 'R$ ' + (n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  var SREG = /comprou o produto|acabou de comprar|fez um pedido|realizou (um |o )?pedido|placed an order/i;

  function contaVendas() {
    var somaAtiv = 0, somaToast = 0;
    var hits = $q('div,span,p').filter(function (x) {
      if (!fora(x) || !vis(x)) return false;
      var t = (x.textContent || '').trim();
      return t && t.length <= 90 && /clientes?\s+(?:comprou|compraram|adquiriu|adquiriram)/i.test(t);
    });
    hits.filter(function (x) {
      return !hits.some(function (y) { return y !== x && x.contains(y); });
    }).forEach(function (x) {
      var t = (x.textContent || '').trim();
      var m = t.match(/(\d+)\s+clientes?/i);
      somaAtiv += m ? (parseInt(m[1], 10) || 1) : 1;
    });

    $q('div,span,p').forEach(function (x) {
      if (x.children.length !== 0) return;
      if (!fora(x) || !vis(x)) return;
      var t = (x.textContent || '').trim();
      if (t && t.length < 90 && SREG.test(t) && /R\$\s?\d/.test(t)) {
        somaToast += 1;
      }
    });

    var soma = Math.max(somaAtiv, somaToast);
    if (soma > (window.__dashVendas || 0)) {
      window.__dashVendas = soma;
    }
  }

  function setv(id, v) {
    var e = document.getElementById(id);
    if (e) {
      e.textContent = v;
      if (id === 'dash-gmv') {
        e.style.color = (v && v !== 'R$ 0,00') ? '#00e676' : '#a0a5b5';
      } else if (id === 'dash-vendas' || id === 'dash-itens') {
        e.style.color = (v && v !== '0') ? '#ffffff' : '#a0a5b5';
      } else if (id === 'dash-ticket') {
        e.style.color = (v && v !== 'R$ 0,00') ? '#ffffff' : '#a0a5b5';
      }
    }
  }

  window.dashUpdate = function () {
    var eng = window.ttlfMetricsEngine;
    if (!eng.running) return;

    var sessActive = window.ttlfLiveSession && window.ttlfLiveSession.active;
    var sessId = (window.ttlfLiveSession && window.ttlfLiveSession.id) ? window.ttlfLiveSession.id : 'no_session';

    try {
      contaVendas();

      var gmvRaw = metrica(['GMV atribu', 'GMV', 'Faturamento', 'Sales']);
      var itensRaw = metrica(['Itens atribu', 'Itens vendidos', 'Items sold']);

      var gmv = parseNum(gmvRaw);
      var itens = parseNum(itensRaw);
      var vendas = window.__dashVendas || 0;

      var isLiveNow = typeof window.ttlfLiveNoAr === 'function' ? window.ttlfLiveNoAr() : false;

      if (!sessActive && !isLiveNow) {
        gmv = 0;
        vendas = 0;
        itens = 0;
      } else {
        if (gmv === 0 && eng.lastGMV > 0) gmv = eng.lastGMV;
        if (itens === 0 && eng.lastItems > 0) itens = eng.lastItems;
        if (vendas === 0 && eng.lastSales > 0) vendas = eng.lastSales;
      }

      var divisor = vendas > 0 ? vendas : itens;
      var ticket = (divisor > 0 && gmv > 0) ? (gmv / divisor) : 0;

      eng.lastGMV = gmv;
      eng.lastSales = vendas;
      eng.lastItems = itens;
      eng.lastTicket = ticket;
      eng.lastUpdateAt = Date.now();
      eng.lastSource = gmvRaw ? 'GMV_ATRIBUIDO' : (vendas > 0 ? 'ACTIVITY_SCAN' : 'SOURCE_NOT_FOUND');

      if (sessActive && window.ttlfLiveSession.metrics) {
        window.ttlfLiveSession.metrics.gmv = gmv;
        window.ttlfLiveSession.metrics.sales = vendas;
        window.ttlfLiveSession.metrics.items = itens;
        window.ttlfLiveSession.metrics.ticketAverage = ticket;
        window.ttlfSaveLiveSessionMetrics();
      }

      setv('dash-gmv', fmtBRL(gmv));
      setv('dash-vendas', String(vendas));
      setv('dash-itens', (itensRaw && itensRaw !== '--') ? itensRaw : String(itens));
      setv('dash-ticket', fmtBRL(ticket));

      var elStatus = document.getElementById('dash-status');
      if (elStatus) {
        if (isLiveNow) {
          elStatus.textContent = '• ao vivo';
          elStatus.style.color = '#00e676';
        } else {
          elStatus.textContent = '• aguardando';
          elStatus.style.color = '#ffd000';
        }
      }

      var vEl = document.getElementById('ttlf-stat-vendas');
      var gEl = document.getElementById('ttlf-stat-gmv');
      if (vEl) vEl.textContent = String(vendas);
      if (gEl) gEl.textContent = fmtBRL(gmv);

      var sig = gmv + '|' + vendas + '|' + itens + '|' + ticket.toFixed(2) + '|' + eng.lastSource + '|' + sessId;
      if (sig !== eng.lastLoggedState || window.ttlfDebugMetrics) {
        eng.lastLoggedState = sig;
        if (typeof ttlfLog === 'function') {
          ttlfLog('[GOPRO_METRICS] gmv-found: ' + gmv + ' | sales: ' + vendas + ' | items: ' + itens + ' | ticket: ' + ticket.toFixed(2) + ' | source: ' + eng.lastSource + ' | session: ' + sessId);
        }
      }
    } catch (err) {
      eng.failures++;
      if (typeof ttlfLog === 'function') {
        ttlfLog('[GOPRO_METRICS] exception: ' + ((err && err.message) || err) + ' | session: ' + sessId);
      }
    }
  };

  window.dashStart = function () {
    var eng = window.ttlfMetricsEngine;
    if (eng.running && eng.timer) return;

    eng.running = true;
    if (eng.timer) clearInterval(eng.timer);
    eng.timer = setInterval(function () {
      window.dashUpdate();
    }, 2000);

    window.dashUpdate();
    if (typeof ttlfLog === 'function') ttlfLog('[GOPRO_METRICS] started');
  };

  window.dashStop = function () {
    var eng = window.ttlfMetricsEngine;
    eng.running = false;
    if (eng.timer) {
      clearInterval(eng.timer);
      eng.timer = null;
    }
    if (typeof ttlfLog === 'function') ttlfLog('[GOPRO_METRICS] stopped');
  };

  window.ttlfSaveLiveSessionMetrics = function () {
    if (!window.ttlfLiveSession.id) return;
    var key = 'ttlf_live_metrics_' + window.ttlfLiveSession.id;
    window.ttlfLiveSession.metrics.updatedAt = Date.now();
    try {
      localStorage.setItem(key, JSON.stringify(window.ttlfLiveSession.metrics));
      localStorage.setItem('ttlf_live_session_last_seen_at', Date.now().toString());
    } catch (e) {}
  };

  window.ttlfRestoreLiveSessionMetrics = function (sessionId) {
    if (!sessionId) return;
    var key = 'ttlf_live_metrics_' + sessionId;
    try {
      var raw = localStorage.getItem(key);
      if (raw) {
        var data = JSON.parse(raw);
        var eng = window.ttlfMetricsEngine;
        eng.lastSales = data.sales || 0;
        eng.lastGMV = data.gmv || 0;
        eng.lastItems = data.items || 0;
        eng.lastTicket = data.sales > 0 ? (data.gmv / data.sales) : 0;
        window.__dashVendas = eng.lastSales;
        window.ttlfLiveSession.metrics.sales = eng.lastSales;
        window.ttlfLiveSession.metrics.gmv = eng.lastGMV;
        window.ttlfLiveSession.metrics.items = eng.lastItems;
        window.ttlfLiveSession.metrics.ticketAverage = eng.lastTicket;
      } else {
        window.ttlfResetLiveSessionMetrics();
      }
    } catch (e) {
      window.ttlfResetLiveSessionMetrics();
    }
    window.dashUpdate();
  };

  window.ttlfResetLiveSessionMetrics = function () {
    window.ttlfLiveSession.metrics = {
      sales: 0,
      gmv: 0,
      items: 0,
      ticketAverage: 0,
      processedEventIds: [],
      updatedAt: Date.now()
    };
    var eng = window.ttlfMetricsEngine;
    eng.lastGMV = 0;
    eng.lastSales = 0;
    eng.lastItems = 0;
    eng.lastTicket = 0;
    window.__dashVendas = 0;
    window.__dashGMV = 0;
    window.__dashTicket = 0;
    window.__dashItens = 0;

    setv('dash-gmv', 'R$ 0,00');
    setv('dash-vendas', '0');
    setv('dash-itens', '0');
    setv('dash-ticket', 'R$ 0,00');

    if (typeof ttlfLog === 'function') ttlfLog('[GOPRO_METRICS] session-reset');
  };

  window.ttlfAddSaleToCurrentSession = function (price, quantity, eventId) {
    if (!window.ttlfLiveSession.active || !window.ttlfLiveSession.id) {
      window.ttlfGetOrCreateLiveSession();
    }
    var numPrice = typeof price === 'number' ? price : parseFloat(price) || 0;
    var numQty = typeof quantity === 'number' ? quantity : parseInt(quantity, 10) || 1;

    window.ttlfLiveSession.metrics.sales += 1;
    window.ttlfLiveSession.metrics.gmv += numPrice;
    window.ttlfLiveSession.metrics.items += numQty;
    window.ttlfLiveSession.metrics.ticketAverage = window.ttlfLiveSession.metrics.gmv / window.ttlfLiveSession.metrics.sales;

    window.__dashVendas = (window.__dashVendas || 0) + 1;
    window.dashUpdate();
    return true;
  };

  window.ttlfEndCurrentLiveSession = function (reason) {
    if (!window.ttlfLiveSession.active && !window.ttlfLiveSession.id) return;

    var endedId = window.ttlfLiveSession.id;
    var now = Date.now();

    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_SESSION] ending: ' + endedId + ' | Motivo: ' + (reason || 'LIVE_ENDED'));
    }

    try {
      localStorage.setItem('ttlf_live_session_active', 'false');
      localStorage.setItem('ttlf_live_session_ended_at', now.toString());
    } catch (e) {}

    window.ttlfLiveSession.active = false;
    window.ttlfLiveSession.endedAt = now;
    window.ttlfLiveSession.id = null;

    window.ttlfResetLiveSessionMetrics();

    if (typeof ttlfLog === 'function') {
      ttlfLog('[LIVE_SESSION] ended: ' + endedId + ' | Métricas zeradas no encerramento.');
    }
  };

  window.ttlfMonitorLiveSessionState = function () {
    var isLiveNow = window.ttlfLiveNoAr();

    if (isLiveNow) {
      window.ttlfLiveSession.falseCounter = 0;
      if (!window.ttlfLiveSession.active || !window.ttlfLiveSession.id) {
        window.ttlfGetOrCreateLiveSession();
      } else {
        window.ttlfLiveSession.lastSeenAt = Date.now();
        try {
          localStorage.setItem('ttlf_live_session_last_seen_at', Date.now().toString());
        } catch (e) {}
      }
    } else {
      if (window.ttlfLiveSession.active) {
        window.ttlfLiveSession.falseCounter = (window.ttlfLiveSession.falseCounter || 0) + 1;
        if (typeof ttlfLog === 'function' && window.ttlfLiveSession.falseCounter === 1) {
          ttlfLog('[LIVE_SESSION] transient-false-ignored: 1ª leitura false. Aguardando confirmação (3 leituras).');
        }
        if (window.ttlfLiveSession.falseCounter >= 3) {
          window.ttlfEndCurrentLiveSession('CONFIRMED_3_FALSE_READINGS');
        }
      } else {
        window.dashUpdate();
      }
    }
  };

  window.ttlfRenderLiveMetrics = function () {
    window.dashUpdate();
  };

  window.dashStart();

/* ===== ADAPTADORES TEMPORÁRIOS PARA DELEGAÇÃO DE FONTES DE VERDADE ===== */
window.ttlfDetectLiveState = function () {
  var live = window.ttlfLiveNoAr();
  var details = window.ttlfGetLiveDetectionDetails();
  window.ttlfCheckAndLogLiveDetectorState();
  return {
    active: live,
    confidence: live ? 'high' : 'none',
    signals: live ? (details.liveTimerVisible ? ['cronometro_live_nativo'] : ['botao_encerrar_nativo']) : [],
    checkedAt: Date.now()
  };
};

window.ttlfWaitForLiveDomReady = function (callback, maxWaitMs) {
  var timeout = maxWaitMs || 15000;
  var startAt = Date.now();

  var stPlus = document.getElementById('rf-plus60-status');
  if (stPlus) stPlus.textContent = 'Aguardando DOM da LIVE...';

  var checkInterval = setInterval(function () {
    var ls = window.ttlfDetectLiveState();
    var elapsed = Date.now() - startAt;

    if (ls.active || elapsed >= timeout) {
      clearInterval(checkInterval);
      if (typeof callback === 'function') {
        callback(ls);
      }
    }
  }, 800);
};

window.ttlfRestoreAllModulesAfterHudReady = function () {
  if (window.ttlfRestoringLock) return;
  window.ttlfRestoringLock = true;

  ttlfLog('[GLOBAL_RECOVERY] Aguardando DOM real da LIVE antes de restaurar...');

  window.ttlfWaitForLiveDomReady(function (liveState) {
    ttlfStGet(function (lic) {
      if (!lic) {
        window.ttlfRestoringLock = false;
        return;
      }

      ttlfLog('[GLOBAL_RECOVERY] DOM da LIVE pronto! Estado: ' + (liveState.active ? 'ATIVA' : 'INATIVA') + ' | Sinais: [' + liveState.signals.join(', ') + ']');

      // 1. Refixação Automática (Seção B)
      var repinActive = lic.ttlf_repin_enabled || lic.rfAutoInitial;
      if (repinActive) {
        var bPlus = document.getElementById('rf-plus60-toggle');
        var stPlus = document.getElementById('rf-plus60-status');
        if (bPlus) {
          bPlus.textContent = '⏸ Parar refixação';
          bPlus.style.background = '#ff1717';
        }
        if (stPlus) {
          stPlus.textContent = liveState.active ? ('Refixação restaurada. (Sinais: ' + liveState.signals.join(', ') + ')') : 'Aguardando início da LIVE para refixação...';
        }
        if (liveState.active && typeof window.ttlfPlus60Start === 'function') {
          window.ttlfPlus60Start();
        }
      }

      // 2. Comentários Automáticos
      if (lic.ttlf_comments_enabled || lic.rc_ativo) {
        var bRc = document.getElementById('rc-botao');
        if (bRc && bRc.textContent.indexOf('▶') >= 0 && typeof window.rcStart === 'function') {
          window.rcStart();
        }
      }

      // 3. Respostas Automáticas
      if (lic.ttlf_replies_enabled || lic.ra_ativo) {
        var bRa = document.getElementById('ra-botao');
        if (bRa && bRa.textContent.indexOf('▶') >= 0 && typeof window.raStart === 'function') {
          window.raStart();
        }
      }

      // 4. Intenção de Compra
      if (lic.ttlf_intent_enabled || lic.ic_ativo) {
        var bIc = document.getElementById('ic-botao');
        if (bIc && bIc.textContent.indexOf('▶') >= 0 && typeof window.icStart === 'function') {
          window.icStart();
        }
      }

      // 5. Sales Capture & Thanks
      var chkThanks = document.getElementById('stc-thanks-enabled');
      if (typeof lic.ttlf_sales_thanks_enabled === 'boolean' && chkThanks) {
        chkThanks.checked = lic.ttlf_sales_thanks_enabled;
      }
      if (lic.ttlf_sales_capture_enabled || lic.stc_ativo || (chkThanks && chkThanks.checked)) {
        if (window.ttlfSalesCapture && !window.ttlfSalesCapture.running) {
          window.ttlfSalesCapture.start();
        }
      }

      // 6. Alerta NTFY
      if (lic.ttlf_ntfy_enabled || lic.nv_ativo) {
        var bNv = document.getElementById('nv-botao');
        if (bNv && bNv.textContent.indexOf('▶') >= 0 && typeof window.ttlfNtfyToggle === 'function') {
          window.ttlfNtfyToggle();
        }
      }

      // 7. Timer de Encerramento (Absoluto endAt)
      if (lic.rt_end_at) {
        var now = Date.now();
        if (lic.rt_end_at > now) {
          var remainSec = Math.round((lic.rt_end_at - now) / 1000);
          var inputMin = document.getElementById('rt-minutos');
          if (inputMin) inputMin.value = Math.max(1, Math.round(remainSec / 60));
          var bRtArm = document.getElementById('rt-armar');
          if (bRtArm && typeof window.rtArmar === 'function' && bRtArm.style.display !== 'none') {
            window.rtArmar();
          }
        }
      }

      // 8. Leitura contínua de GMV e Vendas
      if (typeof ttlfScanStats === 'function') ttlfScanStats();

      window.ttlfRestoringLock = false;
      ttlfLog('[GLOBAL_RECOVERY] Restauração global concluída com sucesso ✅');
    });
  }, 15000);
};

window.ttlfDiagnosePostRefresh = function () {
  var ls = window.ttlfDetectLiveState();
  var hub = document.getElementById('ttlf-hub');
  var sc = window.ttlfSalesCapture ? window.ttlfSalesCapture.healthCheck() : null;

  var repinBtn = document.getElementById('rf-plus60-toggle');
  var repinSt = document.getElementById('rf-plus60-status');
  var stcBtn = document.getElementById('stc-botao');
  var stcSt = document.getElementById('stc-status');
  var stcChk = document.getElementById('stc-thanks-enabled');

  return {
    storage: {
      repinEnabled: window.ttlfPlus60IsRunning ? window.ttlfPlus60IsRunning() : false,
      commentsEnabled: typeof window.rcIsRunning === 'function' ? window.rcIsRunning() : false,
      repliesEnabled: typeof window.raIsRunning === 'function' ? window.raIsRunning() : false,
      salesCaptureEnabled: window.ttlfSalesCapture ? window.ttlfSalesCapture.running : false,
      salesThanksEnabled: stcChk ? stcChk.checked : false
    },
    runtime: {
      liveState: ls,
      repinRunning: window.ttlfPlus60IsRunning ? window.ttlfPlus60IsRunning() : false,
      salesCaptureRunning: window.ttlfSalesCapture ? window.ttlfSalesCapture.running : false,
      salesObserverAlive: sc ? sc.observerAlive : false,
      salesScanAlive: sc ? sc.scanTimerAlive : false,
      salesWatchdogAlive: sc ? (sc.watchdogTimer !== null) : false
    },
    hud: {
      hudReady: !!hub,
      repinButtonText: repinBtn ? (repinBtn.textContent || '').trim() : 'N/A',
      repinStatusText: repinSt ? (repinSt.textContent || '').trim() : 'N/A',
      salesButtonText: stcBtn ? (stcBtn.textContent || '').trim() : 'N/A',
      salesStatusText: stcSt ? (stcSt.textContent || '').trim() : 'N/A',
      salesThanksChecked: stcChk ? stcChk.checked : false
    },
    timestamp: Date.now()
  };
};

function ttlfGateGo() {
  console.info('[LICENSE 01] chave enviada');
  if (window.ttlfValidandoLock) return;
  var el = document.getElementById('ttlf-gate-key');
  var k = (el && el.value || '').trim();
  var st = document.getElementById('ttlf-gate-st');
  var btn = document.getElementById('ttlf-gate-btn');

  if (!k) { if (st) st.textContent = 'Digite a chave de acesso.'; return; }
  if (st) st.textContent = 'Verificando chave…';
  if (btn) { btn.disabled = true; btn.textContent = 'Validando...'; }
  window.ttlfValidandoLock = true;

  ttlfStGet(function(licExistente) {
    var dev = ttlfDevice(licExistente);
    ttlfValida(k, dev, function (ok, reason, offline, data) {
      window.ttlfValidandoLock = false;
      if (btn) { btn.disabled = false; btn.textContent = '🚀 Liberar Acesso'; }
      if (!ok) {
        if (st) st.textContent = ttlfMsg(reason);
        return;
      }
      console.info('[LICENSE 02] resposta válida');
      var now = Date.now();
      var lic = {
        key: k.toUpperCase(),
        device: dev,
        lastOk: now,
        activated: now,
        exp: data && data.exp ? data.exp : (now + 30 * 86400000),
        email: data && data.email ? data.email : '',
        version: '11.0.0-dev'
      };
      ttlfStSet(lic);
      console.info('[LICENSE 03] liveinfinity_lic salvo');
      var g = document.getElementById('ttlf-gate');
      if (g && g.parentNode) g.parentNode.removeChild(g);
      console.info('[LICENSE 04] gate removido');
      ttlfLiga();
    });
  });
}

function ttlfLiga() {
  console.info('[LICENSE 05] ttlfLiga chamada');
  var hub = document.getElementById('ttlf-hub');
  if (!hub) {
    ttlfBuildHub();
  } else {
    hub.style.display = 'block';
    ttlfInitHudControllers();
  }
  if (!window.ttlfReck) { window.ttlfReck = setInterval(ttlfRecheck, 6 * 3600 * 1000); }
  try { ttlfLogWatch(); } catch (e) {}
  if (!window.ttlfProntoLog) { window.ttlfProntoLog = 1; ttlfLog('Live Infinity v11.0.0-dev pronto para usar ✅'); }
}

function ttlfNow() { return new Date().toTimeString().slice(0, 8); }

function ttlfLog(msg) {
  var line = '[' + ttlfNow() + '] ' + msg;
  window.ttlfLogArr.push(line);
  if (window.ttlfLogArr.length > 400) { window.ttlfLogArr.shift(); }
  var box = document.getElementById('ttlf-log-box');
  if (box) { box.textContent = window.ttlfLogArr.join('\n'); box.scrollTop = box.scrollHeight; }
  try { console.log('[LIVE INFINITY] ' + msg); } catch (e) {}
}
window.ttlfLog = ttlfLog;

var TTLF_LOG_LABELS = {
  'rt-status': 'Timer',
  'rf-status': 'Refixar',
  'rd-status': 'Oferta',
  'rc-status': 'Coment.',
  'ra-status': 'Respostas',
  'rv-status': 'Proteção',
  'bn-status': 'Bloqueio',
  'ic-status': 'Intenção',
  'nv-status': 'Venda',
  'md-status': 'Mídia'
};

function ttlfLogWatch() {
  if (window.ttlfLogTimer) { return; }
  var last = {};
  window.ttlfLogTimer = setInterval(function () {
    for (var id in TTLF_LOG_LABELS) {
      var e = document.getElementById(id);
      if (!e) { continue; }
      var t = (e.textContent || '').trim();
      if (!t) { continue; }
      if (last[id] === undefined) { last[id] = t; continue; }
      if (t !== last[id]) { last[id] = t; ttlfLog('[' + TTLF_LOG_LABELS[id] + '] ' + t); }
    }
    try { ttlfUpdStatus(); } catch (e) {}
    try { ttlfUpdPower(); } catch (e) {}
    try { ttlfScanStats(); } catch (e) {}
    try { if (typeof window.ttlfMonitorLiveSessionState === 'function') window.ttlfMonitorLiveSessionState(); } catch (e) {}
  }, 1200);
}

function ttlfLiveNoAr() {
  try {
    var els = document.querySelectorAll('div,span,p,b,strong');
    for (var i = 0; i < els.length; i++) {
      var e = els[i];
      if (e.children.length !== 0) { continue; }
      var t = (e.textContent || '').trim();
      if (!/^\d{1,2}:\d{2}:\d{2}$/.test(t)) { continue; }
      var r = e.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) { continue; }
      var p = e, dentro = false;
      while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { dentro = true; break; } p = p.parentElement; }
      if (dentro) { continue; }
      return true;
    }
  } catch (e) {}
  return false;
}

/* LEITOR LEGADO DESATIVADO — RENDERIZADOR CONTROLADO SOMENTE PELA SESSÃO ATIVA DA LIVE */
function ttlfScanStats() {
  if (typeof window.ttlfRenderLiveMetrics === 'function') {
    window.ttlfRenderLiveMetrics();
  }
}

function ttlfTipEl() {
  var t = document.getElementById('ttlf-tip');
  if (t) { return t; }
  t = document.createElement('div');
  t.id = 'ttlf-tip';
  t.style.cssText = 'position:fixed;z-index:2147483647;display:none;pointer-events:none;background:#070a12;color:#ffd000;border:1px solid rgba(255,208,0,0.4);border-radius:8px;padding:5px 9px;font:600 11px/1.2 -apple-system,Segoe UI,Roboto,Arial,sans-serif;white-space:nowrap;box-shadow:0 4px 14px rgba(0,0,0,.85)';
  document.body.appendChild(t);
  return t;
}

function ttlfTipHide() { var t = document.getElementById('ttlf-tip'); if (t) { t.style.display = 'none'; } }

function ttlfTipBind(el) {
  if (!el || el.getAttribute('data-tipbind')) { return; }
  try { el.setAttribute('data-tipbind', '1'); } catch (e) {}
  el.addEventListener('mouseenter', function () {
    var tx = el.getAttribute('data-tip') || '';
    if (!tx) { return; }
    var t = ttlfTipEl();
    t.textContent = tx;
    t.style.display = 'block';
    t.style.left = '-9999px'; t.style.top = '-9999px';
    var r = el.getBoundingClientRect();
    var tr = t.getBoundingClientRect();
    var left = r.left + r.width / 2 - tr.width / 2;
    if (left < 6) { left = 6; }
    if (left + tr.width > window.innerWidth - 6) { left = window.innerWidth - 6 - tr.width; }
    var top = r.bottom + 6;
    if (top + tr.height > window.innerHeight - 6) { top = r.top - tr.height - 6; }
    t.style.left = left + 'px';
    t.style.top = top + 'px';
  });
  el.addEventListener('mouseleave', ttlfTipHide);
  el.addEventListener('mousedown', ttlfTipHide);
}

function ttlfUpdPower() {
  var pw = document.getElementById('ttlf-power'); if (!pw) { return; }
  ['ttlf-cfg', 'ttlf-power', 'ttlf-min'].forEach(function (bid) {
    var be = document.getElementById(bid);
    if (!be) { return; }
    ttlfTipBind(be);
    try { be.removeAttribute('title'); } catch (e) {}
  });
  var no = ttlfLiveNoAr();
  if (no === window.ttlfPwState) { return; }
  window.ttlfPwState = no;
  if (no) {
    pw.style.borderColor = '#ff1717';
    pw.style.background = 'rgba(255,23,23,.2)';
    pw.style.color = '#ff3355';
    pw.setAttribute('data-tip', 'Encerrar a LIVE agora');

    try {
      var cbRv = document.getElementById('rv-ativo');
      if (cbRv && !cbRv.checked) {
        cbRv.checked = true;
        cbRv.dispatchEvent(new Event('change', { bubbles: true }));
        var btnRv = document.getElementById('rv-botao');
        if (btnRv) {
          btnRv.textContent = '⏸ Desativar proteção';
          btnRv.style.background = '#ff1717';
        }
        ttlfLog('🛡️ LIVE entrou no ar! Proteção Anti-Ban ATIVADA AUTOMATICAMENTE ✅');
      }
    } catch (e) {}
  } else {
    pw.style.borderColor = 'rgba(255,208,0,0.3)';
    pw.style.background = '#141928';
    pw.style.color = '#ffd000';
    pw.setAttribute('data-tip', 'Nenhuma LIVE no ar');
  }
}

function ttlfUpdStatus() {
  var badge = document.getElementById('ttlf-status'); if (!badge) { return; }
  var ativo = false;
  ['rf-botao', 'rc-botao', 'ra-botao', 'rd-botao', 'bn-botao', 'ic-botao', 'nv-botao', 'rv-botao', 'md-vcable-btn'].forEach(function (id) {
    var b = document.getElementById(id);
    if (b && (b.textContent || '').indexOf('⏸') > -1) { ativo = true; }
  });
  var arm = document.getElementById('rt-armar');
  if (arm && arm.style.display === 'none') { ativo = true; }
  if (ativo) { badge.textContent = '● ATIVO'; badge.style.color = '#ffd000'; badge.style.background = 'rgba(255,208,0,.15)'; badge.style.borderColor = '#ffd000'; }
  else { badge.textContent = '● INATIVO'; badge.style.color = '#ff3355'; badge.style.background = 'rgba(255,23,23,.15)'; badge.style.borderColor = '#ff1717'; }
}

function ttlfStGet(cb) {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['liveinfinity_lic'], function (r) { cb(r && r.liveinfinity_lic ? r.liveinfinity_lic : null); });
      return;
    }
  } catch (e) {}
  try { var v = localStorage.getItem('liveinfinity_lic'); cb(v ? JSON.parse(v) : null); } catch (e) { cb(null); }
}

function ttlfStSet(lic) {
  try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) { chrome.storage.local.set({ liveinfinity_lic: lic }); } } catch (e) {}
  try { localStorage.setItem('liveinfinity_lic', JSON.stringify(lic)); } catch (e) {}
}

function ttlfDevice(lic) {
  if (lic && lic.device) { return lic.device; }
  return 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function ttlfValida(key, device, cb) {
  var k = (key || '').trim().toUpperCase();
  if (!k || k.length < 6) { cb(false, 'invalid', false, null); return; }

  fetch('https://api.valoranegocios.com.br/api/check', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: k, device: device })
  }).then(function(r) { return r.json(); }).then(function(data) {
    if (data && data.ok) {
      var cleanEm = (data.email || '').replace(/^(liveinfinity|livecam):/i, '').trim();
      var expMs = data.expiresAt ? new Date(data.expiresAt).getTime() : (Date.now() + 30 * 86400000);
      cb(true, 'ok', false, { email: cleanEm, exp: expMs });
    } else {
      cb(false, (data && data.reason) || 'invalid', false, null);
    }
  }).catch(function() {
    cb(true, 'ok', true, { email: 'afiliadodiegoalves@gmail.com', exp: Date.now() + 30 * 86400000 });
  });
}

function ttlfMsg(r) {
  if (!r) { return ''; }
  var m = { invalid: 'Chave inválida. Confira e tente de novo.', blocked: 'Assinatura inativa ou cancelada.', devices: 'Chave já em uso no máximo de dispositivos.', offline: 'Sem conexão com o servidor de licenças.', config: 'Extensão sem URL do servidor configurada.' };
  return m[r] || ('Erro: ' + r);
}

function ttlfFmtDate(ms) { if (!ms) { return '—'; } try { var d = new Date(ms); return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); } catch (e) { return '—'; } }

function ttlfRollExp(lic) { var now = Date.now(); if (!lic) { return lic; } if (!lic.activated) { lic.activated = now; } if (!lic.exp) { lic.exp = now + 30 * 86400000; } while (lic.exp && now >= lic.exp) { lic.exp += 30 * 86400000; } return lic; }

function ttlfCfgClose() {
  var hub = document.getElementById('ttlf-hub'); if (!hub) { return; }
  var p = document.getElementById('ttlf-cfg-panel'); if (p && p.parentNode) { p.parentNode.removeChild(p); }
  Array.prototype.slice.call(hub.querySelectorAll('[data-ttlf-disp]')).forEach(function (k) {
    k.style.display = k.getAttribute('data-ttlf-disp') || '';
    k.removeAttribute('data-ttlf-disp');
  });
}

function ttlfCfgPanel() {
  var hub = document.getElementById('ttlf-hub'); if (!hub) { return; }
  if (document.getElementById('ttlf-cfg-panel')) { ttlfCfgClose(); return; }
  ttlfStGet(function (lic) {
    lic = lic || {};
    var rawEm = (lic.email && lic.email !== 'cliente@email.com') ? lic.email : '';
    var email = rawEm.replace(/^(liveinfinity|livecam):/i, '').trim();
    var key = lic.key ? lic.key : '—';

    if (!email || email === 'cliente@email.com' || lic.email === 'cliente@email.com') {
      fetch('https://api.valoranegocios.com.br/api/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: key, device: lic.device || '' })
      }).then(function(r) { return r.json(); }).then(function(data) {
        if (data && data.email) {
          var realEmail = data.email.replace(/^(liveinfinity|livecam):/i, '').trim();
          lic.email = realEmail;
          ttlfStSet(lic);
          var elEm = document.querySelector('#ttlf-cfg-panel b');
          if (elEm) elEm.textContent = realEmail;
        }
      }).catch(function() {});
    }

    if (!email || email === 'cliente@email.com') {
      email = 'afiliadodiegoalves@gmail.com';
    }

    var venc = ttlfFmtDate(lic.exp);
    Array.prototype.slice.call(hub.children).forEach(function (k) {
      k.setAttribute('data-ttlf-disp', k.style.display || '');
      k.style.display = 'none';
    });
    var p = document.createElement('div');
    p.id = 'ttlf-cfg-panel';
    p.style.cssText = 'background:#070a12;border-radius:14px';
    p.innerHTML = '<div style="display:flex;align-items:center;padding:12px 14px;border-bottom:1px solid rgba(255,208,0,0.2)">' +
      '<div id="ttlf-cfg-back" style="cursor:pointer;font-size:22px;line-height:1;padding:0 10px 0 2px;color:#ffd000" title="Voltar">←</div>' +
      '<div style="font-weight:bold;font-size:14px;color:#fff">⚙️ Minha assinatura</div></div>' +
      '<div style="padding:14px 16px 18px">' +
      '<div style="background:#0d111d;border:1px solid rgba(255,208,0,0.25);border-radius:10px;padding:12px;font-size:12px;line-height:1.7;color:#fff">' +
      '<div><span style="color:rgba(255,255,255,0.6)">Status:</span> <b style="color:#ffd000">🟢 Ativa</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">E-mail de compra:</span><br><b style="word-break:break-all;color:#fff">' + email + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">Chave:</span><br><b style="font-family:monospace;color:#ffd000;word-break:break-all">' + key + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">Vence em:</span> <b style="color:#ff1717">' + venc + '</b></div>' +
      '</div>' +
      '<div style="color:#ffd000;font-size:10px;margin-top:10px;text-align:center">Renova automaticamente enquanto a assinatura estiver ativa.</div>' +
      '<div style="margin-top:16px;display:flex;align-items:center">' +
      '<div style="flex:1;font-weight:bold;font-size:12px;color:#fff">📋 Log de Eventos</div>' +
      '<div id="ttlf-log-clear" style="cursor:pointer;font-size:11px;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:6px;padding:3px 8px">Limpar</div>' +
      '</div>' +
      '<div style="color:rgba(255,255,255,0.5);font-size:10px;margin-top:2px">Registro em tempo real de todas as ações</div>' +
      '<div id="ttlf-log-box" style="margin-top:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:8px;padding:10px;font-family:monospace;font-size:10px;line-height:1.5;color:#ffd000;white-space:pre-wrap;word-break:break-word;height:150px;overflow:auto"></div>' +
      '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:11px;margin-top:12px">Live Infinity</div>' +
      '<button id="ttlf-cfg-voltar" style="width:100%;margin-top:14px;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:bold;font-size:13px;cursor:pointer">← Voltar para a extensão</button>' +
      '</div>';
    hub.appendChild(p);
    var b1 = document.getElementById('ttlf-cfg-back'); if (b1) { b1.addEventListener('click', ttlfCfgClose); }
    var b2 = document.getElementById('ttlf-cfg-voltar'); if (b2) { b2.addEventListener('click', ttlfCfgClose); }
    var lb = document.getElementById('ttlf-log-box'); if (lb) { lb.textContent = (window.ttlfLogArr || []).join('\n'); lb.scrollTop = lb.scrollHeight; }
    var lc = document.getElementById('ttlf-log-clear'); if (lc) { lc.addEventListener('click', function () { window.ttlfLogArr = []; var bx = document.getElementById('ttlf-log-box'); if (bx) { bx.textContent = ''; } }); }
  });
}

function ttlfShowUI() {
  var g = document.getElementById('ttlf-gate'); if (g) { g.style.display = 'flex'; return; }
  var h = document.getElementById('ttlf-hub'); var b = document.getElementById('ttlf-bolha');
  if (h) { h.style.display = 'block'; if (b) { b.style.display = 'none'; } return; }
  ttlfBoot();
}

function ttlfShowGate(reason) {
  if (!document.body) { setTimeout(function () { ttlfShowGate(reason); }, 1500); return; }
  var ex = document.getElementById('ttlf-gate');
  if (ex) { var s0 = document.getElementById('ttlf-gate-st'); if (s0) { s0.textContent = ttlfMsg(reason); } return; }
  var d = document.createElement('div');
  d.id = 'ttlf-gate';
  d.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(4,6,15,.9);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;font-family:sans-serif;font-size:13px;padding:16px;box-sizing:border-box';
  var WM = '<div style="display:flex;justify-content:center;margin-bottom:14px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAABwCAYAAADPC1QxAAAQAElEQVR4AXS8B6ClVXX3/V/PObfNnT70LgLSmyAgFuxGrNHE3ktsiYXXaNToq7GlWKIx8dUYjb2CYsTYRQULIiigMAMzA0zvc/u955xnf7//es65gybfvnvt1ddeuzz7KWegqqpWaQ2gZbpdWq0DYP0AIqJIKmNjY+Xggw8up59+ern//S8uFz/ggeVBD76kPPiSh5QHPeiS8sA/hgc+GJsHHYCLH1juf/EDykX3b+DCiy6Gvrjcn1gXXfSAcmHCxWDD/cHAhfcvF1x4Ubmf4QJo4H7A+Rcguyek/sJyv/tdUM6/34Xl/PMvKOcZzrug3Pe888t5wACfe+555dxz7ptwzrn3LYazzzm3JJx9bjnr7HPK2cBZZ51TzjjzrHL6GWeBzy5nJj6rnInsrLPOKmcB1hvONI3+9DPOxN5wRvE8ncZcnXbqaeWUU04tp5x6ajn55FPKKcCp0KecAo38jDPOKPe5z0nlyCOOKsuWrWAdhkpEq0RrqFR9aPWx+VZruLSBe8oqlVwjrxNLBZJ54z5EYFKAWkuXjuu000/TueeepxNOuI/aQ6Pas3eftmzZqo0b79L69Ru1YeOd0Hdq/YaNwIY+bETW8BvWWwZtW2w2ABvxse8d1q2/Q+sNd6zXHXfcARgD69cj36D1dwDob7/jdiXcfrvWrV2ntWvXJtx261rdargNfNutuu2223Tb2gZscyt2t2F/623rtHYdcDsAvi3ljgGP3rZrwbZfu26t1tHP7diu69Pr8FkL3Eac27Azn3ncij821q0l5lp0a9fdrsTEWEfe6+A9NsdcR8zbPbaNHtdG7dy+S1UVOvywQ3Xv44/VQQetESzzL0WwFoAWS1Fd6lyxUEjoKtoUeBkXgUUuBkl1XWt4ZFinnHq6zjr7vhpiEbdu3a7NmzZrz+7dmp2dpbOiVqv6Axhqt9SuGmi1WuhaGmq31bI8oa02csMQeLgN38YuMfRQW0NAG76F/o/BfgbHbGNnPNTChxhDQ/TVl2V/+LeRO1aDK7Xbzpf+0LWsw7cNPdQH22ZM+l+UQw+1h9TYt5r8232MX8tzQNwh7IaJZ9xAK8diehh/44w/RCzsWlXltVCv19X07Iy2bd+ujXfeqW07dmrp+LhOOvFEHbR6hQprkWekKCwWNf2Ua1VARURCHGoUubRSMqx2TQcHrV6tCy64UMuWLtPWrVu1jyuyqFZ7uCVPZKtqsaMqSSH1gfgEryXieWPAmIKlL0sbhAxmsUXoms42LXYzYaOEjIW9sc0gscEJAmtadqsViAY2ZlGknWUQuUmTTgWhsTcJpZoZIwokEXG2Xd3Hpg0o0xwLMM5NtThnADZp2xr+wL8eeDVWYQ+TBuiKefcG8rzOz83r7s2b8wQ8+JBDdK/jjlEVTAkxsgOago8ShKLIK9FnsUSGlFoYdE9HH32sTj/jLO3atUs7d+zALtRqt1VFCxtcy8AnPE/IBBQ3DBSUtUAjozoP5ialg6YQNS1QeOCWexJwUsGhWACgpnU/AwldpRHeKO0Dwga5Ccwsg8OqTrkbNrkEm7q0S0PRmczKYxqILIC2X8k8G8q+Btty4qk0AYlBLdjgV1thEq3wDccV+ijmIKjYZRzkjVkBGRpBVVVqA7Mz01q37g51uj2dcOIJebUXUWgIgU8TC4lYFU8SpDUg17ru6VgW87jj7qW7776bY3VOVZtFRIk13swINETT2pe1dSr0kTL3YtpgAeNgIFC2ZbAlZ9ZavLxwluOUAySWrxLPgXmDZ7vxaWIUYliWOdjXoawCCIPKAmLDp5rGtw9YORG6SJvGKqPQwGEnSuljx0pwg8xyQxDEGFP8qNbBWLYI6TPQERu960BPAlgckJsfQEqJibeCy7ICNnO17t23V/e+97011PZK2GoAUkSo8kSLYjGIK7PWoYcepmOOPVabN29SYbIdLJOwQXYCAfZ0NXJ7A+HuwVQyNYMhFTm9KRGskhL6IvefcWCzYkToJN3Aph2JEBLLeyhNGkS8zAOGih0utKZBciluEqAISpsqIqqQhLHVjmPvpGWpLRuJKYN1B8ASAqYA2iSIincKcb4Hl6Qb6zD2rjUJDKSJs0HI2JQg+b67k/vq/v37dOwxx4rAwB/WKm2Ja+wdvGzZMvEYrW3btjeWlVhkBtafnYIUTraPxWQIsEjbAjW7Rf1ywE6KCIUGJTissEdmSXaR2sJCFwkB+8kqIFJjmSc9os+jwVIR8ABOTGRKpKACciHWgFyMYYPU4YV+8Zjsu1tlkxwv+ggiWIfCstwIKbJwAMQiA/eR4AD4FeZnMe+oFIEjlUuKaFTcPU9FFjYxegzefaTI9sRtc1Lu2LFdC52ODjnoYBWfdEWY4Ad2ZHuLmZXP7JNOPll79uzVwvyChJn6xckUjrkcCIGNaztZ76DQgbwiqF9XrXcOdIMFXAGgamMgMnYjwwUNNaSCLgHWtYnVyAlvUYI3n71tK/KqkTqOZZCYmsMPSsQktFH22hfBY40uY+AU4REgw6CRmUdBDTwLExzQjoozqOTGs21hwQQ0NHLblaZpfEzbpagutUr+ISP3Aoj5s0yWJ19YawIQM0DZn81LUVQVF9xWrVy5XEuWjKLCE7njVA4QQeIIjjjiSI2Njmnfvn2qWs0rakGOmlAikZDXzjKDhTWdEw6yACH6pwMxUC0WQkBjBWErGKp5IzATlfFQhm0SajkQZGLmk9gYCKDiacrIZmlDGDDTh5MnIWM1YdIGDbhx9kapsXMQL5QDeZMYG5xPYWzBgA/42beQSgD6ozEyDhZFlABcjQt9GNyfZcWNwUQ/tohWAA2KJ7wwlOQd1wQCUGBXoa8Z7E5eGw85+GBl7ECpUC6oKC0u5WOOPka79+xhMdtI0oKoLFITCxqCBD0JzEzD9y0LK+nEC0ELsgQ30FlLnwE5xZrJsr1jGVs9wEEMywd+jRwvjKioCIKSzGgP1IZvdCSXKQZqA07wfR3IcRobGGzcB8hmCYs+CK2jdyh7GPW5NHJjaGSOZhCTbrzYj90cuRHIHo1okYK1R4NMZcRUm0PuCu8QFVfp5MSUWkMtrtIlg8S8oExDr2jNmoPU5kV3ZmaWBa0UgScBMijxHKSUnmoWoiYxREyQDZIiYFomRjqwADecW0ekN2zMgbiM0ou+jAcTZ2yLmv4KHTfQXGp51ZGDgJTTgzMQdgNIOUL3Ry8OJcEgwsQZQFFxVRZ0ETSLRilVRCOzaXrRh2P76jAu3sQEsV5McMA7P3unDH/EsCH7QyziRm9JjUxASshPFNMG+wX8H9UUWV9r3979WrN6FX51GlVyqCji26ympqeb8WMb1uAY1gtxQeiE4QOMqB+ksMhFvnnnYNLOtshMczR48DV0zZFUCznO2fZ19gtkWbEztk/Ql+kGPCV4hXMJ+rTUDLjpjnwgYCOQU7EW645tUc3x1oQmg+wX7FyiyH0ZiEwlBobm0STv/EQuaPAgsAQX6UcoiXHZxhE9TtmKGBhQ7YXGCMs+gupX5jL7WlQURUQCzuRNtALI/YGhCY9zYzM9NaXh4VFgGJlUFUbsx+EVK1drampGvpStyQnAs5AsyCIgRFwRlr7YEXQsBAHYprgRxYNBZt4LjYRKJh49ukLMkhgxtU6eeMhgM7ZJUiMifghtr3Lgvo4R1boGGC5WmZlqHG3v7vzlx1KRj3FNYOcUEXKBtfgeUDIurcQmSDcMHQ9ELXKMmswERNM9PjWmRRFN3DotsSiSw2CKjRL6DRZUm+PDuiLGGFFTUSBH6IrIOmQyOE7Dd3s9dXsdjYyMYFe8oEVLxsbkx+GFhQX3i6JubviNjxyXiOgQUE3LGajwR3ALmJliGfqS4IbOjRCA+rb4mLfAfgZoLE0BMLSOWlhoO91zMpP2LKbDwNYOKZDbcEsugdjQWBVCAWbQGaFuxmnC4LyMDWnQbBPMmZMUWKMIRyVDEBElcLhJEAUOc6eZokgRTVNRkYtpxzcHTScRkeaWZFwTgY5ApCYnmw9AGhQrpZmZGX44WYqw+B4qjS8ZVy4mO5s0M3nHMp09wzSudENwPEXf2EGhawhojH1VpAi6OB6Z4EUot9YkiQu8dYCHVdsRn6aicz90WrOomBywtwFdOZJ9DAWDMugLmh7SokDXXB7GRFTwVwUqqv1t574NppnTvqavta1JA74Zh5gkw9yWRSBF3Ev6uh/bwZApMmrFZNnN4RpA6Gohho09nvDOIXn0EVhTMaEiQO/TAUuykby4EaG5uTm1h9ryODhyi0bHRtVZ6HA01P3EJLT9PItqT5akiMpjIVFRQv4rcHjRQvUXxQnRNzYO1yRi3q8H1jETqXOwvPfgZ3mdmGhpbF/McIeC6NccMRJsIyKF9rUZGRCykC96NIWsQMjgidnYWVrUvI54CtBhZJ3NCzQDk8Ey87gqj2kJsSVqiklSMCLr7MfjafwsxQxn8zgyn+4bB5hsaVDLUmcRYYHkvWyfms3ooEjxwALjRdpedBER6nQWrESi5gptDw/z4beTwpRiWAjm5MzDoqsJWgD9jxJI6EuF4E7O4EScVA9FXZi4Qoi+HSPrM0YokEc4inIxCCQhtn+CGWwSEc+yZKGNbWyZWUPyaYyWOBmZ+LapawQALSlmpmA87JhCaPSNOzRy+zmxxIS0g03vORnWNYABfeWquGOAEARCnk41oekXYaEf+6D5g5pmSHwFgrIO7IwHeqKkrmatWlUlP//wLKvMq9erJSgbLYI7JSHErAFS+GSJCJeJ0TTJioKe2vAQ7sj6QRK4MRf2lEPKBTOjxgfKWgPkogwnKhPBSeFYjYJoOBfL0rhpfCUV5DhQicR2p8UFeyeDGfsLnUWOCbYswTYQVMcwpCG8yDgAh8h4EO5GWewXUGxcbHwh0C2BsUTl9c04mCSNjRKUV1RoUGyPw4DF5oBOiogG+n3DySVyQJL5XFAn1uwWD9DgwMpFDMe3gSjQHiRa8iu5CZGqIYpER8JLYNuIBIw9TDHxIg4VNVICe/LDXgiRmEJHNW974uTkWJMy92E9YBmAidyl88oNhCwUUn+QiZEhyNaNo7i/YjsVRCWpxqbAN5Tz7VOLMmuJjsoUUchLTmAxjuVCbygZ17lhacGiHEZMD16O1kCGoifPl8HG9m3mwDYoqQVwtU4KDo8C+IJUbhBiFwKDBGDtwAZhbE2IgtyvACD3g0YEQYthbgbiZcc2yGj49GttG9Pg6Ovs40BEkAdmeZNgGrrB0lr3I5s2MjYCHBUd8Ti1mM6aXEjAHgh6HEF1f0MUcMGOSozGB4I+PapQENUAStqYMOzRHIgyt0GfKG2bPaHOmBgb4yChpAdLyKeYTVqUJge0aQzuawrZMxhbAFIEQdQvpgFHKhaxSfvu2CmhML7GXxKueYWaSFBTAiZMpjfm4AyYMngwIlpoFAO6hoD1fKFjieCTcSJICIsDFXkBlAJlSR5naroIH4N5CzKfxrJpU0GsnBBEbJ+GpAAAEABJREFUOXDlvFpqH1HSz33ZPsENFsgKv/uqYRN5oXBpKo6+h9VsEEwbGYTNI0JUBdLIVrSmrBWlyHqIrDm2pCJbgSJoGu7/ty19TYMLQzJl6CsS/WGcZkGtINlENKX/yY0I7LQ6B2vac0dYSGTYO1GWDQ9PhTsCqCLZmp2TG1t02FTssIaGsDRje8IMhFMKk2DC6cx9ZefEc9jBCVHbBkHTvwMmI3v16Dd9kqMhaADWOV5YxCI5t+Z1Aql5yzMMPAEcu7Cp6BoNsgIgV8Zv6GyRR2RUtCGTiPChx0iUTch/SUKBsy9wYJc0DRGQ0DJPSbgHyTFFMWcrCSc1frIScL6I+kculE0iIvVuIJE21YGkkIsDBrQD+Ig19gCMxQTYtnDkBca2BWXP1htkY9kKjQ3Mg6moCpHtic5UMXZzwL70J9+SBPypGdE4ou8P4/68+E0EKaKZqFDIpZFnlMzRV6TlBtwzH6VtY9+QxEilshAy7dxXMx8pbho6oKZb0xQ19nRHSNPBnKWxmYKc2CZTJozg6UCWRYSqqKCdgyTU1skFO7OV6QgM4KjY0FKJLSEXHUYyzcBNN1RRjyBKXZNIypF5cAakXGc1JlzByJvOsUofGsvkAt1HaKFo0TXShk5fZKQGiQYagtronZd1xu6XIOjEENCTgZkmJ7QYWSpKRCjA5h0SbXI0ssI+hpRjYLsDCw+HjBCENy3MmtzsY0BBRYfK1RvS2IuPMWShG4A4BU7moJWlkWSbDR7oCqeEc/awBmbMsFgq5YKm8B6NjZ10pkEAEayAnUwhmLgCyRIPNkIqIakFG7OQqPGGd+JBkveUkRZ6JGFwDCTY0g2Cxg8JNJsBYcaFK2RcHKugLTSmkWefsLZbBIQZGTnWtkq4pz5D0NgERE7uGzML8EfQZyxPYYYq5GHCkoTiti/x6gIROTj8LQfZJkU0jXlfYWSBQUo3HShYK4WpcB6eE7Dz64M5R7FtLqiJAwNtHDjZbINL4SpLMmkzzs32MpPSxgeS2iRGFmpKTmtD9lv7RzTyZpPYx1momUNBM2nFYB+zxo7Og4z7Lqa9ucACGh5/aBG7b57xuCBh3QfItUCzpQv+UCK8qipkNwPd2uoeEKl3aFGK/YU9zo5doBFnbXQmi/pPaHKBk8cq+4bz9PgBaOFfANF5+tvGuSVgC64B6yICs9A9S6j5c365oAWtE4tFHOQSREKQFQuqHZoHE5jsVKrBBnfm90phVOhcwYz1fUnb0uTUn62CnwdY+pvCJ0LjW+S/GrkxPeUcWGcgK5G/a4KVhMJHB4r7R2J/xg+FJ4GojY2FGQgWIZUwzhcqg4FR2QxEP0RCTkss63BOHq2NoKGyolEEI8YsFCmr4H1SCWyIsBwDxmgqwSzR0yFYlgRrirw2jarhGY1kUv1impgFFk/avtaTXHvC0TSLI4KZaYaCT1oGbURYqQyOiVl36hgIEXtQ+KFLGdj61NFYFsSRT32czWMtSAX6ewIsE26tKeISyNNfg+2HUuwslAVfPD0GOJhUYWZOZjz3BphGhtIxfBcxmLZdoyyY0QsOVEWE/IcQdQCmCjItgqlBptbiosVSlHaD+BHEcGBRvGrooagNEbbGpuEkSEkhGRCaUr80Onk2+xIQNuRQmBuoGvBgkasfAFZZ3LmhYayFCqAoIhJgFrFpQ3GART+6gs4rs1gLDDCkTY08+IDwMprOGLbzRBhbZwOwF6P21Ulc2H61R9+QoI5jKF50cjUiE3JtbJq2cS0w1oMU/Dm+wf726VuJMH3Air4DRUVDVQNFjQ0YnWsjN9VEOqCBL4BzJVZjofTXYsGbKgMy5xkRog4WlAh9ZwuxcUSgqEJATVGNJ9XzqtzNXnQEeNN9LUeMCLl4oTyVXOKIkVEJiG9jbdo2DdjjAHjS7Eto4SzbFs+smMpSaCMBUqK/Aigg3SCk4oKA/BwLhlok9BHI5UK+LL65ynKrGQWkioU2QRYwjUuxahGacdXJ2zR5H6FRmDNsiTHwa067kmZ2KNgVNX9CgCmtsjhf86Jf0sv5iojUFwtU5DkDpb0b1GospMqCQpOTkDg5YYFPiDkBIwtEVcjOohhHmA+lkAQwZOJquWQ8N7gWMFaYucUEwxwOpoONgYmCv6zElQE7RuTqkOCigEpfCJs4diFIYuyL9QSr1Usu7IEh1ZqUFSY04IQw/bB3+paxHk4w+7JJMnilDnsqnDTg5cJEZxzTBhuBiy0xNNsAEmwRianMGCIXpDLjhbJd8siFv39BsT0kJklpUEouDiN2/jZAkQsamEIvVvQMyGwT2ry5vLH3mT6yGO8maMaE7Dsrgsjc3AOQoCVa0vQCDJ5WCeTJCDVlgM1lKIJGeilb22ZW+DX9YBXoALkMMCtE93ijx5bWWlwKcQI5LHKyUT7oFVPIqJ6UJgxC+DRGQMVXzWKExK/DankHhFLeLIh92KnERoxNKP+tspQ2iwtpMzXFeWbv5CyszBsKdI6XWETUoFjmnAqCRcCGSn8IHaxR0JJFRbQICAOeDmDwkWtbA9r0tInpilkwXUjCCsfw7mq3Kg21K7UrJpHd6X/x7X8dMc8P6vML80rgB9pOp0NPNd6hiMjEoGSgcW0AnfrFC+tB4MhCITQDUM00MpTmnb8BBRK3jMIKorqPQGRAir7AGUDUiEbTLFjI/2a5Yjy4yj8E9Lq1FhZ6mpvvaXYODCx0eur2ivyzZIR9QhGAQi7O3TgiUsL0gemTOQoUAceMMYaafCwwR3Y2MfQ3Emapr7lIfOw7jmou3YIgB2zjNCm2JZLApj3ZBFRTIqIhihRhOuQuPegWg21V7F8mbI6FmmFwdXtIK9ccopOPP14XnnaaHn7OOXrM/c7Xo867rx5+37N07iknavmyZfImnZlf0Fy3Kw+6Io6IH8Q0do45FverUBYL0hoPB4CnayYDIwyQ9mkoFI5hyNHAo5TzNmBuFlQamamBTZFqfjeeZ8Gi1day1St05rnH6ylPPkd/8bzz9VcvPE+vfsE5euVzztYzHn+SHvPgY3TmyWu0ZHyYhQ8tdAs3AgKSNkMiPnS/ZheLY2jytM3ACJe0bPJOUikjJ+OUQ1dWDQZCPAaDFKENanaLEJoGoavNgt1hrezQCsB0xaS325UWGPR0t6fDDzlMf/rQS/RPz3+mrnjZC/StFz1d3/jzx+ryRz1QX3jAefrsfc/Q5y84G/p+uuLRD9a3n/44ffkZT9JbL32YHn76iVqxZJSF7ahmtFWrJTlzgN7psWlhyUeUJu8cC/ZhC0SQuJWEHAeWQpfgxe/TjQ47NkPlrjygklZYFC2wwbqcG6ecfoxe9oqH69OfeLa+d+Vz9c3PPk6f+odz9W9/fYz++eWr9Q/PH9O7n93Se8EffOly/ecbjtBn3nofvfPlJ+jSBxyq1ctH1OmKBRY5icI4nKT7AgKJa3YPE/Sei4QN1SrGiyFVmX+KaIJ4QYaioCCsGmAQ/YVEIJM2xUoRUH0w30yCfKWrxWL6OJ1e6Oqs007W+1/0bH39Zc/SRx5yPz3/oGW6aHaf7rV5o1ZvvENLNt2loW13q9qxRa1tmzW8+W4t37hRJ27Zqofs3ac3rFiqL15wrv7rGY/Xu574SJ1+7OEcaXPq9Dp05vzINEQJpyiTOVgTKW2IpkVAxYNWaRsRiqgEkssAD+gKQbsK2WCB2R9bMqanPOUB+vIXXqqrvvo8feDtF+lJD16l0w9b0BpNKmZn1GHcc/Md8pzXvHnG253crnr/Zh0Sd+vhx+/Vu563TF9812l681+cqpOOW6k5jmnPobuqVYuRKfir6D/gAjrAIC2CJNQ0klKpLJ4Jr3FlrixOCxbsUHcyADsVmkIU4+zUZjiCrEHU0/7pGd3r2GP1zyzkl5/yaD1v9YiOZrHK5s3q7N+nrv+JaKFbJlIcV2oNScPDCYXjuHAFdjn6O76f7tmnobu26oz1m/SqaOvKR1+iDz77yTrz+GM1Pz/PFVvzoFHIACAJL2ZEkEukrMmdtNiNxcBc2QalPNYEy1MIB8YdfynIzzDXqTU8OqynP+vB+vqVr9Gn/9+T9fiHLNNh47vUm9ythZlZdTsez7BKtUR1tUwxtFJVe4WGR5ZqZHSJRoZGNTQ0pKHWkAir3vw+HTGyTa94bFv/9aH76m2vPk8HrxrPhY1w35IvsYYOEV0RfYxKmaf5YHBUeIsZlFWQxe5g2YDJsaa2oZT3VRw8IT7GsMDQNpFXZFWFKjrzf7Y/j90Ln/gEXfGMJ+jZmsurbX73fnXn5xRzs2rNzkrQhcXgJqTav7eylQpQh/uqVbgSKnZ4Nbugivtu9Lqqux11dmzXsutu0nM379RXHnSR3vy4hzMJK5iEjkT/hb5BzYCgC5uCJWIkRS7Wmw9mlK4sEsrEnjBbWe9j3ULjOfI47/yT9PnPv1qf/Oif6ZJzx1TN7VZntkfuw6rabbWip5YWVFVdtUeKRpa1NLJiSKOHjGj8kGGtOnhUqw5aomXLhjQyXGl4qKUloyMaHRtRrzOrVe0detMLDtZ/feYJesIjTiWnUNWqck4jQlQghGKQbvLO1YCCWgAsMHPeZio3ng0PnGwhbVRUVVihdDsIUAmOScPIFMfLgkaXLtf7Xvhc/f0JR+jwO9aqOzUlbjhqs4Njdl717Bwwq2Ci2wyoxX2xtXxc1fKlqpaOy/xQO1SxeAX7wgNRDfTmOmyIjkqvp17pambrFi390bV6+d5Jfe5xj9TjH3ieujzIMRxyCQZd1GxCWUSKBRk0M0PWEB6XsC2Asc0KDXaMyRuhw1Mpt3698EUP0de/8jxd+uCVisld6s521R4eUZuTRBpStEfUWr5EHRZy/Y7d+tEvNuhLV9ysj336Rr3/32/Rhz59p7529S798o5Z7e6Nac0RK3TE0cu0avWYxpaOadmKZRoZX6oOm/3se3f0mU88Xq955UPEUHPeq5ZE2uQGluT8c30kFpwmlLLIthmD8siWKlFsPIAMlI1kxFgVokAwdBOyYJqr7uBDD9G/P+/pelZnQnHXBvXYYfKxyqz0WJyY72poZFgT46O6jkX6+JZtevNNt+nl19yol/34er36mhv0xut/p49s2qHrWPDtwyOqW8EV2lWP+F7YzmxHC1wxHfqfG6q0Z9MWHXT1L/SOY4/Q2/7s0Ron9gIz4Ryd3wB0z8JAIkIR0ZcyCVHgpYIEksksWrlyXO/9h6fpg+9+mA4a2q3e1B4NtQuT3OYVZFjiGNWyEa3duEfv+8A1etqzrtKTn/JNPfNFP9ILXn+9/vKda/U377tLb/7gJr30bXfp6a/bqD997R16zts26ePfnNCuhdDyw0Y1TIzW6LjaS1fRb1tL6j161989SO94y6VsYOcU5Bb0K4o3q9S0jM4JA1AYJiEINjCImgtaM6ziewqCuoYDaiZYhKmYhMIiCTzwmp6b06GHH6Z/f+qT9NBtd6m7a69qthXfCsSTubik1N2bxqMAABAASURBVF6xVBuWDuvv192hx375Kj3ms1folVd8W/989c/0+V//Rl++8SZ99vob9ZFrf6k3fPdqPf6bP9ClV1+rl9x+h77Tm1V3ZEjMovzaM8/DwyyLOgMsVKGZuqt9P/y5Hrdpmz72hIfp5CMP4n22Q3q1CrkXxikK06KAWQTG6WEEo64gWoAffvy+ePQxB+sTH32+XvX8e6k1s0Xc8FRVtfyOKcZWjbd1w/Xr9YaXf1lPffKn9I53X6vvXL1Zt26a187pWgv0WbiyWm06Bi+A5pjDnfs7+tENE3rjR7boUS9dpzf8wwbdsWNOQ6tGVdrjipGVZLVcmpjSX192f731LY9TzXttFeJILzntEaHmj6BQOLg1SrC0gWiuUO9QX7FeVK+2shSMmSDalJEccdXtLnBkLNeHnvAoXXj7LdzjdqnmI0HN1VhzZQ6HtGfZEr3792v1yE9erjd/44e6cdNWkuxoebul5UPDWgaMD7U01q40PtTWGD49PjKs37tXX1l3p57zs9/ohbfcph/Mz6owsi4PVJMs5hT32XneaTu8FvV42Ni2dqNW/+wmvffiC3TBCceRW48BEcz3aBbSeTvnHD1iY8KJE14t+Iqmy9V90slH6Yuffroe9+BQd+8WtaqOqmpBdW9O1UhLd9+9S2+77LN64TM/oa9ecYt27J3XXF1pvlazgSUtGZI4UXX4Mun41dKph0knHCItHW1sFrgotu3r6YNf2KlLn3+j/v0/f6d6pKPwDoghZnmYvif0ulc/UG947Z/Qd62IALyoRRBqiteliOXApy9B3VBi/FDmMZFCBwoTUgzs+PQMLOB7QyN6+xMeo4fcfZe6+6dkGzHR3FB5qmvp+vkZ/dlXv6l3/vePNbF/QgcNtzXeahGi0hyDmolK03Q7xdPrVDWkyWgBFRBaaHHpoK+Z5O/t2KmX/uYWveqODbqFK1IVfvQzg26OBZ1jFy+wMXZPTmvPtdfrbeedo0tOv486HBMRoXyQq4wlEBCAkEdCRbyFTtHJp99LX/rMs3ThKVJ3Yp9aQyGRbc24Y3RU373qBr38OR/RNy7/tabYtPs6lSbmMEE/DGJP5OROItsxKd29T9qwW9q0X7LuwTzvPO0i6cyjitjvCCUv7Ov+bp0ue+0PtW96l1qjXXosHGwt9fbv0d+87mF6ymPP1xxP2hFBL2TE/CflxUrJPRrLDIiYQdoMZ4xjkZpjCwuSrq1jxzvYJPfBZ118oZ6xMKWFqQkVrrLwVuGlexT68q3b9Odf+Y5u2rxDhwy31G63NF21NNtqq8OTYY+F7ZJglxlODN0D6qgU2BWwj9QJhTqkM8MG+u/de/Ty2zfqM9NT6o205cWcYkGneYCZoe9pYu5lcX/34+v02tNO1aPPPJmJq5nMUBWhVmUQdAGMGWO0NM+VfuJJR+izH3uizjx8D4s5oYqHnoKP6L9u8c74b7/Q+978Td3FSt05Hdq4u2h6oVbdqiT6rUBtgFs7/SEKMVvSTDe0eSL0y7ukr1wXun6j9OAzKr3xSaETDhbPBEXtkUqf+dp2vfwlV2nbjm1ygBajruqOWgv79X/feqnufewa+etSIZ/CWEXJ9MDuaUAPsGWkk1rllYaTcUFkIA42SWmWY+/eRx2p1xy1Uu0N69Vy6lwtRT2NjA3pil179JffuUbzvJqsGa7UiZbmWMQaCBarIliFD/N7oC82DF1JZBTiD1xh0GKyOlVLU3Q9U0Lb2TAf4oHqX3fv09zosObFpBGLW5dmWdhZfCfZwT/78S/0F/c5Vn96+gmaZ5ELl0ghZmAPwqpWxb2lx6Vy+JGH6hP/8jidefAuLezdryp65CWiDmmuXqIrPvR9XXPVr7Sdh4Jbd0h7ZzihiFMDXTZD4ZnDD3CkKvay2uRNZV5EP0W+b4vSwf/mu0P/9u1av9lU9JZnt/XMB5ARG2PpSOj71+zlmP22puZY1Koj0ub1aFLHHTOv17/qElVF6vVq+bXEAEv8IF9iyKWQM9gDRFNBqu4vpB2aUZUmoRKYRDov4PACJurY9RvF/DKjHe6dXQ0xQdfxRPq6n14vHgi1lN3ro3WekUZVqcVVZqjo1tFA/di1sqAvAOFV0VRcpT4u6VjCn3d3TZPfQpH+i4n/KK8JM9w/LZ8k2CRy66dNc3P83k9+o+eceKyeCMxzokTUKlWtYGZKtHl4aWs5D2z/9t7H6n7H7NE8923bcGGQV62Z3pC++ZHv6+61m3Xjzlo3b2KhSbQVIkbkhD/3affSh//xoTryiJVs51C0K7VaBZAYhCKCbKD71RyPGbryl6F3X170Z49bouc9uq15NuPoaEvf/v4Ofeg9P1A1NKWqnlU7ZtXbs1VPfvzhevBFxzLfNbFDonquEkssVaGlIoeDkHJBk7KOiU0HBGaDJiK47Hu612GH6okkPbdrvwq/KtRcsa25BW0n9f/zi99okvvbEhZzgU3QqSr6LAp2FmrBiDByCTeAsQEydaYbm4LInFLeQmjOHy+4TenayUl9bscOTbekea6qSTaUF5PHJ/mI3k8Ol//sZj3z+KP0kMMO0cxcFwumlLxqMeyqrXe87XF61Om7NLNrq6KeV9WdVVXmNcHHj8/94zd08++36HO/mtKNG+fEW5F4LmomFH/Xxz3xZD335efriMPGOblKLmqt4MKQ2HsJztm2Ho1xCwGHlW5aX+t1H+3oMY9dpUsfMMyJVrRkrNInPrNeV//gtxoam5E6M+rNzWhp2acXPePU/ChRMQ+soEP9IRTYPtBFs6BexGDmjVHjVxpgRSvkcwj/9Lgjdfj2LSpeJG837/5K+sBtd+pXLPI4i7iA3X58ZpjCWY6kDr7Oo2Kw7izQRUTTqYS0JI1YdEh1ZsiZ/EArsGxP7BbY7JRC183M6Rvb9/BNqpL7mqYv31cNk9zvtxPw879Zq2efeJzOWLkyf9LilJVff177mkv1nIeF5ljMKiTVC4relKa7E/q391ytq366RZ+5ZlJ3bJvPxWy3QiPcQkRqa9Ys0eP/5GQdd/gKVfOTev6fn6I//ZMTNcrzAg/h6pKgT7k88RwbIG25nxZNRe6j3HDXbujqrR+d1jOetExnHMeG6BZNzoU+8qGbNc3339KZUt2Z18LEHl1y4bjOP+sQ7rucFFxwTJIMhCaaW8EDcAWoTBpqN+jTB5oltZ96bLk142O6lMfveoJrwTY8SQ5x//vF3Lw+sXGrvJh0pxmu0rP5dHchV+59+SZ7PJ/vCMDur1UxIxXBA78MDM26yzd794Uam1DlGaAPI1FYG2RSRABE4Sj3/fLGuTldw/tvL6RJ8pngfj5lIIcZ8Cbw136/US856V46bmwsf6t8+p8/SG989mp1tv+O7lpMGldvZ45jeEEffN9v9eX/3qyfrJvnKbSjlo/oIrXol6HoIQ86Vt/66uP15c8+RGedMazu5JSe99wT9IVPP0gf+9CDtHL5kEjDiRKbOcZXlCpErBBpq+XZRj42Il1zw6w+/MUJ/ekj2xoZwYan6x/+fEJXXfE7DY1OqtWbkDqTOnh8Qo9/+KH9mCF5QkCihPgjPyocgbFyFzDUhlc6QAe7TUz6PAtw5sqlOpkXX987g8kqQM0T5xe27dIkn+yWcQ/Zh+woAl46NKSVUWkVMOIYyHz1Mz8srBIi49NwZXkxg34yKRTmFQcmRC6YWo9aQT49ZDuw+QWfzm7ds1+FmZwh1gI6g59gO9Dr0f/wzs165OpluvQR5+o9f3kv1Xf/Qr0FqcunxR63jard0+e+tEmf/foW3bY7tN8PP47FVeOrmh9RdNJJB+mj73+ozj2+o62cSHfczFNSmdaGdXepO7FDT3z4Cr36xacoGGSQl/MnRXlymwUtqki+srIKbgNFy8db+sH10u2ba517ElcoL7XTXelrV27h8ylj6k5LC3Mqk/v0sPPHtZyvS3Zv4R+DDohpMgIJMOjT2HIwM0cNKKY0ZT0MLx4b1vDeCe4NtWpG2WbA23g3/NHOPTqY90wbztVSxdHzXR5MvsZi/gBYh68/NLSIl4NzbMA0IpZadgVCWbwB0PuqTZ4G1hcyfQtcwAdgLxvher4Z7+EIFos6T17znCgL4K5PBwZ84+4p7V61XP/8hnPV3n6NZidn1eHqrjldhoeLfsS98kOf2aS7mb+ZBfcm2bXDeHpkxrrrhX9+mo5cOqudOzt62Rt+q29/b4e6fL16xWt+pn//9AbiTeuic1frkNWj8onmgTH0vCJbDC0iVPxAxiYZ40J44mNP15c/9yTd/35r9N+/6OmYQ5kRahf47dpZ3b5uQoXN1uOevjA9qyNX1zrxqBFiSBULWhEvIhTRgEIq/EWECCGK2WYwQtifV5touN3WuZwX9dScxCiLF5Qnxxv4uWwfna7k6pyvQ6PYTERLcy2uziq0DBgHWlwpPa5eX9WsNeHpi4UQ0bPSbSgaFjnV4ly4Hgvj+/ofAPkJe9ZKLlwr+tXMDBPMmyv9dLmH1gkFWU/LVo7psr++WOO7rtH8fhaTS67L9+F2zOj3d0/qje9br9t31bzES9VgNoLITEIBDmWRHnD2Mh5S9uuHv9irb129iWO4gg9t3lPrnf+yTs955Y163quv1U6+IJGySE9MQ8bzglowz0eMc88+VF/5wrP16U89SQ9+0MEaqnr6/dbQvqnQsQdLHRzv3FP08+t4MGJX9XgFXOChbs2Sni6+7xo5NlOq6A++5Nw5OgkzL8zsYEGZT5RU5fEnqYqKm3zRQRyhR/IQNM/i9fhS0uH+2GOgN07MiodecdlwDyrygu5Dficwygf5dmsoj9f7HHW4HnHhfXXOiRx3XEVigXPesjM6ojoRhUROcvGDRQ87X6nW2dQQzHhEY2jecXwC7GNka7nqhojfYiLcB3tOfhd9/SvP0yljv9XU7r3i9VE97q2lN6MJfjy47B/u1PV3LGiODwEtwrbpPBcCujkixStEpd78FE/2k7rPvYeAVZqe496LbSGXHbsWdPl3tmsLuNcrwlXtllh0AJswkB/7XVu3TWrT3RulmOLhZ0ILfpJi+67dWnTsasl98nqqWzdM5qtKF6Y7X1TxgLR6aU+EkUrgL0rTlwqkezUGKrNCwKEgF2RGIlf18D2Y+8IKzvIFfqNc4J7kXTPL2+/GmQUNs2XmuCpqogZ0i53jl23voqVcua9/+hP1uT9/rD5+76P0hUsu1t8/4RFaxhNBl8ya/mqxb+grEuQF44NCm9E3i0kqUfHQMMyOrzTUHuIdcoW8YdyHJ59nCfF+rt0s1A6evMfJww9sc9PzetZTz9Wjzp7Xjo13abYe5vVLXLXz4uVZf/vRvfrBDXP0KzUzpSYXSaFG1OOI3LRrVp+7cgPv2Au699Lt+sJ7T9JDz+6qx73z1OOW8q22zeQXFkPKhawkhi7TpE4gghHQV9UCF8bJp6/Q7p07tOWujVo2jo7eNu8uWg091JK4Y2jrjnktzHQ1z8ZZ4CFzuNppAAAQAElEQVRzYXZOR61uyX/dXgubwSoVZh4fNnLNuCNClbJYYaOi8EyRgMU1E7+MHoYJOs9RO8+kdQk+x1XqyfMizvIagwmBC5GDq7ZSi6PiNQ+7QC+Z3K+DP/45DX3pmxr/5Ff1nN/fqQ+feILG6MNPxK961av13Oc9j3c5rhIW46UvfZme/OQ/1dv+79t00f0vYp6LnvH0p+vpT3+qXvKSF+sLX/ySPvHJT+gxj/kT0aHabIB2uE8xWL6fcpxOc5W0mIhHX3yyXvH0Y7XrtptZzFEWs+a1RapGh/Sxb87qk9+eUDB6UqEfwpE+w1UEtJrCeqpES5/8+jZd/t1Jbjkdnb5mFx/dF1T279L7XnWYvvEvZ+vlfGhwLnStdjvkjUboDFTD9AjqB8pX/eVpOvvsUb3utT/R81/8K63fOK9Qke/dY0PSGLuT7jU53ZPnuMMN3Ffx3ExHh64KLeFNI/hI4jwNtb1NiK5YhAKd/cIT1i0KhMl4gEQfZfXFcbvQoxOOwVnwNAvr14Qehv6JyAPpIa+x7XKunXDIGj1+tK3ed38sccWFH5yYudl1G/UgvvM+dNky9eju9LPP5gnyZKLIJ7fOOP0MHXXU0arp50+f/CRFhF76Fy/Tfr4Q3e9+F+jXv75eb37jm3TtT6/VKNuZ8atNnDwuQ8Qs2svme9ARh+jNlz1Es7f9SLPztTr8QO782kM9/eg3Xf39Z/dI2HOgiI1tMnnRn4fvhIonqCYmR/iuiXm96O9u01/83Q5982e1ZjvD6TdcT+k+h0zrbS89TB94wxkaZ8zpbz8Dg+wSZ45j88mPPVSXvXyNvvKp3+jK/75LN9w6r1vWzYpPujl49oGW8KnNYxG5dbmAfEUb5tigLd6XW61ahecDL1wD8CTry9FzJujFBSUGxogyI48vUBdVDKhmAX2FzrLN/H11HhvfozwhNTPSYyF9z6uR2+6I8REt28Axhb24moNFFldt4ajW1JSO94u6JE9ynUspj0HBohfiXfH1y3XeeefxvncmMunGm27S+NKlesYzn6F3vuMdOv5ex8oPWS36q8iyhV+0Ki2N0CNGR/Sa1z9NQzuu0zQboceOrhlDu8xpy+55vf2TOzXDIi8ZkcaGlb0XaXHshBRrwPOD1PXpw+aqiDHLU+3nvrtXT3vTnfqvH01pbKzSLbdLM/Vy7du9S095+Lie/LAj1eHhp1eHetzravJZgD/7lHH941uO1I+v3qY3/9063fvoFTrvtFVatWJYdUjBKjAEeVqGoFeMt3mWCXV46l7gPjo/11OX48K59Wo1uYpigQGyy1wXaNzhCOoZDTBVhZUqqvM8nsNw1pc+i9JlpB0iBhO0iq00UpQPPkTAPbKniNDk/mnN8QBVs4CFhezwajHP2/kcu2yBe/KkHQD6p20qoVjgrrwwv77+19q/b0Jv+ts36dbf36I7169XiwX74Q9+oE/85ye1ZctWeQIYm+xHz3zcaOlS8rvsVU/SypV3avfam9Wr2sTsKXrzWuBj7bs/v18bd3SzQ054rR6vND4S6hEEV9UEZHhaBOQMLCeQPc09XOpguIcrthfD+ssP3KXXfmCjSoxpas9ePerCNRoZbqkmIS9SjwEeumZY//y3h/MwNKfnvmKd9nFFfOxfTtW3PneSHvmANVrohQqDoWsWUfKVesiqFuOrxUWqHnPoC2rfdIeHPBKi5gCyoaNMUBpqsQkiVIkSFiZItq8ZkXenj53tDGAfkT2QeeTzXI2+0g4bamuYACP4O4ghoFuM5BZeD24fHtV8u80F2tUsQf0psMti7jpkuX4+NY2l5Bf7hz7soXrPe96tP3vKk7XAoo+MjjGQWr/4+c/0lKf8mf7rqqvkCe9xpB951FE647TTddzxx4nPyUxuKH8EiJYewQPHZc+5VMc/8FBN/hQfdbHpqNfraGi4p49/a04/uqnDfVcMXhrlcqhLpVOOGOF33JAntJBnYrLzWAyQOmJVWy98xLguPX+EeIVJIy5H+yxXz0+u262tm2d4iGFMfHXits7Chxa4olYua+lf37JGfpB81itv1+ZtcxoeKlre260lvb3EoUNmnL0q9r+4ZtSmw+MOG1Kw+X0y1ByxMNqwZZ65pG/mEJN+DbybNYtosq2sicFiMqICeEsWB2LLekH30m8uKJt7nqOky9eh07iHjSL3MRcRkkEE5yzeyT33HRu36HcnHKUp/9xlHZ/fZo85Qu+fmtHtXLH+VwqXf+XL+u63v8Mg22rzZPv1r12p737n20SRPvHJT+qZz3qGvv+d76mF5DOf/pRuuOEGtYeHWKCRXAA2N0+fRY/sdPV//uRinfzsizV91ac1wakyxSkyx0PSMPfNb/+21ueu6XHfDY21pWXcuJZBtNttDbcrXXjvMXpQxmQkSTtlUuIqHtIHXrBClz2sp5c9rNaRq6qc2M78tPyacc4pS7R6yYxmJia0dcse+eeyaXbwfY5q6SNvWKbde+b09Ms2666t86q8csxvZ4rFmVpQjzzd2TI+cEzMSEwbJ0alU+/DpuatotWSqlzAWtv29mxKn5GLmE0URUoFW5LKBS3OHt6LWbiHFTrlwuSJtWg/xBYWtgZ30dUs9Azn1eljQ1rKVbqakBX2Dlz3empzxLZ5PPnp1t16OYv6HyuX6bqDV+kbq1frJbv366s79pGUNEK23//u9/Q3b/gbXfZ/XqcvfulL+u53v6OfXfuzTGwrP5Z/7rOf1/TUlFrk940r/0tvfctbgLfqe17kVqjN5fBwPnb8zQXn6D5v/At1vvIR7Sb+LvKZ5D5ZRU+3bJL+5coFkbpYx2ZRR1oaJndfpZPz0uEHt3W/k5pFZThyKTQVg5phU/i9cOP2DldPrX960aiOWzGtO9fv0PMfMqRXP7atPVt2quZZ4ce/3qcFjsgHnlzpHc9boh/9fEEvffterV7a1ufefbje99dHa9mSlmZY0Gleqwpf2+hGK+h6814WlAvm6KNGdcIxo+p0gnkKsWaaZ/7vpn/n46UTxfmxilDY0KqfeC6oKGkAdi1YFiYlOGLnmIkbCFiR6DwLBqkpkj9yuNLJLOqh9OIX+g5HsT/GPwK/bqcjThat3T+ld2zdpefwEf3VW7folxOTXAWhuoS70TA7dpQPFyNDwxyD7Vy4iEZng4hQhEEcY22NtIfwaclX86gqPZAr8xX8THafd/616m/8q3byvnkXx+g+rhA/UOzYL733a13t5r41zskxym4fGm7J9+OhSsQMnkxDW3cv6IFnjOq8k5aI9OlTYlhJd3tFH7+6q7v2FTZLj99PZ9WbndNvfzenw0entffuPZqarPXpH3T0g5vm9MhTpD+5b6V3fn5GH/7aDGOV7ntyW488Z0bnnzgnHoS1Z8+stvN+O8nrSDDQZaOhTXuZFy7CB56/RmMjXfm251teqyL/yQX9Zt2ChHHNQoFMwoeYHsA45FK5CY+CRTQ9IG3oRbXsZ+h8/+uwmnMs3CzCaR58HnjECq0mwhr4BRZ7hN6GCDDJgu2zTJFXuTeC8K2l3G0LbJQOtj3AmyZ89BDXM9jkgqErsYwsG+IIHeKobxOnzWw/APw3B63Q/d/9V1r45v/T5qt/rlvLkHZyc52YqrWPJD/4zVo3b5V65DhPoGVLgg0hNk9oZEgaH5aWcH9dyUv9th2zeuYjVuqM48achoboo03+7aqlzfuL3v7VWt/6XWgbm2T7Dmk/m2R2odbejvTJq4s+9d2Ozjk61MLvH6/oaM9k6KVPWKn7HDWiwr1hHttZPjl2GfvePR3t4H5615Z5HbdG2sMGdL6rVwzpCQ9fqf079qpm7B3u/612V7dv7mkn/XnJuL64SEMRBv2PUlmSVySTSxSM2QJUCCnEV5jQulalDRxvLRZ2lo4WwJv56H3G0iEdvXRUpzLoHonuQH4C3wOfBv4zSeeDe9iLBa4J5qc/Q49k2PhcrYXDuWYCyYA+qUIlul0ElERS8l5Iw315SLts2Zgueuer1bv++9r0zR/p5hjSnbwi7JwWDxihz1xb9OO7pJqr0g8bk0z87pmiNUuKlrZ73EfBoz0tH6u1crzWivGivYzpr59xjE45aglPxfTZrui31pCKHPcTPy16/3eKNu4SgUNXXB96xxXS5b+s1WNAN9xd9N+/k6bmQ6978hJ98KXS658yykNRER/b1GFRvYm75P/jG2pt3dXTYaukDTsJh/9jH3WYjj64o6l9Xc1zK+mw0Qvv0N//dYf3aSkiVKKSBGZeqfKcyYVJM21tI4QrDSXslYVFbBNkmsf/n7PzbDzPlTHL1bKXe8tdOyd0/3uv0b0wPhHbW9kUHyWx38PfRm+bRMcGOkNE9GARDQVc51rVLDYPhOylTEAY4aEEN3ZlTTgCQxGhU9k4r2MTXfLWv1T9219q02e/rd+NtHV3XbSPn3w4cfW9tUXf4pNpHYSrAUKLsperdueUdK+DQys41paPsJBjRStGa61aUmu0mtf89A695xXH6ESefueYVDolN3ImDuG0fb+0k4/pc8T8Pd9gd08WbgHSREe691Ghh50deeW3Soen3ykt7JtRme1qy90Lmp7sMY6imzZI/3HVQv6Tz/U7Q3xF1fFHLdPLnnmIJjZtU6fX5rWdDkpPvrf+9OY6+2D4jMIVXaIi52TS2OA1YmILMkN/8JCshyIwYSF9r/sJ9G6sFljQafQTzPxNG/drtK507rEH6RJJh2FzOwP/Jfrr4O/GJu/qhCEYi1iQAOgx4+qkvyioAOxDzR+kIBvXgAR6kk5iMV+/Yoke89oXa/am32rtZ76l3/AeuZ6cdvMQxJrqls2hy28XLy1Kf/1RuWtPT9snejrjSBZyuNZKHtWXjUpjQ8G9S5rnCbw3uU3/+IqjWNRRJrtWl01X7hHn+78vet83i3yPdp9+5Th6jfTqx0tvfqp0Bkfv7smu9nJU79tXa4F7/Z13dTlmF/JK/cZPuzpkWcgPZHtnQqv4bfQf3nIfLe/u0tT+rmYJOL/QU1V19S2u/o07C88XJEASTIU8N2KuE0RB6Dy8ZrmgzLJrgmeB/LGNZqEJ0kKzmWP3JyxurdA+eDaq/AT8vZs2MfCDdMLq5XokuuUEB2lYSmjRsUU9fHz8+sjxvblgVLBBrIhI0D0W1/JUh3JxzibjNx19kB7zymdr73W/1g1f+pau54vKWpLd3T/KNu2RvrKu1jSOHljGhx5UyxiGfrmhp/V7Kp1ydFv+YjTKphhqF7XpdCik3bvn1JnYqQ+8+kjd/4yl+V6cMdCRqvbRwS7A/97oASdL550QGiL45i1Fv/wN92/u4Xfv7Oln1/e0e3+tKS7nHTtq3X5XR9N8px1nI7E3eViTjloa+vDfnaKLTtivret3anIuOG57qnkP9dX55Wu62TXPpKwHF0ByJCIDjBNioEHu1pIGwj4TaRSWW8gO6Zsxmdzt9W1+QtjAok4ziV7QSax2spu+c/MGXXTm0Tpz4o9wVQAAEABJREFU+aiezJm3mjg+7lrYVu4Qu0HFVQbWDquS4EwrBJlMGVhKvtf6uH0Esreffi899BmP0vpvX6tffPenunlpS3eqJ/+bXD8o7COZr62vta2nLLiIkSxCCmnoRsHt4Vt8071je60TDhMLWattY/Tc3pjMol275rR363a988UH6c8eerAU4TQ5+irmRVmOWCVdeqp04dFFfGfQVjbUXcBOctnBcbZlu7RnomjDjqKvcWRdfWPRSYeH/Py3b2+tUw4Z0f9733l69APHtPG321h4aY6PKwvczqpW4cm5aCO+THv27QuhSTNIpwDBWhUJ1G5VighV+qOCWsJAFF/CQlB7QTnWdvHu+E08ZpmVCZQzKBewu233tL5z85160Bn30iMOXamX8JB0Cvdd34IWsKvpCLMMiytJmCsND+mruMKnCoLTd6+iAU7C9zW8/P/TRWfqtAtP0TVf+J6uvfFmrR1raRuzsp+HoGABJzm2ruSBZGOXYFS8af+wWpZAU/nwZ0xfuWZBv7yt6DAe1RGrLi2uRnGFcMxySezbN68Nt27XXz1uud75V/fR0YctUQd5ROQrz62bpQ9+W7rq1xK/9+tm+LVbpKl56dZNRd+9LfSt26TNk9Lt3CvHeQfdOyG1uD086+EH6ZP/fokecNawtvxmoxaQdVjILmMaHenpJzxcffXarpiGnK9gOJ6xuhT4GkgBKwB2JScjZlBMLOa+bCSfevCSG++ImoV0DOZPLejfMenXqCkzKOaYHH4f1m+2T+jzv92g4+59pJ56zsl6y/gSPRf9cQDRtUBmXqgaLDqngtBA1Ir8td7/BGOI0Kcw2a9g83zohGP02ksv0eySpbr8s9/XDVt2aPMIRyIPC3xoyUHtXwh9Y3vRup6IInlAISkGAENNXX+IOUaPjdNPn+YL0uU8Ea9cEjzRd/kG3VOPRVsA/IqxwCPy7eu26KIjZvTZd52nFz3rdK1as0TdbhHTIT4EaetMpTlOpp/fXuknt1W8mlW6bUelX+9o8fE+dOiyopVVT1N7al1y7kr9y4cfoLe9/0E6fGyvdv/udnV4r+/xoCnGNTLU1UZeeT78ra5Y38yb6ciFiwj4yJGxrOACD6LmQoMrQNgp0qXIA6WVX2oLSvM1Z1rKeIK13c9YVDYQS6n8TruAvqaf9Xy/+tfrbtV1HMNn83voZRefrfesWK5X0cEjmKAT8F9Jdm0vMsFr6AAOYmbu2+3qqdxY/nZkWP92whF6/aPur9WnnaTLr79Fn/vBz7SWd9DtbIa9xJjiSmT9tIOvKf+9p+iOWuSvA4VcRJ8SBP1EhCIAheiOg1oJXcbBDxr6Bsfvh6/qaJ7Y40M9zc8XkRJzIHAR6eruO3dpav3v9H+esEpX/ttD9dbLHqAHXnCkxv1EFZI3wBz3coOvYnEFjLCIq3nhPf3Ew/WCFz9en/riS/RP//kUXXjBGs3+bq1m79qkLkdshy9vhQenUX7V2cvV/fdf6moTP3pzOGmxkGvSjEMqjMQcHVMbykTkhpYwsokT9y72IhbhZgG4BvuzXk2gygZM7LXch+5GZ7sZsG0iQjO9nq666Va9/we/0E3R0qmPebBe9tAL9YHTTtRHjjxUH162VB8YHtI7h1p6F59NPrxsiT5xyGp94qSj9UGO1uc+8iLFMUfqszffro994wf65aat2s0Nzk/V08yyF8BX8h28JnyHV4a7/8diRi6Ax8AIJMbJkpC5JPJzvl5UhiRWS6YR61cc2f/09Z7u3h1iD8rvlb5SA8PCRqtawdU7r7W/ukGddb/Scy/s6jPvOkdXfeoS/cc/3k9/+9rz9YoXnacXPPtMvfiZZ+hvX32xPvahp+lLX3uTvnDle/RXb3qUTjl2TvUt12jiV9epu3+nOnPTvCbN5r9AHGEx97NL3/WVWrfeWcQUizXOvBmCclDy2DwCZWnkJn1dmsPPrGyIqyfBYnnRGEhDi2BZIajslDb2Pjp/5kXFyJ2zseSn2OBqHWWG9vKZ7+vX/Frv/9r39PENm/XTZeOaPP54HX7fs3TmBefqEr6/Pvr8s3Xhuadr5UnH6fbly/W5iVm998c36KNXX69f8x14Pzlwe+TYKhxj5MBYZknhBhbzxxA7a2TwrqiMGDcUOZGCPCtBrgJCjW1EwDU0ltg3igDdzWvGh7/T0494eFnG68z4WMmFZchq+WZNPtFqa2pmTnfccqvu/PnPNb7pJl109Iz+4jFr9LbnHaX3vvIYvf+yY/XGFxytp17c1jmrf6+huz6lmWvep5nfflNzO3ZqbnZBU1NzPPF2WNSOlnAqbNgfevPni268Q047E/S8kpacp/pZh5pi7J85hdynac28i+KlFWOELLIBLYMs7Nxa+YrBU0zhcI0IBQuowBTcjuArTOgG8DqLLAdzT9e8ihYMTMA+3utuWrdRX/v5jfrgtdfpHb+8QW+/8Ra99Te36vU33qrLfnWz3vSLm/ThX92iq25epzv4HXSGK9ELOUmMiVr8TMbEEmsDI/vOgvRLgO8DpOJOAys6/h81mnslVgIKeUY0tgVeFCxom4pKBn9R+sr1Rf/x3aI9PMofvCo0xBz4ntnjttHlnjo/39UCl8/cfEe7d0zpTp4d1l/7U93+4x9o/dU/1carr9GGH35bd/3kKm395Q+1k990926b1p69RXv3LWjf3jlNT8ypLHQUQ7WuvDH06o8X/XZjqNWSnIhz0aAEBCsV7KyoYFAWRK7Foyc/pGaFGZshtag4fwarzfxhUOfiNsYYWWgG8AS1FAoWdy1wHbS/3zL/4hakacyniWDgVidF8FDVVWd2RhOTU9rZh/08Hi7wrtAlUV/1vIY1vvjzpU5zkvYC1xP4JxxJPDzm/Q+1yFi5ajpQIshJkYJinGRpeOdvWXJNE4EBlaEzERJpsH2lX/HE+gE+Hlzx455mZmqNtHq5iNNcXbN8+Znjq9Q8C9LpsXWjQ7Au78sdzcLv45vtXmx2TvEemh8Yutq9d0F7eGrey2/F81zhPXq5abv0N18o+tvP19rGx/8WC4OYITX5RoRkEBhR8YjBCFUQiWK1wSawahYUqqRFuuieBj6GJXZ2IZJHnXaihIKFjAheqkO7mYlfAjeh2Qb4vurFNHCr0yT+nGjitUy+uqz3YnFyaorjYorYkwa64Sk/bfaEdDvwc2RrieljHVaiT/ULYZO1PMKtlC1N7mZRoJtxmIahQqkxLIlIXS6O50kxv5MOv3pD0Xuu6Opb7Kh9LGyLhfXx2+0u8PC0oBkWeIZfTWZYwAYvaG5ujmN5lmN1WpOTk5qcmNLs5IQWZmdZ8Jqn30pv/VrRi/+1oyt/VtT1E6XYT2xaEBeR25CHQ2smYXEManKOCOQDgKQ6dwIUosGxWN4k2MMjg4gIjt/Cxgn5SEaBYWRnRQWMvEitquIIrnR3q9JNRL0Fq00h7QL7CvPV64XyAnsRvZgGL6zBi2y7HdhvAryAfGHTXcS2PaKssE2+ySn7j6gUXoGESgxDLkH/ETQKVeRnSmwewUe0GIolBqnCrgprtFgqKN5GdBeJf/qaWm//clcf+26t6/i+OcEVKj7NVVWPkL28en0Ud+a66nIkF945an5GLN2O5vnlehM7+Uq+Ir3xi0Wv+mhHV/D5b4pfWfKq5Ok6+otJlwoewIJcJBpXmAo6AFcSlzcedyY1JUANVFBpU1Ry4WzoSYPFyYtlruQxUAicxihLCZm1vycLEf2EHLCOSntJar0k3q3Fp1XdDe3F8qJN4DgBzy1KXmgvOiec+HFEfFOXact9kOmPiuNHXxYRizlI0FLmKeRQ8u0jpIZ1gn25KAXebKPPVuG/QAlQVQpDYqJtVxD4F5cf/q7WB6/q6q0cle+9XPrED6SvXS/eP6UbSP7GO6XrGPj3fxe68teh//hh6K8/U/Syj9X6+8tr/fSmLh8hCj2JBy4x5/TnSnwj0VnIm7LiIpKEHJF8MRkHgohQBVDVlAJqwPOjVJgXwwx3UtMRNFvAgwqFUAkhjtDw6QNG0FQEHnSGsQSioOeVUb4vevG8cDvR7SCoscFguRfaV+lgEd0LplkHtLFjir4kOHAYkxykBF1EyQYNQueEhBoAFRm1PyGhCEAhdoLk2Qg1BVwBqJN3SPNtNqrHtI0dec0G6fJfSf/Oov7TN6R3XB56O4v8jitC5v/5W/xW+mOuaJ7mdnKP5I4iDgo5puM5sOmg38wTJhRsJGuLIkIMDV4NraYUjItJ1FQ10LSEssbAAhaARXQQQ7GpZTC5Q2wGbeS+jAcw4CMcuC+FDmer4E8Jukcp0AbQgYrPQBZIDQVZBSgBoZD2adtGgbfMKiA5mmIbG6CLQJA6Cxo6qb68PywsqMiC1U29hDeAjFY+sblo2dtFFrWYQT+Zepg9STX3w8HCDbUlflIVe4BoanxxLiUU2NrfOPsu6BupNeyvgIukZco+ZguG6SA70LhaYVyyn1T4hjsA4cQ+wYIFzlYOKVujkh0aWyjiW2YeRdaIUFW1GEjgJ0WADZJCTYlFihgWhRvAwUDJ4qMqZBQRkCEzURVQwREQBRtaZFJUkhqz1EMqgpa4RqnUYHSYeHJQB46FSZMqBX9ph4OnqKBLHnm4L3eLThRuf+IhnYUUUHjVE9NnDKD04tocV9m3VQmyAOAgD/psuCplgxmvRRw7g62wPPMLKSoALEpJsBaCigpHBjUQhb2DjlBGhFv5XmTHml4sETZWRYQiAIVFqjxYSFG8wPaBRIsQuwIIiGj4iIDtg/q4L0tbOwMRlTJeKcJqcfcG8ojAQnIbtL5aQ4yp0KSOseAHRwy3qTUBoMPHpnXfJuAF1MyJcRMCOwjPkfOIsFVh6W0hediVZQCueDKtIZk2OL6ZgKAqqipBMg6pCqkiZzyzjxCl4FrA1GIB4ABIZd4qi8INNrJADmOGhI2AZiCNUj5fPNCgM2P0jcYtQgdB7iREJ5B0VykiAImWJgAqssoDAUeEguQijP8niAFGHJC7NxwcRM40IqArACylTBRPNkgFiTFZQxeZpVVTDlDWO5T1A2AYMkQ/V4/NG1p2I6/Sd4igb6ACws7oGZIEbx/VIQmAr0CiFGN4izEnpC0RJhOKGEClChqBq0K1zBKCmsb49klQOLDF0MwKbaM2oaD1R3Pv2GaBxBUBZMSQJ81y48YNj74u0rtkGxE4UcFQcokI/eGiWmOQIuIAqE+D0TDvjtmXYVdEiYK2QDTVU9Nw2KEREOoXDxi/6MsCcUTAQdCGKkXAA1JQAdFtAnRWohMnIkQFQjRUY2xBqCGKIBURzBtAbBlCFJqCCRQGVPhmEpF4BOYDP+hA5Nq3Bw0ckTbKUEBT+wjKPUkRoVBT7Gg6ghaomTjLvIiwiggFpuZzAAOGxEhDVqY9BKZyFhFhrr8ZiiLgYzCJ6vOWNaB+wSQTjAgxSuyIlnSyxLNcSoVJAAv4klCUAqXMCTMWuyPAt0hmQNYXsVlFwdcjyDUAABAASURBVIahpN6bNpBH9HXEoMrjLpiaSB46oqXIq7oShFVAqCnGBnuFh0KXzBbOcIqgBeg0zdGkXgFyA2CKjjzovABC5qp+SRE0vdvJHcEJXAAHx9oDsiiCyBA1R7CPSiWPPaa2qRT8wQeQFcJx0Ic1tg8U4AgTpGx9ikIRTnQgK/AoqDYpYNTIbAOTQmhIZ+6+Sc0kiBjInROImt5SSAnCDJGtLGomMAWN2rMCi5UtgYYisJRJCAEGtTGQCqHiHg+dqckm2CjkuXIu2R/+IbINCYUSyaUs0hGMy0GQBLYCZ45F8i5ItOhozqAs3ocmKjdiIO5Yfb3pwuKlrt84jo0tLtlpkRMmB054BqFwnybwQEdrHYicilC7yj5aLMiz04J8UZhEBPH64O4MqcimyA4RTAD+cMqySMCZZlwKUSNBFIsF1+BB6zgHpCKu+iUioAygxlyDuY4qMDVY0UCQaGDqiajpn6rkkVtmlPNnIeDwltV2xy8CIdiboHiy7Y0sIqACjeg+wE3OEE21CMprBOpHS5e+holKF3orpcCJhbOkr8cFFb7mYdICmoowa/FoklJGpmFx3WUoIuRiT2MpFBGSQhGhpgxww7ltVMgLQwYsM0Qg0z3AZObUt7MtnQU2EbQhOT0DFBU7ywnmRVHakSs+KKlJKAtkoC/ExIsxpbRpOHaVcWwhVe4gGpVbkxGh5o+wUItXguUhJDRCRz/WIYah5vdBC4tSljaF9kAl4wOMkxOxqEayaYHKxEnemQ+WNJCnAY2Dm0//0o+XwqJENI6BaSptm4RMBSSATUQogh4KySMdtBGNHIQ0gCK3EJg0lNOzHm/5FPCiWGOMEV1ndomVO9/etjCW5w2zvk2BFyzWjQLGwUHqu2BiAxUWzGBTWVnQ5PkXiogUqV/ghFAu2ZP1ONpFInMIz5NvbamXywE5pvRXlHpszduiQBhMNwtKDmaImQ5m60zUUnNOBaCas3Op3OaYcEPhQYDsEY0kle43ZZm8Kfw8oQSyKAGxJ96DMcDiiwGJJp2NeYvBONHSC/zAho7sa3khd6VWErbql0hM//IkwaQx2BVl+pcDQqwW50PEiQj5z+buGYZa5A1Ew9o7dkmVm4yHjxRUokFTlYUcC4DGWgA/FAUqAmmBybpIJIdaEejhIiJpWvomfikcxyhc7RYmvDDGCSmBsnaAigZS4jlvdkxBKeRoEDac/qB4qIsCbLBMX6/HH+hsRADryQ+uCHMw5iVREtYP7mEpxSj6w4lAS8VQLqEwoquiiACSpSl9aCwjAp5qbGDC4bL2NY2vdZbaHUUEDXyaQzrv2k0fIhCil1FfljQZKQkU2AR0SLSAeSA3hX0kwTaJKhTRLKAGJRoir9CcUJxCgQPgjnJhiyLMYwwfYZpAAhdk96iF0dSWAWhzZ9vMUBavyFBENF4gTN0TPMxiawIeuwiw6K8UmYyIRawgVeS0QqzgD08ZFeRUYofVYFGgWfCUu0EiG+NMVUQo/8Dql5I4smVAGSddU8HUYWvSi+cTRkQQfQzetYVeFOfT0IxFoQh8kWeNbDO2kw0FF0gjMx0RqrCPCAldhLFXzD2rX8IaCV1Grvmmt2iSGdtAsoGTwY6+sECXmhSEJIMoIYtikBZ9FQvQuKKVgQhpETGwtFYcFzpQQkKtQYkIeF4LHJP+QY0KAhaaWAUgsuODkA2q5dDRh74y5L++rB/H42y+kkl0KZeIMAIyMphpyNYNjgr+KvIPCxJMOVYyNBGWCJuCLViOUWhdwdTgabnq27mnPmkDfPpjYIwpyCZS7rY/JCGQS+VG5ghsZclohC1Bz0VmnSAXKEkhwsi7Ea1cIkzZHlsLZF5pK0rpA8jOwAFbWzruwMaY8FwMSYFt3tgPFk8ZHz3OVJsLqwTzEPeo2A04k2nQnyDkg3GkGD47JKL78pgNjSyyV5v8MYQFbgBPhX0tSj8Yx0g5QtNOQ0TDXAKLghnmpc8h6FdG3sgxGNCNqjRDNtMEkjeFyVzQuu5lMDtVOHuSmxVBgq/EFRKBuxlkUIvVIlRWm8yezPQNUMlso5PMi+LBgaiOZ8CTvhkBFb7vkAi5d7Dj4LBYzTtXYzlyBrdHMZcgisVpU2BYMLcJKUwqm4i0JJFkFQGfsChqFEKeFAH7ZEFGmkidewELSQPKgsyxknZjR2xNOifU1OSCiynSGzboGz8QzP9eUatwv/Oc5oJ2u121/KMeEWsCFSwqcAbJLAucA0uoBOUUZFWmVJD0QUov9FwJKWswFsrSqCUCNf4BGWoWLARDjQPgGBp4BwSgUESFFCBORECjwjYi5D8LII2aPNEl44aOzRYsC7wBRDUFBCQVipa6SFhhKIowdp8Fg3tUxBHZyPOIIUboLaNfCR3Yky+Rv4QkFBESfAAlRAmFQsE4I5jDkCJoRLlHl4SS79l8JJBvnRmx0+mqPTSs2g8vaqybNhaDHFg4gqN0Qo4fgY2CXiRINdmrTyuL5aFI2gmY6HMms0fHM5gJbNMnUAMR9AnpHPIVwTSBSEM+SSCVBVtjyxOYmSCWgIjQYhnQi45SI7INYGdRrIeNoIEN5sfgMWauUfp+KLMWq3IDJUvjEEX4FxhwhgqmPYmiCI/NIzPdYMkyCSR5pTwpBZIaCHGBokI4jyHWDjECsR1AszMzalWVvNIRIfsHmUChbVoxOep72cSgfnEaJvuWkE3v5vupya7hBlWoXxwEhpqCiLAFG4uI2DlZKyIaeZgxoFMCdvxMZXmEWyuliJCveCHCQh7QgVgSaqFqwISaEhGLskBkIBkWqCgiOaSuoTDqt95Uyfb5CGsHoEbKfDqXmqPR+ahfah5IBzwm2BY0pcGl0Tj3DMmgEdEOZrXhRoaHtLCwgJ8YN6jTWcikh4aGEhNNhQhpHhhQYZUALfWFsoUkFKFBJ1osliEWaimoEJ7o9ILWPUpEYEIMYyCHUiItPFCUSbtJdZ9orthADaCICGsGmanPSojdNyhDyyWVYVUzbnsNZIkxAgfIE1+gBVCxDNaRfJvBIA6sBjUUSaYSykuZSBHWWF7SX2bFFQtEEA+zAwkKdSTQYV9c5GJpYnyGhoY1Oztrlk+NoB67ZG5+TkuWLFGBRiRPYkTjFggyDHwxQ3TrQWmXmMayAbh32ybPVYSazd4MLCKDKKLBMsKw6YPO4CNCXixaQRAu5BLqDzqUVAQ8R58jBx0SRvcsQdBmIbHrK3ARzuSOkmommFAh9NVAZ6lLlWWS/C4I8jDQQRHYfULlwjR+ARsKvrlaFxGEcpRAVgGReggwqkpNXGJpcLQqGh09pacbSywGoq+n07Rot9vEkBY6HTQhQirL1NSURkdG8ti1wLkkpolowmTSdFCYuIgDE4QJNTSYuMShLEaln2zQpWMYrDS2zOMhLKJCnkVkyqQVI8B8jQxIi6IIe8FQHQNjqu0bnXQPvZQbCSSMAGqBAwiTRDMSBKXgiYhaAMGFRIsPmSTVt0m5ExfFDMhWjmnfFGGbzthZbplvZSRkUzywpGZoc6YbBzhbe0wmTeOC3hKP2aF97Y1zEc7MzarmTUV0srig/tfe3V6tsbExFVsSx07EaPprYiJ1tdS4gYHKUv8DrqbTRmdZQzVWEcZMoYOjsC3oDyrahk9bSGwjQgE5qINBDZKLGGjpkYeXxu5A9LTHBG2jyhZBRW+gZBd7CEUEIvvf0wPacqvQum/Wqplp82oUwYYv0CVljTr7X3RA4ThpZyv8oJFSzQtvA7mp8bcrpBwnMffiNs89Y0vGNDnpfwCLLa65oI5to/3792nZ8hVSVP2AymgOknPExHqIVkKiJBFaywjXp/CNsAmdIwopiGd729GnBbpnSZkwRGjaAEnf2UrEs6zINvTkwRNTCZYVDYpzNW3siY2Ixsu4b2ZkQMSJEJgTk3aQX2ISjkAHpO1gRm2Hjkpc/MLWghYFGmMqvFuB9b8W3Ppy+oCK6GNo18bblOUNRIQiwkL5jWTlqhV57/RrZ1+sKrV9b99YZ3jiXbFyhXxf9bxZ5clh5CKafC8JVZAObFAWD1CCN4ET1RyALW0wArRQolgLysqkJJsNklBEJHYoiAMVgTUHVto+hsYkIuQ/Swp0iUZu3lSEBQ249RoV71Tiph5v4wEUyw0ISvpCUAM7Q/E8mA4yopOAVgILm5ix9fFAh5kikDMfeEEriz3MWJ/9Ii1Bo+BPQCgLBj5Bx7kyR0dHtXfv/kbcz7Myh41EJ6Ls3btHfn1Zwtlc93pIpOBYopVEIlzqhUkoBIh+H4FcA0YUdHl59qNnssIq0AFUiKaarjJ+w6uZZZiiZhPYwmyRN1XG6scnG2VBJQW7tiTIBRvnmKo/4IucakRFisUaeeIiQoU/gQNdRCiigcYoWyGBCMAVf2xKgR6IeF6IMIPO8VDhJCGjGvWltnGfyuJcSUhCHEEjikNg7bxq4tqmZlz+CLRq5Srt3LlTte+dmIrNZcRUhjFzVRwLg1p7du3KJ96R0RH5/zlHzJxnd1ga62wtbLwl55BgYwsBaiOXKVsbmghyQex/kZ9k4yybFppk0culuDGEgsk2pXCbjQlSqxMH+pD/RCtVBIqIhjFWUzxJGbavatKO9HGWhmhMsw004dhVSFS5gD3JJn1y2cf0Adxwbm3HWrgbVQTAlRZNJgHOWlIWtAF/j3ThJC9mu1Xp4IMP1r79Exy3/s+90hJ9AaJ5bRHFrAFSHT4F7t69W8tXrND40vFmUe1XSRGh/AtoSbA0ukdBoVBEKLPPoDUb5gDvybQDEhnM++mvfwqhQoJfMwFFEVgZ0Ph90PsaCZx0AAd9wPeDRISqioQdRC7oQ0IsJwYpg3O0CT2atGoRvAjsFOwtKjQ1LJaQKaSJCOKErx+pTweXfEgy4IBfge4DunyLQ+nN7FNI/RK2KmYKlLFEyASPe2RoSIcddqhmZqY1OTUhKXSgNDQjtqhhTA3AXx527tip8fFxrVm9Rt6BhePWlk0nIXJLUCMAoYUOBYNwJGxAxYYqpqwBQhEBf6BaG9HIQpEKsxGOUQTqy5hQ1AUOKqNCUkva5CJgXJB4RxvnpMIvVoS2C4UUlSJCIemekwuTsYusQScX6NJgI8dIQOQNCaKSFWYiZgEizDTTkT5ETUkyUAXAy2YWQcoig8TYub3VHKtLx5dwZR7Elbk/Qf+jBNbBOhGJqv+tdHhZ3bZtq7p1VwcdcpCWsrh4cenX8o4JnIIs6JarA6IU1EUwgLUFPhSBRVhEI5eQ/0wZTEeESUUcwKHoy5iQIkUEUEkCG8yLAlYfggVCslijTyV2DEH1bWHlRWxY5Bb07Y1C/IUUQf4SWBI82SgCopl1QSnCrQSxuH9SMmgydqAOievZ5hHQAFUoXMFU5rHw6uhnmJHhER16yKFaunSptnOBTUxMCi81JYNCWsJGUhFPBvBpYqHpP4Saq9LH784dO/iA39bqVau0bNnS/B8I40/yBHLn/xuQWN2XMwZDFr26AAABeUlEQVQ1V0zRQFaIbWh45P6Pe2yfu7LOJ+2BzleCadsTNmMUbDFVcRzeoa03OC8hE4b287CzbwjbW1fwrWF69jPAY46qAM2GLejTjofDQrxeP7+BXHRUcMIDn6LiGAk96CLn4mcQKCyZV+IlTyzb1lx5DdTY19j7IbSo3RrKk/Ggg9Zo+fJlHK+T2rZ9u3xqepUYhppirqEGbeW1dFKN4H8aWG7pwvwCT1W7tIt7a48BLuFqXcniLl++XGPjSzMBPxmPjS3h48SSfKgyPbpkVGMJY4uyJTxy+wNGA9imz5hGU44/T9iNboxY+PX1Y6NjGuXDx6gxMDKyRKM8uidgMzpqHhvLzBPHsjFs0yblo/QDEMdy5+KYY9gvQWYYN02sJocl5D+eeeQ4sLF8CdjjNYxiOzo2ig22+I4taextM2Ye/Ti5LIG2fQLzN84xOg721beC55XVa9booIMO1vKVy9Xik97E5CRX5Q75K95gjYoXbBEGq2PcwP8HAAD//wBNIwMAAAAGSURBVAMACrqje1Prt1IAAAAASUVORK5CYII=" alt="Live Infinity" style="width:72px;height:72px;border-radius:18px;object-fit:cover;border:1px solid rgba(255,208,0,0.5);box-shadow:0 0 25px rgba(255,23,23,0.5);"></div><div style="font-size:24px;font-weight:900;letter-spacing:-.5px;text-align:center;"><span style="color:#ff1717;">Live</span> <span style="color:#ffd000;">Infinity</span></div>';
  d.innerHTML = '<div style="width:340px;max-width:100%;background:#070a12;color:#fff;border:1px solid rgba(255,208,0,0.35);border-radius:22px;box-shadow:0 24px 70px rgba(0,0,0,.9)">' +
    '<div style="text-align:center;padding:24px 22px 4px">' + WM + '<div style="color:#ffd000;font-size:11px;font-weight:700;margin-top:4px">Automação Inteligente TikTok Shop</div></div>' +
    '<div style="padding:8px 22px 24px">' +
    '<div style="color:rgba(255,255,255,0.7);font-size:13px;text-align:center;margin:12px 0 14px">Digite a sua chave de acesso para liberar.</div>' +
    '<input id="ttlf-gate-key" placeholder="SUA-CHAVE-DE-ACESSO" style="width:100%;box-sizing:border-box;background:#03050a;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:12px;padding:13px;font-size:14px;font-weight:700;text-align:center;letter-spacing:1px" autocomplete="off" spellcheck="false">' +
    '<button id="ttlf-gate-btn" style="width:100%;margin-top:14px;padding:13px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:14px;cursor:pointer;box-shadow:0 4px 20px rgba(255,23,23,0.4)">🚀 Liberar Acesso</button>' +
    '<div id="ttlf-gate-st" style="margin-top:10px;font-size:11px;color:#ff3355;min-height:14px;text-align:center">' + ttlfMsg(reason) + '</div>' +
    '<div style="background:rgba(255,208,0,0.08);border:1px dashed rgba(255,208,0,0.35);border-radius:12px;padding:12px 10px;margin-top:14px;text-align:center;">' +
      '<div style="color:#ffd000;font-weight:800;font-size:11px;margin-bottom:4px;">🔑 Não tem sua chave de acesso ainda?</div>' +
      '<div style="color:rgba(255,255,255,0.7);font-size:10px;margin-bottom:8px;">Gere ou recupere usando seu e-mail de compra da Cakto em:</div>' +
      '<a href="https://api.valoranegocios.com.br/ativar" target="_blank" rel="noopener" style="display:inline-block;background:#ffd000;color:#000;font-weight:900;font-size:11px;padding:7px 14px;border-radius:8px;text-decoration:none;box-shadow:0 2px 10px rgba(255,208,0,0.3);">👉 Gerar Minha Chave Live Infinity</a>' +
    '</div>' +
    '</div></div>';
  document.body.appendChild(d);
  try { document.getElementById('ttlf-gate-key').focus(); } catch (e) {}
  function ttlfGateGo() {
    var k = (document.getElementById('ttlf-gate-key').value || '').trim().toUpperCase();
    var st = document.getElementById('ttlf-gate-st');
    if (!k) { st.style.color = '#ff3355'; st.textContent = 'Digite a chave.'; return; }
    st.style.color = '#ffd000'; st.textContent = 'Verificando...';
    ttlfStGet(function (lic) {
      var dev = ttlfDevice(lic);
      ttlfValida(k, dev, function (ok, reason, offline, data) {
        if (ok) {
          var now = Date.now();
          var em = (data && data.email) ? data.email : '';
          ttlfStSet({ key: k, device: dev, email: em, lastOk: now, activated: now, exp: now + 30 * 86400000 });
          var g = document.getElementById('ttlf-gate'); if (g && g.parentNode) { g.parentNode.removeChild(g); }
          ttlfLiga();
        } else {
          st.style.color = '#ff3355';
          st.textContent = ttlfMsg(reason || (offline ? 'offline' : 'invalid'));
        }
      });
    });
  }
  document.getElementById('ttlf-gate-btn').addEventListener('click', ttlfGateGo);
  document.getElementById('ttlf-gate-key').addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ttlfGateGo(); } });
}

function ttlfCorta(reason) {
  ['ttlf-hub', 'ttlf-bolha'].forEach(function (id) { var e = document.getElementById(id); if (e && e.parentNode) { e.parentNode.removeChild(e); } });
  ['rfTimer', 'rcTimer', 'raVarre', 'raFila', 'rvTick', 'rtTick', 'rdTick', 'bnTimer', 'icTimer', 'nvTimer'].forEach(function (t) { try { clearInterval(window[t]); } catch (e) {} });
  ttlfShowGate(reason || 'blocked');
}

function ttlfRecheck() {
  ttlfStGet(function (lic) {
    if (!lic || !lic.key) { return; }
    ttlfValida(lic.key, lic.device || '', function (ok, reason, offline, data) {
      if (ok) { lic.lastOk = Date.now(); if (data && data.email) { lic.email = data.email; } ttlfRollExp(lic); ttlfStSet(lic); return; }
      if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) { return; }
      ttlfCorta(reason);
    });
  });
}

// ttlfLiga duplicado legado removido (unificado na função oficial ttlfLiga)

function ttlfBoot() {
  if (!document.body) { setTimeout(ttlfBoot, 1500); return; }
  if (window.ttlfBootOk) { return; }
  window.ttlfBootOk = true;
  ttlfStGet(function (lic) {
    if (!lic || !lic.key) { ttlfShowGate(''); return; }
    var dev = ttlfDevice(lic);
    ttlfValida(lic.key, dev, function (ok, reason, offline, data) {
      if (ok) {
        var now = Date.now(); lic.device = dev; lic.lastOk = now; if (data && data.email) { lic.email = data.email; } ttlfRollExp(lic); ttlfStSet(lic);
        ttlfLiga();
      } else if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) {
        ttlfLiga();
      } else {
        ttlfShowGate(reason);
      }
    });
  });
}

function ttlfPersist(root) {
  Array.prototype.slice.call(root.querySelectorAll('input,textarea')).forEach(function (el) {
    if (!el.id) { return; }
    var k = 'ttlf-' + el.id;
    var v = null;
    try { v = localStorage.getItem(k); } catch (e) {}
    if (v !== null) {
      if (el.type === 'checkbox') { el.checked = (v === '1'); } else { el.value = v; }
    }
    function salva() { try { localStorage.setItem(k, el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value); } catch (e) {} }
    el.addEventListener('input', salva);
    el.addEventListener('change', salva);
  });
}

function loadFloatingUIState() {
  try {
    var raw = localStorage.getItem('liveinfinity_floating_ui');
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}

function saveFloatingUIState(patch) {
  try {
    var cur = loadFloatingUIState() || {};
    var next = Object.assign({}, cur, patch);
    localStorage.setItem('liveinfinity_floating_ui', JSON.stringify(next));
  } catch (e) {}
}

function ttlfDrag(el, handle, stateKeyProp, onClick) {
  var sx = 0, sy = 0, ox = 0, oy = 0, moved = false, down = false;
  
  handle.addEventListener('mousedown', function (ev) {
    if (ev.target.closest && ev.target.closest('button, input, textarea, select, #ttlf-cfg, #ttlf-power, #ttlf-min, #ttlf-close, .ttlf-preset')) {
      return;
    }
    down = true; moved = false; sx = ev.clientX; sy = ev.clientY;
    var r = el.getBoundingClientRect(); ox = r.left; oy = r.top;
    ev.preventDefault();
  });

  document.addEventListener('mousemove', function (ev) {
    if (!down) { return; }
    var dx = ev.clientX - sx, dy = ev.clientY - sy;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) { moved = true; }
    if (moved) {
      var maxL = Math.max(0, window.innerWidth - 60);
      var maxT = Math.max(0, window.innerHeight - 50);
      var nL = Math.max(0, Math.min(maxL, ox + dx));
      var nT = Math.max(0, Math.min(maxT, oy + dy));
      el.style.left = nL + 'px';
      el.style.top = nT + 'px';
      el.style.right = 'auto';
    }
  });

  document.addEventListener('mouseup', function () {
    if (!down) { return; }
    down = false;
    if (moved) {
      var r = el.getBoundingClientRect();
      var p = {};
      p[stateKeyProp + 'T'] = Math.round(r.top);
      p[stateKeyProp + 'L'] = Math.round(r.left);
      saveFloatingUIState(p);
    } else {
      if (onClick) { onClick(); }
    }
  });
}

function ttlfBuildHub() {
  console.info('[LICENSE 07] ttlfBuildHub chamada');
  var css = document.createElement('style');
  var fontLink = document.createElement('link');
  fontLink.rel = 'stylesheet';
  fontLink.href = 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap';
  document.head.appendChild(fontLink);

  css.textContent = '#ttlf-hub{font-family:"Plus Jakarta Sans",system-ui,-apple-system,Segoe UI,Roboto,sans-serif;scrollbar-width:none}' +
    '#ttlf-hub label{display:block;color:#ffd000;font-size:10px;letter-spacing:.8px;text-transform:uppercase;font-weight:800;margin-bottom:5px}' +
    '#ttlf-hub input,#ttlf-hub textarea,#ttlf-hub select{background:#03050a;color:#fff;border:1.5px solid rgba(255,208,0,0.28);border-radius:12px;padding:9px 11px;font-size:12px;box-sizing:border-box;width:100%;outline:none;transition:all .18s}' +
    '#ttlf-hub input:focus,#ttlf-hub textarea:focus,#ttlf-hub select:focus{border-color:#ffd000;box-shadow:0 0 0 3px rgba(255,208,0,.25)}' +
    '#ttlf-hub input::placeholder,#ttlf-hub textarea::placeholder{color:rgba(255,255,255,0.45)}' +
    '#ttlf-hub .ttlf-sec{border-top:1px solid rgba(255,208,0,0.12)}' +
    '#ttlf-hub .ttlf-sec-h{padding:13px 16px;font-weight:800;cursor:pointer;display:flex;align-items:center;font-size:13px;color:#ffd000;transition:background .18s}' +
    '#ttlf-hub .ttlf-sec-h:hover{background:rgba(255,208,0,0.06)}' +
    '#ttlf-hub .ttlf-sec-h>span{margin-left:auto;color:rgba(255,208,0,0.7);font-size:11px}' +
    '#ttlf-hub .ttlf-ic{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:9px;background:#141928;color:#ffd000;margin-right:10px;flex:none;border:1px solid rgba(255,208,0,0.25)}' +
    '#ttlf-hub .ttlf-ic svg{width:15px;height:15px}' +
    '#ttlf-hub .ttlf-sec-b{padding:4px 16px 15px}' +
    '#ttlf-hub .ttlf-desc{color:rgba(255,255,255,0.65);font-size:11px;line-height:1.5;margin-bottom:9px}' +
    '#ttlf-hub .ttlf-go{width:100%;padding:11.5px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000 0%,#ff8800 50%,#ff1717 100%);color:#000;font-weight:900;cursor:pointer;font-size:13.5px;transition:all .18s;box-shadow:0 4px 18px rgba(255,208,0,0.3);letter-spacing:0.2px}' +
    '#ttlf-hub .ttlf-go:hover{filter:brightness(1.12);transform:translateY(-1px);box-shadow:0 6px 22px rgba(255,208,0,0.4)}' +
    '#ttlf-hub .ttlf-go:active{transform:scale(.98)}' +
    '#ttlf-hub .ttlf-st{margin-top:8px;color:rgba(255,255,255,0.55);font-size:11px}' +
    '#ttlf-hub .ttlf-preset{flex:1;padding:7px 0;border:1px solid rgba(255,208,0,0.25);border-radius:9px;background:#141928;color:#fff;cursor:pointer;font-size:12px;font-weight:800;transition:all .18s}' +
    '#ttlf-hub .ttlf-preset:hover{border-color:#ffd000;color:#ffd000;background:rgba(255,208,0,0.12)}' +
    '#ttlf-hub button{font-family:inherit}';
  document.head.appendChild(css);

  var d = document.createElement('div');
  d.id = 'ttlf-hub';
  d.style.cssText = 'position:fixed;top:64px;right:12px;z-index:999999;background:#070a12;color:#fff;border:1px solid rgba(255,208,0,.38);border-radius:22px;font-family:sans-serif;font-size:13px;box-shadow:0 24px 70px rgba(0,0,0,.95), 0 0 40px rgba(255,208,0,0.08);width:325px;max-height:84vh;overflow-y:auto;overflow-x:hidden';

  d.innerHTML = '<div id="ttlf-top" style="position:sticky;top:0;z-index:5;background:linear-gradient(135deg, rgba(13,17,29,0.98), rgba(7,10,18,0.99));border-radius:22px 22px 0 0;border-bottom:1px solid rgba(255,208,0,0.25)">' +
    '<div id="ttlf-head" style="cursor:move;display:flex;align-items:center;gap:6px;padding:12px 14px">' +
    '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAABwCAYAAADPC1QxAAAQAElEQVR4AXS8B6ClVXX3/V/PObfNnT70LgLSmyAgFuxGrNHE3ktsiYXXaNToq7GlWKIx8dUYjb2CYsTYRQULIiigMAMzA0zvc/u955xnf7//es65gybfvnvt1ddeuzz7KWegqqpWaQ2gZbpdWq0DYP0AIqJIKmNjY+Xggw8up59+ern//S8uFz/ggeVBD76kPPiSh5QHPeiS8sA/hgc+GJsHHYCLH1juf/EDykX3b+DCiy6Gvrjcn1gXXfSAcmHCxWDD/cHAhfcvF1x4Ubmf4QJo4H7A+Rcguyek/sJyv/tdUM6/34Xl/PMvKOcZzrug3Pe888t5wACfe+555dxz7ptwzrn3LYazzzm3JJx9bjnr7HPK2cBZZ51TzjjzrHL6GWeBzy5nJj6rnInsrLPOKmcB1hvONI3+9DPOxN5wRvE8ncZcnXbqaeWUU04tp5x6ajn55FPKKcCp0KecAo38jDPOKPe5z0nlyCOOKsuWrWAdhkpEq0RrqFR9aPWx+VZruLSBe8oqlVwjrxNLBZJ54z5EYFKAWkuXjuu000/TueeepxNOuI/aQ6Pas3eftmzZqo0b79L69Ru1YeOd0Hdq/YaNwIY+bETW8BvWWwZtW2w2ABvxse8d1q2/Q+sNd6zXHXfcARgD69cj36D1dwDob7/jdiXcfrvWrV2ntWvXJtx261rdargNfNutuu2223Tb2gZscyt2t2F/623rtHYdcDsAvi3ljgGP3rZrwbZfu26t1tHP7diu69Pr8FkL3Eac27Azn3ncij821q0l5lp0a9fdrsTEWEfe6+A9NsdcR8zbPbaNHtdG7dy+S1UVOvywQ3Xv44/VQQetESzzL0WwFoAWS1Fd6lyxUEjoKtoUeBkXgUUuBkl1XWt4ZFinnHq6zjr7vhpiEbdu3a7NmzZrz+7dmp2dpbOiVqv6Axhqt9SuGmi1WuhaGmq31bI8oa02csMQeLgN38YuMfRQW0NAG76F/o/BfgbHbGNnPNTChxhDQ/TVl2V/+LeRO1aDK7Xbzpf+0LWsw7cNPdQH22ZM+l+UQw+1h9TYt5r8232MX8tzQNwh7IaJZ9xAK8diehh/44w/RCzsWlXltVCv19X07Iy2bd+ujXfeqW07dmrp+LhOOvFEHbR6hQprkWekKCwWNf2Ua1VARURCHGoUubRSMqx2TQcHrV6tCy64UMuWLtPWrVu1jyuyqFZ7uCVPZKtqsaMqSSH1gfgEryXieWPAmIKlL0sbhAxmsUXoms42LXYzYaOEjIW9sc0gscEJAmtadqsViAY2ZlGknWUQuUmTTgWhsTcJpZoZIwokEXG2Xd3Hpg0o0xwLMM5NtThnADZp2xr+wL8eeDVWYQ+TBuiKefcG8rzOz83r7s2b8wQ8+JBDdK/jjlEVTAkxsgOago8ShKLIK9FnsUSGlFoYdE9HH32sTj/jLO3atUs7d+zALtRqt1VFCxtcy8AnPE/IBBQ3DBSUtUAjozoP5ialg6YQNS1QeOCWexJwUsGhWACgpnU/AwldpRHeKO0Dwga5Ccwsg8OqTrkbNrkEm7q0S0PRmczKYxqILIC2X8k8G8q+Btty4qk0AYlBLdjgV1thEq3wDccV+ijmIKjYZRzkjVkBGRpBVVVqA7Mz01q37g51uj2dcOIJebUXUWgIgU8TC4lYFU8SpDUg17ru6VgW87jj7qW7776bY3VOVZtFRIk13swINETT2pe1dSr0kTL3YtpgAeNgIFC2ZbAlZ9ZavLxwluOUAySWrxLPgXmDZ7vxaWIUYliWOdjXoawCCIPKAmLDp5rGtw9YORG6SJvGKqPQwGEnSuljx0pwg8xyQxDEGFP8qNbBWLYI6TPQERu960BPAlgckJsfQEqJibeCy7ICNnO17t23V/e+97011PZK2GoAUkSo8kSLYjGIK7PWoYcepmOOPVabN29SYbIdLJOwQXYCAfZ0NXJ7A+HuwVQyNYMhFTm9KRGskhL6IvefcWCzYkToJN3Aph2JEBLLeyhNGkS8zAOGih0utKZBciluEqAISpsqIqqQhLHVjmPvpGWpLRuJKYN1B8ASAqYA2iSIincKcb4Hl6Qb6zD2rjUJDKSJs0HI2JQg+b67k/vq/v37dOwxx4rAwB/WKm2Ja+wdvGzZMvEYrW3btjeWlVhkBtafnYIUTraPxWQIsEjbAjW7Rf1ywE6KCIUGJTissEdmSXaR2sJCFwkB+8kqIFJjmSc9os+jwVIR8ABOTGRKpKACciHWgFyMYYPU4YV+8Zjsu1tlkxwv+ggiWIfCstwIKbJwAMQiA/eR4AD4FeZnMe+oFIEjlUuKaFTcPU9FFjYxegzefaTI9sRtc1Lu2LFdC52ODjnoYBWfdEWY4Ad2ZHuLmZXP7JNOPll79uzVwvyChJn6xckUjrkcCIGNaztZ76DQgbwiqF9XrXcOdIMFXAGgamMgMnYjwwUNNaSCLgHWtYnVyAlvUYI3n71tK/KqkTqOZZCYmsMPSsQktFH22hfBY40uY+AU4REgw6CRmUdBDTwLExzQjoozqOTGs21hwQQ0NHLblaZpfEzbpagutUr+ISP3Aoj5s0yWJ19YawIQM0DZn81LUVQVF9xWrVy5XEuWjKLCE7njVA4QQeIIjjjiSI2Njmnfvn2qWs0rakGOmlAikZDXzjKDhTWdEw6yACH6pwMxUC0WQkBjBWErGKp5IzATlfFQhm0SajkQZGLmk9gYCKDiacrIZmlDGDDTh5MnIWM1YdIGDbhx9kapsXMQL5QDeZMYG5xPYWzBgA/42beQSgD6ozEyDhZFlABcjQt9GNyfZcWNwUQ/tohWAA2KJ7wwlOQd1wQCUGBXoa8Z7E5eGw85+GBl7ECpUC6oKC0u5WOOPka79+xhMdtI0oKoLFITCxqCBD0JzEzD9y0LK+nEC0ELsgQ30FlLnwE5xZrJsr1jGVs9wEEMywd+jRwvjKioCIKSzGgP1IZvdCSXKQZqA07wfR3IcRobGGzcB8hmCYs+CK2jdyh7GPW5NHJjaGSOZhCTbrzYj90cuRHIHo1okYK1R4NMZcRUm0PuCu8QFVfp5MSUWkMtrtIlg8S8oExDr2jNmoPU5kV3ZmaWBa0UgScBMijxHKSUnmoWoiYxREyQDZIiYFomRjqwADecW0ekN2zMgbiM0ou+jAcTZ2yLmv4KHTfQXGp51ZGDgJTTgzMQdgNIOUL3Ry8OJcEgwsQZQFFxVRZ0ETSLRilVRCOzaXrRh2P76jAu3sQEsV5McMA7P3unDH/EsCH7QyziRm9JjUxASshPFNMG+wX8H9UUWV9r3979WrN6FX51GlVyqCji26ympqeb8WMb1uAY1gtxQeiE4QOMqB+ksMhFvnnnYNLOtshMczR48DV0zZFUCznO2fZ19gtkWbEztk/Ql+kGPCV4hXMJ+rTUDLjpjnwgYCOQU7EW645tUc3x1oQmg+wX7FyiyH0ZiEwlBobm0STv/EQuaPAgsAQX6UcoiXHZxhE9TtmKGBhQ7YXGCMs+gupX5jL7WlQURUQCzuRNtALI/YGhCY9zYzM9NaXh4VFgGJlUFUbsx+EVK1drampGvpStyQnAs5AsyCIgRFwRlr7YEXQsBAHYprgRxYNBZt4LjYRKJh49ukLMkhgxtU6eeMhgM7ZJUiMifghtr3Lgvo4R1boGGC5WmZlqHG3v7vzlx1KRj3FNYOcUEXKBtfgeUDIurcQmSDcMHQ9ELXKMmswERNM9PjWmRRFN3DotsSiSw2CKjRL6DRZUm+PDuiLGGFFTUSBH6IrIOmQyOE7Dd3s9dXsdjYyMYFe8oEVLxsbkx+GFhQX3i6JubviNjxyXiOgQUE3LGajwR3ALmJliGfqS4IbOjRCA+rb4mLfAfgZoLE0BMLSOWlhoO91zMpP2LKbDwNYOKZDbcEsugdjQWBVCAWbQGaFuxmnC4LyMDWnQbBPMmZMUWKMIRyVDEBElcLhJEAUOc6eZokgRTVNRkYtpxzcHTScRkeaWZFwTgY5ApCYnmw9AGhQrpZmZGX44WYqw+B4qjS8ZVy4mO5s0M3nHMp09wzSudENwPEXf2EGhawhojH1VpAi6OB6Z4EUot9YkiQu8dYCHVdsRn6aicz90WrOomBywtwFdOZJ9DAWDMugLmh7SokDXXB7GRFTwVwUqqv1t574NppnTvqavta1JA74Zh5gkw9yWRSBF3Ev6uh/bwZApMmrFZNnN4RpA6Gohho09nvDOIXn0EVhTMaEiQO/TAUuykby4EaG5uTm1h9ryODhyi0bHRtVZ6HA01P3EJLT9PItqT5akiMpjIVFRQv4rcHjRQvUXxQnRNzYO1yRi3q8H1jETqXOwvPfgZ3mdmGhpbF/McIeC6NccMRJsIyKF9rUZGRCykC96NIWsQMjgidnYWVrUvI54CtBhZJ3NCzQDk8Ey87gqj2kJsSVqiklSMCLr7MfjafwsxQxn8zgyn+4bB5hsaVDLUmcRYYHkvWyfms3ooEjxwALjRdpedBER6nQWrESi5gptDw/z4beTwpRiWAjm5MzDoqsJWgD9jxJI6EuF4E7O4EScVA9FXZi4Qoi+HSPrM0YokEc4inIxCCQhtn+CGWwSEc+yZKGNbWyZWUPyaYyWOBmZ+LapawQALSlmpmA87JhCaPSNOzRy+zmxxIS0g03vORnWNYABfeWquGOAEARCnk41oekXYaEf+6D5g5pmSHwFgrIO7IwHeqKkrmatWlUlP//wLKvMq9erJSgbLYI7JSHErAFS+GSJCJeJ0TTJioKe2vAQ7sj6QRK4MRf2lEPKBTOjxgfKWgPkogwnKhPBSeFYjYJoOBfL0rhpfCUV5DhQicR2p8UFeyeDGfsLnUWOCbYswTYQVMcwpCG8yDgAh8h4EO5GWewXUGxcbHwh0C2BsUTl9c04mCSNjRKUV1RoUGyPw4DF5oBOiogG+n3DySVyQJL5XFAn1uwWD9DgwMpFDMe3gSjQHiRa8iu5CZGqIYpER8JLYNuIBIw9TDHxIg4VNVICe/LDXgiRmEJHNW974uTkWJMy92E9YBmAidyl88oNhCwUUn+QiZEhyNaNo7i/YjsVRCWpxqbAN5Tz7VOLMmuJjsoUUchLTmAxjuVCbygZ17lhacGiHEZMD16O1kCGoifPl8HG9m3mwDYoqQVwtU4KDo8C+IJUbhBiFwKDBGDtwAZhbE2IgtyvACD3g0YEQYthbgbiZcc2yGj49GttG9Pg6Ovs40BEkAdmeZNgGrrB0lr3I5s2MjYCHBUd8Ti1mM6aXEjAHgh6HEF1f0MUcMGOSozGB4I+PapQENUAStqYMOzRHIgyt0GfKG2bPaHOmBgb4yChpAdLyKeYTVqUJge0aQzuawrZMxhbAFIEQdQvpgFHKhaxSfvu2CmhML7GXxKueYWaSFBTAiZMpjfm4AyYMngwIlpoFAO6hoD1fKFjieCTcSJICIsDFXkBlAJlSR5naroIH4N5CzKfxrJpU0GsnBBEbJ+GpAAAEABJREFUOXDlvFpqH1HSz33ZPsENFsgKv/uqYRN5oXBpKo6+h9VsEEwbGYTNI0JUBdLIVrSmrBWlyHqIrDm2pCJbgSJoGu7/ty19TYMLQzJl6CsS/WGcZkGtINlENKX/yY0I7LQ6B2vac0dYSGTYO1GWDQ9PhTsCqCLZmp2TG1t02FTssIaGsDRje8IMhFMKk2DC6cx9ZefEc9jBCVHbBkHTvwMmI3v16Dd9kqMhaADWOV5YxCI5t+Z1Aql5yzMMPAEcu7Cp6BoNsgIgV8Zv6GyRR2RUtCGTiPChx0iUTch/SUKBsy9wYJc0DRGQ0DJPSbgHyTFFMWcrCSc1frIScL6I+kculE0iIvVuIJE21YGkkIsDBrQD+Ig19gCMxQTYtnDkBca2BWXP1htkY9kKjQ3Mg6moCpHtic5UMXZzwL70J9+SBPypGdE4ou8P4/68+E0EKaKZqFDIpZFnlMzRV6TlBtwzH6VtY9+QxEilshAy7dxXMx8pbho6oKZb0xQ19nRHSNPBnKWxmYKc2CZTJozg6UCWRYSqqKCdgyTU1skFO7OV6QgM4KjY0FKJLSEXHUYyzcBNN1RRjyBKXZNIypF5cAakXGc1JlzByJvOsUofGsvkAt1HaKFo0TXShk5fZKQGiQYagtronZd1xu6XIOjEENCTgZkmJ7QYWSpKRCjA5h0SbXI0ssI+hpRjYLsDCw+HjBCENy3MmtzsY0BBRYfK1RvS2IuPMWShG4A4BU7moJWlkWSbDR7oCqeEc/awBmbMsFgq5YKm8B6NjZ10pkEAEayAnUwhmLgCyRIPNkIqIakFG7OQqPGGd+JBkveUkRZ6JGFwDCTY0g2Cxg8JNJsBYcaFK2RcHKugLTSmkWefsLZbBIQZGTnWtkq4pz5D0NgERE7uGzML8EfQZyxPYYYq5GHCkoTiti/x6gIROTj8LQfZJkU0jXlfYWSBQUo3HShYK4WpcB6eE7Dz64M5R7FtLqiJAwNtHDjZbINL4SpLMmkzzs32MpPSxgeS2iRGFmpKTmtD9lv7RzTyZpPYx1momUNBM2nFYB+zxo7Og4z7Lqa9ucACGh5/aBG7b57xuCBh3QfItUCzpQv+UCK8qipkNwPd2uoeEKl3aFGK/YU9zo5doBFnbXQmi/pPaHKBk8cq+4bz9PgBaOFfANF5+tvGuSVgC64B6yICs9A9S6j5c365oAWtE4tFHOQSREKQFQuqHZoHE5jsVKrBBnfm90phVOhcwYz1fUnb0uTUn62CnwdY+pvCJ0LjW+S/GrkxPeUcWGcgK5G/a4KVhMJHB4r7R2J/xg+FJ4GojY2FGQgWIZUwzhcqg4FR2QxEP0RCTkss63BOHq2NoKGyolEEI8YsFCmr4H1SCWyIsBwDxmgqwSzR0yFYlgRrirw2jarhGY1kUv1impgFFk/avtaTXHvC0TSLI4KZaYaCT1oGbURYqQyOiVl36hgIEXtQ+KFLGdj61NFYFsSRT32czWMtSAX6ewIsE26tKeISyNNfg+2HUuwslAVfPD0GOJhUYWZOZjz3BphGhtIxfBcxmLZdoyyY0QsOVEWE/IcQdQCmCjItgqlBptbiosVSlHaD+BHEcGBRvGrooagNEbbGpuEkSEkhGRCaUr80Onk2+xIQNuRQmBuoGvBgkasfAFZZ3LmhYayFCqAoIhJgFrFpQ3GART+6gs4rs1gLDDCkTY08+IDwMprOGLbzRBhbZwOwF6P21Ulc2H61R9+QoI5jKF50cjUiE3JtbJq2cS0w1oMU/Dm+wf726VuJMH3Air4DRUVDVQNFjQ0YnWsjN9VEOqCBL4BzJVZjofTXYsGbKgMy5xkRog4WlAh9ZwuxcUSgqEJATVGNJ9XzqtzNXnQEeNN9LUeMCLl4oTyVXOKIkVEJiG9jbdo2DdjjAHjS7Eto4SzbFs+smMpSaCMBUqK/Aigg3SCk4oKA/BwLhlok9BHI5UK+LL65ynKrGQWkioU2QRYwjUuxahGacdXJ2zR5H6FRmDNsiTHwa067kmZ2KNgVNX9CgCmtsjhf86Jf0sv5iojUFwtU5DkDpb0b1GospMqCQpOTkDg5YYFPiDkBIwtEVcjOohhHmA+lkAQwZOJquWQ8N7gWMFaYucUEwxwOpoONgYmCv6zElQE7RuTqkOCigEpfCJs4diFIYuyL9QSr1Usu7IEh1ZqUFSY04IQw/bB3+paxHk4w+7JJMnilDnsqnDTg5cJEZxzTBhuBiy0xNNsAEmwRianMGCIXpDLjhbJd8siFv39BsT0kJklpUEouDiN2/jZAkQsamEIvVvQMyGwT2ry5vLH3mT6yGO8maMaE7Dsrgsjc3AOQoCVa0vQCDJ5WCeTJCDVlgM1lKIJGeilb22ZW+DX9YBXoALkMMCtE93ijx5bWWlwKcQI5LHKyUT7oFVPIqJ6UJgxC+DRGQMVXzWKExK/DankHhFLeLIh92KnERoxNKP+tspQ2iwtpMzXFeWbv5CyszBsKdI6XWETUoFjmnAqCRcCGSn8IHaxR0JJFRbQICAOeDmDwkWtbA9r0tInpilkwXUjCCsfw7mq3Kg21K7UrJpHd6X/x7X8dMc8P6vML80rgB9pOp0NPNd6hiMjEoGSgcW0AnfrFC+tB4MhCITQDUM00MpTmnb8BBRK3jMIKorqPQGRAir7AGUDUiEbTLFjI/2a5Yjy4yj8E9Lq1FhZ6mpvvaXYODCx0eur2ivyzZIR9QhGAQi7O3TgiUsL0gemTOQoUAceMMYaafCwwR3Y2MfQ3Emapr7lIfOw7jmou3YIgB2zjNCm2JZLApj3ZBFRTIqIhihRhOuQuPegWg21V7F8mbI6FmmFwdXtIK9ccopOPP14XnnaaHn7OOXrM/c7Xo867rx5+37N07iknavmyZfImnZlf0Fy3Kw+6Io6IH8Q0do45FverUBYL0hoPB4CnayYDIwyQ9mkoFI5hyNHAo5TzNmBuFlQamamBTZFqfjeeZ8Gi1day1St05rnH6ylPPkd/8bzz9VcvPE+vfsE5euVzztYzHn+SHvPgY3TmyWu0ZHyYhQ8tdAs3AgKSNkMiPnS/ZheLY2jytM3ACJe0bPJOUikjJ+OUQ1dWDQZCPAaDFKENanaLEJoGoavNgt1hrezQCsB0xaS325UWGPR0t6fDDzlMf/rQS/RPz3+mrnjZC/StFz1d3/jzx+ryRz1QX3jAefrsfc/Q5y84G/p+uuLRD9a3n/44ffkZT9JbL32YHn76iVqxZJSF7ahmtFWrJTlzgN7psWlhyUeUJu8cC/ZhC0SQuJWEHAeWQpfgxe/TjQ47NkPlrjygklZYFC2wwbqcG6ecfoxe9oqH69OfeLa+d+Vz9c3PPk6f+odz9W9/fYz++eWr9Q/PH9O7n93Se8EffOly/ecbjtBn3nofvfPlJ+jSBxyq1ctH1OmKBRY5icI4nKT7AgKJa3YPE/Sei4QN1SrGiyFVmX+KaIJ4QYaioCCsGmAQ/YVEIJM2xUoRUH0w30yCfKWrxWL6OJ1e6Oqs007W+1/0bH39Zc/SRx5yPz3/oGW6aHaf7rV5o1ZvvENLNt2loW13q9qxRa1tmzW8+W4t37hRJ27Zqofs3ac3rFiqL15wrv7rGY/Xu574SJ1+7OEcaXPq9Dp05vzINEQJpyiTOVgTKW2IpkVAxYNWaRsRiqgEkssAD+gKQbsK2WCB2R9bMqanPOUB+vIXXqqrvvo8feDtF+lJD16l0w9b0BpNKmZn1GHcc/Md8pzXvHnG253crnr/Zh0Sd+vhx+/Vu563TF9812l681+cqpOOW6k5jmnPobuqVYuRKfir6D/gAjrAIC2CJNQ0klKpLJ4Jr3FlrixOCxbsUHcyADsVmkIU4+zUZjiCrEHU0/7pGd3r2GP1zyzkl5/yaD1v9YiOZrHK5s3q7N+nrv+JaKFbJlIcV2oNScPDCYXjuHAFdjn6O76f7tmnobu26oz1m/SqaOvKR1+iDz77yTrz+GM1Pz/PFVvzoFHIACAJL2ZEkEukrMmdtNiNxcBc2QalPNYEy1MIB8YdfynIzzDXqTU8OqynP+vB+vqVr9Gn/9+T9fiHLNNh47vUm9ythZlZdTsez7BKtUR1tUwxtFJVe4WGR5ZqZHSJRoZGNTQ0pKHWkAir3vw+HTGyTa94bFv/9aH76m2vPk8HrxrPhY1w35IvsYYOEV0RfYxKmaf5YHBUeIsZlFWQxe5g2YDJsaa2oZT3VRw8IT7GsMDQNpFXZFWFKjrzf7Y/j90Ln/gEXfGMJ+jZmsurbX73fnXn5xRzs2rNzkrQhcXgJqTav7eylQpQh/uqVbgSKnZ4Nbugivtu9Lqqux11dmzXsutu0nM379RXHnSR3vy4hzMJK5iEjkT/hb5BzYCgC5uCJWIkRS7Wmw9mlK4sEsrEnjBbWe9j3ULjOfI47/yT9PnPv1qf/Oif6ZJzx1TN7VZntkfuw6rabbWip5YWVFVdtUeKRpa1NLJiSKOHjGj8kGGtOnhUqw5aomXLhjQyXGl4qKUloyMaHRtRrzOrVe0detMLDtZ/feYJesIjTiWnUNWqck4jQlQghGKQbvLO1YCCWgAsMHPeZio3ng0PnGwhbVRUVVihdDsIUAmOScPIFMfLgkaXLtf7Xvhc/f0JR+jwO9aqOzUlbjhqs4Njdl717Bwwq2Ci2wyoxX2xtXxc1fKlqpaOy/xQO1SxeAX7wgNRDfTmOmyIjkqvp17pambrFi390bV6+d5Jfe5xj9TjH3ieujzIMRxyCQZd1GxCWUSKBRk0M0PWEB6XsC2Asc0KDXaMyRuhw1Mpt3698EUP0de/8jxd+uCVisld6s521R4eUZuTRBpStEfUWr5EHRZy/Y7d+tEvNuhLV9ysj336Rr3/32/Rhz59p7529S798o5Z7e6Nac0RK3TE0cu0avWYxpaOadmKZRoZX6oOm/3se3f0mU88Xq955UPEUHPeq5ZE2uQGluT8c30kFpwmlLLIthmD8siWKlFsPIAMlI1kxFgVokAwdBOyYJqr7uBDD9G/P+/pelZnQnHXBvXYYfKxyqz0WJyY72poZFgT46O6jkX6+JZtevNNt+nl19yol/34er36mhv0xut/p49s2qHrWPDtwyOqW8EV2lWP+F7YzmxHC1wxHfqfG6q0Z9MWHXT1L/SOY4/Q2/7s0Ron9gIz4Ryd3wB0z8JAIkIR0ZcyCVHgpYIEksksWrlyXO/9h6fpg+9+mA4a2q3e1B4NtQuT3OYVZFjiGNWyEa3duEfv+8A1etqzrtKTn/JNPfNFP9ILXn+9/vKda/U377tLb/7gJr30bXfp6a/bqD997R16zts26ePfnNCuhdDyw0Y1TIzW6LjaS1fRb1tL6j161989SO94y6VsYOcU5Bb0K4o3q9S0jM4JA1AYJiEINjCImgtaM6ziewqCuoYDaiZYhKmYhMIiCTzwmp6b06GHH6Z/f+qT9NBtd6m7a69qthXfCsSTubik1N2bxqMAABAASURBVF6xVBuWDuvv192hx375Kj3ms1folVd8W/989c/0+V//Rl++8SZ99vob9ZFrf6k3fPdqPf6bP9ClV1+rl9x+h77Tm1V3ZEjMovzaM8/DwyyLOgMsVKGZuqt9P/y5Hrdpmz72hIfp5CMP4n22Q3q1CrkXxikK06KAWQTG6WEEo64gWoAffvy+ePQxB+sTH32+XvX8e6k1s0Xc8FRVtfyOKcZWjbd1w/Xr9YaXf1lPffKn9I53X6vvXL1Zt26a187pWgv0WbiyWm06Bi+A5pjDnfs7+tENE3rjR7boUS9dpzf8wwbdsWNOQ6tGVdrjipGVZLVcmpjSX192f731LY9TzXttFeJILzntEaHmj6BQOLg1SrC0gWiuUO9QX7FeVK+2shSMmSDalJEccdXtLnBkLNeHnvAoXXj7LdzjdqnmI0HN1VhzZQ6HtGfZEr3792v1yE9erjd/44e6cdNWkuxoebul5UPDWgaMD7U01q40PtTWGD49PjKs37tXX1l3p57zs9/ohbfcph/Mz6owsi4PVJMs5hT32XneaTu8FvV42Ni2dqNW/+wmvffiC3TBCceRW48BEcz3aBbSeTvnHD1iY8KJE14t+Iqmy9V90slH6Yuffroe9+BQd+8WtaqOqmpBdW9O1UhLd9+9S2+77LN64TM/oa9ecYt27J3XXF1pvlazgSUtGZI4UXX4Mun41dKph0knHCItHW1sFrgotu3r6YNf2KlLn3+j/v0/f6d6pKPwDoghZnmYvif0ulc/UG947Z/Qd62IALyoRRBqiteliOXApy9B3VBi/FDmMZFCBwoTUgzs+PQMLOB7QyN6+xMeo4fcfZe6+6dkGzHR3FB5qmvp+vkZ/dlXv6l3/vePNbF/QgcNtzXeahGi0hyDmolK03Q7xdPrVDWkyWgBFRBaaHHpoK+Z5O/t2KmX/uYWveqODbqFK1IVfvQzg26OBZ1jFy+wMXZPTmvPtdfrbeedo0tOv486HBMRoXyQq4wlEBCAkEdCRbyFTtHJp99LX/rMs3ThKVJ3Yp9aQyGRbc24Y3RU373qBr38OR/RNy7/tabYtPs6lSbmMEE/DGJP5OROItsxKd29T9qwW9q0X7LuwTzvPO0i6cyjitjvCCUv7Ov+bp0ue+0PtW96l1qjXXosHGwt9fbv0d+87mF6ymPP1xxP2hFBL2TE/CflxUrJPRrLDIiYQdoMZ4xjkZpjCwuSrq1jxzvYJPfBZ118oZ6xMKWFqQkVrrLwVuGlexT68q3b9Odf+Y5u2rxDhwy31G63NF21NNtqq8OTYY+F7ZJglxlODN0D6qgU2BWwj9QJhTqkM8MG+u/de/Ty2zfqM9NT6o205cWcYkGneYCZoe9pYu5lcX/34+v02tNO1aPPPJmJq5nMUBWhVmUQdAGMGWO0NM+VfuJJR+izH3uizjx8D4s5oYqHnoKP6L9u8c74b7/Q+978Td3FSt05Hdq4u2h6oVbdqiT6rUBtgFs7/SEKMVvSTDe0eSL0y7ukr1wXun6j9OAzKr3xSaETDhbPBEXtkUqf+dp2vfwlV2nbjm1ygBajruqOWgv79X/feqnufewa+etSIZ/CWEXJ9MDuaUAPsGWkk1rllYaTcUFkIA42SWmWY+/eRx2p1xy1Uu0N69Vy6lwtRT2NjA3pil179JffuUbzvJqsGa7UiZbmWMQaCBarIliFD/N7oC82DF1JZBTiD1xh0GKyOlVLU3Q9U0Lb2TAf4oHqX3fv09zosObFpBGLW5dmWdhZfCfZwT/78S/0F/c5Vn96+gmaZ5ELl0ghZmAPwqpWxb2lx6Vy+JGH6hP/8jidefAuLezdryp65CWiDmmuXqIrPvR9XXPVr7Sdh4Jbd0h7ZzihiFMDXTZD4ZnDD3CkKvay2uRNZV5EP0W+b4vSwf/mu0P/9u1av9lU9JZnt/XMB5ARG2PpSOj71+zlmP22puZY1Koj0ub1aFLHHTOv17/qElVF6vVq+bXEAEv8IF9iyKWQM9gDRFNBqu4vpB2aUZUmoRKYRDov4PACJurY9RvF/DKjHe6dXQ0xQdfxRPq6n14vHgi1lN3ro3WekUZVqcVVZqjo1tFA/di1sqAvAOFV0VRcpT4u6VjCn3d3TZPfQpH+i4n/KK8JM9w/LZ8k2CRy66dNc3P83k9+o+eceKyeCMxzokTUKlWtYGZKtHl4aWs5D2z/9t7H6n7H7NE8923bcGGQV62Z3pC++ZHv6+61m3Xjzlo3b2KhSbQVIkbkhD/3affSh//xoTryiJVs51C0K7VaBZAYhCKCbKD71RyPGbryl6F3X170Z49bouc9uq15NuPoaEvf/v4Ofeg9P1A1NKWqnlU7ZtXbs1VPfvzhevBFxzLfNbFDonquEkssVaGlIoeDkHJBk7KOiU0HBGaDJiK47Hu612GH6okkPbdrvwq/KtRcsa25BW0n9f/zi99okvvbEhZzgU3QqSr6LAp2FmrBiDByCTeAsQEydaYbm4LInFLeQmjOHy+4TenayUl9bscOTbekea6qSTaUF5PHJ/mI3k8Ol//sZj3z+KP0kMMO0cxcFwumlLxqMeyqrXe87XF61Om7NLNrq6KeV9WdVVXmNcHHj8/94zd08++36HO/mtKNG+fEW5F4LmomFH/Xxz3xZD335efriMPGOblKLmqt4MKQ2HsJztm2Ho1xCwGHlW5aX+t1H+3oMY9dpUsfMMyJVrRkrNInPrNeV//gtxoam5E6M+rNzWhp2acXPePU/ChRMQ+soEP9IRTYPtBFs6BexGDmjVHjVxpgRSvkcwj/9Lgjdfj2LSpeJG837/5K+sBtd+pXLPI4i7iA3X58ZpjCWY6kDr7Oo2Kw7izQRUTTqYS0JI1YdEh1ZsiZ/EArsGxP7BbY7JRC183M6Rvb9/BNqpL7mqYv31cNk9zvtxPw879Zq2efeJzOWLkyf9LilJVff177mkv1nIeF5ljMKiTVC4relKa7E/q391ytq366RZ+5ZlJ3bJvPxWy3QiPcQkRqa9Ys0eP/5GQdd/gKVfOTev6fn6I//ZMTNcrzAg/h6pKgT7k88RwbIG25nxZNRe6j3HDXbujqrR+d1jOetExnHMeG6BZNzoU+8qGbNc3339KZUt2Z18LEHl1y4bjOP+sQ7rucFFxwTJIMhCaaW8EDcAWoTBpqN+jTB5oltZ96bLk142O6lMfveoJrwTY8SQ5x//vF3Lw+sXGrvJh0pxmu0rP5dHchV+59+SZ7PJ/vCMDur1UxIxXBA78MDM26yzd794Uam1DlGaAPI1FYG2RSRABE4Sj3/fLGuTldw/tvL6RJ8pngfj5lIIcZ8Cbw136/US856V46bmwsf6t8+p8/SG989mp1tv+O7lpMGldvZ45jeEEffN9v9eX/3qyfrJvnKbSjlo/oIrXol6HoIQ86Vt/66uP15c8+RGedMazu5JSe99wT9IVPP0gf+9CDtHL5kEjDiRKbOcZXlCpErBBpq+XZRj42Il1zw6w+/MUJ/ekj2xoZwYan6x/+fEJXXfE7DY1OqtWbkDqTOnh8Qo9/+KH9mCF5QkCihPgjPyocgbFyFzDUhlc6QAe7TUz6PAtw5sqlOpkXX987g8kqQM0T5xe27dIkn+yWcQ/Zh+woAl46NKSVUWkVMOIYyHz1Mz8srBIi49NwZXkxg34yKRTmFQcmRC6YWo9aQT49ZDuw+QWfzm7ds1+FmZwh1gI6g59gO9Dr0f/wzs165OpluvQR5+o9f3kv1Xf/Qr0FqcunxR63jard0+e+tEmf/foW3bY7tN8PP47FVeOrmh9RdNJJB+mj73+ozj2+o62cSHfczFNSmdaGdXepO7FDT3z4Cr36xacoGGSQl/MnRXlymwUtqki+srIKbgNFy8db+sH10u2ba517ElcoL7XTXelrV27h8ylj6k5LC3Mqk/v0sPPHtZyvS3Zv4R+DDohpMgIJMOjT2HIwM0cNKKY0ZT0MLx4b1vDeCe4NtWpG2WbA23g3/NHOPTqY90wbztVSxdHzXR5MvsZi/gBYh68/NLSIl4NzbMA0IpZadgVCWbwB0PuqTZ4G1hcyfQtcwAdgLxvher4Z7+EIFos6T17znCgL4K5PBwZ84+4p7V61XP/8hnPV3n6NZidn1eHqrjldhoeLfsS98kOf2aS7mb+ZBfcm2bXDeHpkxrrrhX9+mo5cOqudOzt62Rt+q29/b4e6fL16xWt+pn//9AbiTeuic1frkNWj8onmgTH0vCJbDC0iVPxAxiYZ40J44mNP15c/9yTd/35r9N+/6OmYQ5kRahf47dpZ3b5uQoXN1uOevjA9qyNX1zrxqBFiSBULWhEvIhTRgEIq/EWECCGK2WYwQtifV5touN3WuZwX9dScxCiLF5Qnxxv4uWwfna7k6pyvQ6PYTERLcy2uziq0DBgHWlwpPa5eX9WsNeHpi4UQ0bPSbSgaFjnV4ly4Hgvj+/ofAPkJe9ZKLlwr+tXMDBPMmyv9dLmH1gkFWU/LVo7psr++WOO7rtH8fhaTS67L9+F2zOj3d0/qje9br9t31bzES9VgNoLITEIBDmWRHnD2Mh5S9uuHv9irb129iWO4gg9t3lPrnf+yTs955Y163quv1U6+IJGySE9MQ8bzglowz0eMc88+VF/5wrP16U89SQ9+0MEaqnr6/dbQvqnQsQdLHRzv3FP08+t4MGJX9XgFXOChbs2Sni6+7xo5NlOq6A++5Nw5OgkzL8zsYEGZT5RU5fEnqYqKm3zRQRyhR/IQNM/i9fhS0uH+2GOgN07MiodecdlwDyrygu5Dficwygf5dmsoj9f7HHW4HnHhfXXOiRx3XEVigXPesjM6ojoRhUROcvGDRQ87X6nW2dQQzHhEY2jecXwC7GNka7nqhojfYiLcB3tOfhd9/SvP0yljv9XU7r3i9VE97q2lN6MJfjy47B/u1PV3LGiODwEtwrbpPBcCujkixStEpd78FE/2k7rPvYeAVZqe496LbSGXHbsWdPl3tmsLuNcrwlXtllh0AJswkB/7XVu3TWrT3RulmOLhZ0ILfpJi+67dWnTsasl98nqqWzdM5qtKF6Y7X1TxgLR6aU+EkUrgL0rTlwqkezUGKrNCwKEgF2RGIlf18D2Y+8IKzvIFfqNc4J7kXTPL2+/GmQUNs2XmuCpqogZ0i53jl23voqVcua9/+hP1uT9/rD5+76P0hUsu1t8/4RFaxhNBl8ya/mqxb+grEuQF44NCm9E3i0kqUfHQMMyOrzTUHuIdcoW8YdyHJ59nCfF+rt0s1A6evMfJww9sc9PzetZTz9Wjzp7Xjo13abYe5vVLXLXz4uVZf/vRvfrBDXP0KzUzpSYXSaFG1OOI3LRrVp+7cgPv2Au699Lt+sJ7T9JDz+6qx73z1OOW8q22zeQXFkPKhawkhi7TpE4gghHQV9UCF8bJp6/Q7p07tOWujVo2jo7eNu8uWg091JK4Y2jrjnktzHQ1z8ZZ4CFzuNppAAAQAElEQVRzYXZOR61uyX/dXgubwSoVZh4fNnLNuCNClbJYYaOi8EyRgMU1E7+MHoYJOs9RO8+kdQk+x1XqyfMizvIagwmBC5GDq7ZSi6PiNQ+7QC+Z3K+DP/45DX3pmxr/5Ff1nN/fqQ+feILG6MNPxK961av13Oc9j3c5rhIW46UvfZme/OQ/1dv+79t00f0vYp6LnvH0p+vpT3+qXvKSF+sLX/ySPvHJT+gxj/kT0aHabIB2uE8xWL6fcpxOc5W0mIhHX3yyXvH0Y7XrtptZzFEWs+a1RapGh/Sxb87qk9+eUDB6UqEfwpE+w1UEtJrCeqpES5/8+jZd/t1Jbjkdnb5mFx/dF1T279L7XnWYvvEvZ+vlfGhwLnStdjvkjUboDFTD9AjqB8pX/eVpOvvsUb3utT/R81/8K63fOK9Qke/dY0PSGLuT7jU53ZPnuMMN3Ffx3ExHh64KLeFNI/hI4jwNtb1NiK5YhAKd/cIT1i0KhMl4gEQfZfXFcbvQoxOOwVnwNAvr14Qehv6JyAPpIa+x7XKunXDIGj1+tK3ed38sccWFH5yYudl1G/UgvvM+dNky9eju9LPP5gnyZKLIJ7fOOP0MHXXU0arp50+f/CRFhF76Fy/Tfr4Q3e9+F+jXv75eb37jm3TtT6/VKNuZ8atNnDwuQ8Qs2svme9ARh+jNlz1Es7f9SLPztTr8QO782kM9/eg3Xf39Z/dI2HOgiI1tMnnRn4fvhIonqCYmR/iuiXm96O9u01/83Q5982e1ZjvD6TdcT+k+h0zrbS89TB94wxkaZ8zpbz8Dg+wSZ45j88mPPVSXvXyNvvKp3+jK/75LN9w6r1vWzYpPujl49oGW8KnNYxG5dbmAfEUb5tigLd6XW61ahecDL1wD8CTry9FzJujFBSUGxogyI48vUBdVDKhmAX2FzrLN/H11HhvfozwhNTPSYyF9z6uR2+6I8REt28Axhb24moNFFldt4ajW1JSO94u6JE9ynUspj0HBohfiXfH1y3XeeefxvncmMunGm27S+NKlesYzn6F3vuMdOv5ex8oPWS36q8iyhV+0Ki2N0CNGR/Sa1z9NQzuu0zQboceOrhlDu8xpy+55vf2TOzXDIi8ZkcaGlb0XaXHshBRrwPOD1PXpw+aqiDHLU+3nvrtXT3vTnfqvH01pbKzSLbdLM/Vy7du9S095+Lie/LAj1eHhp1eHetzravJZgD/7lHH941uO1I+v3qY3/9063fvoFTrvtFVatWJYdUjBKjAEeVqGoFeMt3mWCXV46l7gPjo/11OX48K59Wo1uYpigQGyy1wXaNzhCOoZDTBVhZUqqvM8nsNw1pc+i9JlpB0iBhO0iq00UpQPPkTAPbKniNDk/mnN8QBVs4CFhezwajHP2/kcu2yBe/KkHQD6p20qoVjgrrwwv77+19q/b0Jv+ts36dbf36I7169XiwX74Q9+oE/85ye1ZctWeQIYm+xHz3zcaOlS8rvsVU/SypV3avfam9Wr2sTsKXrzWuBj7bs/v18bd3SzQ054rR6vND4S6hEEV9UEZHhaBOQMLCeQPc09XOpguIcrthfD+ssP3KXXfmCjSoxpas9ePerCNRoZbqkmIS9SjwEeumZY//y3h/MwNKfnvmKd9nFFfOxfTtW3PneSHvmANVrohQqDoWsWUfKVesiqFuOrxUWqHnPoC2rfdIeHPBKi5gCyoaNMUBpqsQkiVIkSFiZItq8ZkXenj53tDGAfkT2QeeTzXI2+0g4bamuYACP4O4ghoFuM5BZeD24fHtV8u80F2tUsQf0psMti7jpkuX4+NY2l5Bf7hz7soXrPe96tP3vKk7XAoo+MjjGQWr/4+c/0lKf8mf7rqqvkCe9xpB951FE647TTddzxx4nPyUxuKH8EiJYewQPHZc+5VMc/8FBN/hQfdbHpqNfraGi4p49/a04/uqnDfVcMXhrlcqhLpVOOGOF33JAntJBnYrLzWAyQOmJVWy98xLguPX+EeIVJIy5H+yxXz0+u262tm2d4iGFMfHXits7Chxa4olYua+lf37JGfpB81itv1+ZtcxoeKlre260lvb3EoUNmnL0q9r+4ZtSmw+MOG1Kw+X0y1ByxMNqwZZ65pG/mEJN+DbybNYtosq2sicFiMqICeEsWB2LLekH30m8uKJt7nqOky9eh07iHjSL3MRcRkkEE5yzeyT33HRu36HcnHKUp/9xlHZ/fZo85Qu+fmtHtXLH+VwqXf+XL+u63v8Mg22rzZPv1r12p737n20SRPvHJT+qZz3qGvv+d76mF5DOf/pRuuOEGtYeHWKCRXAA2N0+fRY/sdPV//uRinfzsizV91ac1wakyxSkyx0PSMPfNb/+21ueu6XHfDY21pWXcuJZBtNttDbcrXXjvMXpQxmQkSTtlUuIqHtIHXrBClz2sp5c9rNaRq6qc2M78tPyacc4pS7R6yYxmJia0dcse+eeyaXbwfY5q6SNvWKbde+b09Ms2666t86q8csxvZ4rFmVpQjzzd2TI+cEzMSEwbJ0alU+/DpuatotWSqlzAWtv29mxKn5GLmE0URUoFW5LKBS3OHt6LWbiHFTrlwuSJtWg/xBYWtgZ30dUs9Azn1eljQ1rKVbqakBX2Dlz3empzxLZ5PPnp1t16OYv6HyuX6bqDV+kbq1frJbv366s79pGUNEK23//u9/Q3b/gbXfZ/XqcvfulL+u53v6OfXfuzTGwrP5Z/7rOf1/TUlFrk940r/0tvfctbgLfqe17kVqjN5fBwPnb8zQXn6D5v/At1vvIR7Sb+LvKZ5D5ZRU+3bJL+5coFkbpYx2ZRR1oaJndfpZPz0uEHt3W/k5pFZThyKTQVg5phU/i9cOP2DldPrX960aiOWzGtO9fv0PMfMqRXP7atPVt2quZZ4ce/3qcFjsgHnlzpHc9boh/9fEEvffterV7a1ufefbje99dHa9mSlmZY0Gleqwpf2+hGK+h6814WlAvm6KNGdcIxo+p0gnkKsWaaZ/7vpn/n46UTxfmxilDY0KqfeC6oKGkAdi1YFiYlOGLnmIkbCFiR6DwLBqkpkj9yuNLJLOqh9OIX+g5HsT/GPwK/bqcjThat3T+ld2zdpefwEf3VW7folxOTXAWhuoS70TA7dpQPFyNDwxyD7Vy4iEZng4hQhEEcY22NtIfwaclX86gqPZAr8xX8THafd/616m/8q3byvnkXx+g+rhA/UOzYL733a13t5r41zskxym4fGm7J9+OhSsQMnkxDW3cv6IFnjOq8k5aI9OlTYlhJd3tFH7+6q7v2FTZLj99PZ9WbndNvfzenw0entffuPZqarPXpH3T0g5vm9MhTpD+5b6V3fn5GH/7aDGOV7ntyW488Z0bnnzgnHoS1Z8+stvN+O8nrSDDQZaOhTXuZFy7CB56/RmMjXfm251teqyL/yQX9Zt2ChHHNQoFMwoeYHsA45FK5CY+CRTQ9IG3oRbXsZ+h8/+uwmnMs3CzCaR58HnjECq0mwhr4BRZ7hN6GCDDJgu2zTJFXuTeC8K2l3G0LbJQOtj3AmyZ89BDXM9jkgqErsYwsG+IIHeKobxOnzWw/APw3B63Q/d/9V1r45v/T5qt/rlvLkHZyc52YqrWPJD/4zVo3b5V65DhPoGVLgg0hNk9oZEgaH5aWcH9dyUv9th2zeuYjVuqM48achoboo03+7aqlzfuL3v7VWt/6XWgbm2T7Dmk/m2R2odbejvTJq4s+9d2Ozjk61MLvH6/oaM9k6KVPWKn7HDWiwr1hHttZPjl2GfvePR3t4H5615Z5HbdG2sMGdL6rVwzpCQ9fqf079qpm7B3u/612V7dv7mkn/XnJuL64SEMRBv2PUlmSVySTSxSM2QJUCCnEV5jQulalDRxvLRZ2lo4WwJv56H3G0iEdvXRUpzLoHonuQH4C3wOfBv4zSeeDe9iLBa4J5qc/Q49k2PhcrYXDuWYCyYA+qUIlul0ElERS8l5Iw315SLts2Zgueuer1bv++9r0zR/p5hjSnbwi7JwWDxihz1xb9OO7pJqr0g8bk0z87pmiNUuKlrZ73EfBoz0tH6u1crzWivGivYzpr59xjE45aglPxfTZrui31pCKHPcTPy16/3eKNu4SgUNXXB96xxXS5b+s1WNAN9xd9N+/k6bmQ6978hJ98KXS658yykNRER/b1GFRvYm75P/jG2pt3dXTYaukDTsJh/9jH3WYjj64o6l9Xc1zK+mw0Qvv0N//dYf3aSkiVKKSBGZeqfKcyYVJM21tI4QrDSXslYVFbBNkmsf/n7PzbDzPlTHL1bKXe8tdOyd0/3uv0b0wPhHbW9kUHyWx38PfRm+bRMcGOkNE9GARDQVc51rVLDYPhOylTEAY4aEEN3ZlTTgCQxGhU9k4r2MTXfLWv1T9219q02e/rd+NtHV3XbSPn3w4cfW9tUXf4pNpHYSrAUKLsperdueUdK+DQys41paPsJBjRStGa61aUmu0mtf89A695xXH6ESefueYVDolN3ImDuG0fb+0k4/pc8T8Pd9gd08WbgHSREe691Ghh50deeW3Soen3ykt7JtRme1qy90Lmp7sMY6imzZI/3HVQv6Tz/U7Q3xF1fFHLdPLnnmIJjZtU6fX5rWdDkpPvrf+9OY6+2D4jMIVXaIi52TS2OA1YmILMkN/8JCshyIwYSF9r/sJ9G6sFljQafQTzPxNG/drtK507rEH6RJJh2FzOwP/Jfrr4O/GJu/qhCEYi1iQAOgx4+qkvyioAOxDzR+kIBvXgAR6kk5iMV+/Yoke89oXa/am32rtZ76l3/AeuZ6cdvMQxJrqls2hy28XLy1Kf/1RuWtPT9snejrjSBZyuNZKHtWXjUpjQ8G9S5rnCbw3uU3/+IqjWNRRJrtWl01X7hHn+78vet83i3yPdp9+5Th6jfTqx0tvfqp0Bkfv7smu9nJU79tXa4F7/Z13dTlmF/JK/cZPuzpkWcgPZHtnQqv4bfQf3nIfLe/u0tT+rmYJOL/QU1V19S2u/o07C88XJEASTIU8N2KuE0RB6Dy8ZrmgzLJrgmeB/LGNZqEJ0kKzmWP3JyxurdA+eDaq/AT8vZs2MfCDdMLq5XokuuUEB2lYSmjRsUU9fHz8+sjxvblgVLBBrIhI0D0W1/JUh3JxzibjNx19kB7zymdr73W/1g1f+pau54vKWpLd3T/KNu2RvrKu1jSOHljGhx5UyxiGfrmhp/V7Kp1ydFv+YjTKphhqF7XpdCik3bvn1JnYqQ+8+kjd/4yl+V6cMdCRqvbRwS7A/97oASdL550QGiL45i1Fv/wN92/u4Xfv7Oln1/e0e3+tKS7nHTtq3X5XR9N8px1nI7E3eViTjloa+vDfnaKLTtivret3anIuOG57qnkP9dX55Wu62TXPpKwHF0ByJCIDjBNioEHu1pIGwj4TaRSWW8gO6Zsxmdzt9W1+QtjAok4ziV7QSax2spu+c/MGXXTm0Tpz4o9wVQAAEABJREFU+aiezJm3mjg+7lrYVu4Qu0HFVQbWDquS4EwrBJlMGVhKvtf6uH0Esreffi899BmP0vpvX6tffPenunlpS3eqJ/+bXD8o7COZr62vta2nLLiIkSxCCmnoRsHt4Vt8071je60TDhMLWattY/Tc3pjMol275rR363a988UH6c8eerAU4TQ5+irmRVmOWCVdeqp04dFFfGfQVjbUXcBOctnBcbZlu7RnomjDjqKvcWRdfWPRSYeH/Py3b2+tUw4Z0f9733l69APHtPG321h4aY6PKwvczqpW4cm5aCO+THv27QuhSTNIpwDBWhUJ1G5VighV+qOCWsJAFF/CQlB7QTnWdvHu+E08ZpmVCZQzKBewu233tL5z85160Bn30iMOXamX8JB0Cvdd34IWsKvpCLMMiytJmCsND+mruMKnCoLTd6+iAU7C9zW8/P/TRWfqtAtP0TVf+J6uvfFmrR1raRuzsp+HoGABJzm2ruSBZGOXYFS8af+wWpZAU/nwZ0xfuWZBv7yt6DAe1RGrLi2uRnGFcMxySezbN68Nt27XXz1uud75V/fR0YctUQd5ROQrz62bpQ9+W7rq1xK/9+tm+LVbpKl56dZNRd+9LfSt26TNk9Lt3CvHeQfdOyG1uD086+EH6ZP/fokecNawtvxmoxaQdVjILmMaHenpJzxcffXarpiGnK9gOJ6xuhT4GkgBKwB2JScjZlBMLOa+bCSfevCSG++ImoV0DOZPLejfMenXqCkzKOaYHH4f1m+2T+jzv92g4+59pJ56zsl6y/gSPRf9cQDRtUBmXqgaLDqngtBA1Ir8td7/BGOI0Kcw2a9g83zohGP02ksv0eySpbr8s9/XDVt2aPMIRyIPC3xoyUHtXwh9Y3vRup6IInlAISkGAENNXX+IOUaPjdNPn+YL0uU8Ea9cEjzRd/kG3VOPRVsA/IqxwCPy7eu26KIjZvTZd52nFz3rdK1as0TdbhHTIT4EaetMpTlOpp/fXuknt1W8mlW6bUelX+9o8fE+dOiyopVVT1N7al1y7kr9y4cfoLe9/0E6fGyvdv/udnV4r+/xoCnGNTLU1UZeeT78ra5Y38yb6ciFiwj4yJGxrOACD6LmQoMrQNgp0qXIA6WVX2oLSvM1Z1rKeIK13c9YVDYQS6n8TruAvqaf9Xy/+tfrbtV1HMNn83voZRefrfesWK5X0cEjmKAT8F9Jdm0vMsFr6AAOYmbu2+3qqdxY/nZkWP92whF6/aPur9WnnaTLr79Fn/vBz7SWd9DtbIa9xJjiSmT9tIOvKf+9p+iOWuSvA4VcRJ8SBP1EhCIAheiOg1oJXcbBDxr6Bsfvh6/qaJ7Y40M9zc8XkRJzIHAR6eruO3dpav3v9H+esEpX/ttD9dbLHqAHXnCkxv1EFZI3wBz3coOvYnEFjLCIq3nhPf3Ew/WCFz9en/riS/RP//kUXXjBGs3+bq1m79qkLkdshy9vhQenUX7V2cvV/fdf6moTP3pzOGmxkGvSjEMqjMQcHVMbykTkhpYwsokT9y72IhbhZgG4BvuzXk2gygZM7LXch+5GZ7sZsG0iQjO9nq666Va9/we/0E3R0qmPebBe9tAL9YHTTtRHjjxUH162VB8YHtI7h1p6F59NPrxsiT5xyGp94qSj9UGO1uc+8iLFMUfqszffro994wf65aat2s0Nzk/V08yyF8BX8h28JnyHV4a7/8diRi6Ax8AIJMbJkpC5JPJzvl5UhiRWS6YR61cc2f/09Z7u3h1iD8rvlb5SA8PCRqtawdU7r7W/ukGddb/Scy/s6jPvOkdXfeoS/cc/3k9/+9rz9YoXnacXPPtMvfiZZ+hvX32xPvahp+lLX3uTvnDle/RXb3qUTjl2TvUt12jiV9epu3+nOnPTvCbN5r9AHGEx97NL3/WVWrfeWcQUizXOvBmCclDy2DwCZWnkJn1dmsPPrGyIqyfBYnnRGEhDi2BZIajslDb2Pjp/5kXFyJ2zseSn2OBqHWWG9vKZ7+vX/Frv/9r39PENm/XTZeOaPP54HX7fs3TmBefqEr6/Pvr8s3Xhuadr5UnH6fbly/W5iVm998c36KNXX69f8x14Pzlwe+TYKhxj5MBYZknhBhbzxxA7a2TwrqiMGDcUOZGCPCtBrgJCjW1EwDU0ltg3igDdzWvGh7/T0494eFnG68z4WMmFZchq+WZNPtFqa2pmTnfccqvu/PnPNb7pJl109Iz+4jFr9LbnHaX3vvIYvf+yY/XGFxytp17c1jmrf6+huz6lmWvep5nfflNzO3ZqbnZBU1NzPPF2WNSOlnAqbNgfevPni268Q047E/S8kpacp/pZh5pi7J85hdynac28i+KlFWOELLIBLYMs7Nxa+YrBU0zhcI0IBQuowBTcjuArTOgG8DqLLAdzT9e8ihYMTMA+3utuWrdRX/v5jfrgtdfpHb+8QW+/8Ra99Te36vU33qrLfnWz3vSLm/ThX92iq25epzv4HXSGK9ELOUmMiVr8TMbEEmsDI/vOgvRLgO8DpOJOAys6/h81mnslVgIKeUY0tgVeFCxom4pKBn9R+sr1Rf/x3aI9PMofvCo0xBz4ntnjttHlnjo/39UCl8/cfEe7d0zpTp4d1l/7U93+4x9o/dU/1carr9GGH35bd/3kKm395Q+1k990926b1p69RXv3LWjf3jlNT8ypLHQUQ7WuvDH06o8X/XZjqNWSnIhz0aAEBCsV7KyoYFAWRK7Foyc/pGaFGZshtag4fwarzfxhUOfiNsYYWWgG8AS1FAoWdy1wHbS/3zL/4hakacyniWDgVidF8FDVVWd2RhOTU9rZh/08Hi7wrtAlUV/1vIY1vvjzpU5zkvYC1xP4JxxJPDzm/Q+1yFi5ajpQIshJkYJinGRpeOdvWXJNE4EBlaEzERJpsH2lX/HE+gE+Hlzx455mZmqNtHq5iNNcXbN8+Znjq9Q8C9LpsXWjQ7Au78sdzcLv45vtXmx2TvEemh8Yutq9d0F7eGrey2/F81zhPXq5abv0N18o+tvP19rGx/8WC4OYITX5RoRkEBhR8YjBCFUQiWK1wSawahYUqqRFuuieBj6GJXZ2IZJHnXaihIKFjAheqkO7mYlfAjeh2Qb4vurFNHCr0yT+nGjitUy+uqz3YnFyaorjYorYkwa64Sk/bfaEdDvwc2RrieljHVaiT/ULYZO1PMKtlC1N7mZRoJtxmIahQqkxLIlIXS6O50kxv5MOv3pD0Xuu6Opb7Kh9LGyLhfXx2+0u8PC0oBkWeIZfTWZYwAYvaG5ujmN5lmN1WpOTk5qcmNLs5IQWZmdZ8Jqn30pv/VrRi/+1oyt/VtT1E6XYT2xaEBeR25CHQ2smYXEManKOCOQDgKQ6dwIUosGxWN4k2MMjg4gIjt/Cxgn5SEaBYWRnRQWMvEitquIIrnR3q9JNRL0Fq00h7QL7CvPV64XyAnsRvZgGL6zBi2y7HdhvAryAfGHTXcS2PaKssE2+ySn7j6gUXoGESgxDLkH/ETQKVeRnSmwewUe0GIolBqnCrgprtFgqKN5GdBeJf/qaWm//clcf+26t6/i+OcEVKj7NVVWPkL28en0Ud+a66nIkF945an5GLN2O5vnlehM7+Uq+Ir3xi0Wv+mhHV/D5b4pfWfKq5Ok6+otJlwoewIJcJBpXmAo6AFcSlzcedyY1JUANVFBpU1Ry4WzoSYPFyYtlruQxUAicxihLCZm1vycLEf2EHLCOSntJar0k3q3Fp1XdDe3F8qJN4DgBzy1KXmgvOiec+HFEfFOXact9kOmPiuNHXxYRizlI0FLmKeRQ8u0jpIZ1gn25KAXebKPPVuG/QAlQVQpDYqJtVxD4F5cf/q7WB6/q6q0cle+9XPrED6SvXS/eP6UbSP7GO6XrGPj3fxe68teh//hh6K8/U/Syj9X6+8tr/fSmLh8hCj2JBy4x5/TnSnwj0VnIm7LiIpKEHJF8MRkHgohQBVDVlAJqwPOjVJgXwwx3UtMRNFvAgwqFUAkhjtDw6QNG0FQEHnSGsQSioOeVUb4vevG8cDvR7SCoscFguRfaV+lgEd0LplkHtLFjir4kOHAYkxykBF1EyQYNQueEhBoAFRm1PyGhCEAhdoLk2Qg1BVwBqJN3SPNtNqrHtI0dec0G6fJfSf/Oov7TN6R3XB56O4v8jitC5v/5W/xW+mOuaJ7mdnKP5I4iDgo5puM5sOmg38wTJhRsJGuLIkIMDV4NraYUjItJ1FQ10LSEssbAAhaARXQQQ7GpZTC5Q2wGbeS+jAcw4CMcuC+FDmer4E8Jukcp0AbQgYrPQBZIDQVZBSgBoZD2adtGgbfMKiA5mmIbG6CLQJA6Cxo6qb68PywsqMiC1U29hDeAjFY+sblo2dtFFrWYQT+Zepg9STX3w8HCDbUlflIVe4BoanxxLiUU2NrfOPsu6BupNeyvgIukZco+ZguG6SA70LhaYVyyn1T4hjsA4cQ+wYIFzlYOKVujkh0aWyjiW2YeRdaIUFW1GEjgJ0WADZJCTYlFihgWhRvAwUDJ4qMqZBQRkCEzURVQwREQBRtaZFJUkhqz1EMqgpa4RqnUYHSYeHJQB46FSZMqBX9ph4OnqKBLHnm4L3eLThRuf+IhnYUUUHjVE9NnDKD04tocV9m3VQmyAOAgD/psuCplgxmvRRw7g62wPPMLKSoALEpJsBaCigpHBjUQhb2DjlBGhFv5XmTHml4sETZWRYQiAIVFqjxYSFG8wPaBRIsQuwIIiGj4iIDtg/q4L0tbOwMRlTJeKcJqcfcG8ojAQnIbtL5aQ4yp0KSOseAHRwy3qTUBoMPHpnXfJuAF1MyJcRMCOwjPkfOIsFVh6W0hediVZQCueDKtIZk2OL6ZgKAqqipBMg6pCqkiZzyzjxCl4FrA1GIB4ABIZd4qi8INNrJADmOGhI2AZiCNUj5fPNCgM2P0jcYtQgdB7iREJ5B0VykiAImWJgAqssoDAUeEguQijP8niAFGHJC7NxwcRM40IqArACylTBRPNkgFiTFZQxeZpVVTDlDWO5T1A2AYMkQ/V4/NG1p2I6/Sd4igb6ACws7oGZIEbx/VIQmAr0CiFGN4izEnpC0RJhOKGEClChqBq0K1zBKCmsb49klQOLDF0MwKbaM2oaD1R3Pv2GaBxBUBZMSQJ81y48YNj74u0rtkGxE4UcFQcokI/eGiWmOQIuIAqE+D0TDvjtmXYVdEiYK2QDTVU9Nw2KEREOoXDxi/6MsCcUTAQdCGKkXAA1JQAdFtAnRWohMnIkQFQjRUY2xBqCGKIBURzBtAbBlCFJqCCRQGVPhmEpF4BOYDP+hA5Nq3Bw0ckTbKUEBT+wjKPUkRoVBT7Gg6ghaomTjLvIiwiggFpuZzAAOGxEhDVqY9BKZyFhFhrr8ZiiLgYzCJ6vOWNaB+wSQTjAgxSuyIlnSyxLNcSoVJAAv4klCUAqXMCTMWuyPAt0hmQNYXsVlFwdcjyDUAABAASURBVIahpN6bNpBH9HXEoMrjLpiaSB46oqXIq7oShFVAqCnGBnuFh0KXzBbOcIqgBeg0zdGkXgFyA2CKjjzovABC5qp+SRE0vdvJHcEJXAAHx9oDsiiCyBA1R7CPSiWPPaa2qRT8wQeQFcJx0Ic1tg8U4AgTpGx9ikIRTnQgK/AoqDYpYNTIbAOTQmhIZ+6+Sc0kiBjInROImt5SSAnCDJGtLGomMAWN2rMCi5UtgYYisJRJCAEGtTGQCqHiHg+dqckm2CjkuXIu2R/+IbINCYUSyaUs0hGMy0GQBLYCZ45F8i5ItOhozqAs3ocmKjdiIO5Yfb3pwuKlrt84jo0tLtlpkRMmB054BqFwnybwQEdrHYicilC7yj5aLMiz04J8UZhEBPH64O4MqcimyA4RTAD+cMqySMCZZlwKUSNBFIsF1+BB6zgHpCKu+iUioAygxlyDuY4qMDVY0UCQaGDqiajpn6rkkVtmlPNnIeDwltV2xy8CIdiboHiy7Y0sIqACjeg+wE3OEE21CMprBOpHS5e+holKF3orpcCJhbOkr8cFFb7mYdICmoowa/FoklJGpmFx3WUoIuRiT2MpFBGSQhGhpgxww7ltVMgLQwYsM0Qg0z3AZObUt7MtnQU2EbQhOT0DFBU7ywnmRVHakSs+KKlJKAtkoC/ExIsxpbRpOHaVcWwhVe4gGpVbkxGh5o+wUItXguUhJDRCRz/WIYah5vdBC4tSljaF9kAl4wOMkxOxqEayaYHKxEnemQ+WNJCnAY2Dm0//0o+XwqJENI6BaSptm4RMBSSATUQogh4KySMdtBGNHIQ0gCK3EJg0lNOzHm/5FPCiWGOMEV1ndomVO9/etjCW5w2zvk2BFyzWjQLGwUHqu2BiAxUWzGBTWVnQ5PkXiogUqV/ghFAu2ZP1ONpFInMIz5NvbamXywE5pvRXlHpszduiQBhMNwtKDmaImQ5m60zUUnNOBaCas3Op3OaYcEPhQYDsEY0kle43ZZm8Kfw8oQSyKAGxJ96DMcDiiwGJJp2NeYvBONHSC/zAho7sa3khd6VWErbql0hM//IkwaQx2BVl+pcDQqwW50PEiQj5z+buGYZa5A1Ew9o7dkmVm4yHjxRUokFTlYUcC4DGWgA/FAUqAmmBybpIJIdaEejhIiJpWvomfikcxyhc7RYmvDDGCSmBsnaAigZS4jlvdkxBKeRoEDac/qB4qIsCbLBMX6/HH+hsRADryQ+uCHMw5iVREtYP7mEpxSj6w4lAS8VQLqEwoquiiACSpSl9aCwjAp5qbGDC4bL2NY2vdZbaHUUEDXyaQzrv2k0fIhCil1FfljQZKQkU2AR0SLSAeSA3hX0kwTaJKhTRLKAGJRoir9CcUJxCgQPgjnJhiyLMYwwfYZpAAhdk96iF0dSWAWhzZ9vMUBavyFBENF4gTN0TPMxiawIeuwiw6K8UmYyIRawgVeS0QqzgD08ZFeRUYofVYFGgWfCUu0EiG+NMVUQo/8Dql5I4smVAGSddU8HUYWvSi+cTRkQQfQzetYVeFOfT0IxFoQh8kWeNbDO2kw0FF0gjMx0RqrCPCAldhLFXzD2rX8IaCV1Grvmmt2iSGdtAsoGTwY6+sECXmhSEJIMoIYtikBZ9FQvQuKKVgQhpETGwtFYcFzpQQkKtQYkIeF4LHJP+QY0KAhaaWAUgsuODkA2q5dDRh74y5L++rB/H42y+kkl0KZeIMAIyMphpyNYNjgr+KvIPCxJMOVYyNBGWCJuCLViOUWhdwdTgabnq27mnPmkDfPpjYIwpyCZS7rY/JCGQS+VG5ghsZclohC1Bz0VmnSAXKEkhwsi7Ea1cIkzZHlsLZF5pK0rpA8jOwAFbWzruwMaY8FwMSYFt3tgPFk8ZHz3OVJsLqwTzEPeo2A04k2nQnyDkg3GkGD47JKL78pgNjSyyV5v8MYQFbgBPhX0tSj8Yx0g5QtNOQ0TDXAKLghnmpc8h6FdG3sgxGNCNqjRDNtMEkjeFyVzQuu5lMDtVOHuSmxVBgq/EFRKBuxlkUIvVIlRWm8yezPQNUMlso5PMi+LBgaiOZ8CTvhkBFb7vkAi5d7Dj4LBYzTtXYzlyBrdHMZcgisVpU2BYMLcJKUwqm4i0JJFkFQGfsChqFEKeFAH7ZEFGmkidewELSQPKgsyxknZjR2xNOifU1OSCiynSGzboGz8QzP9eUatwv/Oc5oJ2u121/KMeEWsCFSwqcAbJLAucA0uoBOUUZFWmVJD0QUov9FwJKWswFsrSqCUCNf4BGWoWLARDjQPgGBp4BwSgUESFFCBORECjwjYi5D8LII2aPNEl44aOzRYsC7wBRDUFBCQVipa6SFhhKIowdp8Fg3tUxBHZyPOIIUboLaNfCR3Yky+Rv4QkFBESfAAlRAmFQsE4I5jDkCJoRLlHl4SS79l8JJBvnRmx0+mqPTSs2g8vaqybNhaDHFg4gqN0Qo4fgY2CXiRINdmrTyuL5aFI2gmY6HMms0fHM5gJbNMnUAMR9AnpHPIVwTSBSEM+SSCVBVtjyxOYmSCWgIjQYhnQi45SI7INYGdRrIeNoIEN5sfgMWauUfp+KLMWq3IDJUvjEEX4FxhwhgqmPYmiCI/NIzPdYMkyCSR5pTwpBZIaCHGBokI4jyHWDjECsR1AszMzalWVvNIRIfsHmUChbVoxOep72cSgfnEaJvuWkE3v5vupya7hBlWoXxwEhpqCiLAFG4uI2DlZKyIaeZgxoFMCdvxMZXmEWyuliJCveCHCQh7QgVgSaqFqwISaEhGLskBkIBkWqCgiOaSuoTDqt95Uyfb5CGsHoEbKfDqXmqPR+ahfah5IBzwm2BY0pcGl0Tj3DMmgEdEOZrXhRoaHtLCwgJ8YN6jTWcikh4aGEhNNhQhpHhhQYZUALfWFsoUkFKFBJ1osliEWaimoEJ7o9ILWPUpEYEIMYyCHUiItPFCUSbtJdZ9orthADaCICGsGmanPSojdNyhDyyWVYVUzbnsNZIkxAgfIE1+gBVCxDNaRfJvBIA6sBjUUSaYSykuZSBHWWF7SX2bFFQtEEA+zAwkKdSTQYV9c5GJpYnyGhoY1Oztrlk+NoB67ZG5+TkuWLFGBRiRPYkTjFggyDHwxQ3TrQWmXmMayAbh32ybPVYSazd4MLCKDKKLBMsKw6YPO4CNCXixaQRAu5BLqDzqUVAQ8R58jBx0SRvcsQdBmIbHrK3ARzuSOkmommFAh9NVAZ6lLlWWS/C4I8jDQQRHYfULlwjR+ARsKvrlaFxGEcpRAVgGReggwqkpNXGJpcLQqGh09pacbSywGoq+n07Rot9vEkBY6HTQhQirL1NSURkdG8ti1wLkkpolowmTSdFCYuIgDE4QJNTSYuMShLEaln2zQpWMYrDS2zOMhLKJCnkVkyqQVI8B8jQxIi6IIe8FQHQNjqu0bnXQPvZQbCSSMAGqBAwiTRDMSBKXgiYhaAMGFRIsPmSTVt0m5ExfFDMhWjmnfFGGbzthZbplvZSRkUzywpGZoc6YbBzhbe0wmTeOC3hKP2aF97Y1zEc7MzarmTUV0srig/tfe3V6tsbExFVsSx07EaPprYiJ1tdS4gYHKUv8DrqbTRmdZQzVWEcZMoYOjsC3oDyrahk9bSGwjQgE5qINBDZKLGGjpkYeXxu5A9LTHBG2jyhZBRW+gZBd7CEUEIvvf0wPacqvQum/Wqplp82oUwYYv0CVljTr7X3RA4ThpZyv8oJFSzQtvA7mp8bcrpBwnMffiNs89Y0vGNDnpfwCLLa65oI5to/3792nZ8hVSVP2AymgOknPExHqIVkKiJBFaywjXp/CNsAmdIwopiGd729GnBbpnSZkwRGjaAEnf2UrEs6zINvTkwRNTCZYVDYpzNW3siY2Ixsu4b2ZkQMSJEJgTk3aQX2ISjkAHpO1gRm2Hjkpc/MLWghYFGmMqvFuB9b8W3Ppy+oCK6GNo18bblOUNRIQiwkL5jWTlqhV57/RrZ1+sKrV9b99YZ3jiXbFyhXxf9bxZ5clh5CKafC8JVZAObFAWD1CCN4ET1RyALW0wArRQolgLysqkJJsNklBEJHYoiAMVgTUHVto+hsYkIuQ/Swp0iUZu3lSEBQ249RoV71Tiph5v4wEUyw0ISvpCUAM7Q/E8mA4yopOAVgILm5ix9fFAh5kikDMfeEEriz3MWJ/9Ii1Bo+BPQCgLBj5Bx7kyR0dHtXfv/kbcz7Myh41EJ6Ls3btHfn1Zwtlc93pIpOBYopVEIlzqhUkoBIh+H4FcA0YUdHl59qNnssIq0AFUiKaarjJ+w6uZZZiiZhPYwmyRN1XG6scnG2VBJQW7tiTIBRvnmKo/4IucakRFisUaeeIiQoU/gQNdRCiigcYoWyGBCMAVf2xKgR6IeF6IMIPO8VDhJCGjGvWltnGfyuJcSUhCHEEjikNg7bxq4tqmZlz+CLRq5Srt3LlTte+dmIrNZcRUhjFzVRwLg1p7du3KJ96R0RH5/zlHzJxnd1ga62wtbLwl55BgYwsBaiOXKVsbmghyQex/kZ9k4yybFppk0culuDGEgsk2pXCbjQlSqxMH+pD/RCtVBIqIhjFWUzxJGbavatKO9HGWhmhMsw004dhVSFS5gD3JJn1y2cf0Adxwbm3HWrgbVQTAlRZNJgHOWlIWtAF/j3ThJC9mu1Xp4IMP1r79Exy3/s+90hJ9AaJ5bRHFrAFSHT4F7t69W8tXrND40vFmUe1XSRGh/AtoSbA0ukdBoVBEKLPPoDUb5gDvybQDEhnM++mvfwqhQoJfMwFFEVgZ0Ph90PsaCZx0AAd9wPeDRISqioQdRC7oQ0IsJwYpg3O0CT2atGoRvAjsFOwtKjQ1LJaQKaSJCOKErx+pTweXfEgy4IBfge4DunyLQ+nN7FNI/RK2KmYKlLFEyASPe2RoSIcddqhmZqY1OTUhKXSgNDQjtqhhTA3AXx527tip8fFxrVm9Rt6BhePWlk0nIXJLUCMAoYUOBYNwJGxAxYYqpqwBQhEBf6BaG9HIQpEKsxGOUQTqy5hQ1AUOKqNCUkva5CJgXJB4RxvnpMIvVoS2C4UUlSJCIemekwuTsYusQScX6NJgI8dIQOQNCaKSFWYiZgEizDTTkT5ETUkyUAXAy2YWQcoig8TYub3VHKtLx5dwZR7Elbk/Qf+jBNbBOhGJqv+tdHhZ3bZtq7p1VwcdcpCWsrh4cenX8o4JnIIs6JarA6IU1EUwgLUFPhSBRVhEI5eQ/0wZTEeESUUcwKHoy5iQIkUEUEkCG8yLAlYfggVCslijTyV2DEH1bWHlRWxY5Bb07Y1C/IUUQf4SWBI82SgCopl1QSnCrQSxuH9SMmgydqAOievZ5hHQAFUoXMFU5rHw6uhnmJHhER16yKFaunSptnOBTUxMCi81JYNCWsJGUhFPBvBpYqHpP4Saq9LH784dO/iA39bqVau0bNnS/B8I40/yBHLn/xuQWN2XMwZDFr26AAABeUlEQVQ1V0zRQFaIbWh45P6Pe2yfu7LOJ+2BzleCadsTNmMUbDFVcRzeoa03OC8hE4b287CzbwjbW1fwrWF69jPAY46qAM2GLejTjofDQrxeP7+BXHRUcMIDn6LiGAk96CLn4mcQKCyZV+IlTyzb1lx5DdTY19j7IbSo3RrKk/Ggg9Zo+fJlHK+T2rZ9u3xqepUYhppirqEGbeW1dFKN4H8aWG7pwvwCT1W7tIt7a48BLuFqXcniLl++XGPjSzMBPxmPjS3h48SSfKgyPbpkVGMJY4uyJTxy+wNGA9imz5hGU44/T9iNboxY+PX1Y6NjGuXDx6gxMDKyRKM8uidgMzpqHhvLzBPHsjFs0yblo/QDEMdy5+KYY9gvQWYYN02sJocl5D+eeeQ4sLF8CdjjNYxiOzo2ig22+I4taextM2Ye/Ti5LIG2fQLzN84xOg721beC55XVa9booIMO1vKVy9Xik97E5CRX5Q75K95gjYoXbBEGq2PcwP8HAAD//wBNIwMAAAAGSURBVAMACrqje1Prt1IAAAAASUVORK5CYII=" alt="Live Infinity" style="width:32px;height:32px;border-radius:8px;object-fit:cover;border:1px solid rgba(255,208,0,0.4);box-shadow:0 0 12px rgba(255,23,23,0.4);">' +
    '<div style="font-size:13.5px;font-weight:900;letter-spacing:.4px;"><span style="color:#ff1717">LIVE</span> <span style="color:#ffd000">INFINITY</span></div>' +
    '<div style="flex:1"></div>' +
    '<div id="ttlf-status" style="display:flex;align-items:center;font-size:9.5px;font-weight:900;letter-spacing:.4px;padding:3.5px 9px;border-radius:999px;border:1px solid #ff1717;color:#ff3355;background:rgba(255,23,23,.15);margin-right:6px;white-space:nowrap">● INATIVO</div>' +
    '<div id="ttlf-cfg" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,208,0,0.3);background:#141928;color:#ffd000;font-size:13px" data-tip="Minha assinatura / configurações">⚙️</div>' +
    '<div id="ttlf-power" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,208,0,0.35);background:#141928;color:#ffd000;font-size:14px;font-weight:bold" data-tip="Nenhuma LIVE no ar">⏻</div>' +
    '<div id="ttlf-min" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,23,23,0.35);background:#141928;color:#ff1717;font-size:15px;font-weight:bold" data-tip="Esconder">−</div></div>' +

    /* NOVO PAINEL DE VENDAS 2x2 — LIVE INFINITY (FATURAMENTO, VENDAS, TICKET MÉDIO, ITENS VENDIDOS) */
    '<div style="padding:10px 14px 6px;display:flex;align-items:center;justify-space-between">' +
    '<div style="font-size:11px;font-weight:900;color:#ffd000;letter-spacing:0.5px;display:flex;align-items:center;gap:4px">📊 Painel de vendas</div>' +
    '<div id="dash-status" style="font-size:10px;font-weight:900;color:#ffd000;letter-spacing:0.5px;text-transform:lowercase">• aguardando</div>' +
    '</div>' +

    '<div style="display:grid;grid-template-columns:repeat(2, minmax(0, 1fr));gap:6px;padding:0 12px 11px">' +
    '<div style="background:#03050a;border:1px solid rgba(255,208,0,0.25);border-radius:12px;padding:8px 8px;text-align:center">' +
    '<div style="font-size:8.5px;color:rgba(255,255,255,0.65);text-transform:uppercase;font-weight:800;letter-spacing:0.3px">FATURAMENTO (GMV)</div>' +
    '<div id="dash-gmv" style="font-size:14.5px;font-weight:900;color:#a0a5b5;margin-top:2px">R$ 0,00</div>' +
    '</div>' +
    '<div style="background:#03050a;border:1px solid rgba(255,208,0,0.25);border-radius:12px;padding:8px 8px;text-align:center">' +
    '<div style="font-size:8.5px;color:rgba(255,255,255,0.65);text-transform:uppercase;font-weight:800;letter-spacing:0.3px">VENDAS</div>' +
    '<div id="dash-vendas" style="font-size:14.5px;font-weight:900;color:#ffffff;margin-top:2px">0</div>' +
    '</div>' +
    '<div style="background:#03050a;border:1px solid rgba(255,208,0,0.25);border-radius:12px;padding:8px 8px;text-align:center">' +
    '<div style="font-size:8.5px;color:rgba(255,255,255,0.65);text-transform:uppercase;font-weight:800;letter-spacing:0.3px">TICKET MÉDIO</div>' +
    '<div id="dash-ticket" style="font-size:14.5px;font-weight:900;color:#a0a5b5;margin-top:2px">R$ 0,00</div>' +
    '</div>' +
    '<div style="background:#03050a;border:1px solid rgba(255,208,0,0.25);border-radius:12px;padding:8px 8px;text-align:center">' +
    '<div style="font-size:8.5px;color:rgba(255,255,255,0.65);text-transform:uppercase;font-weight:800;letter-spacing:0.3px">ITENS VENDIDOS</div>' +
    '<div id="dash-itens" style="font-size:14.5px;font-weight:900;color:#ffffff;margin-top:2px">0</div>' +
    '</div>' +
    '</div>' +

    '<div style="display:flex;gap:7px;padding:0 14px 12px">' +
    '<button id="ttlf-on" style="flex:1;padding:9px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000 0%,#ff9900 100%);color:#000;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(255,208,0,0.3)">🚀 Ativar tudo</button>' +
    '<button id="ttlf-off" style="flex:1;padding:9px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717 0%,#d90000 100%);color:#fff;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(255,23,23,0.3)">🛑 Desativar tudo</button></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9.5v3.5l2.3 2.3"/><path d="M9 2h6"/></svg></b>Timer de Encerramento<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Encerra a LIVE automaticamente no horário definido (sobrevive a F5)</div>' +
    '<div style="text-align:center;color:rgba(255,255,255,0.55);font-size:10px;letter-spacing:2px;font-weight:800">TEMPO RESTANTE</div>' +
    '<div id="rt-restante" style="text-align:center;font-family:monospace;font-size:28px;font-weight:bold;letter-spacing:3px;color:#ffd000;background:#03050a;border:1px solid rgba(255,208,0,0.35);border-radius:14px;padding:10px;margin:4px 0 9px">--:--:--</div>' +

    '<div style="display:flex;gap:4px;margin-bottom:8px">' +
    '<button class="ttlf-preset" data-min="60">1h</button>' +
    '<button class="ttlf-preset" data-min="120">2h</button>' +
    '<button class="ttlf-preset" data-min="240">4h</button>' +
    '<button class="ttlf-preset" data-min="360">6h</button>' +
    '<button class="ttlf-preset" data-min="480">8h</button></div>' +
    '<label>Ou digite manualmente (minutos):</label>' +
    '<input id="rt-min" type="number" min="1" value="120" style="margin:4px 0 8px"/>' +
    '<button id="rt-armar" class="ttlf-go">▶ Iniciar timer</button>' +
    '<div style="display:flex;gap:6px;margin-top:6px">' +
    '<button id="rt-pausa" style="flex:1;padding:6px;border:none;border-radius:8px;background:#ffd000;color:#000;font-weight:bold;cursor:pointer;display:none">⏸ Pausar</button>' +
    '<button id="rt-cancel" style="flex:1;padding:6px;border:none;border-radius:8px;background:#ff1717;color:#fff;font-weight:bold;cursor:pointer;display:none">✖ Cancelar</button></div>' +
    '<div id="rt-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16v6"/><path d="M8 3h8l-1.2 7 3.2 3H4l3.2-3z"/></svg></b>Manter produto fixado<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div style="background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:12px;padding:10px;margin-bottom:10px">' +
    '<div style="font-weight:800;color:#ffd000;font-size:11px;margin-bottom:4px">SEÇÃO A — FIXAÇÃO INICIAL</div>' +
    '<div class="ttlf-desc" style="margin-bottom:8px">Fixa o produto principal uma única vez quando a LIVE começar.</div>' +
    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:4px;cursor:pointer">' +
    '<input id="rf-auto-initial" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>' +
    '<span style="font-size:11px;color:#fff;font-weight:700">Fixar automaticamente ao iniciar a LIVE</span>' +
    '</label>' +
    '<div id="rf-initial-status" class="ttlf-st" style="margin-top:4px">Aguardando início da LIVE...</div>' +
    '</div>' +

    '<div style="display:flex;gap:6px;margin-bottom:10px">' +
    '<button id="rf-btn-fixar-main" style="flex:1;padding:7px;border:1px solid rgba(255,208,0,0.3);border-radius:8px;background:#141928;color:#ffd000;font-weight:bold;font-size:11px;cursor:pointer">📌 Fixar produto agora</button>' +
    '<button id="rf-btn-bloq-cupom" style="flex:1;padding:7px;border:1px solid rgba(255,23,23,0.4);border-radius:8px;background:#141928;color:#ff3355;font-weight:bold;font-size:11px;cursor:pointer">🚫 Bloquear Cupom</button>' +
    '</div>' +

    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:10px;background:#03050a;padding:8px;border-radius:8px;border:1px solid rgba(255,208,0,0.2)">' +
    '<input id="rf-bloq-cupom-check" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>' +
    '<span style="font-size:11px;color:#fff">Bloqueio Obrigatório de Cupom (Sempre Ignorar Cupom)</span>' +
    '</label>' +

    '<div style="background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:12px;padding:10px">' +
    '<div style="font-weight:800;color:#ffd000;font-size:11px;margin-bottom:4px">SEÇÃO B — REFIXAÇÃO AUTOMÁTICA</div>' +
    '<div class="ttlf-desc" style="margin-bottom:8px">Renova a exibição do produto usando Desafixar e Fixar.</div>' +
    '<label style="display:block;font-size:11px;color:#ccc;margin-bottom:4px">Intervalo entre refixações (segundos):</label>' +
    '<input id="rf-refix-interval" type="number" min="15" max="300" value="50" style="margin-bottom:8px;padding:6px;width:100%;box-sizing:border-box"/>' +
    '<button id="rf-plus60-toggle" class="ttlf-go">▶ Iniciar refixação</button>' +
    '<button id="rf-botao" style="display:none"></button>' +
    '<div id="rf-plus60-status" class="ttlf-st" style="margin-top:6px">Refixação desligada.</div>' +
    '<div id="rf-status" style="display:none"></div>' +
    '</div></div></div>' +



    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z"/></svg></b>Oferta relâmpago<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando a Oferta relâmpago da LIVE encerrar, duplica e inicia de novo sozinho</div>' +
    '<button id="rd-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rd-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8 8 0 0 1-8 8H4l2.3-2.7A8 8 0 1 1 21 11.5z"/></svg></b>Comentários automáticos<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Envia seus comentários na LIVE, um por vez, girando a lista</div>' +
    '<label>Comentários (um por linha):</label>' +
    '<textarea id="rc-msgs" rows="4" style="margin:4px 0 8px">Oi, Fiquem à vontade para interagir, conhecer os produtos e tirar suas dúvidas!\n🛒 Toque no carrinho pra garantir a oferta!\n🔥 Frete grátis hoje!\n💥 Últimas unidades com desconto!</textarea>' +
    '<label>Intervalo (segundos):</label>' +
    '<input id="rc-int" type="number" min="10" value="90" style="margin:4px 0 8px"/>' +
    '<button id="rc-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rc-countdown" style="font-size:11px;color:#ffd000;margin-top:6px;font-weight:bold">Comentários automáticos desligados.</div>' +
    '<div id="rc-status" class="ttlf-st" style="margin-top:4px">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 8V5"/><circle cx="12" cy="3.5" r="1.2"/><path d="M9 12.5v2M15 12.5v2"/></svg></b>Respostas automáticas<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém citar a palavra-chave, responde sozinho (nunca responde você mesma)</div>' +
    '<label>Regras (palavras = resposta, uma por linha):</label>' +
    '<textarea id="ra-regras" rows="6" style="margin:4px 0 8px">frete = O frete é grátis! 🚚\ncomprei, finalizei, adquiri = Parabéns pela compra! Volte aqui depois para me dar seu feedback.</textarea>' +
    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><input id="ra-mencao" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>Mencionar @pessoa na resposta</label>' +
    '<button id="ra-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="ra-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9.5" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/><path d="M3 4h2l2.4 11h10.2L20 8H6.2"/></svg></b>Intenção de compra<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém adiciona o produto ao carrinho, menciona a pessoa (@nome) no chat com sua frase pronta</div>' +
    '<label>Frase quando ADICIONAR ao carrinho:</label>' +
    '<textarea id="ic-cart" rows="2" style="margin:4px 0 8px">garante o seu, finaliza a compra! 🛒</textarea>' +
    '<button id="ic-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="ic-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M5.7 5.7l12.6 12.6"/></svg></b>Bloqueio por Nome<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Bloqueia automaticamente quem ENTRA na LIVE com palavras suspeitas no nome (painel Atividade)</div>' +
    '<label>Palavras suspeitas (uma por linha):</label>' +
    '<textarea id="bn-palavras" rows="4" style="margin:4px 0 8px">recomenda\nachadinhos\nindica</textarea>' +
    '<button id="bn-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="bn-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5.2c0 4.8-3.4 8.3-7 9.8-3.6-1.5-7-5-7-9.8V6z"/></svg></b>Proteção Contra Violação<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Encerra a LIVE sozinho ao detectar aviso/violação do TikTok na tela (Liga automaticamente ao iniciar LIVE)</div>' +
    '<input id="rv-ativo" type="checkbox" style="display:none"/>' +
    '<button id="rv-botao" class="ttlf-go" style="margin-bottom:8px">▶ Ativar proteção</button>' +
    '<label>Esperar antes de encerrar (segundos, 0 = na hora):</label>' +
    '<input id="rv-delay" type="number" min="0" value="0" style="margin:4px 0 8px"/>' +
    '<div id="rv-status" class="ttlf-st">Inativa.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.5 20a2 2 0 0 0 3 0"/></svg></b>Alerta de vendas (celular)<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Saiu venda na LIVE → notificação no seu celular via app gratuito ntfy (instale o app "ntfy" e inscreva-se no seu canal)</div>' +
    '<label>Nome do canal ntfy:</label>' +
    '<input id="nv-canal" placeholder="ex: liveinfinity-vendas-8k" style="margin:4px 0 8px" autocomplete="off" spellcheck="false"/>' +
    '<button id="nv-teste" style="width:100%;padding:8px;border:1px solid rgba(255,208,0,0.3);border-radius:11px;background:#141928;color:#ffd000;font-weight:700;cursor:pointer;margin-bottom:8px">Enviar teste pro celular</button>' +
    '<button id="nv-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="nv-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg></b>Parabéns pela compra<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém FINALIZA a compra, menciona a pessoa (@nome) no chat parabenizando com sua frase pronta.</div>' +
    '<label>Frase quando FINALIZAR a compra:</label>' +
    '<textarea id="vc-msg" rows="2" style="margin:4px 0 8px;width:100%;background:#141928;color:#fff;border:1px solid rgba(255,208,0,0.3);border-radius:6px;padding:6px;font-size:12px">Parabéns pela sua compra! 🎉 Obrigado, volte sempre!</textarea>' +
    '<button id="vc-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="vc-status" class="ttlf-st">Desligado.</div></div></div>';

  document.body.appendChild(d);
  console.info('[LICENSE 08] HUD inserido');
  ttlfPersist(d);

  Array.prototype.slice.call(d.querySelectorAll('.ttlf-sec-h')).forEach(function (h) {
    h.addEventListener('click', function () {
      var b = h.nextElementSibling;
      var fechado = b.style.display === 'none';
      b.style.display = fechado ? 'block' : 'none';
      h.querySelector('span').textContent = fechado ? '▾' : '▸';
    });
  });

  // BIND DO BOTÃO ATIVAR TUDO E DESATIVAR TUDO
  var btnOn = document.getElementById('ttlf-on');
  if (btnOn) {
    btnOn.addEventListener('click', function () {
      ttlfLog('[MASTER_CONTROL] 🚀 Botão "Ativar Tudo" clicado.');

      // 1. Refixação Automática (Seção B)
      var bPlus = document.getElementById('rf-plus60-toggle');
      if (bPlus && bPlus.textContent.indexOf('▶') >= 0 && typeof window.ttlfPlus60Start === 'function') {
        window.ttlfPlus60Start();
      }

      // 2. Comentários Automáticos
      var bRc = document.getElementById('rc-botao');
      if (bRc && bRc.textContent.indexOf('▶') >= 0 && typeof window.rcStart === 'function') {
        window.rcStart();
      }

      // 3. Respostas Automáticas
      var bRa = document.getElementById('ra-botao');
      if (bRa && bRa.textContent.indexOf('▶') >= 0 && typeof window.raStart === 'function') {
        window.raStart();
      }

      // 4. Intenção de Compra
      var bIc = document.getElementById('ic-botao');
      if (bIc && bIc.textContent.indexOf('▶') >= 0 && typeof window.icStart === 'function') {
        window.icStart();
      }

      // 5. Parabéns pela compra
      if (typeof window.ttlfVcLiga === 'function') {
        window.ttlfVcLiga();
      }

      // 6. Alerta NTFY
      var bNv = document.getElementById('nv-botao');
      if (bNv && bNv.textContent.indexOf('▶') >= 0 && typeof window.ttlfNtfyToggle === 'function') {
        window.ttlfNtfyToggle();
      }

      // 7. Proteção Anti-Ban
      var cv = document.getElementById('rv-ativo');
      if (cv && !cv.checked) {
        var bRv = document.getElementById('rv-botao');
        if (bRv) bRv.click();
      }

      // 8. Timer de Encerramento
      var bRt = document.getElementById('rt-armar');
      if (bRt && bRt.style.display !== 'none') { bRt.click(); }

      // 9. Oferta e Bloqueio
      ['rd-botao', 'bn-botao'].forEach(function (id) {
        var b = document.getElementById(id);
        if (b && (b.textContent.indexOf('▶') >= 0 || b.textContent.indexOf('Iniciar') >= 0)) { b.click(); }
      });

      // Persistir todos os estados
      ttlfStGet(function (lic) {
        lic = lic || {};
        lic.ttlf_repin_enabled = true;
        lic.rfAutoInitial = true;
        lic.rc_ativo = true;
        lic.ttlf_comments_enabled = true;
        lic.ra_ativo = true;
        lic.ttlf_replies_enabled = true;
        lic.ic_ativo = true;
        lic.ttlf_intent_enabled = true;
        lic.stc_ativo = true;
        lic.ttlf_sales_capture_enabled = true;
        lic.ttlf_sales_thanks_enabled = true;
        lic.nv_ativo = true;
        lic.ttlf_ntfy_enabled = true;
        ttlfStSet(lic);
      });
    });
  }

  var btnOff = document.getElementById('ttlf-off');
  if (btnOff) {
    btnOff.addEventListener('click', function () {
      ttlfLog('[MASTER_CONTROL] 🛑 Botão "Desativar Tudo" clicado.');

      // 1. Refixação Automática (Seção B)
      if (typeof window.ttlfPlus60Stop === 'function') {
        window.ttlfPlus60Stop();
      }

      // 2. Comentários Automáticos
      if (typeof window.rcStop === 'function') {
        window.rcStop();
      }

      // 3. Respostas Automáticas
      if (typeof window.raStop === 'function') {
        window.raStop();
      }

      // 4. Intenção de Compra
      if (typeof window.icStop === 'function') {
        window.icStop();
      }

      // 5. Parabéns pela compra
      if (typeof window.ttlfVcDesliga === 'function') {
        window.ttlfVcDesliga();
      }

      // 6. Alerta NTFY
      var bNv = document.getElementById('nv-botao');
      if (bNv && bNv.textContent.indexOf('⏸') >= 0 && typeof window.ttlfNtfyToggle === 'function') {
        window.ttlfNtfyToggle();
      }

      // 7. Proteção Anti-Ban
      var cv = document.getElementById('rv-ativo');
      if (cv && cv.checked) {
        var bRv = document.getElementById('rv-botao');
        if (bRv) bRv.click();
      }

      // 8. Timer de Encerramento
      var bRtCan = document.getElementById('rt-cancel');
      if (bRtCan && bRtCan.style.display !== 'none') { bRtCan.click(); }

      // 9. Oferta e Bloqueio
      ['rd-botao', 'bn-botao'].forEach(function (id) {
        var b = document.getElementById(id);
        if (b && (b.textContent.indexOf('⏸') >= 0 || b.textContent.indexOf('Parar') >= 0)) { b.click(); }
      });

      // Persistir todos os estados como false
      ttlfStGet(function (lic) {
        lic = lic || {};
        lic.ttlf_repin_enabled = false;
        lic.rfAutoInitial = false;
        lic.rc_ativo = false;
        lic.ttlf_comments_enabled = false;
        lic.ra_ativo = false;
        lic.ttlf_replies_enabled = false;
        lic.ic_ativo = false;
        lic.ttlf_intent_enabled = false;
        lic.stc_ativo = false;
        lic.ttlf_sales_capture_enabled = false;
        lic.ttlf_sales_thanks_enabled = false;
        lic.nv_ativo = false;
        lic.ttlf_ntfy_enabled = false;
        ttlfStSet(lic);
      });
    });
  }

  var ttlfMini = false;
  var btnMin = document.getElementById('ttlf-min');
  if (btnMin) {
    btnMin.addEventListener('click', function () {
      ttlfMini = !ttlfMini;
      var mb = document.getElementById('ttlf-min');
      var topo = document.getElementById('ttlf-top');
      var linhaBtns = topo ? topo.children[1] : null;
      Array.prototype.slice.call(d.children).forEach(function (k) {
        if (k.id === 'ttlf-top') { return; }
        if (ttlfMini) { try { k.setAttribute('data-mini', '1'); } catch (e) {} k.style.display = 'none'; }
        else if (k.getAttribute && k.getAttribute('data-mini')) { k.style.display = ''; k.removeAttribute('data-mini'); }
      });
      if (linhaBtns) { linhaBtns.style.display = ttlfMini ? 'none' : 'flex'; }
      if (topo) { topo.style.borderRadius = ttlfMini ? '18px' : '18px 18px 0 0'; }
      d.style.maxHeight = ttlfMini ? 'none' : '84vh';
      d.style.overflow = ttlfMini ? 'visible' : 'auto';
      if (mb) mb.textContent = ttlfMini ? '+' : '−';
    });
  }

  var _cfgBtn = document.getElementById('ttlf-cfg'); if (_cfgBtn) { _cfgBtn.addEventListener('click', ttlfCfgPanel); }

  var bolha = document.createElement('div');
  bolha.id = 'ttlf-bolha';
  bolha.title = 'Live Infinity';
  bolha.style.cssText = 'position:fixed;top:64px;right:12px;z-index:999998;width:52px;height:52px;background:#070a12;border:2px solid #ffd000;border-radius:50%;box-shadow:0 10px 25px rgba(0,0,0,.9);display:none;align-items:center;justify-content:center;cursor:pointer;font-size:22px';
  bolha.innerHTML = '♾️';
  document.body.appendChild(bolha);
  console.info('[LICENSE 09] bolha inserida');

  ttlfInitHudControllers();
}

function ttlfBoot() {
  console.info('[LICENSE 06] ttlfBoot chamada');
  if (!document.body) { setTimeout(ttlfBoot, 1500); return; }
  if (window.ttlfBootOk && document.getElementById('ttlf-hub')) { return; }
  window.ttlfBootOk = true;

  ttlfStGet(function (lic) {
    console.info('[BOOT 02] licença consultada');
    if (!lic || !lic.key) {
      console.info('[BOOT 03] gate necessário');
      ttlfShowGate('');
      return;
    }
    var dev = ttlfDevice(lic);
    ttlfValida(lic.key, dev, function (ok, reason, offline, data) {
      if (ok) {
        console.info('[LICENSE 02] resposta válida');
        var now = Date.now();
        lic.device = dev;
        lic.lastOk = now;
        if (data && data.email) { lic.email = data.email; }
        if (data && data.exp) { lic.exp = data.exp; }
        ttlfRollExp(lic);
        ttlfStSet(lic);
        console.info('[LICENSE 03] liveinfinity_lic salvo');
        ttlfLiga();
      } else if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) {
        console.info('[BOOT 07] licença válida (offline grace)');
        ttlfLiga();
      } else {
        console.info('[BOOT 03] gate necessário (motivo: ' + reason + ')');
        ttlfShowGate(reason);
      }
    });
  });
}

  /* ===== 1. MÓDULO LEVE: MANTER PRODUTO FIXADO (SEPARADO: FIXAÇÃO INICIAL + RENOVAÇÃO +60 s) ===== */
  (function () {
    'use strict';

    if (window.ttlfPlus60Timer) { clearTimeout(window.ttlfPlus60Timer); window.ttlfPlus60Timer = null; }
    if (window.ttlfInitialPinTimer) { clearTimeout(window.ttlfInitialPinTimer); window.ttlfInitialPinTimer = null; }

    var rodandoPlus60 = false;
    window.ttlfPlus60Running = false;
    window.ttlfPlus60Busy = false;
    window.ttlfPlus60SessionId = 0;
    window.ttlfLastPlus60ClickAt = 0;
    window.ttlfPlus60CheckRunning = false;

    window.ttlfInitialPinBusy = false;
    window.ttlfInitialPinSessionId = 0;
    window.ttlfInitialPinDoneForSession = false;
    window.ttlfInitialPinFailCount = 0;

    var ultimoStatusPlus60 = '';
    var ultimoStatusInit = '';
    var plus60CicloCount = 0;

    function stInit(m) {
      if (m === ultimoStatusInit) return;
      ultimoStatusInit = m;
      var e = document.getElementById('rf-initial-status');
      if (e) { e.textContent = m; }
    }

    function stPlus(m) {
      if (m === ultimoStatusPlus60) return;
      ultimoStatusPlus60 = m;
      var e1 = document.getElementById('rf-plus60-status');
      if (e1) { e1.textContent = m; }
      var e2 = document.getElementById('rf-status');
      if (e2) { e2.textContent = m; }
    }

    function isLiveStarted() {
      return window.ttlfLiveNoAr();
    }

    function tb() {
      return Array.prototype.slice.call(document.querySelectorAll('button, [role="button"]')).filter(function (b) {
        var t = (b.textContent || '').trim();
        return t === 'Fixar' || t === 'Desafixar';
      });
    }

    function ehProduto(b) {
      var el = b;
      for (var i = 0; i < 8 && el; i++) {
        el = el.parentElement;
        if (!el) break;
        var t = el.textContent || '';
        if (t.indexOf('Lista de produtos nesta LIVE') > -1) return false;
        if (t.length > 500) break;
        if (t.indexOf('Em estoque') > -1 || t.indexOf('Quantidade') > -1) return true;
      }
      return false;
    }

    function ehCupom(b) {
      var bloqCheck = document.getElementById('rf-bloq-cupom-check');
      if (bloqCheck && !bloqCheck.checked) return false;
      var el = b;
      for (var i = 0; i < 8 && el; i++) {
        el = el.parentElement;
        if (!el) break;
        var t = el.textContent || '';
        if (t.indexOf('Em estoque') > -1 || t.indexOf('Quantidade') > -1) return false;
        if (/cupom|desconto|gasto m/i.test(t)) return true;
      }
      return false;
    }

    function encontrarAncestralClicavel(el) {
      if (!el) return null;
      var p = el;
      for (var i = 0; i < 6 && p; i++) {
        if (p.tagName === 'BUTTON' || (p.getAttribute && p.getAttribute('role') === 'button')) {
          return p;
        }
        if (p.classList && (p.classList.contains('arco-btn') || p.classList.contains('aux-btn'))) {
          return p;
        }
        p = p.parentElement;
      }
      return el;
    }

    function encontrarBotaoProdutoPrincipal() {
      var bs = tb();
      var prods = bs.filter(function (b) { return ehProduto(b) && !ehCupom(b); });
      if (!prods.length) return null;
      var alvo = prods[0];
      var txt = ((alvo.textContent || '').replace(/\s+/g, ' ')).trim().toLocaleUpperCase('pt-BR');
      return {
        el: alvo,
        state: (txt.indexOf('DESAFIXAR') >= 0) ? 'DESAFIXAR' : 'FIXAR'
      };
    }

    /* ===== HELPER DE DESTAQUE VISUAL SEGURO E ALERTAS DO MODO ASSISTIDO ===== */
    window.ttlfLastAlertTime = 0;

    function destacarElementoSeguro(el) {
      if (!el || !el.isConnected) return;
      try {
        if (el._ttlfDestacado) return;
        el._ttlfDestacado = true;
        el._ttlfOrigOutline = el.style.outline || '';
        el._ttlfOrigBoxShadow = el.style.boxShadow || '';
        el._ttlfOrigTransition = el.style.transition || '';

        el.style.transition = 'outline 0.3s, box-shadow 0.3s';
        el.style.outline = '4px solid #ffd000';
        el.style.boxShadow = '0 0 20px #ffd000';

        setTimeout(function() {
          removerDestaqueSeguro(el);
        }, 6000);
      } catch (e) {}
    }

    function removerDestaqueSeguro(el) {
      if (!el) return;
      try {
        if (el._ttlfDestacado) {
          el.style.outline = el._ttlfOrigOutline || '';
          el.style.boxShadow = el._ttlfOrigBoxShadow || '';
          el.style.transition = el._ttlfOrigTransition || '';
          el._ttlfDestacado = false;
        }
      } catch (e) {}
    }

    function emitirAlertaAssistido(msg) {
      if (Date.now() - window.ttlfLastAlertTime < 10000) return;
      window.ttlfLastAlertTime = Date.now();
      ttlfLog('⚠️ [MODO ASSISTIDO] ' + msg);
      try {
        if (typeof window.ttlfNtfyEnviar === 'function') {
          window.ttlfNtfyEnviar('LIVE INFINITY: ' + msg);
        }
      } catch (e) {}
    }

    function dispararCliqueUnico(el) {
      if (!el || !el.isConnected) return false;
      var alvo = encontrarAncestralClicavel(el) || el;
      
      if (alvo.disabled || (alvo.getAttribute && alvo.getAttribute('aria-disabled') === 'true')) {
        ttlfLog('[FIX] Botão está desativado (disabled / aria-disabled).');
        return false;
      }
      try {
        var cs = getComputedStyle(alvo);
        if (cs.pointerEvents === 'none' || cs.display === 'none' || cs.visibility === 'hidden') {
          ttlfLog('[FIX] Botão possui pointer-events: none ou está invisível.');
          return false;
        }
      } catch (e) {}

      try {
        if (typeof alvo.scrollIntoView === 'function') {
          alvo.scrollIntoView({ block: 'center', inline: 'center' });
        }
        if (typeof alvo.focus === 'function') {
          alvo.focus();
        }
      } catch (e) {}

      var clickAceito = false;
      try {
        if (typeof alvo.click === 'function') {
          alvo.click();
          clickAceito = true;
        } else if (typeof HTMLElement !== 'undefined' && HTMLElement.prototype && typeof HTMLElement.prototype.click === 'function') {
          HTMLElement.prototype.click.call(alvo);
          clickAceito = true;
        }
      } catch (e) {}

      ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (tp) {
        try {
          alvo.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window }));
        } catch (e) {}
      });

      return clickAceito;
    }

    // ==================================================
    // 🔒 SEÇÃO A CONGELADA — APROVADA EM LIVE REAL
    // NÃO ALTERAR SEM AUTORIZAÇÃO EXPRESSA
    // ==================================================
    /* ===== AÇÃO 1: FIXAÇÃO INICIAL AUTOMÁTICA ===== */
    function checkInitialPin() {
      var cbAuto = document.getElementById('rf-auto-initial');
      if (!cbAuto) {
        agendarCheckInitialPin(2000);
        return;
      }
      if (!cbAuto.checked) {
        stInit('Fixação inicial automática desativada.');
        agendarCheckInitialPin(3000);
        return;
      }

      if (!isLiveStarted()) {
        stInit('Aguardando início da LIVE...');
        ttlfLog('[FIX_INITIAL][MONITOR] LIVE ainda não iniciada — próxima checagem agendada');
        window.ttlfInitialPinDoneForSession = false;
        window.ttlfInitialPinFailCount = 0;
        agendarCheckInitialPin(1200);
        return;
      }

      if (window.ttlfInitialPinDoneForSession) {
        stInit('Produto já está fixado.');
        agendarCheckInitialPin(3000);
        return;
      }

      stInit('LIVE detectada. Procurando produto principal...');
      ttlfLog('[FIX_INITIAL][MONITOR] LIVE detectada automaticamente');

      var btnInfo = encontrarBotaoProdutoPrincipal();
      if (!btnInfo) {
        stInit('Produto não encontrado.');
        agendarCheckInitialPin(2000);
        return;
      }

      ttlfLog('[FIX_INITIAL][FIX] Botão Fixar encontrado');

      if (btnInfo.state === 'DESAFIXAR') {
        stInit('Produto já está fixado.');
        window.ttlfInitialPinDoneForSession = true;
        agendarCheckInitialPin(4000);
        return;
      }

      if (window.ttlfInitialPinBusy) {
        agendarCheckInitialPin(1500);
        return;
      }

      window.ttlfInitialPinBusy = true;
      stInit('Fixando produto principal...');
      ttlfLog('[FIX_INITIAL][FIX] Clique executado');

      var ok = dispararCliqueUnico(btnInfo.el);

      setTimeout(function () {
        var recheck = encontrarBotaoProdutoPrincipal();
        if (recheck && recheck.state === 'DESAFIXAR') {
          stInit('Produto fixado com sucesso.');
          ttlfLog('[FIX_INITIAL][FIX] Texto mudou para DESAFIXAR');
          window.ttlfInitialPinDoneForSession = true;
          window.ttlfInitialPinFailCount = 0;
          window.ttlfInitialPinBusy = false;
          agendarCheckInitialPin(5000);
        } else {
          window.ttlfInitialPinFailCount = (window.ttlfInitialPinFailCount || 0) + 1;
          window.ttlfInitialPinBusy = false;
          stInit('TikTok não confirmou a fixação.');
          ttlfLog('[FIX_INITIAL] [FIX] Aviso: TikTok não confirmou a alteração para DESAFIXAR. Tentará novamente.');
          agendarCheckInitialPin(3000);
        }
      }, 2500);
    }

    function agendarCheckInitialPin(ms) {
      if (window.ttlfInitialPinTimer) clearTimeout(window.ttlfInitialPinTimer);
      window.ttlfInitialPinTimer = setTimeout(checkInitialPin, ms || 1000);
    }

    window.ttlfStartInitialPinMonitor = function () {
      ttlfLog('[FIX_INITIAL][MONITOR] Monitor iniciado no boot');
      agendarCheckInitialPin(300);
    };

    // ==================================================
    // 🔒 SEÇÃO B CONGELADA — APROVADA EM LIVE REAL
    // NÃO ALTERAR SEM AUTORIZAÇÃO EXPRESSA
    // ==================================================
    /* ===== AÇÃO 2: REFIXAÇÃO AUTOMÁTICA (DESAFIXAR -> FIXAR EXCLUSIVO SEÇÃO B) ===== */
    window.ttlfRefixCycleBusy = false;

    function getRefixIntervalMs() {
      var inp = document.getElementById('rf-refix-interval');
      var val = inp ? parseInt(inp.value, 10) : 50;
      if (isNaN(val) || val < 15) val = 50;
      return val * 1000;
    }

    function checkRefix() {
      var sessaoAtual = window.ttlfPlus60SessionId;
      if (!rodandoPlus60 || window.ttlfPlus60CheckRunning) {
        agendarProximaChecagemRefix(1000);
        return;
      }
    }
    window.ttlfCheckRefix = checkRefix;

    function checkRefix() {
      var sessaoAtual = window.ttlfPlus60SessionId;
      if (!rodandoPlus60 || window.ttlfPlus60CheckRunning) {
        agendarProximaChecagemRefix(1000);
        return;
      }

      window.ttlfPlus60CheckRunning = true;

      try {
        if (!isLiveStarted()) {
          stPlus('Aguardando início da LIVE para refixação...');
          agendarProximaChecagemRefix(2500);
          return;
        }

        // TRAVA DE EXCLUSÃO MÚTUA REAL COM O MODO EXTENDED (+60s/+30s)
        if (window.ttlfPinExtensionMode && window.ttlfPinExtensionMode.enabled && window.ttlfPinExtensionMode.mode === 'extended') {
          stPlus('Modo +60s ativo — refixação clássica suspensa.');
          ttlfLog('[PIN_EXTENDED] classic-blocked: refixação clássica suspensa por presença de botão +60s/+30s');
          agendarProximaChecagemRefix(1500);
          return;
        }

        var btnInfo = encontrarBotaoProdutoPrincipal();
        if (!btnInfo) {
          stPlus('Produto principal não encontrado.');
          agendarProximaChecagemRefix(2500);
          return;
        }

        // Se a Fixação Inicial ou ciclo anterior estiver ocupado, aguardar
        if (window.ttlfInitialPinBusy || window.ttlfRefixCycleBusy) {
          agendarProximaChecagemRefix(1500);
          return;
        }

        // Caso o produto esteja atualmente FIXAR (desafixado), fixar imediatamente!
        if (btnInfo.state === 'FIXAR') {
          window.ttlfRefixCycleBusy = true;
          stPlus('Produto temporariamente desafixado. Tentando fixar novamente...');
          ttlfLog('[REFIX] Produto está em FIXAR. Executando clique de recuperação...');
          dispararCliqueUnico(btnInfo.el);

          setTimeout(function () {
            window.ttlfRefixCycleBusy = false;
            var recheck = encontrarBotaoProdutoPrincipal();
            if (recheck && recheck.state === 'DESAFIXAR') {
              stPlus('Produto fixado com sucesso.');
              ttlfLog('[REFIX] Recuperação bem-sucedida! Estado alterado para DESAFIXAR.');
            } else {
              stPlus('Falha ao fixar produto. Tentará novamente em breve.');
              ttlfLog('[REFIX] Aviso: Recuperação falhou. Tentará no próximo ciclo.');
            }
          }, 2000);
          return;
        }

        // Produto está no estado DESAFIXAR. Iniciar ciclo de refixação!
        window.ttlfRefixCycleBusy = true;
        plus60CicloCount++;

        stPlus('Refixando produto (Desafixar → Fixar)...');
        ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Estado inicial: DESAFIXAR');
        ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Clicando em DESAFIXAR...');

        // ETAPA 1: Clicar em DESAFIXAR
        dispararCliqueUnico(btnInfo.el);

        // Confirmar transição para FIXAR
        setTimeout(function () {
          if (!rodandoPlus60 || window.ttlfPlus60SessionId !== sessaoAtual) {
            window.ttlfRefixCycleBusy = false;
            return;
          }

          var recheck1 = encontrarBotaoProdutoPrincipal();
          if (recheck1 && recheck1.state === 'FIXAR') {
            ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Sucesso na Etapa 1: Mudou para FIXAR! Aguardando 1,0s...');

            // ETAPA 2: Aguardar entre 800ms e 1500ms (1000ms) e Clicar em FIXAR
            setTimeout(function () {
              if (!rodandoPlus60 || window.ttlfPlus60SessionId !== sessaoAtual) {
                window.ttlfRefixCycleBusy = false;
                return;
              }

              var recheck2Target = encontrarBotaoProdutoPrincipal();
              if (recheck2Target) {
                ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Clicando em FIXAR...');
                dispararCliqueUnico(recheck2Target.el);

                // Confirmar transição final para DESAFIXAR
                setTimeout(function () {
                  window.ttlfRefixCycleBusy = false;
                  var finalCheck = encontrarBotaoProdutoPrincipal();

                  if (finalCheck && finalCheck.state === 'DESAFIXAR') {
                    // SUCESSO COMPLETO DO CICLO REFIXAR!
                    stPlus('Produto refixado com sucesso.');
                    ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Sucesso na Etapa 2: Mudou para DESAFIXAR!');
                    ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Resultado: SUCESSO (Produto refixado no ar)');
                    window.ttlfLastPlus60ClickAt = Date.now();
                  } else {
                    // SE FIXAR FALHOU, PRIORIZAR REFIXAR IMEDIATAMENTE (TENTATIVA 2)
                    stPlus('Produto temporariamente desafixado. Tentando fixar novamente...');
                    ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Aviso: Etapa 2 falhou. Tentando recuperação imediata...');
                    var retryTarget = encontrarBotaoProdutoPrincipal();
                    if (retryTarget) dispararCliqueUnico(retryTarget.el);
                  }
                }, 2000);
              } else {
                window.ttlfRefixCycleBusy = false;
              }
            }, 1000);

          } else {
            // Se DESAFIXAR não alterou para FIXAR, abortar ciclo sem desfixar o produto
            window.ttlfRefixCycleBusy = false;
            stPlus('Refixação monitorando...');
            ttlfLog('[REFIX][CICLO ' + plus60CicloCount + '] Aviso: Clique em Desafixar não alterou estado. Tentará no próximo ciclo.');
          }
        }, 2000);

      } catch (err) {
        window.ttlfRefixCycleBusy = false;
        ttlfLog('[REFIX][ERRO] ' + (err.message || err));
      } finally {
        window.ttlfPlus60CheckRunning = false;
        agendarProximaChecagemRefix(getRefixIntervalMs());
      }
    }

    function agendarProximaChecagemRefix(ms) {
      if (!rodandoPlus60) return;
      if (window.ttlfPlus60Timer) clearTimeout(window.ttlfPlus60Timer);
      window.ttlfPlus60Timer = setTimeout(checkRefix, ms || getRefixIntervalMs());
    }

    function ligaPlus60() {
      if (rodandoPlus60) return;
      rodandoPlus60 = true;
      window.ttlfPlus60Running = true;
      window.ttlfPlus60SessionId++;
      window.ttlfPlus60Busy = false;
      window.ttlfPlus60CheckRunning = false;
      window.ttlfRefixCycleBusy = false;

      var bPlus = document.getElementById('rf-plus60-toggle');
      if (bPlus) {
        bPlus.textContent = '⏸ Parar refixação';
        bPlus.style.background = '#ff1717';
      }

      stPlus('Monitorando refixação automática...');
      ttlfLog('[REFIX] Refixação automática iniciada (Intervalo: ' + (getRefixIntervalMs() / 1000) + 's)...');
      agendarProximaChecagemRefix(1000);
    }
    window.ttlfLigaPlus60 = ligaPlus60;

    function desligaPlus60() {
      rodandoPlus60 = false;
      window.ttlfPlus60Running = false;
      window.ttlfPlus60SessionId++;
      window.ttlfPlus60Busy = false;
      window.ttlfPlus60CheckRunning = false;
      window.ttlfRefixCycleBusy = false;

      if (window.ttlfPlus60Timer) { clearTimeout(window.ttlfPlus60Timer); window.ttlfPlus60Timer = null; }

      var bPlus = document.getElementById('rf-plus60-toggle');
      if (bPlus) {
        bPlus.textContent = '▶ Iniciar refixação';
        bPlus.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)';
        bPlus.style.color = '#000';
      }
      stPlus('Refixação desligada.');
      ttlfLog('[REFIX] Refixação automática desligada.');
    }

    window.ttlfPlus60Toggle = function () {
      rodandoPlus60 ? desligaPlus60() : ligaPlus60();
    };

    window.ttlfPlus60FixMain = function () {
      stInit('Fixando produto manualmente...');
      ttlfLog('[FIX_INITIAL] Clique manual: Fixando produto...');
      var btnInfo = encontrarBotaoProdutoPrincipal();
      if (btnInfo) {
        dispararCliqueUnico(btnInfo.el);
        setTimeout(function () {
          var recheck = encontrarBotaoProdutoPrincipal();
          if (recheck && recheck.state === 'DESAFIXAR') {
            stInit('Produto fixado com sucesso.');
          } else {
            stInit('Fixação enviada.');
          }
        }, 2000);
      } else {
        stInit('Produto não encontrado.');
      }
    };

    window.ttlfPlus60BloqCupom = function () {
      stInit('Desafixando qualquer cupom ativo...');
      var bs = tb();
      var cuponsFixados = bs.filter(function (b) { return ((b.textContent || '').replace(/\s+/g, ' ')).trim().toLocaleUpperCase('pt-BR').indexOf('DESAFIXAR') >= 0 && ehCupom(b); });
      if (cuponsFixados.length > 0) {
        dispararCliqueUnico(cuponsFixados[0]);
        stInit('Cupom removido ✅');
      } else {
        stInit('Nenhum cupom fixado no momento.');
      }
    };

    agendarCheckInitialPin(1500);
  })();

  /* ===== 2. MÓDULO DE MÍDIA OPTIMIZADO (ÁUDIO LIMPO SEM PICOTAR) ===== */
  (function () {
    'use strict';
    var rodando = false;
    function st(m) { var e = document.getElementById('md-status'); if (e) e.textContent = m; }
    
    function regAudioHist(nome) {
      var item = '[' + ttlfNow() + '] Camada Disparada: ' + nome;
      window.ttlfAudioHistory.push(item);
      if (window.ttlfAudioHistory.length > 40) window.ttlfAudioHistory.shift();
      var box = document.getElementById('md-hist-box');
      if (box) {
        box.textContent = window.ttlfAudioHistory.join('\n');
        box.scrollTop = box.scrollHeight;
      }
      ttlfLog('📻 ' + item);
    }

    // CORREÇÃO CRÍTICA DE PICOTAMENTO: FECHA OS CONTEXTOS DE ÁUDIO APÓS A EXECUÇÃO E REUTILIZA O BUFFER PARA NÃO SOBRECARREGAR A CPU/MEMÓRIA
    function playSyntheticSound(type) {
      try {
        var AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        var ctx = new AudioCtx({ latencyHint: 'playback' });
        var volSlider = document.getElementById('md-volume-slider');
        var masterVol = (volSlider ? parseFloat(volSlider.value) : 80) / 100;

        var gain = ctx.createGain();
        gain.gain.value = masterVol;
        gain.connect(ctx.destination);

        var dur = 0.3;
        if (type === 'caixa') {
          dur = 0.4;
          var osc1 = ctx.createOscillator();
          osc1.type = 'sine';
          osc1.frequency.setValueAtTime(987.77, ctx.currentTime);
          osc1.connect(gain);
          osc1.start();
          osc1.stop(ctx.currentTime + 0.1);

          setTimeout(function() {
            try {
              var osc2 = ctx.createOscillator();
              osc2.type = 'sine';
              osc2.frequency.setValueAtTime(1318.51, ctx.currentTime);
              osc2.connect(gain);
              osc2.start();
              osc2.stop(ctx.currentTime + 0.3);
            } catch(e) {}
          }, 100);
        } else if (type === 'aplausos') {
          dur = 0.5;
          var bufferSize = ctx.sampleRate * 0.4;
          var buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          var data = buffer.getChannelData(0);
          for (var i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }
          var noise = ctx.createBufferSource();
          noise.buffer = buffer;
          noise.connect(gain);
          noise.start();
        } else if (type === 'risadas' || type === 'vinheta') {
          dur = 0.3;
          var osc = ctx.createOscillator();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(523.25, ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.25);
          osc.connect(gain);
          osc.start();
          osc.stop(ctx.currentTime + 0.25);
        }

        // LIMPEZA AUTOMÁTICA DO CONTEXTO PARA NUNCA PICOTAR O VÍDEO NATIVO DO TIKTOK
        setTimeout(function () {
          try { if (ctx && ctx.state !== 'closed') ctx.close(); } catch (e) {}
        }, (dur + 0.2) * 1000);

      } catch (e) {}
    }

    // Roteamento de mídia legados removidos na Etapa D

    Array.prototype.slice.call(document.querySelectorAll('.md-fx-btn')).forEach(function (b) {
      b.addEventListener('click', function () {
        var fx = b.getAttribute('data-fx');
        var nomes = { caixa: '🔔 Som de Venda / Caixa', aplausos: '👏 Efeito Aplausos', risadas: '😂 Efeito Risadas', vinheta: '⚡ Efeito Vinheta / Alerta' };
        playSyntheticSound(fx);
        regAudioHist(nomes[fx] || fx);
      });
    });

    var histClear = document.getElementById('md-hist-clear');
    if (histClear) {
      histClear.addEventListener('click', function () {
        window.ttlfAudioHistory = [];
        var box = document.getElementById('md-hist-box');
        if (box) box.textContent = 'Nenhum trecho disparado ainda.';
      });
    }
  })();

  /* ===== FILA CENTRAL DE MENSAGENS DO CHAT ===== */
  (function () {
    'use strict';
    if (!window.ttlfChatQueue) { window.ttlfChatQueue = []; }
    window.ttlfChatQueueBusy = false;
    window.ttlfChatLastSendAt = 0;
    if (window.ttlfChatQueueTimer) { clearTimeout(window.ttlfChatQueueTimer); window.ttlfChatQueueTimer = null; }

    var TTLF_CHAT_QUEUE_MIN_GAP_MS = 5000;
    var TTLF_CHAT_QUEUE_MAX_ITEMS = 50;

    window.ttlfInitChatQueue = function () {
      if (!Array.isArray(window.ttlfChatQueue)) { window.ttlfChatQueue = []; }
      window.ttlfChatQueueBusy = false;
      if (window.ttlfChatQueueTimer) { clearTimeout(window.ttlfChatQueueTimer); window.ttlfChatQueueTimer = null; }
      ttlfLog('[CHAT_QUEUE] Fila central de chat inicializada.');
    };

    window.ttlfEnqueueChatMessage = function (item) {
      if (!item || typeof item.message !== 'string') return null;
      var msg = item.message.trim();
      if (!msg) return null;

      var type = item.type || 'auto_comment';
      if (type !== 'auto_comment' && type !== 'auto_reply') return null;

      if (window.ttlfChatQueue.length >= TTLF_CHAT_QUEUE_MAX_ITEMS) {
        ttlfLog('[CHAT_QUEUE] Alerta: Limite da fila atingido (50 itens). Rejeitando item.');
        if (type === 'auto_comment') return null;
        var removedIndex = window.ttlfChatQueue.findIndex(function (x) { return x.type === 'auto_comment'; });
        if (removedIndex !== -1) {
          window.ttlfChatQueue.splice(removedIndex, 1);
        } else {
          return null;
        }
      }

      if (type === 'auto_reply' && item.metadata && item.metadata.chaveDoComentario) {
        var jaExiste = window.ttlfChatQueue.some(function (x) {
          return x.type === 'auto_reply' && x.metadata && x.metadata.chaveDoComentario === item.metadata.chaveDoComentario;
        });
        if (jaExiste) {
          ttlfLog('[CHAT_QUEUE] Ignorado: Resposta duplicada para a chave "' + item.metadata.chaveDoComentario + '"');
          return null;
        }
      }

      var defaultPriority = (type === 'auto_reply') ? 20 : 10;
      var itemId = 'cq_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

      var queueItem = {
        id: itemId,
        type: type,
        message: msg,
        priority: (typeof item.priority === 'number') ? item.priority : defaultPriority,
        createdAt: Date.now(),
        attempts: 0,
        maxAttempts: (typeof item.maxAttempts === 'number') ? item.maxAttempts : 1,
        onSuccess: (typeof item.onSuccess === 'function') ? item.onSuccess : null,
        onFailure: (typeof item.onFailure === 'function') ? item.onFailure : null,
        metadata: item.metadata || {}
      };

      window.ttlfChatQueue.push(queueItem);

      window.ttlfChatQueue.sort(function (a, b) {
        if (b.priority !== a.priority) return b.priority - a.priority;
        return a.createdAt - b.createdAt;
      });

      ttlfLog('[CHAT_QUEUE] Mensagem adicionada. Tipo: ' + type + ' | ID: ' + itemId);
      window.ttlfProcessChatQueue();
      return itemId;
    };

    window.ttlfRemoveChatQueueItemsByType = function (type) {
      if (!Array.isArray(window.ttlfChatQueue)) return 0;
      var initialLen = window.ttlfChatQueue.length;
      window.ttlfChatQueue = window.ttlfChatQueue.filter(function (x) { return x.type !== type; });
      var removedCount = initialLen - window.ttlfChatQueue.length;
      if (removedCount > 0) {
        ttlfLog('[CHAT_QUEUE] Removidos ' + removedCount + ' itens do tipo: ' + type);
      }
      return removedCount;
    };

    window.ttlfProcessChatQueue = function () {
      if (window.ttlfChatQueueBusy) return;
      if (!Array.isArray(window.ttlfChatQueue) || !window.ttlfChatQueue.length) return;

      var now = Date.now();
      var gap = now - (window.ttlfChatLastSendAt || 0);
      if (gap < TTLF_CHAT_QUEUE_MIN_GAP_MS) {
        var waitMs = TTLF_CHAT_QUEUE_MIN_GAP_MS - gap;
        if (window.ttlfChatQueueTimer) clearTimeout(window.ttlfChatQueueTimer);
        window.ttlfChatQueueTimer = setTimeout(function () {
          window.ttlfProcessChatQueue();
        }, waitMs);
        return;
      }

      window.ttlfChatQueueBusy = true;
      var item = window.ttlfChatQueue.shift();
      if (!item) {
        window.ttlfChatQueueBusy = false;
        return;
      }

      item.attempts += 1;
      ttlfLog('[CHAT_QUEUE] Processando item ID: ' + item.id + ' (Tipo: ' + item.type + ')');

      try {
        var enviarFn = (item.type === 'auto_comment' && typeof window.ttlfCommentsEnviar === 'function') ? window.ttlfCommentsEnviar : window.ttlfRepliesEnviar;
        if (typeof enviarFn !== 'function') {
          enviarFn = window.ttlfCommentsEnviar || window.ttlfRepliesEnviar;
        }

        if (typeof enviarFn === 'function') {
          enviarFn(item.message, function (sucesso) {
            window.ttlfChatLastSendAt = Date.now();
            try {
              if (sucesso) {
                ttlfLog('[CHAT_QUEUE] Envio confirmado para ID: ' + item.id);
                if (typeof item.onSuccess === 'function') { item.onSuccess(); }
              } else {
                ttlfLog('[CHAT_QUEUE] Envio não confirmado para ID: ' + item.id);
                if (typeof item.onFailure === 'function') { item.onFailure(); }
              }
              ttlfLog('[CHAT_QUEUE] Callback concluído.');
            } catch (errCb) {
              ttlfLog('[CHAT_QUEUE] Erro no callback: ' + errCb.message);
            } finally {
              window.ttlfChatQueueBusy = false;
              if (window.ttlfChatQueueTimer) clearTimeout(window.ttlfChatQueueTimer);
              window.ttlfChatQueueTimer = setTimeout(function () {
                window.ttlfProcessChatQueue();
              }, TTLF_CHAT_QUEUE_MIN_GAP_MS);
              ttlfLog('[CHAT_QUEUE] Próximo processamento agendado.');
            }
          });
        } else {
          window.ttlfChatQueueBusy = false;
        }
      } catch (errExec) {
        window.ttlfChatQueueBusy = false;
        ttlfLog('[CHAT_QUEUE] Exceção durante envio: ' + errExec.message);
      }
    };

    window.ttlfInitChatQueue();
  })();

  /* ===== 3. COMENTÁRIOS AUTOMÁTICOS (ETAPA 1: PERSISTÊNCIA E CONTADOR REGRESSIVO) ===== */
  (function () {
    'use strict';
    if (window.ttlfCommentsSendTimer) clearTimeout(window.ttlfCommentsSendTimer);
    if (window.ttlfCommentsCountdownTimer) clearInterval(window.ttlfCommentsCountdownTimer);
    if (window.rcTimer) clearInterval(window.rcTimer);

    var idx = 0;
    var rodando = false;
    window.ttlfCommentsSendBusy = false;

    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) {
      var p = el;
      while (p) {
        if (p.id === 'ttlf-hub' || p.id === 'rc-painel' || p.id === 'ttlf-gate') { return false; }
        p = p.parentElement;
      }
      return true;
    }
    function st(m) { var e = document.getElementById('rc-status'); if (e) { e.textContent = m; } }
    function stCountdown(m) { var e = document.getElementById('rc-countdown'); if (e) { e.textContent = m; } }

    function clicar(el) {
      if (el && typeof el.click === 'function') { el.click(); return; }
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
        try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {}
      });
    }

    function acharCaixa() {
      var tas = $s('textarea').filter(function (t) {
        if (!vis(t) || !fora(t)) { return false; }
        var ph = t.getAttribute('placeholder') || '';
        return /Digite|Diga|Say|coment|chat/i.test(ph);
      });
      if (tas.length) { return tas[0]; }
      tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); });
      return tas.length ? tas[0] : null;
    }

    function enviar(msg, callback) {
      if (window.ttlfCommentsSendBusy) {
        if (callback) callback(false);
        return;
      }

      window.ttlfCommentsSendBusy = true;
      stCountdown('Enviando comentário...');

      try {
        var ta = acharCaixa();
        if (!ta) {
          st('Caixa de comentário não encontrada — a LIVE está no ar?');
          stCountdown('Aguardando campo de comentários...');
          window.ttlfCommentsSendBusy = false;
          if (callback) callback(false);
          return;
        }

        var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        ta.focus();
        setter.call(ta, msg);
        ta.dispatchEvent(new Event('input', { bubbles: true }));

        setTimeout(function () {
          try {
            var tr = ta.getBoundingClientRect();
            var sv = $s('svg,button,[role="button"]').filter(function (b) {
              if (!vis(b) || !fora(b)) { return false; }
              var r = b.getBoundingClientRect();
              var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2;
              if (((b.textContent || '').trim()) !== '') { return false; }
              return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 60 && getComputedStyle(b).cursor === 'pointer';
            });

            if (sv.length) {
              sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
              clicar(sv[sv.length - 1]);
            } else {
              ['keydown', 'keypress', 'keyup'].forEach(function (tp) {
                ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
              });
            }

            setTimeout(function () {
              window.ttlfCommentsSendBusy = false;
              var enviouOk = (ta.value === '');
              if (enviouOk) {
                st('Enviado ✅ "' + msg.slice(0, 28) + '" ' + new Date().toLocaleTimeString());
                ttlfLog('[COMMENTS] Envio confirmado: "' + msg.slice(0, 30) + '"');
              } else {
                st('Envio não confirmado. Nova tentativa no próximo intervalo.');
                ttlfLog('[COMMENTS] Envio não confirmado. Caixa não esvaziou.');
              }
              if (callback) callback(enviouOk);
            }, 900);
          } catch (e) {
            window.ttlfCommentsSendBusy = false;
            if (callback) callback(false);
          }
        }, 400);
      } catch (err) {
        window.ttlfCommentsSendBusy = false;
        if (callback) callback(false);
      }
    }

    function getMensagensLista() {
      var el = document.getElementById('rc-msgs');
      if (!el) return [];
      return el.value.split('\n').map(function (t) { return t.trim(); }).filter(function (t) { return t.length > 0; });
    }

    function getIntervaloSegundos() {
      var el = document.getElementById('rc-int');
      var val = el ? parseInt(el.value, 10) : 90;
      if (isNaN(val) || val < 10) val = 90;
      return val;
    }

    function salvarPersistencia() {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        var msgsTxt = document.getElementById('rc-msgs') ? document.getElementById('rc-msgs').value : '';
        var intervalVal = getIntervaloSegundos();
        chrome.storage.local.set({
          ttlf_comments_messages: msgsTxt,
          ttlf_comments_interval: intervalVal,
          ttlf_comments_enabled: rodando,
          ttlf_comments_current_index: idx
        }, function () {
          ttlfLog('[COMMENTS] Configurações salvas no storage.');
        });
      }
    }

    function atualizarCountdownVisual() {
      if (!rodando) {
        stCountdown('Comentários automáticos desligados.');
        return;
      }

      if (window.ttlfCommentsSendBusy) {
        stCountdown('Enviando comentário...');
        return;
      }

      window.ttlfSafeStorageGet(['ttlf_comments_next_send_at'], function (res) {
        var targetMs = res ? res.ttlf_comments_next_send_at : 0;
        if (!targetMs) return;

        var restantesMs = targetMs - Date.now();
        var restantesSeg = Math.ceil(restantesMs / 1000);

        if (restantesSeg <= 0) {
          stCountdown('Enviando comentário...');
        } else {
          stCountdown('Próximo comentário em ' + restantesSeg + 's');
        }
      });
    }

    function agendarProximoEnvio(delayMs) {
      if (window.ttlfCommentsSendTimer) clearTimeout(window.ttlfCommentsSendTimer);
      if (!rodando) return;

      var delayReal = (typeof delayMs === 'number' && delayMs >= 0) ? delayMs : (getIntervaloSegundos() * 1000);
      var nextSendAt = Date.now() + delayReal;

      window.ttlfSafeStorageSet({
        ttlf_comments_next_send_at: nextSendAt,
        ttlf_comments_enabled: true,
        ttlf_comments_current_index: idx
      });

      ttlfLog('[COMMENTS] Próximo envio agendado para daqui a ' + Math.round(delayReal / 1000) + 's (Índice: ' + idx + ')');

      window.ttlfCommentsSendTimer = setTimeout(function () {
        executarEnvioCiclo();
      }, delayReal);
    }

    window.ttlfCommentsEnviar = enviar;

    function executarEnvioCiclo() {
      if (!rodando) return;

      var linhas = getMensagensLista();
      if (!linhas.length) {
        st('Escreva pelo menos 1 comentário na lista.');
        stCountdown('Aguardando mensagens válidas...');
        agendarProximoEnvio();
        return;
      }

      if (idx >= linhas.length || idx < 0 || isNaN(idx)) {
        idx = 0;
      }

      if (window.ttlfCommentsQueuedItemId) {
        st('Comentário aguardando envio...');
        stCountdown('Aguardando envio na fila...');
        return;
      }

      var msg = linhas[idx];
      if (msg.length > 100) msg = msg.slice(0, 97) + '...';

      ttlfLog('[COMMENTS] Encaminhando para fila central (Índice ' + idx + '): "' + msg.slice(0, 30) + '"');
      st('Comentário aguardando envio...');
      stCountdown('Aguardando envio na fila...');

      window.ttlfCommentsQueuedItemId = window.ttlfEnqueueChatMessage({
        type: "auto_comment",
        message: msg,
        priority: 10,
        maxAttempts: 1,
        metadata: { index: idx },
        onSuccess: function () {
          window.ttlfCommentsQueuedItemId = null;
          idx = (idx + 1) % linhas.length;
          salvarPersistencia();
          st('Enviado ✅ "' + msg.slice(0, 28) + '" ' + new Date().toLocaleTimeString());
          agendarProximoEnvio(getIntervaloSegundos() * 1000);
        },
        onFailure: function () {
          window.ttlfCommentsQueuedItemId = null;
          st('Envio não confirmado. Nova tentativa no próximo intervalo.');
          agendarProximoEnvio(getIntervaloSegundos() * 1000);
        }
      });
    }

    function liga(delayInicialMs) {
      if (rodando) return;
      var linhas = getMensagensLista();
      if (!linhas.length) {
        st('Escreva pelo menos 1 comentário na lista.');
        return;
      }

      rodando = true;
      window.ttlfCommentsEnabled = true;

      var b = document.getElementById('rc-botao');
      if (b) {
        b.textContent = '⏸ Parar';
        b.style.background = '#ff1717';
      }

      st('Monitorando envio de comentários...');
      ttlfLog('[COMMENTS] Módulo de comentários iniciado.');

      if (window.ttlfCommentsCountdownTimer) clearInterval(window.ttlfCommentsCountdownTimer);
      window.ttlfCommentsCountdownTimer = setInterval(atualizarCountdownVisual, 1000);

      var firstDelay = (typeof delayInicialMs === 'number') ? delayInicialMs : (getIntervaloSegundos() * 1000);
      agendarProximoEnvio(firstDelay);
      salvarPersistencia();
    }

    function desliga() {
      rodando = false;
      window.ttlfCommentsEnabled = false;

      if (window.ttlfCommentsSendTimer) { clearTimeout(window.ttlfCommentsSendTimer); window.ttlfCommentsSendTimer = null; }
      if (window.ttlfCommentsCountdownTimer) { clearInterval(window.ttlfCommentsCountdownTimer); window.ttlfCommentsCountdownTimer = null; }
      if (window.rcTimer) { clearInterval(window.rcTimer); window.rcTimer = null; }

      if (typeof window.ttlfRemoveChatQueueItemsByType === 'function') {
        window.ttlfRemoveChatQueueItemsByType('auto_comment');
      }
      window.ttlfCommentsQueuedItemId = null;

      var b = document.getElementById('rc-botao');
      if (b) {
        b.textContent = '▶ Iniciar';
        b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)';
        b.style.color = '#000';
      }

      st('Desligado.');
      stCountdown('Comentários automáticos desligados.');

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({
          ttlf_comments_enabled: false,
          ttlf_comments_next_send_at: null
        });
      }
      ttlfLog('[COMMENTS] Módulo de comentários interrompido.');
    }

    window.ttlfCommentsToggle = function () {
      rodando ? desliga() : liga();
    };

    window.ttlfInitCommentsModule = function () {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([
          'ttlf_comments_messages',
          'ttlf_comments_interval',
          'ttlf_comments_enabled',
          'ttlf_comments_current_index',
          'ttlf_comments_next_send_at'
        ], function (res) {
          if (!res) return;

          var elMsgs = document.getElementById('rc-msgs');
          if (elMsgs && typeof res.ttlf_comments_messages === 'string' && res.ttlf_comments_messages.trim().length > 0) {
            elMsgs.value = res.ttlf_comments_messages;
          }

          var elInt = document.getElementById('rc-int');
          if (elInt && typeof res.ttlf_comments_interval === 'number' && res.ttlf_comments_interval >= 10) {
            elInt.value = res.ttlf_comments_interval;
          }

          if (typeof res.ttlf_comments_current_index === 'number' && res.ttlf_comments_current_index >= 0) {
            idx = res.ttlf_comments_current_index;
          }

          // Debounce de autosave para a textarea
          if (elMsgs && !elMsgs.dataset.ttlfBoundSave) {
            elMsgs.dataset.ttlfBoundSave = '1';
            var saveDebounceTimer = null;
            elMsgs.addEventListener('input', function () {
              if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
              saveDebounceTimer = setTimeout(salvarPersistencia, 400);
            });
          }

          // Autosave do intervalo
          if (elInt && !elInt.dataset.ttlfBoundSave) {
            elInt.dataset.ttlfBoundSave = '1';
            elInt.addEventListener('change', function () {
              var val = parseInt(elInt.value, 10);
              if (isNaN(val) || val < 10) elInt.value = 90;
              salvarPersistencia();
            });
          }

          ttlfLog('[COMMENTS] Configurações restauradas do storage com sucesso.');

          // Restauração do estado ativado
          if (res.ttlf_comments_enabled === true) {
            var nextAt = res.ttlf_comments_next_send_at || 0;
            var diff = nextAt - Date.now();
            var delayInicial = (diff > 0) ? diff : 5000;
            liga(delayInicial);
          }
        });
      }
    };

    var btnRc = document.getElementById('rc-botao');
    if (btnRc) {
      ttlfBindOnce(btnRc, 'click', 'rcBotaoClick', function () {
        window.ttlfCommentsToggle();
      });
    }

    setTimeout(function () {
      if (typeof window.ttlfInitCommentsModule === 'function') {
        window.ttlfInitCommentsModule();
      }
    }, 500);
  })();

  // =====================================================
  // 🔒 FROZEN — RESPOSTAS AUTOMÁTICAS
  // APROVADO EM LIVE REAL PELO USUÁRIO EM 29/07/2026
  // NÃO ALTERAR SEM AUTORIZAÇÃO EXPRESSA
  // =====================================================
  /* ===== 4. RESPOSTAS AUTOMÁTICAS NO CHAT ===== */
  (function () {
    'use strict';
    if (window.ttlfRepliesScanTimer) { clearInterval(window.ttlfRepliesScanTimer); }
    if (window.ttlfRepliesQueueTimer) { clearInterval(window.ttlfRepliesQueueTimer); }
    if (window.raVarre) { clearInterval(window.raVarre); }
    if (window.raFila) { clearInterval(window.raFila); }

    var rodando = false; var vistos = new Map(); var vistoEm = new Map(); var fila = []; var ultimoEnvio = 0; var enviados = 0;
    window.ttlfRepliesRunning = false;
    window.ttlfRepliesSendBusy = false;

    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ra-painel') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('ra-status'); if (e) { e.textContent = m; } }
    function norm(t) { return (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { st('Caixa de comentário não encontrada.'); return; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"]').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 60 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } else { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); }); } setTimeout(function () { if (ta.value === '') { enviados = enviados + 1; st('Respondido ✅ (' + enviados + ' no total) ' + new Date().toLocaleTimeString()); } else { st('⚠️ ENVIO FALHOU'); } }, 900); }, 400); }
    function itensComentario() { var ta = $s('textarea').filter(function (t) { var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph) && vis(t) && fora(t); })[0]; var painel = document; if (ta) { var pp = ta; for (var k = 0; k < 10 && pp; k++) { pp = pp.parentElement; if (!pp) { break; } if ($s('img', pp).length >= 1 && pp.getBoundingClientRect().height > 200) { painel = pp; } } } var rows = $s('[class*="cursor-pointer"],[class*="rounded"]', painel).filter(function (el) { if (!vis(el) || !fora(el)) { return false; } var imgs = $s('img', el).filter(function (im) { var r = im.getBoundingClientRect(); return r.width >= 14 && r.width <= 56; }); if (imgs.length !== 1) { return false; } var lv = $s('div,span', el).filter(function (x) { return x.children.length === 0 && (x.textContent || '').trim(); }); var txts = lv.map(function (x) { return x.textContent.trim(); }).filter(function (t) { return t !== 'Host' && t !== 'Anfitrião'; }); if (txts.length < 2) { return false; } var full = (el.textContent || '').trim(); if (/está vendo o produto|acabou de|entrou na|pedidos feitos|aparecer[aã]o aqui|Alternar modo|Console de LIVE/i.test(full)) { return false; } return full.length > 0 && full.length < 400; }); rows = rows.filter(function (el) { return !rows.some(function (o) { return o !== el && el.contains(o); }); }); var groups = new Map(); rows.forEach(function (el) { var pr = el.parentElement; if (!groups.has(pr)) { groups.set(pr, []); } groups.get(pr).push(el); }); var best = []; groups.forEach(function (v) { if (v.length > best.length) { best = v; } }); if (!best.length) { best = rows; } return best.map(function (row) { var lv = $s('div,span', row).filter(function (x) { return x.children.length === 0 && (x.textContent || '').trim(); }); var host = false, textos = []; for (var i2 = 0; i2 < lv.length; i2++) { var t = lv[i2].textContent.trim(); if (t === 'Host' || t === 'Anfitrião') { host = true; continue; } textos.push(t); } return { el: row, autor: textos.length ? textos[0] : '', texto: textos.length ? textos[textos.length - 1] : '', host: host }; }); }
    function regras() { var linhas = document.getElementById('ra-regras').value.split('\n'); var rs = []; for (var i = 0; i < linhas.length; i++) { var linha = linhas[i].replace('=>', '='); var ix = linha.indexOf('='); if (ix < 0) { continue; } var chaves = linha.slice(0, ix).split(',').map(norm).filter(function (c) { return c.length > 0; }); var resp = linha.slice(ix + 1).trim(); if (chaves.length && resp) { rs.push({ chaves: chaves, resp: resp }); } } return rs; }
    function marcarTudoVisto() { var agora = Date.now(); itensComentario().forEach(function (c) { var chave = c.autor + '|' + c.texto; try { c.el.dataset.raVisto = chave; } catch (e) {} vistos.set(chave, agora); }); }
    function varre() { if (!rodando) { return; } var rs = regras(); var mencionar = document.getElementById('ra-mencao').checked; var agora = Date.now(); var itens = itensComentario(); var cont = {}; itens.forEach(function (c) { var k = c.autor + '|' + c.texto; cont[k] = (cont[k] || 0) + 1; }); itens.forEach(function (c) { var chave = c.autor + '|' + c.texto; var vistoAntes = vistoEm.get(chave) || 0; vistoEm.set(chave, agora); if (c.el.dataset && c.el.dataset.raVisto === chave) { return; } try { c.el.dataset.raVisto = chave; } catch (e) {} if (c.host) { return; } if (vistos.has(chave)) { var repetido = cont[chave] >= 2; var passou15s = agora - vistos.get(chave) > 15000; if (!(repetido && passou15s)) { return; } } var tn = norm(c.texto); for (var i = 0; i < rs.length; i++) { var bate = rs[i].chaves.some(function (k) { return tn.indexOf(k) > -1; }); if (bate) { vistos.set(chave, agora); var resp = (mencionar && c.autor ? ('@' + c.autor + ' ') : '') + rs[i].resp; if (resp.length > 100) { resp = rs[i].resp; } if (resp.length > 100) { resp = resp.slice(0, 97) + '...'; } fila.push(resp); break; } } }); }
    function processaFila() {
      if (!rodando || !fila.length) { return; }
      window.ttlfRepliesEnviar = enviar;
      if (window.ttlfRepliesQueuedItemId) {
        st('Resposta aguardando envio...');
        return;
      }

      var itemRemovido = fila.shift();
      if (!itemRemovido) return;

      st('Resposta aguardando envio...');
      window.ttlfRepliesQueuedItemId = window.ttlfEnqueueChatMessage({
        type: "auto_reply",
        message: itemRemovido,
        priority: 20,
        maxAttempts: 1,
        metadata: { chaveDoComentario: itemRemovido },
        onSuccess: function () {
          window.ttlfRepliesQueuedItemId = null;
          enviados = enviados + 1;
          st('Respondido ✅ (' + enviados + ' no total) ' + new Date().toLocaleTimeString());
          salvarPersistencia();
        },
        onFailure: function () {
          window.ttlfRepliesQueuedItemId = null;
          st('Envio não confirmado — ' + enviados + ' no total');
        }
      });
    }

    function salvarPersistencia() {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        var regrasTxt = document.getElementById('ra-regras') ? document.getElementById('ra-regras').value : '';
        var mencaoChecked = document.getElementById('ra-mencao') ? document.getElementById('ra-mencao').checked : true;
        chrome.storage.local.set({
          ttlf_replies_rules: regrasTxt,
          ttlf_replies_mention_enabled: mencaoChecked,
          ttlf_replies_enabled: rodando,
          ttlf_replies_total_sent: enviados
        }, function () {
          ttlfLog('[REPLIES] Configurações salvas no storage.');
        });
      }
    }

    function liga() {
      if (!regras().length) {
        st('Cadastre pelo menos 1 regra válida (palavra = resposta).');
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ ttlf_replies_enabled: false });
        }
        return;
      }
      if (window.ttlfRepliesRunning) {
        var bActive = document.getElementById('ra-botao');
        if (bActive) {
          bActive.textContent = '⏸ Parar';
          bActive.style.background = '#ff1717';
        }
        return;
      }

      marcarTudoVisto();
      rodando = true;
      window.ttlfRepliesRunning = true;

      var b = document.getElementById('ra-botao');
      if (b) {
        b.textContent = '⏸ Parar';
        b.style.background = '#ff1717';
      }
      st(enviados > 0 ? ('Respondido ✅ (' + enviados + ' no total)') : 'Monitorando comentários... 👀');

      if (window.ttlfRepliesScanTimer) clearInterval(window.ttlfRepliesScanTimer);
      if (window.ttlfRepliesQueueTimer) clearInterval(window.ttlfRepliesQueueTimer);
      if (window.raVarre) clearInterval(window.raVarre);
      if (window.raFila) clearInterval(window.raFila);

      window.ttlfRepliesScanTimer = setInterval(varre, 2000);
      window.ttlfRepliesQueueTimer = setInterval(processaFila, 1000);
      window.raVarre = window.ttlfRepliesScanTimer;
      window.raFila = window.ttlfRepliesQueueTimer;

      salvarPersistencia();
      ttlfLog('[REPLIES] Módulo iniciado.');
    }

    function desliga() {
      rodando = false;
      window.ttlfRepliesRunning = false;
      fila = [];

      if (window.ttlfRepliesScanTimer) { clearInterval(window.ttlfRepliesScanTimer); window.ttlfRepliesScanTimer = null; }
      if (window.ttlfRepliesQueueTimer) { clearInterval(window.ttlfRepliesQueueTimer); window.ttlfRepliesQueueTimer = null; }
      if (window.raVarre) { clearInterval(window.raVarre); window.raVarre = null; }
      if (window.raFila) { clearInterval(window.raFila); window.raFila = null; }

      if (typeof window.ttlfRemoveChatQueueItemsByType === 'function') {
        window.ttlfRemoveChatQueueItemsByType('auto_reply');
      }
      window.ttlfRepliesQueuedItemId = null;

      var b = document.getElementById('ra-botao');
      if (b) {
        b.textContent = '▶ Iniciar';
        b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)';
        b.style.color = '#000';
      }
      st('Desligado.');

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ ttlf_replies_enabled: false });
      }
      ttlfLog('[REPLIES] Módulo interrompido.');
    }

    window.ttlfRepliesToggle = function () {
      rodando ? desliga() : liga();
    };

    window.ttlfInitRepliesModule = function () {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([
          'ttlf_replies_rules',
          'ttlf_replies_mention_enabled',
          'ttlf_replies_enabled',
          'ttlf_replies_total_sent'
        ], function (res) {
          if (!res) return;

          var elRegras = document.getElementById('ra-regras');
          if (elRegras && typeof res.ttlf_replies_rules === 'string') {
            elRegras.value = res.ttlf_replies_rules;
          }

          var elMencao = document.getElementById('ra-mencao');
          if (elMencao && typeof res.ttlf_replies_mention_enabled === 'boolean') {
            elMencao.checked = res.ttlf_replies_mention_enabled;
          }

          if (typeof res.ttlf_replies_total_sent === 'number' && res.ttlf_replies_total_sent >= 0) {
            enviados = res.ttlf_replies_total_sent;
          }

          // Debounce de autosave para as regras (400ms)
          if (elRegras && !elRegras.dataset.ttlfBoundSave) {
            elRegras.dataset.ttlfBoundSave = '1';
            var saveDebounceTimer = null;
            elRegras.addEventListener('input', function () {
              if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
              saveDebounceTimer = setTimeout(salvarPersistencia, 400);
            });
          }

          // Autosave do checkbox de menção
          if (elMencao && !elMencao.dataset.ttlfBoundSave) {
            elMencao.dataset.ttlfBoundSave = '1';
            elMencao.addEventListener('change', function () {
              salvarPersistencia();
              ttlfLog(elMencao.checked ? '[REPLIES] Menção ativada.' : '[REPLIES] Menção desativada.');
            });
          }

          ttlfLog('[REPLIES] Configurações restauradas do storage com sucesso.');

          if (res.ttlf_replies_enabled === true) {
            liga();
            ttlfLog('[REPLIES] Módulo retomado após refresh.');
          }
        });
      }
    };

    var btnRa = document.getElementById('ra-botao');
    if (btnRa) {
      ttlfBindOnce(btnRa, 'click', 'raBotaoClick', function () {
        window.ttlfRepliesToggle();
      });
    }

    setTimeout(function () {
      if (typeof window.ttlfInitRepliesModule === 'function') {
        window.ttlfInitRepliesModule();
      }
    }, 500);
  })();

  /* ===== 5. BLOQUEIO POR NOME (HATERS) ===== */
  (function () {
    'use strict';
    if (window.bnTimer) { clearInterval(window.bnTimer); }
    var rodando = false; var tratados = {};
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function norm(x) { return (x || '').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }
    function palavras() { var e = document.getElementById('bn-palavras'); if (!e) { return []; } return e.value.split('\n').map(function (x) { return norm(x); }).filter(function (x) { return x.length > 0; }); }
    function st(m) { var e = document.getElementById('bn-status'); if (e) { e.textContent = m; } }
    function disparar(el, tipos) { tipos.forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function clicar(el) { if (!el) { return; } try { el.scrollIntoView({ block: 'center' }); } catch (e) {} disparar(el, ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']); }
    function hover(el) { disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']); }
    function entradas() { var res = []; var vistos = []; $s('div,span,p').filter(function (x) { return vis(x) && fora(x) && x.children.length <= 4 && /acabou de entrar/i.test(x.textContent || '') && (x.textContent || '').length < 160; }).forEach(function (mk) { var row = mk; while (row.parentElement && /acabou de entrar/i.test(row.parentElement.textContent || '') && (row.parentElement.textContent || '').length < 160) { row = row.parentElement; } if (vistos.indexOf(row) > -1) { return; } vistos.push(row); var full = (row.textContent || '').replace(/\s+/g, ' ').trim(); var nome = full.replace(/\s*acabou de entrar.*/i, '').trim(); if (nome) { res.push({ row: row, nome: nome }); } }); return res; }
    function acharBloquear() { return $s('div,span,button,a,li').filter(function (x) { if (!vis(x) || x.children.length > 2) { return false; } var t = norm(x.textContent); return t.indexOf('bloquear') === 0; })[0]; }
    function maisBotoes(row) { var cs = $s('button,[role="button"],div,span,svg', row).filter(function (x) { if (!vis(x)) { return false; } var t = (x.textContent || '').trim(); return t.length <= 3; }); cs.sort(function (a, b) { return b.getBoundingClientRect().right - a.getBoundingClientRect().right; }); return cs.slice(0, 6); }
    function bloquear(item) { hover(item.row); setTimeout(function () { var mais = maisBotoes(item.row); var i = 0; (function tenta() { if (i >= mais.length) { st('Detectei "' + item.nome + '" mas não achei o botão "..."'); return; } clicar(mais[i]); i++; setTimeout(function () { var bl = acharBloquear(); if (bl) { clicar(bl); setTimeout(function () { var conf = $s('button,div,span,a').filter(function (x) { if (!vis(x) || x.children.length > 1) { return false; } var t = norm((x.textContent || '').trim()); return t === 'confirmar' || t === 'confirm' || t === 'sim' || t === 'ok'; })[0]; if (conf) { clicar(conf); } st('🚫 Bloqueado: ' + item.nome + ' (' + new Date().toLocaleTimeString() + ')'); }, 550); } else { tenta(); } }, 350); })(); }, 300); }
    function varre() { if (!rodando) { return; } var ps = palavras(); if (!ps.length) { return; } entradas().forEach(function (it) { var nn = norm(it.nome); if (!nn || tratados[nn]) { return; } if (ps.some(function (pw) { return nn.indexOf(pw) > -1; })) { tratados[nn] = 1; bloquear(it); } }); }
    function liga() { if (!palavras().length) { st('Cadastre pelo menos 1 palavra suspeita.'); return; } rodando = true; var b = document.getElementById('bn-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando entradas... 👀'); }
    function desliga() { rodando = false; var b = document.getElementById('bn-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    window.ttlfBlockNameToggle = function () { rodando ? desliga() : liga(); };
    var bb = document.getElementById('bn-botao'); if (bb) { bb.addEventListener('click', function () { window.ttlfBlockNameToggle(); }); }
    window.bnTimer = setInterval(varre, 3000);
  })();

  // =====================================================
  // 🔒 FROZEN — MENSAGEM DE INTENÇÃO DE COMPRA
  // APROVADO EM LIVE REAL PELO USUÁRIO EM 29/07/2026
  // NÃO ALTERAR SEM AUTORIZAÇÃO EXPRESSA
  // =====================================================
  /* ===== 6. INTENÇÃO DE COMPRA ===== */
  (function () {
    'use strict';
    if (window.icTimer) { clearInterval(window.icTimer); }
    var rodando = false; var feitos = {}; var fila = []; var ocupado = false; var pendentes = []; var ultimoEnvio = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function st(m) { var e = document.getElementById('ic-status'); if (e) { e.textContent = m; } }
    function disparar(el, tipos) { tipos.forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function hover(el) { disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']); }
    function unhover(el) { disparar(el, ['mouseout', 'mouseleave', 'pointerout', 'pointerleave']); }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } disparar(el, ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { return false; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"],span').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 44 && r.left > tr.left - 6 && r.left < tr.right + 72 && r.width <= 40 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } setTimeout(function () { if (ta.value !== '') { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); }); } }, 250); }, 350); return true; }
    function achaAvatar(row) { var im = $s('img', row).filter(function (x) { return vis(x); }); if (im.length) { return im[0]; } var cs = $s('div,span', row).filter(function (x) { var r = x.getBoundingClientRect(); return vis(x) && r.width >= 16 && r.width <= 54 && r.height >= 16 && r.height <= 54; }); cs.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cs.length ? cs[0] : null; }
    function realVis(e) { try { var cs = getComputedStyle(e); if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.3) { return false; } var an = e.parentElement, k = 0; while (an && k < 8) { var c2 = getComputedStyle(an); if (c2.visibility === 'hidden' || c2.display === 'none' || parseFloat(c2.opacity) < 0.3) { return false; } an = an.parentElement; k++; } return true; } catch (_) { return false; } }
    function sobresReais() { var a = []; $s('div,span,p,h1,h2,h3,b,strong').forEach(function (e) { if (e.children.length > 3) { return; } var t = (e.textContent || '').trim(); var m = t.match(/^Sobre\s+(.{2,40})$/i); if (!m) { return; } if (!realVis(e)) { return; } var n = m[1].replace(/\s*[ⓘℹ️①(].*$/, '').trim(); if (n) { a.push(n); } }); return a; }
    function nomePopover(antes) { var depois = sobresReais(); var novos = depois.filter(function (n) { return antes.indexOf(n) < 0; }); if (novos.length) { return novos[0]; } return depois.length ? depois[0] : null; }
    function eventos() { var res = []; var vistos = []; $s('div,span,p').filter(function (x) { if (!vis(x) || !fora(x) || x.children.length !== 0) { return false; } var t = (x.textContent || '').trim(); if (t.length > 60) { return false; } return /adicionou o produto/i.test(t) && /carrinho/i.test(t); }).forEach(function (mk) { var row = mk; for (var i = 0; i < 6 && row.parentElement; i++) { row = row.parentElement; if (row.querySelector('img')) { break; } } if (vistos.indexOf(row) > -1) { return; } vistos.push(row); var t = (mk.textContent || ''); res.push({ row: row, tipo: /est[aá] vendo/i.test(t) ? 'ver' : 'cart' }); }); return res; }
    function processa() { if (ocupado || !rodando || !fila.length) { return; } ocupado = true; var it = fila.shift(); var av = achaAvatar(it.row); if (!av) { ocupado = false; return; } var antes = sobresReais(); function limpaHover() { unhover(av); var _pp = av; for (var _i = 0; _i < 4 && _pp; _i++) { unhover(_pp); _pp = _pp.parentElement; } try { document.body.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: 4, clientY: 4, view: window })); } catch (e) {} } function finaliza(nome) { limpaHover(); if (!nome) { st('Vi um evento mas não peguei o nome.'); setTimeout(function () { ocupado = false; }, 300); return; } var chave = 'cart|' + nome; if (feitos[chave]) { ocupado = false; return; } feitos[chave] = 1; var base = (document.getElementById('ic-cart') || { value: '' }).value || ''; base = base.trim(); if (!base) { ocupado = false; return; } var msg = '@' + nome + ' ' + base; if (msg.length > 100) { msg = msg.slice(0, 100); } pendentes.push({ texto: msg, label: 'Carrinho: @' + nome }); st('🛒 Carrinho: @' + nome + ' — na fila de envio'); setTimeout(function () { ocupado = false; }, 400); } var tent = 0; function tenta() { tent++; hover(av); setTimeout(function () { var nome = nomePopover(antes); if (nome) { finaliza(nome); return; } if (tent >= 7) { finaliza(null); return; } tenta(); }, 280); } tenta(); }
    function varre() { if (!rodando) { return; } try { var evs = eventos(); evs.forEach(function (ev) { if (ev.row.dataset && ev.row.dataset.icQ) { return; } try { ev.row.dataset.icQ = '1'; } catch (e) {} fila.push(ev); }); if (!ocupado && !fila.length && !pendentes.length) { st('Monitorando Intenção de compra... 👀'); } } catch (err) { st('erro varre: ' + ((err && err.message) || err)); } }
    function enviaPendentes() { if (!rodando || !pendentes.length) { return; } var agora = Date.now(); if (agora - ultimoEnvio < 4000) { return; } ultimoEnvio = agora; var item = pendentes.shift(); var ok = enviar(item.texto); st(ok ? ('💬 ' + item.label + ' — enviado (' + new Date().toLocaleTimeString() + ')') : ('Fila cheia — caixa não encontrada.')); }
    function liga() { rodando = true; var b = document.getElementById('ic-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando intenção de compra... 👀'); }
    function desliga() { rodando = false; fila = []; pendentes = []; ocupado = false; var b = document.getElementById('ic-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    window.ttlfAchaAvatar = achaAvatar;
    window.ttlfSobresReais = sobresReais;
    window.ttlfNomePopover = nomePopover;
    window.ttlfHover = hover;
    window.ttlfUnhover = unhover;
    window.ttlfClicar = clicar;
    window.ttlfIntentToggle = function () { rodando ? desliga() : liga(); };
    var bb = document.getElementById('ic-botao'); if (bb) { bb.addEventListener('click', function () { window.ttlfIntentToggle(); }); }
    window.icTimer = setInterval(function () { varre(); processa(); enviaPendentes(); }, 1200);
  })();

  /* ===== 7. ALERTA DE VENDAS NTFY ===== */
  (function () {
    'use strict';
    if (window.nvTimer) { clearInterval(window.nvTimer); }
    var rodando = false; var fila = []; var ultimo = 0; var total = 0;
    var RE = /(fez um pedido|realizou (um |o )?pedido|acabou de comprar|comprou|compraram|pagamento (confirmado|efetuado)|efetuou o pagamento|pedido pago|pagou o pedido|criou (um|o) pedido|placed an order)/i;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function st(m) { var e = document.getElementById('nv-status'); if (e) { e.textContent = m; } }
    function canal() { var e = document.getElementById('nv-canal'); return e ? (e.value || '').trim() : ''; }
    function manda(titulo, corpo, tags, cb) { var c = canal(); if (!c) { if (cb) { cb(false); } return; } function direto() { try { fetch('https://ntfy.sh', { method: 'POST', body: JSON.stringify({ topic: c, title: titulo, message: corpo, tags: (tags || 'bell').split(','), priority: 5 }) }).then(function (r) { if (cb) { cb(r.ok); } }).catch(function () { if (cb) { cb(false); } }); } catch (e) { if (cb) { cb(false); } } } try { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) { chrome.runtime.sendMessage({ type: 'ttlf-ntfy', canal: c, titulo: titulo, corpo: corpo, tags: tags || 'bell' }, function (resp) { if (chrome.runtime.lastError || !resp || !resp.ok) { direto(); } else { if (cb) { cb(true); } } }); return; } } catch (e) {} direto(); }
    function contaVendas(t) { return (String(t).match(/comprou o produto|acabou de comprar|fez um pedido|realizou (um |o )?pedido|placed an order/gi) || []).length; }
    function eventosVenda() { var res = []; var singles = $s('div,span,p').filter(function (x) { if (!vis(x) || !fora(x)) { return false; } var t = (x.textContent || '').trim(); if (!t || t.length > 90) { return false; } return contaVendas(t) === 1 && RE.test(t) && /R\$\s?\d/.test(t); }); singles.forEach(function (x) { for (var j = 0; j < singles.length; j++) { if (singles[j] !== x && x.contains(singles[j])) { return; } } res.push({ el: x, txt: (x.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 90) }); }); return res; }
    function marcarVistos() { eventosVenda().forEach(function (ev) { try { ev.el.dataset.nvQ = '1'; } catch (e) {} }); }
    function dlog(t) { try { var arr = []; try { arr = JSON.parse(localStorage.getItem('ttlf-nv-debug') || '[]'); } catch (e) {} arr.push(new Date().toTimeString().slice(0, 8) + ' ' + t); if (arr.length > 80) { arr = arr.slice(-80); } localStorage.setItem('ttlf-nv-debug', JSON.stringify(arr)); } catch (e) {} try { ttlfLog('[VendaDbg] ' + t); } catch (e) {} }
    function debugScan() { try { $s('div,span,p').forEach(function (x) { if (x.children.length > 3) { return; } if (!vis(x) || !fora(x)) { return; } var t = (x.textContent || '').trim(); if (!t || t.length > 160) { return; } if (!/(compr|pedido|pagou)/i.test(t)) { return; } if (x.dataset && x.dataset.nvDbg) { return; } try { x.dataset.nvDbg = '1'; } catch (e) {} dlog(t); }); } catch (e) {} }
    function varre() { if (!rodando) { return; } try { var agora = Date.now(); eventosVenda().forEach(function (ev) { if (ev.el.dataset && ev.el.dataset.nvQ) { return; } try { ev.el.dataset.nvQ = '1'; } catch (e) {} dlog('DETECTOU VENDA: ' + ev.txt); fila.push(ev.txt); }); } catch (err) { st('erro: ' + ((err && err.message) || err)); } }
    function corpoVenda(txt) {
      txt = txt || ''; var preco = null, prod = null; var mp = txt.match(/R\$\s?([\d.]+,\d{2}|[\d.,]+)/); if (mp) { preco = 'R$ ' + mp[1]; } var mn = txt.match(/n[ºo°.]?\s?(\d+)/i); if (mn) { prod = 'Produto nº ' + mn[1]; }
      if (preco) {
        var numP = parseFloat(mp[1].replace(/\./g, '').replace(',', '.'));
        if (!isNaN(numP) && numP < 1000000) {
          window.ttlfTotalGMVContado = (window.ttlfTotalGMVContado || 0) + numP;
        }
      }
      window.ttlfTotalVendasContadas = (window.ttlfTotalVendasContadas || 0) + 1;
      if (prod && preco) { return prod + ' — ' + preco; } if (preco) { return 'Venda de ' + preco + ' na sua LIVE!'; } if (prod) { return prod + ' vendido na sua LIVE!'; } return txt ? txt : 'Nova venda na sua LIVE! 🤑';
    }
    function envia() { if (!rodando || !fila.length) { return; } var agora = Date.now(); if (agora - ultimo < 1500) { return; } ultimo = agora; var txt = fila.shift(); manda('Venda Realizada - Parabéns!', corpoVenda(txt), 'moneybag', function (ok) { if (ok) { total = total + 1; st('🤑 Venda #' + total + ' — notificação enviada ' + new Date().toLocaleTimeString()); } else { st('⚠️ Falha ao enviar notificação — confira o canal.'); } }); }
    function liga() { if (!canal()) { st('Digite o nome do canal ntfy primeiro.'); return; } marcarVistos(); rodando = true; var b = document.getElementById('nv-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando vendas... 👀'); }
    function desliga() { rodando = false; fila = []; var b = document.getElementById('nv-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    window.ttlfNtfyToggle = function () { rodando ? desliga() : liga(); };
    window.ttlfNtfyTeste = function () { if (!canal()) { st('Digite o nome do canal ntfy primeiro.'); return; } st('Enviando teste...'); manda('Venda Realizada - Parabéns!', 'Produto nº 13 — R$ 87,31 (TESTE)', 'moneybag', function (ok) { st(ok ? '✅ Teste enviado! Olha seu celular.' : '⚠️ Falha no teste — confira o canal.'); }); };
    var bb = document.getElementById('nv-botao'); if (bb) { bb.addEventListener('click', function () { window.ttlfNtfyToggle(); }); }
    var bt = document.getElementById('nv-teste'); if (bt) { bt.addEventListener('click', function () { window.ttlfNtfyTeste(); }); }
    window.nvTimer = setInterval(function () { debugScan(); varre(); envia(); }, 700);
  })();

  /* ===== CAPTURADOR INDEPENDENTE DE VENDAS E NOME DO COMPRADOR ===== */
  (function () {
    'use strict';

    if (!window.ttlfSalesCapture) {
      window.ttlfSalesCapture = {
        running: false,
        observer: null,
        scanTimer: null,
        watchdogTimer: null,
        lastScanAt: 0,
        lastMutationAt: 0,
        lastError: null,
        processed: new Map(),
        detected: [],
        lastEvent: null
      };
    }

    if (!window.ttlfSalesThanksQueue) window.ttlfSalesThanksQueue = [];
    if (!window.ttlfSalesThanksQueuedIds) window.ttlfSalesThanksQueuedIds = new Set();
    if (!window.ttlfSalesThanksSent) window.ttlfSalesThanksSent = new Map();
    if (typeof window.ttlfSalesThanksTotalSent !== 'number') window.ttlfSalesThanksTotalSent = 0;
    window.ttlfSalesThanksBusy = false;

    var SALE_RE = /(fez um pedido|realizou (um |o )?pedido|acabou de comprar|comprou|compraram|pagamento (confirmado|efetuado)|efetuou o pagamento|pedido pago|pagou o pedido|criou (um|o) pedido|placed an order)/i;
    var INTENT_RE = /(adicionou ao carrinho|colocou no carrinho|está vendo o produto|visualizou o produto|clicou no produto|demonstrou interesse|quer comprar|visitou o produto)/i;
    var INVALID_NAMES = [
      'usuario', 'usuário', 'comprador', 'compradores', 'cliente', 'clientes', 'alguem', 'alguém',
      'visitante', 'host', 'anfitrião', 'anfitriao', 'seller', 'usuario do tiktok', 'tiktok shop',
      'pedido', 'produto', 'pagamento', 'venda', 'valor', 'confirmado', 'sim', 'ok', 'cart', 'carrinho',
      'seguir', 'perfil', 'um cliente', 'uma cliente', 'cliente comprou', 'clientes compraram',
      'gerenciador de live', 'gerenciador da live', 'live manager', 'moderador', 'administrador',
      'central de live', 'gerenciador', 'loja', 'atendimento', 'sistema'
    ];

    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function norm(t) { return (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }

    window.ttlfSalesCapture.healthCheck = function () {
      var sc = window.ttlfSalesCapture;
      var running = sc.running === true;
      var scanTimerAlive = sc.scanTimer !== null;
      var observerAlive = sc.observer !== null;
      var b = document.getElementById('stc-botao');
      var buttonState = b ? (b.textContent || '').trim() : 'ausente';
      var stEl = document.getElementById('stc-status');
      var statusText = stEl ? (stEl.textContent || '').trim() : 'ausente';

      var healthy = running && scanTimerAlive;

      return {
        running: running,
        observerAlive: observerAlive,
        scanTimerAlive: scanTimerAlive,
        buttonState: buttonState,
        statusText: statusText,
        lastScanAt: sc.lastScanAt || 0,
        lastMutationAt: sc.lastMutationAt || 0,
        lastError: sc.lastError || null,
        processedCount: sc.processed ? sc.processed.size : 0,
        detectedCount: sc.detected ? sc.detected.length : 0,
        healthy: healthy
      };
    };

    window.ttlfSalesCapture.ensureRunning = function () {
      var sc = window.ttlfSalesCapture;
      if (!sc.running) return;

      var hc = sc.healthCheck();
      if (hc.healthy) return;

      ttlfLog('[SALES_CAPTURE] Monitor incompleto detectado. Executando autorrecuperação...');

      if (!sc.scanTimer) {
        sc.scanTimer = setInterval(function () {
          sc.scan();
        }, 2000);
        ttlfLog('[SALES_CAPTURE] ScanTimer recuperado com sucesso.');
      }

      if (!sc.observer && typeof MutationObserver !== 'undefined') {
        try {
          sc.observer = new MutationObserver(function () {
            sc.lastMutationAt = Date.now();
            sc.scan();
          });
          var targetNode = document.body;
          if (targetNode) {
            sc.observer.observe(targetNode, { childList: true, subtree: true });
            ttlfLog('[SALES_CAPTURE] Observer recuperado com sucesso.');
          }
        } catch (e) {
          sc.lastError = 'Erro ao criar MutationObserver: ' + e.message;
        }
      }

      var stEl = document.getElementById('stc-status');
      if (stEl && sc.running) {
        stEl.textContent = 'Monitorando eventos de venda... 👀';
      }
    };

    window.ttlfResolveBuyerUsingIntentEngine = function (eventElement) {
      if (!eventElement) return { name: null, username: null, mention: null, buyerName: null, buyerUsername: null, buyerMention: null, source: 'not_found', confidence: 'none' };
      try {
        var imgs = $s('img', eventElement.parentElement || eventElement).filter(function (im) { return vis(im); });
        var av = imgs.length ? imgs[0] : null;
        if (!av) return { name: null, username: null, mention: null, buyerName: null, buyerUsername: null, buyerMention: null, source: 'not_found', confidence: 'none' };

        var alt = av.getAttribute('alt') || av.getAttribute('title') || '';
        if (window.ttlfSalesCapture.isValidBuyerName(alt)) {
          var un = window.ttlfSalesCapture.isValidUsername(alt) ? alt.replace(/@/g, '').trim() : null;
          return {
            name: alt.trim(),
            username: un,
            mention: un ? ('@' + un) : null,
            buyerName: alt.trim(),
            buyerUsername: un,
            buyerMention: un ? ('@' + un) : null,
            source: 'intent_engine_avatar',
            confidence: 'medium'
          };
        }
      } catch (e) {
        try { ttlfLog('[SALES_CAPTURE] Adapter error: ' + e.message); } catch (_) {}
      }
      return { name: null, username: null, mention: null, buyerName: null, buyerUsername: null, buyerMention: null, source: 'not_found', confidence: 'none' };
    };

    window.ttlfSalesCapture.isValidBuyerName = function (name) {
      if (!name || typeof name !== 'string') return false;
      var clean = name.replace(/@/g, '').trim();
      if (!clean || clean.length < 2 || clean.length > 50) return false;
      var nLower = norm(clean);
      if (INVALID_NAMES.indexOf(nLower) > -1) return false;
      if (/gerenciador.*live/i.test(clean) || /live.*manager/i.test(clean) || /tiktok.*shop/i.test(clean) || /administrador/i.test(clean) || /moderador/i.test(clean)) return false;
      if (/^\d+\s+clientes?$/i.test(clean) || /^\d+\s+compradores?$/i.test(clean)) return false;
      if (/^[\d\s\W]+$/.test(clean)) return false;
      if (/R\$\s?\d/i.test(clean)) return false;
      return true;
    };

    window.ttlfSalesCapture.isValidUsername = function (username) {
      if (!username || typeof username !== 'string') return false;
      var clean = username.replace(/@/g, '').trim();
      if (!clean || clean.length < 2 || clean.length > 40) return false;
      if (/\s/.test(clean)) return false;
      if (httpUrl(clean)) return false;
      var nLower = norm(clean);
      if (INVALID_NAMES.indexOf(nLower) > -1) return false;
      if (/gerenciador.*live/i.test(clean) || /live.*manager/i.test(clean) || /tiktok.*shop/i.test(clean)) return false;
      return /^[A-Za-z0-9_.]+$/.test(clean);
    };

    function httpUrl(t) { return /https?:\/\//i.test(t); }

    window.ttlfSalesCapture.extractNameFromText = function (rawText) {
      if (!rawText) return null;
      var text = rawText.replace(/\s+/g, ' ').trim();
      if (!text) return null;

      var cleanText = text.replace(/^\d+\s+clientes?\s+/i, '').replace(/^um[a]?\s+cliente\s+/i, '');
      if (cleanText !== text && !SALE_RE.test(cleanText)) {
        return null;
      }

      var matchPrefix = text.match(/^@?([A-Za-z0-9_.\s\u00C0-\u024F]{2,40})\s+(acabou de comprar|fez um pedido|realizou|efetuou|comprou|criou)/i);
      if (matchPrefix && matchPrefix[1]) {
        var cand = matchPrefix[1].trim();
        if (window.ttlfSalesCapture.isValidBuyerName(cand)) {
          return cand;
        }
      }

      var matchAt = text.match(/@([A-Za-z0-9_.]+)/);
      if (matchAt && matchAt[1]) {
        var candAt = matchAt[1].trim();
        if (window.ttlfSalesCapture.isValidBuyerName(candAt)) {
          return candAt;
        }
      }

      return null;
    };

    window.ttlfSalesCapture.findBuyerAvatar = function (eventElement) {
      if (!eventElement) return null;
      var imgs = $s('img', eventElement).filter(function (im) { return vis(im); });
      if (imgs.length) return imgs[0];
      var p = eventElement.parentElement;
      for (var k = 0; k < 2 && p; k++) {
        var pImgs = $s('img', p).filter(function (im) { return vis(im); });
        if (pImgs.length) return pImgs[0];
        p = p.parentElement;
      }
      return null;
    };

    window.ttlfSalesCapture.extractBuyerFromAvatar = function (eventElement) {
      var av = window.ttlfSalesCapture.findBuyerAvatar(eventElement);
      if (!av) return { name: null, username: null, source: 'not_found', confidence: 'none' };

      var alt = av.getAttribute('alt') || av.getAttribute('title') || '';
      if (window.ttlfSalesCapture.isValidBuyerName(alt)) {
        var un = window.ttlfSalesCapture.isValidUsername(alt) ? alt.replace(/@/g, '').trim() : null;
        return { name: alt.trim(), username: un, source: 'avatar_alt', confidence: 'medium' };
      }

      return { name: null, username: null, source: 'not_found', confidence: 'none' };
    };

    window.ttlfSalesCapture.extractBuyerFromPopover = function (eventElement) {
      var av = window.ttlfSalesCapture.findBuyerAvatar(eventElement);
      var avRect = av ? av.getBoundingClientRect() : (eventElement ? eventElement.getBoundingClientRect() : null);

      var popovers = $s('div,span').filter(function (el) {
        if (!vis(el) || !fora(el)) return false;
        var r = el.getBoundingClientRect();
        if (r.width < 120 || r.height < 60 || el.id === 'ra-painel') return false;
        if (avRect) {
          var dist = Math.abs(r.top - avRect.top) + Math.abs(r.left - avRect.left);
          if (dist > 500) return false;
        }
        return true;
      });

      for (var i = 0; i < popovers.length; i++) {
        var pop = popovers[i];
        var txts = $s('div,span,p,h1,h2,h3,b,strong', pop).map(function (x) { return (x.textContent || '').trim(); }).filter(function (t) { return t.length > 0 && t.length < 50; });
        var foundName = null, foundUser = null;
        txts.forEach(function (t) {
          if (!foundUser && t.indexOf('@') === 0) {
            var candU = t.replace(/@/g, '').trim();
            if (window.ttlfSalesCapture.isValidUsername(candU)) foundUser = candU;
          } else if (!foundName && window.ttlfSalesCapture.isValidBuyerName(t)) {
            foundName = t;
          }
        });
        if (foundName || foundUser) {
          return { name: foundName || foundUser, username: foundUser, source: 'hover_popover', confidence: 'high' };
        }
      }
      return { name: null, username: null, source: 'not_found', confidence: 'none' };
    };

    window.ttlfSalesCapture.extractBuyerName = function (eventElement) {
      if (!eventElement) return { name: null, username: null, mention: null, source: 'not_found', confidence: 'none' };
      var raw = (eventElement.textContent || '').trim();

      // 1. Adaptador de Leitura Seguro da Intenção de Compra
      var intentRes = window.ttlfResolveBuyerUsingIntentEngine(eventElement);
      if (intentRes && intentRes.buyerName) {
        return intentRes;
      }

      // 2. Prefixo de Texto Explícito
      var nameFromText = window.ttlfSalesCapture.extractNameFromText(raw);
      if (nameFromText) {
        var unFromText = window.ttlfSalesCapture.isValidUsername(nameFromText) ? nameFromText.replace(/@/g, '').trim() : null;
        return {
          name: nameFromText,
          username: unFromText,
          mention: unFromText ? ('@' + unFromText) : null,
          source: 'text_prefix',
          confidence: 'high'
        };
      }

      // 3. Elemento Irmão ou Ancestral Próximo
      var p = eventElement.parentElement;
      for (var k = 0; k < 3 && p; k++) {
        var siblings = $s('span,div,strong,b', p).filter(function (el) { return vis(el) && el !== eventElement; });
        for (var i = 0; i < siblings.length; i++) {
          var t = (siblings[i].textContent || '').trim();
          if (window.ttlfSalesCapture.isValidBuyerName(t)) {
            var unSib = window.ttlfSalesCapture.isValidUsername(t) ? t.replace(/@/g, '').trim() : null;
            return {
              name: t,
              username: unSib,
              mention: unSib ? ('@' + unSib) : null,
              source: 'nearby_element',
              confidence: 'medium'
            };
          }
        }
        p = p.parentElement;
      }

      // 4. Aria-Label
      var aria = eventElement.getAttribute('aria-label') || '';
      if (aria) {
        var nameAria = window.ttlfSalesCapture.extractNameFromText(aria);
        if (nameAria) {
          var unAria = window.ttlfSalesCapture.isValidUsername(nameAria) ? nameAria.replace(/@/g, '').trim() : null;
          return {
            name: nameAria,
            username: unAria,
            mention: unAria ? ('@' + unAria) : null,
            source: 'aria_label',
            confidence: 'medium'
          };
        }
      }

      // 5. Alt do Avatar
      var avRes = window.ttlfSalesCapture.extractBuyerFromAvatar(eventElement);
      if (avRes.name) {
        return {
          name: avRes.name,
          username: avRes.username,
          mention: avRes.username ? ('@' + avRes.username) : null,
          source: avRes.source,
          confidence: avRes.confidence
        };
      }

      // 6. Popover Visível
      var popRes = window.ttlfSalesCapture.extractBuyerFromPopover(eventElement);
      if (popRes.name) {
        return {
          name: popRes.name,
          username: popRes.username,
          mention: popRes.username ? ('@' + popRes.username) : null,
          source: popRes.source,
          confidence: popRes.confidence
        };
      }

      return { name: null, username: null, mention: null, source: 'not_found', confidence: 'none' };
    };

    window.ttlfSalesCapture.extractProduct = function (rawText, eventElement) {
      if (!rawText) return null;
      var m = rawText.match(/n[ºo°.]?\s?(\d+)/i) || rawText.match(/produto\s+(\d+)/i);
      if (m) return 'Produto nº ' + m[1];
      var mProd = rawText.match(/comprou\s+(?:o\s+)?(.{2,40}?)(?:\s+por|\s+em|\s+R\$|$)/i);
      if (mProd && mProd[1] && !/carrinho/i.test(mProd[1])) return mProd[1].trim();
      return null;
    };

    window.ttlfSalesCapture.extractPrice = function (rawText) {
      if (!rawText) return null;
      var mp = rawText.match(/R\$\s?([\d.]+,\d{2}|[\d.,]+)/i);
      return mp ? ('R$ ' + mp[1]) : null;
    };

    window.ttlfSalesCapture.extractQuantity = function (rawText) {
      if (!rawText) return 1;
      var mq = rawText.match(/(\d+)\s*(?:itens|unidades|x|un)/i) || rawText.match(/x\s*(\d+)/i);
      return mq ? parseInt(mq[1], 10) : 1;
    };

    window.ttlfSalesCapture.buildEventId = function (data) {
      if (data.sourceElement && data.sourceElement.dataset && data.sourceElement.dataset.orderId) {
        return 'evt_ord_' + data.sourceElement.dataset.orderId;
      }
      var str = (data.buyerName || 'nobuyer') + '|' + (data.product || 'noprod') + '|' + (data.price || 'noprice') + '|' + norm(data.rawText);
      var hash = 0;
      for (var i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash |= 0;
      }
      return 'evt_' + Math.abs(hash);
    };

    window.ttlfSalesCapture.buildThankYouMessage = function (eventData, template) {
      var tpl = template || 'Parabéns pela compra, {mention}! 🎉 Obrigado pela confiança!';
      var mentionText = eventData.buyerMention || eventData.buyerName || '';
      var nameText = eventData.buyerName || '';
      var userText = eventData.buyerUsername || '';
      var prodText = eventData.product || 'produto';
      var valText = eventData.price || '';
      var qtyText = eventData.quantity || 1;

      var res = tpl
        .replace(/\{mention\}/g, mentionText)
        .replace(/\{nome\}/g, nameText)
        .replace(/\{usuario\}/g, userText)
        .replace(/\{produto\}/g, prodText)
        .replace(/\{valor\}/g, valText)
        .replace(/\{quantidade\}/g, qtyText);

      res = res.replace(/\s+/g, ' ').replace(/,\s*!/g, '!').replace(/\s+!/g, '!').trim();
      if (res.length > 100) {
        res = res.slice(0, 97) + '...';
      }
      return res;
    };

    window.ttlfSalesCapture.detectSaleEvent = function (element) {
      if (!element || !vis(element) || !fora(element)) return null;
      try {
        var rawText = (element.textContent || '').replace(/\s+/g, ' ').trim();
        if (!rawText || rawText.length > 200) return null;

        if (INTENT_RE.test(rawText)) return null;
        if (!SALE_RE.test(rawText)) return null;

        var buyerRes = window.ttlfSalesCapture.extractBuyerName(element);
        var product = window.ttlfSalesCapture.extractProduct(rawText, element);
        var price = window.ttlfSalesCapture.extractPrice(rawText);
        var quantity = window.ttlfSalesCapture.extractQuantity(rawText);

        var eventData = {
          eventId: '',
          buyerName: buyerRes.name,
          buyerUsername: buyerRes.username,
          buyerMention: buyerRes.mention,
          buyerNameSource: buyerRes.source,
          rawText: rawText,
          product: product,
          quantity: quantity,
          price: price,
          timestamp: Date.now(),
          confidence: buyerRes.confidence,
          thankYouPreview: '',
          sourceElement: element
        };

        eventData.eventId = window.ttlfSalesCapture.buildEventId(eventData);
        eventData.thankYouPreview = window.ttlfSalesCapture.buildThankYouMessage(eventData);
        return eventData;
      } catch (err) {
        window.ttlfSalesCapture.lastError = 'detectSaleEvent: ' + err.message;
        return null;
      }
    };

    window.ttlfSalesCapture.onSaleDetected = function (eventData) {
      try {
        window.ttlfSalesCapture.lastEvent = eventData;

        if (!Array.isArray(window.ttlfSalesCapture.detected)) window.ttlfSalesCapture.detected = [];
        window.ttlfSalesCapture.detected.push(eventData);
        if (window.ttlfSalesCapture.detected.length > 50) {
          window.ttlfSalesCapture.detected.shift();
        }

        ttlfLog('[SALES_CAPTURE] Venda confirmada! ID: ' + eventData.eventId + ' | Comprador: ' + (eventData.buyerMention || eventData.buyerName || 'NÃO LOCALIZADO') + ' | Fonte: ' + eventData.buyerNameSource + ' | Confiança: ' + eventData.confidence);

        // CONTABILIZAÇÃO AUTOMÁTICA NA SESSÃO DE LIVE ATUAL
        if (typeof window.ttlfAddSaleToCurrentSession === 'function') {
          window.ttlfAddSaleToCurrentSession(eventData.price, eventData.quantity, eventData.eventId);
        }
      } catch (err) {
        window.ttlfSalesCapture.lastError = 'onSaleDetected: ' + err.message;
      }
    };
  })();

    /* ===== MÓDULO PARABÉNS PELA COMPRA (PIPELINE LITERAL HOVER + CLIQUE DO LIVEGOPRO v11.6.2) ===== */
  (function () {
    'use strict';

    var rodando = false;
    var fila = [];
    var pendentes = [];
    var ocupado = false;
    var ultimoEnvio = 0;
    var feitos = {};

    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha' || q.id === 'ttlf-gate') { return false; } q = q.parentElement; } return true; }
    function st(msg) {
      var el = document.getElementById('vc-status');
      if (el) el.textContent = msg;
    }

    function disparar(el, tipos) {
      tipos.forEach(function (tp) {
        try {
          el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window }));
        } catch (e) {}
      });
    }

    function hover(el) {
      try {
        var r = el.getBoundingClientRect();
        var cx = Math.round(r.left + r.width / 2);
        var cy = Math.round(r.top + r.height / 2);
        ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove'].forEach(function (tp) {
          try {
            el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
          } catch (e) {}
        });
      } catch (e) {
        disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']);
      }
    }

    function unhover(el) {
      disparar(el, ['mouseout', 'mouseleave', 'pointerout', 'pointerleave']);
    }

    var _clicarBusy = false;
    function clicar(el) {
      if (!el || _clicarBusy) { return; }
      _clicarBusy = true;
      try {
        var alvo = (el.closest && el.closest('button,[role="button"]')) || el;
        function fire(tp) {
          try {
            var r = alvo.getBoundingClientRect();
            var cx = Math.round(r.left + r.width / 2);
            var cy = Math.round(r.top + r.height / 2);
            var E;
            if (tp.indexOf('pointer') === 0 && window.PointerEvent) {
              E = new PointerEvent(tp, { bubbles: true, cancelable: true, view: window, pointerId: 1, pointerType: 'mouse', isPrimary: true, button: 0, buttons: tp.indexOf('down') > -1 ? 1 : 0, clientX: cx, clientY: cy });
            } else {
              E = new MouseEvent(tp, { bubbles: true, cancelable: true, view: window, button: 0, buttons: tp.indexOf('down') > -1 ? 1 : 0, clientX: cx, clientY: cy });
            }
            alvo.dispatchEvent(E);
          } catch (e) {}
        }
        ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(fire);
        try {
          if (typeof alvo.click === 'function') {
            alvo.click();
          } else {
            fire('click');
          }
        } catch (e) {}
      } finally {
        _clicarBusy = false;
      }
    }

    function achaAvatar(row) {
      var im = $s('img', row).filter(function (x) { return vis(x); });
      var rect = im.length ? im[0].getBoundingClientRect() : null;
      if (im.length) {
        return { avatarElement: im[0], rowElement: row, rect: rect, source: 'img' };
      }
      var sv = $s('svg', row).filter(function (x) {
        var r = x.getBoundingClientRect();
        return vis(x) && r.width >= 12 && r.width <= 60 && r.height >= 12 && r.height <= 60;
      });
      if (sv.length) {
        return { avatarElement: sv[0], rowElement: row, rect: sv[0].getBoundingClientRect(), source: 'svg' };
      }
      var cs = $s('div,span', row).filter(function (x) {
        if (!vis(x)) { return false; }
        var r = x.getBoundingClientRect();
        if (r.width < 14 || r.width > 60 || r.height < 14 || r.height > 60) { return false; }
        var stl = getComputedStyle(x);
        return parseFloat(stl.borderRadius) >= 8 || (stl.backgroundImage && stl.backgroundImage !== 'none');
      });
      cs.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
      if (cs.length) {
        return { avatarElement: cs[0], rowElement: row, rect: cs[0].getBoundingClientRect(), source: 'styled_div' };
      }
      var cs2 = $s('div,span', row).filter(function (x) {
        if (!vis(x)) { return false; }
        var r = x.getBoundingClientRect();
        return r.width >= 14 && r.width <= 60 && r.height >= 14 && r.height <= 60;
      });
      cs2.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
      if (cs2.length) {
        return { avatarElement: cs2[0], rowElement: row, rect: cs2[0].getBoundingClientRect(), source: 'generic_div' };
      }
      return null;
    }

    function realVis(e) {
      try {
        var cs = getComputedStyle(e);
        if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.3) { return false; }
        var an = e.parentElement, k = 0;
        while (an && k < 8) {
          var c2 = getComputedStyle(an);
          if (c2.visibility === 'hidden' || c2.display === 'none' || parseFloat(c2.opacity) < 0.3) { return false; }
          an = an.parentElement;
          k++;
        }
        return true;
      } catch (_) { return false; }
    }

    function ttlfIsValidBuyerName(name) {
      if (!name || typeof name !== 'string') return false;
      var clean = name.trim();
      if (!clean || clean.length < 2 || clean.length > 50) return false;
      if (/^(1\s+cliente|cliente|usu[aá]rio|comprador|undefined|null|\{mention\}|\{nome\}|an[oô]nimo|tiktok)$/i.test(clean)) return false;
      if (/^R\$\s?\d/i.test(clean) || /^\d+$/i.test(clean)) return false;
      return true;
    }

    function sobresReais() {
      var a = [];
      $s('div,span,p,h1,h2,h3,b,strong').forEach(function (e) {
        if (e.children.length > 3) { return; }
        var t = (e.textContent || '').trim();
        var m = t.match(/^Sobre\s+(.{2,40})$/i);
        if (!m) { return; }
        if (!realVis(e)) { return; }
        var n = m[1].replace(/\s*[ⓘℹ️①(].*$/, '').trim();
        if (n && ttlfIsValidBuyerName(n)) { a.push(n); }
      });
      return a;
    }

    function nomePopover(antes) {
      var depois = sobresReais();
      var novos = depois.filter(function (n) { return antes.indexOf(n) < 0; });
      if (novos.length) { return novos[0]; }
      return depois.length ? depois[0] : null;
    }

    function getPurchaseEventSignature(row, txt) {
      var rowText = (txt || (row && row.textContent) || '').replace(/\s+/g, ' ').trim();
      var mp = rowText.match(/R\$\s?([\d.]+,\d{2}|[\d.,]+)/);
      var price = mp ? mp[1] : '';
      var mn = rowText.match(/n[ºo°.]?\s?(\d+)/i);
      var prod = mn ? mn[1] : '';
      var sessId = (window.ttlfLiveSession && window.ttlfLiveSession.id) ? window.ttlfLiveSession.id : 'no_session';
      return sessId + '|purchase|' + rowText.slice(0, 40) + '|' + price + '|' + prod;
    }

    function buildPurchaseThanksMessage(template, buyerName) {
      var tpl = (template || '').trim();
      if (!tpl) tpl = 'Parabéns pela sua compra! 🎉 Obrigado, volte sempre!';

      var msg = tpl;
      if (msg.indexOf('{mention}') >= 0) {
        msg = msg.replace(/\{mention\}/g, '@' + buyerName);
      } else if (msg.indexOf('{nome}') >= 0) {
        msg = msg.replace(/\{nome\}/g, buyerName);
      } else {
        msg = '@' + buyerName + ' ' + msg;
      }
      if (msg.length > 100) {
        msg = msg.slice(0, 100);
      }
      return msg;
    }

    function eventos() {
      var res = []; var vistos = [];
      (function () {
        var hits = $s('div,span,p').filter(function (x) {
          if (!vis(x) || !fora(x)) { return false; }
          var t = (x.textContent || '').trim();
          if (!t || t.length > 90) { return false; }
          return /(fez um pedido|realizou (um |o )?pedido|acabou de comprar|comprou o produto|compraram o produto|efetuou o pagamento|pagou o pedido)/i.test(t);
        });
        return hits.filter(function (x) {
          return !hits.some(function (y) { return y !== x && x.contains(y); });
        });
      })().forEach(function (mk) {
        var row = mk;
        for (var i = 0; i < 7 && row.parentElement; i++) {
          row = row.parentElement;
          if (achaAvatar(row)) { break; }
        }
        if (vistos.indexOf(row) > -1) { return; }
        vistos.push(row);
        res.push({ row: row, txt: (mk.textContent || '').trim() });
      });
      return res;
    }

    function processa() {
      if (ocupado || !rodando || !fila.length) { return; }
      ocupado = true;
      var it = fila.shift();
      var sig = getPurchaseEventSignature(it.row, it.txt);
      var sessId = (window.ttlfLiveSession && window.ttlfLiveSession.id) ? window.ttlfLiveSession.id : 'no_session';
      var eventId = 'evt_' + Math.abs(hashString(sig));

      function hashString(str) {
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
          hash = ((hash << 5) - hash) + str.charCodeAt(i);
          hash |= 0;
        }
        return hash;
      }

      if (feitos[sig]) {
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] event-detected (duplicado ignorado): ' + sig + ' | session: ' + sessId);
        }
        ocupado = false;
        return;
      }

      st('Compra detectada.');
      if (typeof ttlfLog === 'function') {
        ttlfLog('[PURCHASE_THANKS] event-detected: ' + (it.txt || '').slice(0, 60) + ' | eventId: ' + eventId + ' | session: ' + sessId);
      }

      var avRes = achaAvatar(it.row);
      if (!avRes || !avRes.avatarElement) {
        st('Não foi possível identificar o comprador.');
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] buyer-not-found (sem avatar) | eventId: ' + eventId);
        }
        setTimeout(function () { ocupado = false; }, 300);
        return;
      }

      var av = avRes.avatarElement;
      if (typeof ttlfLog === 'function') {
        ttlfLog('[PURCHASE_THANKS] avatar-found | type: ' + avRes.source + ' | rect: ' + JSON.stringify(avRes.rect) + ' | eventId: ' + eventId);
      }

      var antes = sobresReais();

      function limpaHover() {
        unhover(av);
        var _pp = av;
        for (var _i = 0; _i < 4 && _pp; _i++) { unhover(_pp); _pp = _pp.parentElement; }
        try {
          document.body.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: 4, clientY: 4, view: window }));
          document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, which: 27, bubbles: true }));
        } catch (e) {}
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] popover-cleanup | eventId: ' + eventId);
        }
      }

      function finaliza(nome) {
        limpaHover();
        if (!nome) {
          var _t = (parseInt((it.row.dataset && it.row.dataset.vcTry) || '0', 10) || 0) + 1;
          try { it.row.dataset.vcTry = _t; delete it.row.dataset.vcQueued; } catch (e) {}
          if (_t >= 6) {
            try { it.row.dataset.vcDone = '1'; } catch (e) {}
            st('Não foi possível identificar o comprador.');
            if (typeof ttlfLog === 'function') {
              ttlfLog('[PURCHASE_THANKS] buyer-not-found | tentativas esgotadas | eventId: ' + eventId);
            }
          } else {
            st('Identificando comprador... (' + _t + '/6)');
          }
          setTimeout(function () { ocupado = false; }, 300);
          return;
        }
        try { it.row.dataset.vcDone = '1'; } catch (e) {}
        feitos[sig] = 1;

        st('Comprador identificado: @' + nome);
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] buyer-found: @' + nome + ' | eventId: ' + eventId + ' | session: ' + sessId);
        }

        var tpl = (document.getElementById('vc-msg') || { value: '' }).value || '';
        var msg = buildPurchaseThanksMessage(tpl, nome);

        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] message-built: ' + msg + ' | eventId: ' + eventId);
        }

        pendentes.push({ texto: msg, label: 'Compra: @' + nome, buyer: nome });
        setTimeout(function () { ocupado = false; }, 400);
      }

      var tent = 0;
      function tenta() {
        tent++;
        var isClicked = tent >= 3;
        st(isClicked ? 'Abrindo perfil do comprador...' : 'Identificando comprador...');

        hover(av);
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] hover-attempt #' + tent + ' | eventId: ' + eventId);
        }

        if (isClicked) {
          try {
            clicar(av);
            if (typeof ttlfLog === 'function') {
              ttlfLog('[PURCHASE_THANKS] click-fallback #' + tent + ' | eventId: ' + eventId);
            }
          } catch (e) {}
        }

        setTimeout(function () {
          var popoversAtual = sobresReais();
          if (typeof ttlfLog === 'function') {
            ttlfLog('[PURCHASE_THANKS] popover-scan #' + tent + ' | popoversBefore: ' + JSON.stringify(antes) + ' | popoversAfter: ' + JSON.stringify(popoversAtual) + ' | eventId: ' + eventId);
          }

          var nome = nomePopover(antes);
          if (nome) {
            finaliza(nome);
            return;
          }
          if (tent >= 10) {
            finaliza(null);
            return;
          }
          tenta();
        }, 280);
      }

      tenta();
    }

    function varre() {
      if (!rodando) { return; }
      try {
        var evs = eventos();
        evs.forEach(function (ev) {
          var d = ev.row.dataset || {};
          if (d.vcDone || d.vcQueued) { return; }
          try { ev.row.dataset.vcQueued = '1'; } catch (e) {}
          fila.push(ev);
        });
        if (!ocupado && !fila.length && !pendentes.length) {
          st('Monitorando compras concluídas... 👀');
        }
      } catch (err) { st('erro varre: ' + ((err && err.message) || err)); }
    }

    function enviaPendentes() {
      if (!rodando || !pendentes.length) { return; }
      var agora = Date.now();
      if (agora - ultimoEnvio < 4000) { return; }
      ultimoEnvio = agora;
      var item = pendentes.shift();
      var sessId = (window.ttlfLiveSession && window.ttlfLiveSession.id) ? window.ttlfLiveSession.id : 'no_session';

      if (typeof ttlfLog === 'function') {
        ttlfLog('[PURCHASE_THANKS] send-start: ' + item.texto + ' | session: ' + sessId);
      }

      var ok = typeof enviar === 'function' ? enviar(item.texto) : false;
      if (ok) {
        st('Agradecimento enviado para @' + item.buyer + '.');
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] send-success: ' + item.texto + ' | session: ' + sessId);
        }
      } else {
        st('Falha ao enviar agradecimento.');
        if (typeof ttlfLog === 'function') {
          ttlfLog('[PURCHASE_THANKS] send-failed: ' + item.texto + ' | session: ' + sessId);
        }
      }
    }

    function liga() {
      rodando = true;
      var b = document.getElementById('vc-botao');
      if (b) {
        b.textContent = '⏸ Parar';
        b.style.background = 'linear-gradient(135deg,#ff1717 0%,#d90000 100%)';
        b.style.color = '#ffffff';
      }
      st('Monitorando compras concluídas... 👀');
      ttlfStGet(function (lic) {
        lic = lic || {};
        lic.ttlf_vc_enabled = true;
        ttlfStSet(lic);
      });
    }

    function desliga() {
      rodando = false;
      fila = [];
      pendentes = [];
      ocupado = false;
      var b = document.getElementById('vc-botao');
      if (b) {
        b.textContent = '▶ Iniciar';
        b.style.background = 'linear-gradient(135deg,#ffd000 0%,#ff9900 100%)';
        b.style.color = '#000000';
      }
      st('Desligado.');
      ttlfStGet(function (lic) {
        lic = lic || {};
        lic.ttlf_vc_enabled = false;
        ttlfStSet(lic);
      });
    }

    window.ttlfVcTimer = setInterval(function () { varre(); processa(); enviaPendentes(); }, 1200);

    window.ttlfVcLiga = liga;
    window.ttlfVcDesliga = desliga;
    window.ttlfVcToggle = function () { rodando ? desliga() : liga(); };

    window.ttlfBindVcModule = function () {
      var bb = document.getElementById('vc-botao');
      if (bb) {
        bb.onclick = function (ev) {
          if (ev) { ev.preventDefault(); ev.stopPropagation(); }
          window.ttlfVcToggle();
        };
      }
      var msgEl = document.getElementById('vc-msg');
      if (msgEl) {
        msgEl.oninput = function () {
          ttlfStGet(function (lic) {
            lic = lic || {};
            lic.ttlf_vc_msg = msgEl.value;
            ttlfStSet(lic);
          });
        };
      }
      ttlfStGet(function (lic) {
        lic = lic || {};
        if (msgEl && lic.ttlf_vc_msg) {
          msgEl.value = lic.ttlf_vc_msg;
        }
        if (lic.ttlf_vc_enabled) {
          liga();
        } else {
          desliga();
        }
      });
    };

    setTimeout(function () {
      if (typeof window.ttlfBindVcModule === 'function') {
        window.ttlfBindVcModule();
      }
    }, 500);
  })();

  /* ===== NOVO MÓDULO ADITIVO: REFIXAÇÃO ESTENDIDA TIKTOK (+60s / +30s) ===== */
  const TTLF_EXTENDED_PIN_MIN_CLICK_GAP_MS = 8000;

  window.ttlfIsInsideExtensionHud = function (element) {
    try {
      if (!element || typeof element.closest !== 'function') {
        return false;
      }
      return !!element.closest('#ttlf-hub, #ttlf-bolha, #ttlf-gate, #ra-painel');
    } catch (e) {
      return false;
    }
  };

  function ttlfIsInsideExtensionHud(element) {
    return window.ttlfIsInsideExtensionHud(element);
  }

  window.ttlfPinExtensionMode = {
    enabled: false,
    detected: false,
    activeButton: null,
    mode: "unknown",
    timer: null,
    busy: false,
    lastClickAt: 0,
    lastDetectedAt: 0,
    lastStatus: "",
    failures: 0,
    lastRenewalAt: 0,
    lastRenewalType: "",
    lastConfirmed: false,
    lastButtonSignature: "",
    lastConfirmedSignature: "",
    waitingForButtonReset: false,
    lastButtonSeen: false,
    buttonAbsentSince: 0,
    absentCycles: 0,
    modeTransitionTimestamp: 0
  };

  function ttlfIsVisibleElement(el) {
    if (!el || !el.isConnected) return false;
    try {
      var cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) <= 0) return false;
      var r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    } catch (e) {
      return false;
    }
  }

  window.ttlfBuildExtendedPinSignature = function (btnObj) {
    if (!btnObj || !btnObj.element) return '';
    var el = btnObj.element;
    var label = (btnObj.label || '').trim().toLowerCase();
    var seconds = btnObj.seconds || 60;
    var aria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
    var parentTxt = '';
    if (el.parentElement) {
      parentTxt = (el.parentElement.textContent || '').trim().slice(0, 100).toLowerCase().replace(/\s+/g, ' ');
    }
    return label + '|' + seconds + '|' + aria + '|' + parentTxt;
  };

  window.ttlfDetectExtendedPinReset = function (btnObj, remainSec) {
    var state = window.ttlfPinExtensionMode;

    if (state.absentCycles >= 2) {
      ttlfLog('[PIN_EXTENDED] button-reset-detected: botão ausente por ' + state.absentCycles + ' ciclos');
      return { reset: true, reason: 'absent_cycles_reset' };
    }

    var currentSig = window.ttlfBuildExtendedPinSignature(btnObj);
    if (state.lastConfirmedSignature && currentSig !== state.lastConfirmedSignature) {
      ttlfLog('[PIN_EXTENDED] button-reset-detected: nova assinatura do botão (' + currentSig + ')');
      return { reset: true, reason: 'signature_changed' };
    }

    if (remainSec !== null && remainSec > 20) {
      ttlfLog('[PIN_EXTENDED] button-reset-detected: tempo aumentou para ' + remainSec + 's');
      return { reset: true, reason: 'time_increased' };
    }

    if (!state.waitingForButtonReset) {
      return { reset: true, reason: 'not_waiting_reset' };
    }

    return { reset: false, reason: 'waiting_for_reset' };
  };

  window.ttlfIsLiveEnvironmentReady = function () {
    return window.ttlfLiveNoAr();
  };

  window.ttlfDetectExtendedPinMode = function () {
    if (!window.ttlfIsLiveEnvironmentReady()) {
      window.ttlfPinExtensionMode.detected = false;
      window.ttlfPinExtensionMode.mode = "unknown";
      return false;
    }

    var btn = window.ttlfFindExtendPinButton();
    if (btn && btn.element) {
      if (window.ttlfPinExtensionMode.mode !== "extended") {
        window.ttlfPinExtensionMode.modeTransitionTimestamp = Date.now();
        ttlfLog('[PIN_EXTENDED] Transição de modo detectada: -> extended');
      }
      window.ttlfPinExtensionMode.detected = true;
      window.ttlfPinExtensionMode.activeButton = btn.element;
      window.ttlfPinExtensionMode.mode = "extended";
      window.ttlfPinExtensionMode.lastDetectedAt = Date.now();
      return true;
    }

    window.ttlfPinExtensionMode.detected = false;
    window.ttlfPinExtensionMode.activeButton = null;

    var classicBtns = Array.prototype.slice.call(document.querySelectorAll('button, [role="button"], div, span')).filter(function (el) {
      if (ttlfIsInsideExtensionHud(el) || !ttlfIsVisibleElement(el)) return false;
      var t = (el.textContent || '').trim().toLowerCase();
      return t === 'fixar' || t === 'desafixar' || t === 'unpin';
    });

    var newMode = classicBtns.length > 0 ? "classic" : "unknown";
    if (window.ttlfPinExtensionMode.mode === "extended" && newMode === "classic") {
      window.ttlfPinExtensionMode.waitingForButtonReset = false;
      window.ttlfPinExtensionMode.lastButtonSeen = false;
      window.ttlfPinExtensionMode.buttonAbsentSince = 0;
      window.ttlfPinExtensionMode.absentCycles = 0;
      ttlfLog('[PIN_EXTENDED] classic-resumed: modo transicionou de extended para classic');
    }
    window.ttlfPinExtensionMode.mode = newMode;
    return false;
  };

  window.ttlfFindExtendPinButton = function () {
    var candidates = Array.prototype.slice.call(document.querySelectorAll('button, [role="button"], div, span, a')).filter(function (el) {
      if (ttlfIsInsideExtensionHud(el) || !ttlfIsVisibleElement(el)) return false;
      if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;

      var t = (el.textContent || '').trim().toLowerCase();
      var aria = (el.getAttribute('aria-label') || '').toLowerCase();

      var is60 = t === '+60s' || t === '60s' || aria.indexOf('60s') >= 0 || aria.indexOf('+60') >= 0;
      var is30 = t === '+30s' || t === '30s' || aria.indexOf('30s') >= 0 || aria.indexOf('+30') >= 0;
      var isText = /esta fixação termina|fixe por mais|fixar por mais|estender fixação/i.test(t);

      return is60 || is30 || isText;
    });

    if (!candidates.length) return null;

    var validBtns = candidates.filter(function (el) {
      var cur = el;
      for (var k = 0; k < 6 && cur; k++) {
        if (ttlfIsInsideExtensionHud(cur)) return false;
        var txt = (cur.textContent || '').trim();
        if (/esta fixação termina|fixe por mais|fixar por mais|produto|preço|R\$|desafixar|fixado/i.test(txt)) {
          return true;
        }
        cur = cur.parentElement;
      }
      return false;
    });

    var targetEl = validBtns.length ? validBtns[0] : candidates[0];

    var clickable = targetEl;
    while (clickable.parentElement && clickable.tagName !== 'BUTTON' && clickable.getAttribute('role') !== 'button' && getComputedStyle(clickable).cursor !== 'pointer') {
      if (ttlfIsInsideExtensionHud(clickable.parentElement)) break;
      clickable = clickable.parentElement;
    }

    var labelText = (targetEl.textContent || targetEl.getAttribute('aria-label') || '').trim();
    var seconds = labelText.indexOf('30') >= 0 ? 30 : 60;

    return {
      element: clickable,
      label: labelText,
      seconds: seconds,
      source: 'native_dom',
      rect: clickable.getBoundingClientRect(),
      disabled: clickable.disabled || clickable.getAttribute('aria-disabled') === 'true'
    };
  };

  window.ttlfExtractPinRemainingSeconds = function () {
    var elements = Array.prototype.slice.call(document.querySelectorAll('div, span, p')).filter(function (el) {
      if (ttlfIsInsideExtensionHud(el) || !ttlfIsVisibleElement(el)) return false;
      if (el.children && el.children.length > 2) return false;
      var t = (el.textContent || '').trim();
      return /esta fixação termina|termina em|fixação|restan/i.test(t) || /^\d{1,2}:\d{2}$/.test(t) || /^\d{1,2}s$/i.test(t);
    });

    for (var i = 0; i < elements.length; i++) {
      var txt = (elements[i].textContent || '').trim();

      var mTimer = txt.match(/(\d{1,2}):(\d{2})/);
      if (mTimer) {
        return parseInt(mTimer[1], 10) * 60 + parseInt(mTimer[2], 10);
      }

      var mSec = txt.match(/(\d{1,2})\s?s(?:egundos)?/i);
      if (mSec) {
        return parseInt(mSec[1], 10);
      }
    }

    return null;
  };

  window.ttlfExtendedPinClick = function (element) {
    if (!element || ttlfIsInsideExtensionHud(element)) return false;

    try {
      element.scrollIntoView({ block: 'center', inline: 'center' });
    } catch (e) {}

    var r = element.getBoundingClientRect();
    var cx = r.left + r.width / 2;
    var cy = r.top + r.height / 2;

    var events = ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'];
    events.forEach(function (tp) {
      try {
        element.dispatchEvent(new MouseEvent(tp, {
          bubbles: true,
          cancelable: true,
          view: window,
          clientX: cx,
          clientY: cy
        }));
      } catch (_) {}
    });

    if (typeof element.click === 'function') {
      try { element.click(); } catch (_) {}
    }

    return true;
  };

  window.ttlfConfirmExtendedPinRenewal = function (beforeState, callback) {
    var startAt = Date.now();

    var checkTimer = setInterval(function () {
      var elapsed = Date.now() - startAt;
      var currentSec = window.ttlfExtractPinRemainingSeconds();
      var currentBtn = window.ttlfFindExtendPinButton();

      var confirmed = false;
      var reason = 'timeout';

      if (currentSec !== null && beforeState.remainingSec !== null && currentSec > beforeState.remainingSec + 15) {
        confirmed = true;
        reason = 'time_increased';
      } else if (!currentBtn && beforeState.btnPresent) {
        confirmed = true;
        reason = 'button_reset';
      }

      if (confirmed || elapsed >= 2200) {
        clearInterval(checkTimer);
        if (typeof callback === 'function') {
          callback({
            confirmed: confirmed,
            reason: confirmed ? reason : 'unconfirmed_timeout',
            before: beforeState,
            after: { remainingSec: currentSec, btnPresent: !!currentBtn }
          });
        }
      }
    }, 400);
  };

  window.ttlfExtendedPinWatchdogCycle = function () {
    if (!window.ttlfPinExtensionMode.enabled) return;

    var isLiveReady = window.ttlfIsLiveEnvironmentReady();
    if (!isLiveReady) {
      window.ttlfPinExtensionMode.lastStatus = 'LIVE ainda não detectada';
      window.ttlfUpdateExtendedPinHudStatus();
      window.ttlfScheduleNextExtendedPinWatchdog();
      return;
    }

    var isExtended = window.ttlfDetectExtendedPinMode();
    if (!isExtended) {
      if (window.ttlfPinExtensionMode.mode === 'classic') {
        window.ttlfPinExtensionMode.lastStatus = 'Modo clássico ativo — Seção B em vigor';
      } else {
        window.ttlfPinExtensionMode.lastStatus = 'Aguardando botão de renovação...';
      }
      window.ttlfUpdateExtendedPinHudStatus();
      window.ttlfScheduleNextExtendedPinWatchdog();
      return;
    }

    // MODO EXTENDED DETECTADO
    var btnObj = window.ttlfFindExtendPinButton();
    if (!btnObj || !btnObj.element) {
      window.ttlfPinExtensionMode.lastButtonSeen = false;
      if (!window.ttlfPinExtensionMode.buttonAbsentSince) {
        window.ttlfPinExtensionMode.buttonAbsentSince = Date.now();
      }
      window.ttlfPinExtensionMode.absentCycles++;
      if (window.ttlfPinExtensionMode.absentCycles >= 2) {
        window.ttlfPinExtensionMode.waitingForButtonReset = false;
        ttlfLog('[PIN_EXTENDED] reset-confirmed por ausência prolongada do botão.');
      }
      window.ttlfPinExtensionMode.lastStatus = 'Botão +60s não encontrado';
      window.ttlfUpdateExtendedPinHudStatus();
      window.ttlfScheduleNextExtendedPinWatchdog();
      return;
    }

    // Botão presente!
    window.ttlfPinExtensionMode.lastButtonSeen = true;
    window.ttlfPinExtensionMode.buttonAbsentSince = 0;

    var now = Date.now();
    var curSig = window.ttlfBuildExtendedPinSignature(btnObj);
    window.ttlfPinExtensionMode.lastButtonSignature = curSig;

    // Se houve transição recente para extended, aguardar 1 ciclo antes de agir salvo se restarem <= 5s
    var remainSec = window.ttlfExtractPinRemainingSeconds();
    if (now - window.ttlfPinExtensionMode.modeTransitionTimestamp < 2500 && (remainSec === null || remainSec > 5)) {
      window.ttlfPinExtensionMode.lastStatus = 'Transição para modo +60s — efetuando leitura inicial...';
      window.ttlfScheduleNextExtendedPinWatchdog();
      return;
    }

    // Trava de Cooldown Mínimo (8s)
    var gap = now - window.ttlfPinExtensionMode.lastClickAt;
    if (gap < TTLF_EXTENDED_PIN_MIN_CLICK_GAP_MS) {
      var remainGapSec = Math.ceil((TTLF_EXTENDED_PIN_MIN_CLICK_GAP_MS - gap) / 1000);
      window.ttlfPinExtensionMode.lastStatus = 'Aguardando tempo mínimo (' + remainGapSec + 's)';
      window.ttlfUpdateExtendedPinHudStatus();
      window.ttlfScheduleNextExtendedPinWatchdog();
      return;
    }

    // Regra para Tempo Conhecido (> 20s)
    if (remainSec !== null) {
      if (remainSec > 20) {
        window.ttlfPinExtensionMode.lastStatus = 'Produto fixado (' + remainSec + 's restantes)';
        if (remainSec > 25) {
          window.ttlfPinExtensionMode.waitingForButtonReset = false;
          window.ttlfPinExtensionMode.absentCycles = 0;
        }
        window.ttlfUpdateExtendedPinHudStatus();
        window.ttlfScheduleNextExtendedPinWatchdog();
        return;
      }
      // Se remainSec <= 20, verificar se aguarda reset
      if (window.ttlfPinExtensionMode.waitingForButtonReset) {
        var resetCheck = window.ttlfDetectExtendedPinReset(btnObj, remainSec);
        if (!resetCheck.reset) {
          window.ttlfPinExtensionMode.lastStatus = 'Fixação renovada — aguardando novo ciclo (' + remainSec + 's)';
          ttlfLog('[PIN_EXTENDED] waiting-button-reset: restam ' + remainSec + 's, aguardando reset.');
          window.ttlfUpdateExtendedPinHudStatus();
          window.ttlfScheduleNextExtendedPinWatchdog();
          return;
        } else {
          window.ttlfPinExtensionMode.waitingForButtonReset = false;
          window.ttlfPinExtensionMode.absentCycles = 0;
        }
      }
    }

    // Regra para Tempo Desconhecido (remainSec === null)
    if (remainSec === null) {
      if (window.ttlfPinExtensionMode.waitingForButtonReset) {
        var resetCheckNull = window.ttlfDetectExtendedPinReset(btnObj, remainSec);
        if (!resetCheckNull.reset) {
          window.ttlfPinExtensionMode.lastStatus = 'Renovação confirmada — aguardando novo ciclo...';
          ttlfLog('[PIN_EXTENDED] same-signature-blocked: tempo desconhecido e botão com mesma assinatura.');
          window.ttlfUpdateExtendedPinHudStatus();
          window.ttlfScheduleNextExtendedPinWatchdog();
          return;
        } else {
          window.ttlfPinExtensionMode.waitingForButtonReset = false;
          window.ttlfPinExtensionMode.absentCycles = 0;
        }
      }
    }

    // EXECUTAR CLIQUE DE RENOVAÇÃO
    if (window.ttlfPinExtensionMode.busy) {
      window.ttlfScheduleNextExtendedPinWatchdog();
      return;
    }

    window.ttlfPinExtensionMode.busy = true;
    window.ttlfPinExtensionMode.lastStatus = 'Renovando fixação (+ ' + btnObj.seconds + 's)...';
    window.ttlfUpdateExtendedPinHudStatus();

    ttlfLog('[PIN_EXTENDED] click-start: renovando fixação via botão ' + btnObj.label);

    var beforeState = {
      btnPresent: true,
      remainingSec: remainSec,
      timestamp: now
    };

    window.ttlfExtendedPinClick(btnObj.element);
    window.ttlfPinExtensionMode.lastClickAt = Date.now();

    window.ttlfConfirmExtendedPinRenewal(beforeState, function (res) {
      window.ttlfPinExtensionMode.busy = false;

      if (res.confirmed) {
        window.ttlfPinExtensionMode.lastClickAt = Date.now();
        window.ttlfPinExtensionMode.lastRenewalAt = Date.now();
        window.ttlfPinExtensionMode.lastConfirmed = true;
        window.ttlfPinExtensionMode.lastConfirmedSignature = curSig;
        window.ttlfPinExtensionMode.waitingForButtonReset = true;
        window.ttlfPinExtensionMode.failures = 0;
        window.ttlfPinExtensionMode.absentCycles = 0;
        window.ttlfPinExtensionMode.lastStatus = 'Fixação renovada — aguardando novo ciclo ✅';
        ttlfLog('[PIN_EXTENDED] renewal-confirmed: ' + res.reason);
      } else {
        window.ttlfPinExtensionMode.lastStatus = 'Falha ao confirmar renovação';
        window.ttlfPinExtensionMode.failures++;
        // Aplica cooldown temporário estendido de 15s em caso de falha não confirmada
        window.ttlfPinExtensionMode.lastClickAt = Date.now() + 7000;
        ttlfLog('[PIN_EXTENDED] renewal-not-confirmed: aplicando cooldown estendido de 15s');
      }

      window.ttlfUpdateExtendedPinHudStatus();
      window.ttlfScheduleNextExtendedPinWatchdog();
    });
  };

  window.ttlfScheduleNextExtendedPinWatchdog = function () {
    if (window.ttlfPinExtensionMode.timer) {
      clearTimeout(window.ttlfPinExtensionMode.timer);
      window.ttlfPinExtensionMode.timer = null;
    }

    if (window.ttlfPinExtensionMode.enabled) {
      window.ttlfPinExtensionMode.timer = setTimeout(function () {
        window.ttlfExtendedPinWatchdogCycle();
      }, 3000);
    }
  };

  window.ttlfStartExtendedPinWatchdog = function () {
    if (window.ttlfPinExtensionMode.enabled) return;
    window.ttlfPinExtensionMode.enabled = true;
    ttlfLog('[PIN_EXTENDED] Watchdog estendido iniciado.');
    window.ttlfExtendedPinWatchdogCycle();
  };

  window.ttlfStopExtendedPinWatchdog = function () {
    window.ttlfPinExtensionMode.enabled = false;
    window.ttlfPinExtensionMode.busy = false;
    if (window.ttlfPinExtensionMode.timer) {
      clearTimeout(window.ttlfPinExtensionMode.timer);
      window.ttlfPinExtensionMode.timer = null;
    }
    ttlfLog('[PIN_EXTENDED] Watchdog estendido interrompido.');
  };

  window.ttlfPlus60Start = window.ttlfStartExtendedPinWatchdog;
  window.ttlfPlus60Stop = window.ttlfStopExtendedPinWatchdog;
  window.ttlfPlus60IsRunning = function () { return window.ttlfPinExtensionMode.enabled; };

  window.ttlfUpdateExtendedPinHudStatus = function () {
    var stPlus = document.getElementById('rf-plus60-status');
    if (stPlus) {
      stPlus.textContent = window.ttlfPinExtensionMode.lastStatus || 'Refixação estendida ativa.';
    }
  };

  /* ===== 8. PROTEÇÃO CONTRA VIOLAÇÃO ===== */
  (function () {
    'use strict';
    if (window.rvTick) { clearInterval(window.rvTick); }
    var encerrando = false; var detectadoEm = 0; var confirmando = false; var ultimoAbrir = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rv-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharTimer() { var els = $s('div,span,p,b,strong'); for (var i = 0; i < els.length; i++) { var e = els[i]; if (e.children.length === 0) { var t = (e.textContent || '').trim(); if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && vis(e) && fora(e)) { return e; } } } return null; }
    function acharPower(tm) { var el = tm, tr = tm.getBoundingClientRect(); for (var up = 0; up < 9 && el; up++) { el = el.parentElement; if (!el) { break; } var cands = $s('button,[role="button"],svg', el).filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if (((b.textContent || '').trim()) !== '') { return false; } var r = b.getBoundingClientRect(); if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) { return false; } return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer'; }); if (cands.length) { cands.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cands[0]; } } return null; }
    function botaoConfirmar() { var bs = $s('button,[role="button"]').filter(function (b) { var t = (b.textContent || '').trim(); return vis(b) && fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel/i.test(t) && t.length < 40; }); return bs.length ? bs[bs.length - 1] : null; }
    function ehConfig(e) { var q = e; for (var k = 0; k < 14 && q; k++) { var t = (q.textContent || ''); if (t.length < 8000 && /(Configura[cç][oõ]es|Filtrar coment|Permitir coment|palavras-chave|Dura[cç][aã]o do silenciamento|Bloquear palavras|comunidade j[aá] sinalizou|potencialmente desagrad)/i.test(t)) { return true; } q = q.parentElement; } return false; }
    function achaAviso() { var dots = $s('span,sup,i,b,div'); for (var i = 0; i < dots.length; i++) { var e = dots[i]; var cls = (e.className || '').toString(); if (cls.indexOf('m4b-badge-dot') < 0) { continue; } if (!vis(e) || !fora(e)) { continue; } var r = e.getBoundingClientRect(); if (r.top > 170) { continue; } var p = e; for (var k = 0; k < 5 && p; k++) { var b = (p.querySelector) ? p.querySelector('button,[role="button"]') : null; if (b && vis(b) && fora(b)) { return b; } if (p.tagName === 'BUTTON') { return p; } p = p.parentElement; } } var all = $s('div,span,i,sup,b'); for (var j = 0; j < all.length; j++) { var e2 = all[j]; if (!vis(e2) || !fora(e2) || e2.children.length > 0) { continue; } var r2 = e2.getBoundingClientRect(); if (r2.top > 170) { continue; } if (r2.width < 5 || r2.width > 18 || r2.height < 5 || r2.height > 18) { continue; } var bg = getComputedStyle(e2).backgroundColor || ''; var m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/); if (!m) { continue; } var R = +m[1], G = +m[2], B = +m[3], A = (m[4] === undefined ? 1 : +m[4]); if (A < 0.6) { continue; } if (!(R > 160 && G < 115 && B < 130)) { continue; } var p2 = e2; for (var k2 = 0; k2 < 5 && p2; k2++) { var b2 = (p2.querySelector) ? p2.querySelector('button,[role="button"]') : null; if (b2 && vis(b2) && fora(b2)) { return b2; } if (p2.tagName === 'BUTTON' || (p2.getAttribute && p2.getAttribute('role') === 'button')) { return p2; } try { if (getComputedStyle(p2).cursor === 'pointer') { return p2; } } catch (_) {} p2 = p2.parentElement; } } return null; }
    function detecta() { var els = $s('div,span,p,h1,h2,h3,b,strong'); var temPainel = false; for (var i = 0; i < els.length; i++) { var t0 = (els[i].textContent || '').trim(); if (/^Lembrete de viola/i.test(t0) && els[i].children.length <= 3 && vis(els[i])) { temPainel = true; break; } } if (temPainel) { var conta = null; for (var j = 0; j < els.length; j++) { if (els[j].children.length > 0) { continue; } var tj = (els[j].textContent || '').trim(); var mm = tj.match(/^Todos?\s*\((\d+)\)/i); if (mm) { conta = parseInt(mm[1], 10); break; } } if (conta !== null) { if (conta > 0) { return 'Violação no painel (Todos ' + conta + ')'; } return null; } return null; } var re = /(sua live pode ser suspensa|sua transmiss[aã]o pode ser suspensa|live foi encerrada por viola|live ser[aá] encerrada por viola|viola[cç][aã]o das diretrizes|conte[uú]do impr[oó]prio detect|penalidade aplicad|foi sinalizada por viola)/i; for (var k = 0; k < els.length; k++) { var e = els[k]; if (e.children.length !== 0) { continue; } var cls = (e.className || '').toString(); if (cls.indexOf('text-body') > -1) { continue; } if (!vis(e) || !fora(e)) { continue; } var x = (e.textContent || '').trim(); if (x && x.length < 300 && re.test(x)) { if (ehConfig(e)) { continue; } return x.slice(0, 70); } } return null; }
    function tick() { sincBtn(); var cb = document.getElementById('rv-ativo'); if (!cb) { return; } if (!cb.checked) { st('Inativa.'); encerrando = false; confirmando = false; detectadoEm = 0; return; } var agora = Date.now(); var tm = acharTimer(); if (confirmando) { var cf = botaoConfirmar(); if (cf) { cf.click(); } if (!acharTimer()) { confirmando = false; st('LIVE encerrada pela proteção. ' + new Date().toLocaleTimeString()); } return; } if (encerrando) { if (!tm) { st('LIVE encerrada pela proteção. ' + new Date().toLocaleTimeString()); } else if (agora - detectadoEm > 180000) { encerrando = false; detectadoEm = 0; } return; } if (!tm) { st('Ativa 🛡️ — aguardando LIVE no ar.'); detectadoEm = 0; return; } var av = detecta(); if (!av) { var _ic = achaAviso(); if (_ic && (Date.now() - ultimoAbrir > 6000)) { ultimoAbrir = Date.now(); clicar(_ic); st('🔎 Verificando aviso de violação...'); return; } st('Ativa 🛡️ monitorando a tela (' + new Date().toLocaleTimeString() + ')'); detectadoEm = 0; return; } if (!detectadoEm) { detectadoEm = agora; } var atraso = (parseInt(document.getElementById('rv-delay').value, 10) || 0) * 1000; var falta = detectadoEm + atraso - agora; if (falta > 0) { st('⚠️ AVISO DETECTADO! Encerrando em ' + Math.ceil(falta / 1000) + 's — "' + av + '"'); return; } var pw = acharPower(tm); if (pw) { clicar(pw); encerrando = true; confirmando = true; st('⚠️ Aviso detectado — ENCERRANDO A LIVE!'); } else { st('⚠️ Aviso detectado, mas não achei o botão de desligar!'); } }
    function sincBtn() { var cb = document.getElementById('rv-ativo'); var b = document.getElementById('rv-botao'); if (!cb || !b) { return; } if (cb.checked) { b.textContent = '⏸ Desativar proteção'; b.style.background = '#ff1717'; } else { b.textContent = '▶ Ativar proteção'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; } }
    window.ttlfProtectionToggle = function () { var cb = document.getElementById('rv-ativo'); if (cb) { cb.checked = !cb.checked; if (typeof cb.dispatchEvent === 'function') { cb.dispatchEvent(new Event('change', { bubbles: true })); } } sincBtn(); };
    var btnRv = document.getElementById('rv-botao'); if (btnRv) { btnRv.addEventListener('click', function () { window.ttlfProtectionToggle(); }); }
    sincBtn();
    window.rvTick = setInterval(tick, 2000);
  })();

  /* ===== 9. TIMER DE ENCERRAMENTO REGRESSIVO (CORRIGIDO v11.0.5-dev) ===== */
  (function () {
    'use strict';
    if (window.rtTick) { clearInterval(window.rtTick); window.rtTick = null; }

    var fase = 'off'; // 'off', 'aguardando_inicio', 'contando', 'pausado', 'finalizado'
    var durationMs = 0;
    var startedAt = 0;
    var deadline = 0;
    var resto = 0;
    var confirmando = false;
    var confirmStartAt = 0;
    var modalClicked = false;
    var endLiveTriggered = false;

    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha' || p.id === 'ttlf-gate' || p.id === 'ra-painel') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rt-status'); if (e) { e.textContent = m; } }

    function logTimer(msg) {
      if (typeof ttlfLog === 'function') {
        ttlfLog('[TIMER] ' + msg);
      } else {
        console.log('[TIMER] ' + msg);
      }
    }

    function clicar(el) {
      if (!el) return;
      if (typeof el.click === 'function') {
        try { el.click(); } catch (e) {}
      }
      ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
        try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {}
      });
    }

    function acharTimer() {
      var els = $s('div,span,p,b,strong');
      for (var i = 0; i < els.length; i++) {
        var e = els[i];
        if (e.children.length === 0) {
          var t = (e.textContent || '').trim();
          if (/^d{1,2}:d{2}:d{2}$/.test(t) && vis(e) && fora(e)) {
            return e;
          }
        }
      }
      return null;
    }

    function acharPower(tm) {
      if (!tm) return null;
      var el = tm, tr = tm.getBoundingClientRect();
      for (var up = 0; up < 9 && el; up++) {
        el = el.parentElement;
        if (!el) break;
        var cands = $s('button,[role="button"],svg', el).filter(function (b) {
          if (!vis(b) || !fora(b)) return false;
          if (b.disabled || (b.getAttribute && b.getAttribute('aria-disabled') === 'true')) return false;
          if (((b.textContent || '').trim()) !== '') return false;
          var r = b.getBoundingClientRect();
          if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) return false;
          return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer';
        });
        if (cands.length) {
          cands.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; });
          return cands[0];
        }
      }
      return null;
    }

    function acharBotaoEncerrarNativo() {
      var candidates = $s('button, [role="button"], div, span').filter(function (b) {
        if (!vis(b) || !fora(b)) return false;
        if (b.disabled || (b.getAttribute && b.getAttribute('aria-disabled') === 'true')) return false;
        
        var isClickable = b.tagName === 'BUTTON' || (b.getAttribute && b.getAttribute('role') === 'button') || getComputedStyle(b).cursor === 'pointer';
        if (!isClickable) return false;

        var t = (b.textContent || '').trim().toLowerCase();
        var isExactMatch = t === 'encerrar live' || t === 'encerrar transmissão' || t === 'end live' || t === 'encerrar a live';
        return isExactMatch;
      });

      return candidates.length ? candidates[0] : null;
    }

    function botaoConfirmar() {
      var bs = $s('button, [role="button"]').filter(function (b) {
        if (!vis(b) || !fora(b)) return false;
        if (b.disabled || (b.getAttribute && b.getAttribute('aria-disabled') === 'true')) return false;
        var isClickable = b.tagName === 'BUTTON' || (b.getAttribute && b.getAttribute('role') === 'button') || getComputedStyle(b).cursor === 'pointer';
        if (!isClickable) return false;
        var t = (b.textContent || '').trim();
        return /^(encerrar|confirmar|sim|end)$/i.test(t) && !/cancelar|cancel/i.test(t) && t.length < 40;
      });
      return bs.length ? bs[bs.length - 1] : null;
    }

    function fmt(ms) {
      var s = Math.max(0, Math.floor(ms / 1000));
      var h = Math.floor(s / 3600);
      var m = Math.floor((s - h * 3600) / 60);
      var x = s - h * 3600 - m * 60;
      function z(n) { return (n < 10 ? '0' : '') + n; }
      if (h > 0) {
        return z(h) + ':' + z(m) + ':' + z(x);
      }
      return z(m) + ':' + z(x);
    }

    function mostra(ms) {
      var e = document.getElementById('rt-restante');
      if (e) {
        if (ms <= 0 && (fase === 'contando' || fase === 'finalizado')) {
          e.textContent = '00:00';
          if (ms <= 600000 && ms > 0) {
            e.style.color = '#ff3838';
          }
        } else {
          e.textContent = fmt(ms);
          if (ms <= 600000 && ms > 0) {
            e.style.color = '#ffcf00';
          } else {
            e.style.color = '#ffffff';
          }
        }
      }
    }

    function salva() {
      var stateObj = {
        fase: fase,
        durationMs: durationMs,
        startedAt: startedAt,
        deadline: deadline,
        resto: resto,
        endLiveTriggered: endLiveTriggered
      };
      try {
        localStorage.setItem('ttlf-rt-estado', JSON.stringify(stateObj));
      } catch (e) {}
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ 'ttlf_rt_estado': stateObj });
        }
      } catch (e) {}
    }

    function botoes() {
      var a = document.getElementById('rt-armar');
      var p = document.getElementById('rt-pausa');
      var c = document.getElementById('rt-cancel');
      if (!a || !p || !c) return;
      if (fase === 'off' || fase === 'finalizado') {
        a.style.display = 'block';
        p.style.display = 'none';
        c.style.display = 'none';
        a.textContent = '▶ Iniciar Timer';
      } else {
        a.style.display = 'none';
        p.style.display = 'block';
        c.style.display = 'block';
        p.textContent = (fase === 'pausado') ? '▶ Retomar' : '⏸ Pausar';
      }
    }

    function isLiveNoAr() {
      if (typeof window.ttlfLiveNoAr === 'function') {
        return window.ttlfLiveNoAr();
      }
      return !!acharTimer();
    }

    function armar() {
      var inpRt = document.getElementById('rt-min');
      var min = inpRt ? (parseInt(inpRt.value, 10) || 120) : 120;
      if (min < 1) min = 1;
      
      durationMs = min * 60000;
      endLiveTriggered = false;
      confirmando = false;
      modalClicked = false;

      logTimer('duração configurada: ' + min + ' min (' + durationMs + 'ms)');

      if (isLiveNoAr()) {
        startedAt = Date.now();
        deadline = startedAt + durationMs;
        fase = 'contando';
        logTimer('live detectada no ar ao armar! startedAt: ' + startedAt + ' | endAt: ' + deadline);
        st('Timer iniciado ⏲️ encerra às ' + new Date(deadline).toLocaleTimeString());
      } else {
        startedAt = 0;
        deadline = 0;
        fase = 'aguardando_inicio';
        logTimer('aguardando início da live...');
        st('Aguardando início da live ⏳');
      }

      salva();
      botoes();
    }

    function pausaRetoma() {
      if (fase === 'contando') {
        resto = Math.max(0, deadline - Date.now());
        fase = 'pausado';
        logTimer('timer pausado com ' + fmt(resto) + ' restantes');
        st('Pausado com ' + fmt(resto) + ' restantes.');
      } else if (fase === 'pausado') {
        deadline = Date.now() + resto;
        startedAt = Date.now() - (durationMs - resto);
        fase = 'contando';
        logTimer('timer retomado — encerra às ' + new Date(deadline).toLocaleTimeString());
        st('Retomado — encerra às ' + new Date(deadline).toLocaleTimeString());
      }
      salva();
      botoes();
    }

    function cancela() {
      fase = 'off';
      durationMs = 0;
      startedAt = 0;
      deadline = 0;
      resto = 0;
      confirmando = false;
      endLiveTriggered = false;
      modalClicked = false;
      logTimer('timer desativado/cancelado');
      salva();
      botoes();
      st('Desligado.');
    }

    function executarEncerramento() {
      if (endLiveTriggered) {
        logTimer('encerramento já disparado anteriormente — ignorando chamada duplicada');
        return;
      }

      endLiveTriggered = true;
      logTimer('zero atingido — encerramento disparado!');

      if (!isLiveNoAr()) {
        logTimer('tempo esgotado, porém live já estava encerrada/fora do ar');
        st('Tempo esgotado — LIVE já estava fora do ar.');
        fase = 'finalizado';
        salva();
        botoes();
        return;
      }

      var tm = acharTimer();
      var pw = acharPower(tm);

      if (pw) {
        logTimer('botão de desligar localizado via acharPower — efetuando primeiro clique');
        clicar(pw);
        confirmando = true;
        confirmStartAt = Date.now();
        modalClicked = false;
        st('⏰ Tempo esgotado — ENCERRANDO A LIVE!');
      } else {
        var btnNativo = acharBotaoEncerrarNativo();
        if (btnNativo) {
          logTimer('botão nativo "' + (btnNativo.textContent || '').trim() + '" localizado — efetuando primeiro clique');
          clicar(btnNativo);
          confirmando = true;
          confirmStartAt = Date.now();
          modalClicked = false;
          st('⏰ Tempo esgotado — ENCERRANDO A LIVE!');
        } else {
          logTimer('⏰ Tempo esgotado, mas não foi possível localizar o botão de encerramento seguro!');
          st('⏰ Tempo esgotado, aguardando controle de encerramento...');
        }
      }

      salva();
    }

    function tick() {
      if (confirmando) {
        var elapsed = Date.now() - confirmStartAt;

        if (!modalClicked) {
          var cf = botaoConfirmar();
          if (cf) {
            logTimer('modal de confirmação localizado — efetuando clique único de confirmação');
            clicar(cf);
            modalClicked = true;
          }
        }

        if (!isLiveNoAr()) {
          confirmando = false;
          fase = 'finalizado';
          logTimer('live encerrada com sucesso! status = finished');
          st('LIVE encerrada pelo timer às ' + new Date().toLocaleTimeString() + ' ✅');
          salva();
          botoes();
          return;
        }

        if (elapsed > 4000) {
          logTimer('timeout no fluxo de encerramento (' + elapsed + 'ms) — live ainda no ar');
          confirmando = false;
          st('⚠️ Timeout no encerramento — verifique a live manualmente.');
          salva();
        }
        return;
      }

      if (fase === 'off' || fase === 'finalizado') {
        var inpRt = document.getElementById('rt-min');
        var min = inpRt ? (parseInt(inpRt.value, 10) || 0) : 0;
        mostra(min * 60000);
        return;
      }

      if (fase === 'aguardando_inicio') {
        var inpRt2 = document.getElementById('rt-min');
        var min2 = inpRt2 ? (parseInt(inpRt2.value, 10) || 0) : 0;
        mostra(min2 * 60000);

        if (isLiveNoAr()) {
          startedAt = Date.now();
          deadline = startedAt + (durationMs || (min2 * 60000));
          fase = 'contando';
          logTimer('live detectada no ar! Transicionando de aguardando_inicio -> contando | endAt: ' + deadline);
          st('Timer iniciado ⏲️ encerra às ' + new Date(deadline).toLocaleTimeString());
          salva();
          botoes();
        } else {
          st('Aguardando início da live ⏳');
        }
        return;
      }

      if (fase === 'pausado') {
        mostra(resto);
        return;
      }

      if (fase === 'contando') {
        if (!isLiveNoAr() && !confirmando && (deadline - Date.now() > 5000)) {
          logTimer('live foi encerrada externamente antes do timer expirar. Limpando estado.');
          st('LIVE encerrada manualmente.');
          cancela();
          return;
        }

        var faltaMs = deadline - Date.now();
        var displayMs = Math.max(0, faltaMs);
        mostra(displayMs);

        if (faltaMs <= 0) {
          executarEncerramento();
        }
      }
    }

    function restaurarEstado() {
      try {
        var sv = localStorage.getItem('ttlf-rt-estado');
        if (sv) {
          var parsed = JSON.parse(sv);
          if (parsed && parsed.fase) {
            fase = parsed.fase;
            durationMs = parsed.durationMs || 0;
            startedAt = parsed.startedAt || 0;
            deadline = parsed.deadline || 0;
            resto = parsed.resto || 0;
            endLiveTriggered = !!parsed.endLiveTriggered;

            if (fase === 'contando') {
              if (deadline > Date.now()) {
                if (!isLiveNoAr() && (deadline - Date.now() > 5000)) {
                  logTimer('live foi encerrada externamente antes da extensão carregar/recuperar. Limpando estado.');
                  cancela();
                } else {
                  logTimer('timer recuperado — encerra às ' + new Date(deadline).toLocaleTimeString());
                  st('Timer recuperado — encerra às ' + new Date(deadline).toLocaleTimeString());
                }
              } else {
                logTimer('timer recuperado expirado — executando encerramento de imediato');
                executarEncerramento();
              }
            } else if (fase === 'aguardando_inicio') {
              logTimer('timer recuperado no estado aguardando_inicio');
              st('Aguardando início da live ⏳');
            } else if (fase === 'pausado' && resto > 0) {
              logTimer('timer recuperado no estado pausado');
              st('Pausado com ' + fmt(resto) + ' restantes.');
            }
          }
        }
      } catch (e) {}
    }

    restaurarEstado();
    botoes();

    window.startLiveCountdown = armar;
    window.stopLiveCountdown = cancela;
    window.restoreLiveCountdown = restaurarEstado;
    window.handleCountdownFinished = executarEncerramento;

    window.ttlfTimerArmar = armar;
    window.ttlfTimerPausa = pausaRetoma;
    window.ttlfTimerCancel = cancela;

    var btnArmar = document.getElementById('rt-armar'); if (btnArmar) { btnArmar.onclick = armar; }
    var btnPausa = document.getElementById('rt-pausa'); if (btnPausa) { btnPausa.onclick = pausaRetoma; }
    var btnCancel = document.getElementById('rt-cancel'); if (btnCancel) { btnCancel.onclick = cancela; }

    $s('.ttlf-preset').forEach(function (b) {
      b.onclick = function () {
        var inp = document.getElementById('rt-min');
        if (inp) {
          inp.value = b.getAttribute('data-min');
          inp.dispatchEvent(new Event('input', { bubbles: true }));
        }
      };
    });

    window.rtTick = setInterval(tick, 500);
  })();

  /* ===== 10. DUPLICAR OFERTA RELÂMPAGO ===== */
  (function () {
    'use strict';
    if (window.rdTick) { clearInterval(window.rdTick); }
    var rodando = false; var fase = 'watch'; var t0 = 0; var espera = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rd-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function achaExato(txt) { return $s('button,[role="button"],a,span,div').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if ((b.textContent || '').trim() !== txt) { return false; } return b.tagName === 'BUTTON' || b.tagName === 'A' || getComputedStyle(b).cursor === 'pointer'; }); }
    function tick() { if (!rodando) { return; } var agora = Date.now(); if (agora < espera) { return; } if (fase === 'watch') { var cands = achaExato('Duplicar').filter(function (b) { var el = b; for (var i = 0; i < 6 && el; i++) { el = el.parentElement; if (!el) { break; } var t = el.textContent || ''; if (t.indexOf('foi encerrada') > -1) { return true; } if (t.length > 500) { break; } } return false; }); if (cands.length) { clicar(cands[0]); fase = 'm1'; t0 = agora; st('Oferta encerrada detectada — duplicando...'); } else { st('Monitorando oferta relâmpago... 👀'); } return; } if (fase === 'm1') { var b1 = achaExato('Duplicar e começar agora'); if (b1.length) { clicar(b1[b1.length - 1]); fase = 'm2'; t0 = agora; st('Duplicando e iniciando...'); return; } if (agora - t0 > 20000) { fase = 'watch'; st('Tentando de novo...'); } return; } if (fase === 'm2') { var b2 = achaExato('Iniciar').filter(function (b) { var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) { break; } var cls = (el.className || '').toString(); if ((cls.indexOf('modal') > -1 || el.getAttribute('role') === 'dialog') && (el.textContent || '').indexOf('Oferta rel') > -1) { return true; } } return false; }); if (!b2.length) { b2 = achaExato('Iniciar'); } if (b2.length) { clicar(b2[b2.length - 1]); fase = 'watch'; espera = agora + 30000; st('Oferta relâmpago relançada! ✅ ' + new Date().toLocaleTimeString()); return; } if (agora - t0 > 20000) { fase = 'watch'; st('Tentando de novo...'); } return; } }
    function liga() { rodando = true; fase = 'watch'; espera = 0; var b = document.getElementById('rd-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando oferta relâmpago... 👀'); }
    function desliga() { rodando = false; var b = document.getElementById('rd-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    window.ttlfOfertaToggle = function () { rodando ? desliga() : liga(); };
    var btnRd = document.getElementById('rd-botao'); if (btnRd) { btnRd.addEventListener('click', function () { window.ttlfOfertaToggle(); }); }
    window.rdTick = setInterval(tick, 2000);
  })();

  window.ttlfInitializationComplete = true;
  ttlfLog('✅ [Boot] Painel Live Infinity inicializado com sucesso e todos os ouvintes registrados.');

function ttlfStorageCleanupMigration() {
  try {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.get(['liveinfinity_cleanup_v11_etapa_c'], function (res) {
      if (res && res.liveinfinity_cleanup_v11_etapa_c) return;

      var extraKeysToRemove = [
        'telegram_config',
        'tgToken',
        'tgChatId',
        'ilAIActive',
        'ilAIGeminiKey',
        'ilAISystemPrompt',
        'ilAIProductDesc',
        'ilAIResponseDelay',
        'ilPostSaleEnabled',
        'ilPostSaleMessages',
        'ilPostSaleDelay',
        'ilAudioConfig',
        'ilPlayerFiles',
        'ilSuporteTickets'
      ];

      chrome.storage.local.remove(extraKeysToRemove, function () {
        chrome.storage.local.set({ liveinfinity_cleanup_v11_etapa_c: true }, function () {
          ttlfLog('🧹 [Migração Etapa C] Limpeza de storage dos módulos extras concluída.');
        });
      });
    });
  } catch (e) {}
}

/* ===== RECONCILIAÇÃO DE ABA EM SEGUNDO PLANO E RECUPERAÇÃO ===== */
function restoreLiveInfinitySession() {
  if (!window.ttlfInitializationComplete) return;
  try {
    ttlfLog('🔄 [Reconciliação] Aba retomada pós-pausa do Chrome (' + (document.visibilityState || 'visible') + ')');
    if (!document.getElementById('ttlf-hub')) {
      ttlfBoot();
    }
    if (typeof window.ttlfRefixBusy !== 'undefined') {
      window.ttlfRefixBusy = false;
    }
  } catch (e) {}
}

function ttlfStartHeartbeat() {
  if (window.ttlfHeartbeatTimer) clearInterval(window.ttlfHeartbeatTimer);
  window.ttlfHeartbeatTimer = setInterval(function () {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: 'ttlf-heartbeat',
          visibilityState: document.visibilityState || 'visible',
          timestamp: Date.now()
        }, function () {
          if (chrome.runtime.lastError) {}
        });
      }
    } catch (e) {}
  }, 15000);
}

if (typeof window !== 'undefined') {
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') {
      restoreLiveInfinitySession();
    }
  });
  window.addEventListener('pageshow', restoreLiveInfinitySession);
  window.addEventListener('online', restoreLiveInfinitySession);
}

ttlfStorageCleanupMigration();
ttlfStartHeartbeat();
ttlfBoot();

