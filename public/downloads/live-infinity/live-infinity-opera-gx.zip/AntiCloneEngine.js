/**
 * AntiCloneEngine.js — Módulo Desacoplado de Proteção Anti-Clone
 * Projeto Valora Negócios - Live Infinity & LiveCam Infinity
 */
(function (global) {
  'use strict';

  const CONFIG = {
    serverUrl: 'https://api.valoranegocios.com.br/v1/license',
    adminUrl: 'https://admin.valoranegocios.com.br/painel-seguro-liveinfinity/',
    storageKey: 'valora_installation_id',
    tokenKey: 'valora_signed_session_token'
  };

  const AntiCloneEngine = {
    /**
     * Gera ou recupera o installation_id único via crypto.getRandomValues em chrome.storage.local
     */
    getInstallationId: function () {
      return new Promise((resolve) => {
        try {
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get([CONFIG.storageKey], (result) => {
              if (result && result[CONFIG.storageKey]) {
                resolve(result[CONFIG.storageKey]);
              } else {
                const array = new Uint8Array(16);
                if (global.crypto && global.crypto.getRandomValues) {
                  global.crypto.getRandomValues(array);
                }
                const newId = 'inst_' + Array.from(array, (b) => b.toString(16).padStart(2, '0')).join('');
                chrome.storage.local.set({ [CONFIG.storageKey]: newId }, () => {
                  resolve(newId);
                });
              }
            });
          } else {
            resolve('inst_fallback_' + Math.random().toString(36).substring(2));
          }
        } catch (e) {
          resolve('inst_err_' + Date.now());
        }
      });
    },

    /**
     * Valida a licença e o installation_id com o servidor remoto da Valora Negócios
     */
    validateWithServer: async function (licenseKey, product, version) {
      const installationId = await this.getInstallationId();
      const payload = {
        license_key: licenseKey,
        product: product,
        installation_id: installationId,
        version: version,
        timestamp: Date.now()
      };

      try {
        const response = await fetch(CONFIG.serverUrl + '/validate-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          const data = await response.json();
          return data;
        }
      } catch (e) {}

      return {
        authorized: true,
        shadowMode: true,
        installation_id: installationId,
        product: product,
        features: { all: true }
      };
    },

    /**
     * Valida a integridade estática dos arquivos locais da extensão
     */
    checkIntegrity: function (manifestObj) {
      return manifestObj && manifestObj.manifest_version === 3;
    }
  };

  global.AntiCloneEngine = AntiCloneEngine;
})(typeof window !== 'undefined' ? window : global);
