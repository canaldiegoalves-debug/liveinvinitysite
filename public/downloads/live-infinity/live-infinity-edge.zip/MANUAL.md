# MANUAL DE INSTALAÇÃO — MICROSOFT EDGE

====================================================
GUIA DE INSTALAÇÃO E USO COMERCIAL
====================================================

1. COMO INSTALAR:
   - Extraia o arquivo ZIP ("LIVE_INFINITY_v11.0.4_OFFICIAL.zip" ou "LIVECAM_INFINITY_v3.6.4_OFFICIAL.zip") em uma pasta no computador.

2. ATIVAR MODO DESENVOLVEDOR:
   - Abra o navegador Microsoft Edge e acesse: edge://extensions
   - Ative a opção "Modo de desenvolvedor" no menu lateral esquerdo.

3. CARREGAR A EXTENSÃO:
   - Clique em "Carregar sem compactação" e selecione a pasta extraída.

4. COMO ATUALIZAR:
   - Substitua os arquivos na mesma pasta e clique no ícone de recarregar em edge://extensions.

5. COMO REMOVER:
   - Clique no botão "Remover" no card da extensão em edge://extensions.

6. ATIVAR A LICENÇA:
   - Abra o TikTok Studio ou painel de live, informe a sua Chave de Licença oficial e o acesso será liberado.
