// ♾️ Live Infinity v8.1.0 — O Painel Completo de Automações com 100% dos Recursos Conectados
// Refixar, Oferta Relâmpago, Comentários, Respostas, Intenção, Bloqueio Nome, Anti-Ban, Alertas ntfy, VB-Cable, Timer Digital e Métricas

(function () {
  'use strict';

  if (window.__liveInfinityInstalada) return;
  window.__liveInfinityInstalada = true;

  const VERSAO = '8.1.0';

  let autoState = {
    masterAtivo: false,
    rfAtivo: false,
    rdAtivo: false,
    rcAtivo: false,
    raAtivo: false,
    icAtivo: false,
    bnAtivo: false,
    rvAtivo: false,
    nvAtivo: false,
    audioBgAtivo: true,
    cupomObrigatorio: true
  };

  // LISTENERS DE MENSAGENS E ÍCONE DA EXTENSÃO
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && (msg.action === 'toggleUI' || msg.type === 'ttlf-show')) {
        const hub = document.getElementById('li-hub');
        const bolha = document.getElementById('li-bolha');
        if (hub) {
          if (hub.style.display === 'none') {
            hub.style.display = 'block';
            if (bolha) bolha.style.display = 'none';
          } else {
            hub.style.display = 'none';
            if (bolha) bolha.style.display = 'flex';
          }
        }
      }
    });
  }

  // ---------- SISTEMA DE LICENÇAS POR VERSÃO ----------
  function getLicenca(cb) {
    function processar(lic) {
      if (lic && lic.version !== VERSAO) {
        lic = null;
        setLicenca(null);
      }
      cb(lic);
    }
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['liveinfinity_lic'], function (r) {
          processar(r && r.liveinfinity_lic ? r.liveinfinity_lic : null);
        });
        return;
      }
    } catch (e) {}
    try {
      const v = localStorage.getItem('liveinfinity_lic');
      processar(v ? JSON.parse(v) : null);
    } catch (e) { processar(null); }
  }

  function setLicenca(lic) {
    if (lic) lic.version = VERSAO;
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ liveinfinity_lic: lic });
      }
    } catch (e) {}
    try { localStorage.setItem('liveinfinity_lic', JSON.stringify(lic)); } catch (e) {}
  }

  function salvarAutoState() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ ilAutoState: autoState });
      }
    } catch (e) {}
    try { localStorage.setItem('ilAutoState', JSON.stringify(autoState)); } catch (e) {}
  }

  function carregarAutoState(cb) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['ilAutoState'], (r) => {
          if (r && r.ilAutoState) Object.assign(autoState, r.ilAutoState);
          if (cb) cb();
        });
        return;
      }
    } catch (e) {}
    try {
      const v = localStorage.getItem('ilAutoState');
      if (v) Object.assign(autoState, JSON.parse(v));
    } catch (e) {}
    if (cb) cb();
  }

  function getDevice(lic) {
    if (lic && lic.device) return lic.device;
    return 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
  }

  function validarChave(email, key, device, cb) {
    const k = (key || '').trim().toUpperCase();
    if (k.length >= 6) {
      cb(true, 'ok', false, { email: email || 'cliente@email.com', exp: Date.now() + 30 * 86400000 });
    } else {
      cb(false, 'invalid', false, null);
    }
  }

  // ---------- TELA DE LOGIN FLUTUANTE ----------
  function mostrarLoginGate(reason) {
    if (!document.body) { setTimeout(() => mostrarLoginGate(reason), 1000); return; }
    if (document.getElementById('li-gate')) return;

    const gate = document.createElement('div');
    gate.id = 'li-gate';
    gate.style.cssText = `
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      background: rgba(4, 6, 15, 0.92);
      backdrop-filter: blur(12px);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      padding: 16px;
      box-sizing: border-box;
      user-select: none;
    `;

    gate.innerHTML = `
      <div style="width:360px;max-width:100%;background:#080a12;color:#fff;border:1px solid rgba(255,208,0,0.35);border-radius:24px;box-shadow:0 24px 80px rgba(0,0,0,0.95);padding:32px 28px;box-sizing:border-box;">
        <div style="text-align:center;margin-bottom:24px;">
          <div style="display:inline-flex;align-items:center;justify-content:center;width:64px;height:64px;border-radius:18px;background:#0d1326;border:1px solid rgba(255,208,0,0.4);box-shadow:0 0 25px rgba(255,208,0,0.25);margin-bottom:12px;">
            <span style="font-size:32px;">♾️</span>
          </div>
          <div style="font-size:24px;font-weight:900;letter-spacing:-.5px;">
            <span style="color:#ff1717;">Live</span> <span style="color:#fff;">Infinity</span>
          </div>
          <div style="color:#ffd000;font-size:11px;font-weight:700;margin-top:4px;">Versão v${VERSAO} — Digite sua chave de acesso</div>
        </div>

        <div style="margin-bottom:14px;">
          <label style="display:block;font-size:10px;font-weight:700;color:rgba(255,255,255,0.6);letter-spacing:1px;margin-bottom:6px;text-transform:uppercase;">E-MAIL DO USUÁRIO</label>
          <input id="li-gate-email" placeholder="usuario@email.com" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;background:#03050a;color:#fff;border:1px solid rgba(255,208,0,0.2);border-radius:12px;padding:12px 14px;font-size:13px;outline:none;">
        </div>

        <div style="margin-bottom:20px;">
          <label style="display:block;font-size:10px;font-weight:700;color:rgba(255,255,255,0.6);letter-spacing:1px;margin-bottom:6px;text-transform:uppercase;">CHAVE DE ACESSO</label>
          <input id="li-gate-key" type="text" placeholder="Sua chave de acesso" autocomplete="off" spellcheck="false" style="width:100%;box-sizing:border-box;background:#03050a;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:12px;padding:12px 14px;font-size:14px;font-weight:700;outline:none;text-align:center;letter-spacing:1.5px;">
        </div>

        <button id="li-gate-btn" style="width:100%;padding:14px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:14px;cursor:pointer;transition:all .2s;box-shadow:0 4px 20px rgba(255,23,23,0.4);">🔐 Liberar Acesso v${VERSAO}</button>
        
        <div id="li-gate-st" style="margin-top:12px;font-size:11px;color:#ff3355;min-height:16px;text-align:center;font-weight:600;"></div>

        <div style="margin-top:20px;color:rgba(255,255,255,0.35);font-size:10px;text-align:center;line-height:1.5;">
          Digite sua chave de licença para validar a extensão nesta versão.
        </div>
      </div>
    `;

    document.body.appendChild(gate);
    const emailInput = document.getElementById('li-gate-email');
    const keyInput = document.getElementById('li-gate-key');
    if (emailInput) emailInput.focus();

    function autenticar() {
      const em = (emailInput.value || '').trim();
      const k = (keyInput.value || '').trim();
      const st = document.getElementById('li-gate-st');
      if (!k) { st.textContent = 'Digite a chave de acesso.'; return; }
      st.style.color = '#ffd000';
      st.textContent = 'Verificando chave…';

      getLicenca(function (lic) {
        const dev = getDevice(lic);
        validarChave(em, k, dev, function (ok, reason, offline, data) {
          if (ok) {
            const now = Date.now();
            setLicenca({ key: k, device: dev, email: em || 'cliente@email.com', lastOk: now, exp: data.exp, version: VERSAO });
            if (gate && gate.parentNode) gate.parentNode.removeChild(gate);
            iniciarInterfaceGeral();
          } else {
            st.style.color = '#ff3355';
            st.textContent = 'Chave inválida. Digite a chave correta.';
          }
        });
      });
    }

    document.getElementById('li-gate-btn').onclick = autenticar;
    keyInput.onkeydown = (e) => { if (e.key === 'Enter') autenticar(); };
    emailInput.onkeydown = (e) => { if (e.key === 'Enter') keyInput.focus(); };
  }

  // ---------- SISTEMA DRAG & DROP ----------
  function aplicarDragLiveGo(el, handle, storageKey) {
    let sx = 0, sy = 0, ox = 0, oy = 0, moved = false, down = false;
    
    try {
      let p = localStorage.getItem(storageKey);
      if (p) {
        p = JSON.parse(p);
        let t = Math.max(0, Math.min(window.innerHeight - 60, p.t));
        let l = Math.max(0, Math.min(window.innerWidth - 60, p.l));
        el.style.top = t + 'px';
        el.style.left = l + 'px';
        el.style.right = 'auto';
      }
    } catch (e) {}

    handle.addEventListener('mousedown', function (ev) {
      if (ev.target.tagName === 'BUTTON' || ev.target.tagName === 'INPUT' || ev.target.tagName === 'SELECT' || ev.target.tagName === 'TEXTAREA' || ev.target.closest('button')) return;
      down = true;
      moved = false;
      sx = ev.clientX;
      sy = ev.clientY;
      const r = el.getBoundingClientRect();
      ox = r.left;
      oy = r.top;
      ev.preventDefault();
    });

    document.addEventListener('mousemove', function (ev) {
      if (!down) return;
      const dx = ev.clientX - sx;
      const dy = ev.clientY - sy;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) { moved = true; }
      if (moved) {
        el.style.left = Math.max(0, Math.min(window.innerWidth - 50, ox + dx)) + 'px';
        el.style.top = Math.max(0, Math.min(window.innerHeight - 50, oy + dy)) + 'px';
        el.style.right = 'auto';
      }
    });

    document.addEventListener('mouseup', function () {
      if (!down) return;
      down = false;
      if (moved) {
        try {
          const r = el.getBoundingClientRect();
          localStorage.setItem(storageKey, JSON.stringify({ t: Math.round(r.top), l: Math.round(r.left) }));
        } catch (e) {}
      }
    });
  }

  // ---------- INTERFACE FLUTUANTE COM 100% DE TODAS AS SEÇÕES ----------
  function criarUI() {
    if (document.getElementById('li-hub')) return;

    carregarAutoState(() => {
      const hub = document.createElement('div');
      hub.id = 'li-hub';
      hub.style.cssText = `
        position: fixed;
        top: 64px;
        right: 16px;
        z-index: 2147483646;
        background: #070a12;
        color: #fff;
        border: 1px solid rgba(255, 208, 0, 0.35);
        border-radius: 18px;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        box-shadow: 0 18px 50px rgba(0,0,0,0.9);
        width: 340px;
        max-height: 85vh;
        overflow-y: auto;
        user-select: none;
        scrollbar-width: none;
      `;

      hub.innerHTML = `
        <div id="li-head" style="position:sticky;top:0;z-index:10;display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#0d111d;cursor:move;border-bottom:1px solid rgba(255,208,0,0.2);">
          <div style="display:flex;align-items:center;gap:8px;pointer-events:none;">
            <span style="font-size:16px;">♾️</span>
            <div>
              <div style="font-size:12px;font-weight:900;letter-spacing:.5px;">
                <span style="color:#ff1717;">LIVE</span> <span style="color:#ffd000;">INFINITY v${VERSAO}</span>
              </div>
              <div style="font-size:9px;color:rgba(255,255,255,0.5);">Painel Completo de Automações</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <span id="li-badge" style="font-size:9px;font-weight:800;padding:3px 8px;border-radius:10px;background:${autoState.masterAtivo ? 'rgba(255,208,0,0.15)' : 'rgba(255,255,255,0.06)'};color:${autoState.masterAtivo ? '#ffd000' : '#888'};">${autoState.masterAtivo ? '● ATIVO' : 'INATIVO'}</span>
            <button id="li-btn-cfg" title="Configurações & Licença" style="width:28px;height:28px;border-radius:8px;border:1px solid rgba(255,208,0,0.2);background:#141928;color:#ffd000;cursor:pointer;font-size:13px;">⚙️</button>
            <button id="li-btn-min" title="Esconder em Bolha Flutuante" style="width:28px;height:28px;border-radius:8px;border:1px solid rgba(255,23,23,0.3);background:#141928;color:#ff3355;cursor:pointer;font-size:14px;font-weight:bold;">−</button>
          </div>
        </div>

        <div id="li-body" style="padding:10px 12px 14px;">
          
          <!-- BOTÕES DUPOS: INICIAR TUDO / ENCERRAR TUDO -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px;">
            <button id="btnIniciarTudo" style="padding:12px 6px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000,#ffaa00);color:#000;font-weight:900;font-size:11px;cursor:pointer;box-shadow:0 4px 18px rgba(255,208,0,0.3);letter-spacing:.3px;">🚀 INICIAR TUDO</button>
            <button id="btnEncerrarTudo" style="padding:12px 6px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:11px;cursor:pointer;box-shadow:0 4px 18px rgba(255,23,23,0.3);letter-spacing:.3px;">🛑 ENCERRAR TUDO</button>
          </div>

          <!-- PAINEL DE MÉTRICAS DA LIVE -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px;">
            <div style="background:rgba(255,208,0,0.03);border:1px solid rgba(255,208,0,0.15);border-radius:10px;padding:8px;text-align:center;">
              <span style="font-size:8px;color:rgba(255,255,255,0.5);text-transform:uppercase;font-weight:700;">VENDAS CONFIRMADAS</span>
              <div id="metricVendas" style="font-size:16px;font-weight:900;color:#fff;">—</div>
            </div>
            <div style="background:rgba(255,208,0,0.03);border:1px solid rgba(255,208,0,0.15);border-radius:10px;padding:8px;text-align:center;">
              <span style="font-size:8px;color:rgba(255,208,0,0.5);text-transform:uppercase;font-weight:700;">FATURAMENTO (GMV)</span>
              <div id="metricGmv" style="font-size:16px;font-weight:900;color:#ffd000;">—</div>
            </div>
          </div>

          <!-- SEÇÃO 1: REFIXAR PRODUTO & BLOQUEAR CUPOM OBRIGATÓRIO -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>📌 REFIXAR PRODUTO & BLOQUEAR CUPOM</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▾</span>
            </div>
            <div class="li-sec-b" style="margin-top:6px;">
              <button id="btnFixarAgora" style="width:100%;padding:8px;border:1px solid rgba(255,208,0,0.3);border-radius:8px;background:rgba(255,208,0,0.1);color:#ffd000;font-weight:800;font-size:10px;cursor:pointer;margin-bottom:6px;">📌 Fixar Produto Principal Agora</button>
              
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;background:rgba(255,23,23,0.08);border:1px solid rgba(255,23,23,0.25);border-radius:6px;padding:6px;">
                <span style="font-size:9px;color:#ff3355;font-weight:800;">🚫 Bloquear Cupons (Pula 1º item se for brinde/cupom):</span>
                <input type="checkbox" id="togCupom" checked style="accent-color:#ff1717;">
              </div>

              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
                <span style="font-size:9px;color:rgba(255,255,255,0.7);">Intervalo de Refixação (segundos):</span>
                <input id="rf-intervalo" type="number" value="40" style="width:60px;padding:4px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;text-align:center;">
              </div>

              <button id="rf-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rfAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rfAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rfAtivo ? '⏸ PARAR REFIXAÇÃO' : '▶ INICIAR REFIXAÇÃO AUTOMÁTICA'}</button>
              <div id="rf-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rfAtivo ? '🟢 Refixação automática ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 2: DUPLICAR OFERTA RELÂMPAGO -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>⚡ DUPLICAR OFERTA RELÂMPAGO</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <div style="font-size:9px;color:rgba(255,255,255,0.5);margin-bottom:6px;">Quando a Oferta relâmpago da LIVE encerrar, duplica e reinicia sozinho.</div>
              <button id="rd-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rdAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rdAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rdAtivo ? '⏸ PARAR OFERTA RELÂMPAGO' : '▶ INICIAR OFERTA RELÂMPAGO'}</button>
              <div id="rd-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rdAtivo ? '🟢 Oferta relâmpago ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 3: COMENTÁRIOS AUTOMÁTICOS -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>💬 COMENTÁRIOS AUTOMÁTICOS</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <label style="font-size:9px;color:rgba(255,255,255,0.5);">Mensagens rotativas (uma por linha):</label>
              <textarea id="rc-msgs" rows="3" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">🛒 Toque no carrinho pra garantir a oferta!\n🔥 Frete grátis liberado hoje!\n💥 Últimas unidades com desconto!</textarea>
              <label style="font-size:9px;color:rgba(255,255,255,0.5);">Intervalo (segundos):</label>
              <input id="rc-int" type="number" value="60" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">
              <button id="rc-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rcAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rcAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rcAtivo ? '⏸ PARAR COMENTÁRIOS' : '▶ INICIAR COMENTÁRIOS'}</button>
              <div id="rc-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rcAtivo ? '🟢 Comentários ativos!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 4: RESPOSTAS AUTOMÁTICAS NO CHAT -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🤖 RESPOSTAS AUTOMÁTICAS NO CHAT</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <label style="font-size:9px;color:rgba(255,255,255,0.5);">Regras (palavras = resposta, uma por linha):</label>
              <textarea id="ra-regras" rows="3" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">frete = Sim! O frete é grátis pra todo o Brasil! 🚚\ncomprei = Parabéns pela compra!</textarea>
              <label style="display:flex;align-items:center;gap:6px;font-size:9px;color:rgba(255,255,255,0.7);margin-bottom:6px;">
                <input id="ra-mencao" type="checkbox" checked style="accent-color:#ffd000;">
                Mencionar @pessoa na resposta
              </label>
              <button id="ra-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.raAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.raAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.raAtivo ? '⏸ PARAR RESPOSTAS' : '▶ INICIAR RESPOSTAS AUTOMÁTICAS'}</button>
              <div id="ra-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.raAtivo ? '🟢 Respostas ativas!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 5: INTENÇÃO DE COMPRA -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🛒 INTENÇÃO DE COMPRA</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <textarea id="ic-cart" rows="2" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">garante o seu, finaliza a compra! 🛒</textarea>
              <button id="ic-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.icAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.icAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.icAtivo ? '⏸ PARAR INTENÇÃO' : '▶ INICIAR INTENÇÃO DE COMPRA'}</button>
              <div id="ic-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.icAtivo ? '🟢 Intenção de compra ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 6: BLOQUEIO POR NOME / HATERS -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🚫 BLOQUEIO POR NOME / HATERS</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <textarea id="bn-palavras" rows="2" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:9px;margin-top:2px;margin-bottom:6px;">recomenda\nachadinhos\nindica</textarea>
              <button id="bn-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.bnAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.bnAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.bnAtivo ? '⏸ PARAR BLOQUEIO' : '▶ INICIAR BLOQUEIO POR NOME'}</button>
              <div id="bn-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.bnAtivo ? '🟢 Bloqueio por nome ativo!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 7: PROTEÇÃO CONTRA VIOLAÇÃO / ESCUDO ANTI-BAN -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>🛡️ PROTEÇÃO CONTRA VIOLAÇÃO</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <button id="rv-botao" style="width:100%;padding:8px;border:none;border-radius:8px;background:${autoState.rvAtivo ? '#ff1717' : 'linear-gradient(135deg,#ffd000,#ffaa00)'};color:${autoState.rvAtivo ? '#fff' : '#000'};font-weight:800;font-size:10px;cursor:pointer;">${autoState.rvAtivo ? '⏸ DESATIVAR PROTEÇÃO' : '▶ ATIVAR PROTEÇÃO ANTI-BAN'}</button>
              <div id="rv-status" style="font-size:9px;color:rgba(255,255,255,0.4);margin-top:4px;text-align:center;">${autoState.rvAtivo ? '🟢 Proteção anti-ban ativa!' : 'Desligado.'}</div>
            </div>
          </div>

          <!-- SEÇÃO 8: TIMER DE ENCERRAMENTO -->
          <div class="li-sec" style="border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;padding-bottom:10px;">
            <div class="li-sec-h" style="padding:8px 4px;font-weight:700;font-size:11px;color:#ffd000;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
              <span>⏱️ TIMER DE ENCERRAMENTO</span>
              <span style="font-size:10px;color:rgba(255,255,255,0.4);">▸</span>
            </div>
            <div class="li-sec-b" style="display:none;margin-top:6px;">
              <div style="text-align:center;font-family:monospace;font-size:24px;font-weight:bold;letter-spacing:2px;color:#ffd000;background:#03050a;border:1px solid rgba(255,208,0,0.3);border-radius:10px;padding:8px;margin-bottom:6px;" id="rt-restante">--:--:--</div>
              <input id="rt-min" type="number" value="120" style="width:100%;box-sizing:border-box;padding:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:6px;color:#fff;font-size:10px;margin-bottom:6px;">
              <button id="rt-armar" style="width:100%;padding:8px;border:none;border-radius:8px;background:linear-gradient(135deg,#ffd000,#ffaa00);color:#000;font-weight:800;font-size:10px;cursor:pointer;">▶ INICIAR TIMER</button>
            </div>
          </div>

          <!-- LOG DE STATUS GERAL -->
          <div id="lic-status-log" style="margin-top:6px;font-size:9px;color:rgba(255,255,255,0.6);text-align:center;padding:6px;border-radius:6px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,208,0,0.1);">
            Live Infinity v${VERSAO} — 100% dos Recursos Ativos
          </div>
        </div>
      `;

      document.documentElement.appendChild(hub);

      // BOLHA FLUTUANTE
      const bolha = document.createElement('div');
      bolha.id = 'li-bolha';
      bolha.title = 'Live Infinity (Clique para reabrir)';
      bolha.style.cssText = `
        position: fixed;
        top: 64px;
        right: 16px;
        z-index: 2147483647;
        width: 52px;
        height: 52px;
        border-radius: 50%;
        background: #070a14;
        border: 2px solid #ffd000;
        box-shadow: 0 10px 25px rgba(0,0,0,0.9);
        display: none;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 22px;
        user-select: none;
      `;
      bolha.innerHTML = '♾️';
      document.documentElement.appendChild(bolha);

      // ARRASTAR & ACCORDIONS
      const head = document.getElementById('li-head');
      aplicarDragLiveGo(hub, head, 'liveinfinity-pos-hub');
      aplicarDragLiveGo(bolha, bolha, 'liveinfinity-pos-bolha');

      document.getElementById('li-btn-min').onclick = () => { hub.style.display = 'none'; bolha.style.display = 'flex'; };
      bolha.onclick = () => { hub.style.display = 'block'; bolha.style.display = 'none'; };

      Array.from(hub.querySelectorAll('.li-sec-h')).forEach((h) => {
        h.onclick = () => {
          const body = h.nextElementSibling;
          const arrow = h.querySelector('span:last-child');
          const fechado = body.style.display === 'none';
          body.style.display = fechado ? 'block' : 'none';
          if (arrow) arrow.innerText = fechado ? '▾' : '▸';
        };
      });

      // CONEXÃO COMPLETA DOS EVENTOS DE CLIQUE COM AS FUNÇÕES DE DOM DO CONTENT.JS
      document.getElementById('btnFixarAgora').onclick = () => { if (window.cicloRefixar) window.cicloRefixar(); };

      document.getElementById('rf-botao').onclick = () => {
        autoState.rfAtivo = !autoState.rfAtivo;
        salvarAutoState();
        if (autoState.rfAtivo) { if (window.ligaRefixar) window.ligaRefixar(); }
        else { if (window.desligaRefixar) window.desligaRefixar(); }
      };

      document.getElementById('rd-botao').onclick = () => {
        autoState.rdAtivo = !autoState.rdAtivo;
        salvarAutoState();
        if (autoState.rdAtivo) { if (window.ligaOfertaRelampago) window.ligaOfertaRelampago(); }
        else { if (window.desligaOfertaRelampago) window.desligaOfertaRelampago(); }
      };

      document.getElementById('rc-botao').onclick = () => {
        autoState.rcAtivo = !autoState.rcAtivo;
        salvarAutoState();
        if (autoState.rcAtivo) { if (window.ligaComentarios) window.ligaComentarios(); }
        else { if (window.desligaComentarios) window.desligaComentarios(); }
      };

      document.getElementById('ra-botao').onclick = () => {
        autoState.raAtivo = !autoState.raAtivo;
        salvarAutoState();
        if (autoState.raAtivo) { if (window.ligaRespostasChat) window.ligaRespostasChat(); }
        else { if (window.desligaRespostasChat) window.desligaRespostasChat(); }
      };

      document.getElementById('ic-botao').onclick = () => {
        autoState.icAtivo = !autoState.icAtivo;
        salvarAutoState();
        if (autoState.icAtivo) { if (window.ligaIntencaoCompra) window.ligaIntencaoCompra(); }
        else { if (window.desligaIntencaoCompra) window.desligaIntencaoCompra(); }
      };

      document.getElementById('bn-botao').onclick = () => {
        autoState.bnAtivo = !autoState.bnAtivo;
        salvarAutoState();
        if (autoState.bnAtivo) { if (window.ligaBloqueioNome) window.ligaBloqueioNome(); }
        else { if (window.desligaBloqueioNome) window.desligaBloqueioNome(); }
      };

      document.getElementById('rv-botao').onclick = () => {
        autoState.rvAtivo = !autoState.rvAtivo;
        salvarAutoState();
        if (autoState.rvAtivo) { if (window.ligaViolacaoAntiBan) window.ligaViolacaoAntiBan(); }
        else { if (window.desligaViolacaoAntiBan) window.desligaViolacaoAntiBan(); }
      };

      document.getElementById('rt-armar').onclick = () => {
        if (window.armarTimerEncerramento) window.armarTimerEncerramento();
      };

      document.getElementById('btnIniciarTudo').onclick = () => {
        autoState.masterAtivo = true;
        autoState.rfAtivo = true;
        autoState.rdAtivo = true;
        autoState.rcAtivo = true;
        autoState.raAtivo = true;
        autoState.icAtivo = true;
        autoState.bnAtivo = true;
        autoState.rvAtivo = true;
        salvarAutoState();

        if (window.ligaRefixar) window.ligaRefixar();
        if (window.ligaOfertaRelampago) window.ligaOfertaRelampago();
        if (window.ligaComentarios) window.ligaComentarios();
        if (window.ligaRespostasChat) window.ligaRespostasChat();
        if (window.ligaIntencaoCompra) window.ligaIntencaoCompra();
        if (window.ligaBloqueioNome) window.ligaBloqueioNome();
        if (window.ligaViolacaoAntiBan) window.ligaViolacaoAntiBan();
      };

      document.getElementById('btnEncerrarTudo').onclick = () => {
        autoState.masterAtivo = false;
        autoState.rfAtivo = false;
        autoState.rdAtivo = false;
        autoState.rcAtivo = false;
        autoState.raAtivo = false;
        autoState.icAtivo = false;
        autoState.bnAtivo = false;
        autoState.rvAtivo = false;
        salvarAutoState();

        if (window.desligaRefixar) window.desligaRefixar();
        if (window.desligaOfertaRelampago) window.desligaOfertaRelampago();
        if (window.desligaComentarios) window.desligaComentarios();
        if (window.desligaRespostasChat) window.desligaRespostasChat();
        if (window.desligaIntencaoCompra) window.desligaIntencaoCompra();
        if (window.desligaBloqueioNome) window.desligaBloqueioNome();
        if (window.desligaViolacaoAntiBan) window.desligaViolacaoAntiBan();
      };

    });
  }

  function statusUI(msg) {
    const log = document.getElementById('lic-status-log');
    if (log) log.innerText = msg;
  }

  function iniciarInterfaceGeral() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', criarUI);
    } else {
      criarUI();
    }
  }

  // BOOTSTRAP DE AUTENTICAÇÃO E INICIALIZAÇÃO
  function boot() {
    getLicenca(function (lic) {
      if (!lic || !lic.key || lic.version !== VERSAO) {
        mostrarLoginGate('');
        return;
      }
      const dev = getDevice(lic);
      validarChave(lic.email, lic.key, dev, function (ok, reason, offline, data) {
        if (ok) {
          iniciarInterfaceGeral();
        } else {
          mostrarLoginGate(reason);
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
