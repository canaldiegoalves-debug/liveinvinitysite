/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "6b0476011a4f8cb6";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "86f52eec62bd7ba3";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "bf96098d03e0e48a";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "9a7eee6f3e1b126d";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
'use strict';
/* Live Infinity v8.2.0 — Background Service Worker
   Fora do TikTok Shop: abre o Gerenciador de LIVE.
   Dentro do TikTok Shop: mostra o painel flutuante da extensão. */
var TTLF_URL = 'https://shop.tiktok.com/streamer/live/product/dashboard';

function ehTikTok(url) {
  return typeof url === 'string' && url.indexOf('https://shop.tiktok.com') === 0;
}

/* Alerta de vendas: envia notificação via ntfy.sh */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === 'ttlf-ntfy') {
    var canal = (msg.canal || '').trim();
    if (!canal) { sendResponse({ ok: false }); return; }
    fetch('https://ntfy.sh', {
      method: 'POST',
      body: JSON.stringify({
        topic: canal,
        title: msg.titulo || 'Live Infinity',
        message: msg.corpo || '',
        tags: (msg.tags || 'bell').split(','),
        priority: 5
      })
    }).then(function (r) { sendResponse({ ok: r.ok }); })
      .catch(function () { sendResponse({ ok: false }); });
    return true;
  }
});

chrome.action.onClicked.addListener(function (tab) {
  try {
    if (tab && ehTikTok(tab.url)) {
      chrome.tabs.sendMessage(tab.id, { type: 'ttlf-show' }, function () {
        if (chrome.runtime.lastError) { /* aba ainda sem content script */ }
      });
      return;
    }
    chrome.tabs.query({ url: 'https://shop.tiktok.com/*' }, function (tabs) {
      if (tabs && tabs.length) {
        var t = tabs[0];
        chrome.tabs.update(t.id, { active: true });
        if (t.windowId != null) { chrome.windows.update(t.windowId, { focused: true }); }
        chrome.tabs.sendMessage(t.id, { type: 'ttlf-show' }, function () {
          if (chrome.runtime.lastError) { /* ignora */ }
        });
      } else {
        chrome.tabs.create({ url: TTLF_URL });
      }
    });
  } catch (e) {
    chrome.tabs.create({ url: TTLF_URL });
  }
});
