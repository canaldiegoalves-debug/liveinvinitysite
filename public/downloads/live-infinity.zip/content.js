/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "e1657f86a0428093";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "7ec07b564008c8b7";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "90a6d478d9909e1b";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "6ee03d5dd850410a";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
'use strict';
/* ============================================================================
   ♾️ LIVE INFINITY v10.0.0 — ÁUDIO CRISTALINO SEM PICOTAMENTO,
   GMV, MÍDIA/VB-CABLE COMPLETO, DRIVER DOWNLOAD, SOUNDBOARD FX, 
   BLOQUEIO OBRIGATÓRIO DE CUPOM E AUTO-PROTEÇÃO DE LIVE ON-AIR
   ============================================================================ */

var TTLF_API = 'https://licencas.liveinfinity.online';
var TTLF_GRACE = 72 * 3600 * 1000;
window.ttlfLogArr = window.ttlfLogArr || [];
window.ttlfAudioHistory = window.ttlfAudioHistory || [];

function ttlfNow() { return new Date().toTimeString().slice(0, 8); }

function ttlfLog(msg) {
  var line = '[' + ttlfNow() + '] ' + msg;
  window.ttlfLogArr.push(line);
  if (window.ttlfLogArr.length > 400) { window.ttlfLogArr.shift(); }
  var box = document.getElementById('ttlf-log-box');
  if (box) { box.textContent = window.ttlfLogArr.join('\n'); box.scrollTop = box.scrollHeight; }
}

var TTLF_LOG_LABELS = {
  'rt-status': 'Timer',
  'rf-status': 'Refixar',
  'rd-status': 'Oferta',
  'rc-status': 'Coment.',
  'ra-status': 'Respostas',
  'rv-status': 'Proteção',
  'bn-status': 'Bloqueio',
  'ic-status': 'Intenção',
  'nv-status': 'Venda',
  'md-status': 'Mídia'
};

function ttlfLogWatch() {
  if (window.ttlfLogTimer) { return; }
  var last = {};
  window.ttlfLogTimer = setInterval(function () {
    for (var id in TTLF_LOG_LABELS) {
      var e = document.getElementById(id);
      if (!e) { continue; }
      var t = (e.textContent || '').trim();
      if (!t) { continue; }
      if (last[id] === undefined) { last[id] = t; continue; }
      if (t !== last[id]) { last[id] = t; ttlfLog('[' + TTLF_LOG_LABELS[id] + '] ' + t); }
    }
    try { ttlfUpdStatus(); } catch (e) {}
    try { ttlfUpdPower(); } catch (e) {}
    try { ttlfScanStats(); } catch (e) {}
  }, 1200);
}

function ttlfLiveNoAr() {
  try {
    var els = document.querySelectorAll('div,span,p,b,strong');
    for (var i = 0; i < els.length; i++) {
      var e = els[i];
      if (e.children.length !== 0) { continue; }
      var t = (e.textContent || '').trim();
      if (!/^\d{1,2}:\d{2}:\d{2}$/.test(t)) { continue; }
      var r = e.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) { continue; }
      var p = e, dentro = false;
      while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { dentro = true; break; } p = p.parentElement; }
      if (dentro) { continue; }
      return true;
    }
  } catch (e) {}
  return false;
}

/* LEITOR AUTOMÁTICO E RIGOROSO DE GMV E VENDAS REALIZADAS DO TIKTOK SHOP */
function ttlfScanStats() {
  var vEl = document.getElementById('ttlf-stat-vendas');
  var gEl = document.getElementById('ttlf-stat-gmv');
  if (!vEl || !gEl) return;

  var totalVendas = 0;
  var totalGMV = 0.00;
  var encontrouLiveCard = false;

  try {
    var allCards = document.querySelectorAll('div, section, article');
    for (var c = 0; c < allCards.length; c++) {
      var cardText = (allCards[c].textContent || '');
      if (/(Análise da transmissão|Análise da live|Desempenho da transmissão|Live Stream Analytics)/i.test(cardText)) {
        encontrouLiveCard = true;

        var mGmv = cardText.match(/R$s?([d.,]+)/);
        if (mGmv) {
          var valG = parseFloat(mGmv[1].replace(/\./g, '').replace(',', '.'));
          if (!isNaN(valG) && valG >= 0) {
            totalGMV = valG;
          }
        }

        var mVnd = cardText.match(/(?:Pedidos|Vendas|Produtos vendidos|Itens pagos)\s*[:\s]*(\d+)/i);
        if (!mVnd) {
          mVnd = cardText.match(/(\d+)\s*(?:pedidos|vendas|unidades)/i);
        }
        if (mVnd) {
          var valV = parseInt(mVnd[1], 10);
          if (!isNaN(valV) && valV >= 0) {
            totalVendas = valV;
          }
        }
        break;
      }
    }

    if (!encontrouLiveCard) {
      totalVendas = window.ttlfTotalVendasContadas || 0;
      totalGMV = window.ttlfTotalGMVContado || 0.00;
    } else {
      if (window.ttlfTotalVendasContadas !== undefined) {
        totalVendas = Math.max(totalVendas, window.ttlfTotalVendasContadas);
      }
      if (window.ttlfTotalGMVContado !== undefined) {
        totalGMV = Math.max(totalGMV, window.ttlfTotalGMVContado);
      }
    }
  } catch (e) {}

  vEl.textContent = totalVendas;
  gEl.textContent = 'R$ ' + totalGMV.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function ttlfTipEl() {
  var t = document.getElementById('ttlf-tip');
  if (t) { return t; }
  t = document.createElement('div');
  t.id = 'ttlf-tip';
  t.style.cssText = 'position:fixed;z-index:2147483647;display:none;pointer-events:none;background:#070a12;color:#ffd000;border:1px solid rgba(255,208,0,0.4);border-radius:8px;padding:5px 9px;font:600 11px/1.2 -apple-system,Segoe UI,Roboto,Arial,sans-serif;white-space:nowrap;box-shadow:0 4px 14px rgba(0,0,0,.85)';
  document.body.appendChild(t);
  return t;
}

function ttlfTipHide() { var t = document.getElementById('ttlf-tip'); if (t) { t.style.display = 'none'; } }

function ttlfTipBind(el) {
  if (!el || el.getAttribute('data-tipbind')) { return; }
  try { el.setAttribute('data-tipbind', '1'); } catch (e) {}
  el.addEventListener('mouseenter', function () {
    var tx = el.getAttribute('data-tip') || '';
    if (!tx) { return; }
    var t = ttlfTipEl();
    t.textContent = tx;
    t.style.display = 'block';
    t.style.left = '-9999px'; t.style.top = '-9999px';
    var r = el.getBoundingClientRect();
    var tr = t.getBoundingClientRect();
    var left = r.left + r.width / 2 - tr.width / 2;
    if (left < 6) { left = 6; }
    if (left + tr.width > window.innerWidth - 6) { left = window.innerWidth - 6 - tr.width; }
    var top = r.bottom + 6;
    if (top + tr.height > window.innerHeight - 6) { top = r.top - tr.height - 6; }
    t.style.left = left + 'px';
    t.style.top = top + 'px';
  });
  el.addEventListener('mouseleave', ttlfTipHide);
  el.addEventListener('mousedown', ttlfTipHide);
}

function ttlfUpdPower() {
  var pw = document.getElementById('ttlf-power'); if (!pw) { return; }
  ['ttlf-cfg', 'ttlf-power', 'ttlf-min'].forEach(function (bid) {
    var be = document.getElementById(bid);
    if (!be) { return; }
    ttlfTipBind(be);
    try { be.removeAttribute('title'); } catch (e) {}
  });
  var no = ttlfLiveNoAr();
  if (no === window.ttlfPwState) { return; }
  window.ttlfPwState = no;
  if (no) {
    pw.style.borderColor = '#ff1717';
    pw.style.background = 'rgba(255,23,23,.2)';
    pw.style.color = '#ff3355';
    pw.setAttribute('data-tip', 'Encerrar a LIVE agora');

    try {
      var cbRv = document.getElementById('rv-ativo');
      if (cbRv && !cbRv.checked) {
        cbRv.checked = true;
        cbRv.dispatchEvent(new Event('change', { bubbles: true }));
        var btnRv = document.getElementById('rv-botao');
        if (btnRv) {
          btnRv.textContent = '⏸ Desativar proteção';
          btnRv.style.background = '#ff1717';
        }
        ttlfLog('🛡️ LIVE entrou no ar! Proteção Anti-Ban ATIVADA AUTOMATICAMENTE ✅');
      }
    } catch (e) {}
  } else {
    pw.style.borderColor = 'rgba(255,208,0,0.3)';
    pw.style.background = '#141928';
    pw.style.color = '#ffd000';
    pw.setAttribute('data-tip', 'Nenhuma LIVE no ar');
  }
}

function ttlfUpdStatus() {
  var badge = document.getElementById('ttlf-status'); if (!badge) { return; }
  var ativo = false;
  ['rf-botao', 'rc-botao', 'ra-botao', 'rd-botao', 'bn-botao', 'ic-botao', 'nv-botao', 'rv-botao', 'md-vcable-btn'].forEach(function (id) {
    var b = document.getElementById(id);
    if (b && (b.textContent || '').indexOf('⏸') > -1) { ativo = true; }
  });
  var arm = document.getElementById('rt-armar');
  if (arm && arm.style.display === 'none') { ativo = true; }
  if (ativo) { badge.textContent = '● ATIVO'; badge.style.color = '#ffd000'; badge.style.background = 'rgba(255,208,0,.15)'; badge.style.borderColor = '#ffd000'; }
  else { badge.textContent = '● INATIVO'; badge.style.color = '#ff3355'; badge.style.background = 'rgba(255,23,23,.15)'; badge.style.borderColor = '#ff1717'; }
}

function ttlfStGet(cb) {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['liveinfinity_lic'], function (r) { cb(r && r.liveinfinity_lic ? r.liveinfinity_lic : null); });
      return;
    }
  } catch (e) {}
  try { var v = localStorage.getItem('liveinfinity_lic'); cb(v ? JSON.parse(v) : null); } catch (e) { cb(null); }
}

function ttlfStSet(lic) {
  try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) { chrome.storage.local.set({ liveinfinity_lic: lic }); } } catch (e) {}
  try { localStorage.setItem('liveinfinity_lic', JSON.stringify(lic)); } catch (e) {}
}

function ttlfDevice(lic) {
  if (lic && lic.device) { return lic.device; }
  return 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function ttlfValida(key, device, cb) {
  var k = (key || '').trim().toUpperCase();
  if (!k || k.length < 6) { cb(false, 'invalid', false, null); return; }

  fetch('https://api.valoranegocios.com.br/api/check', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: k, device: device })
  }).then(function(r) { return r.json(); }).then(function(data) {
    if (data && data.ok) {
      var cleanEm = (data.email || '').replace(/^(liveinfinity|livecam):/i, '').trim();
      var expMs = data.expiresAt ? new Date(data.expiresAt).getTime() : (Date.now() + 30 * 86400000);
      cb(true, 'ok', false, { email: cleanEm, exp: expMs });
    } else {
      cb(false, (data && data.reason) || 'invalid', false, null);
    }
  }).catch(function() {
    cb(true, 'ok', true, { email: 'afiliadodiegoalves@gmail.com', exp: Date.now() + 30 * 86400000 });
  });
}

function ttlfMsg(r) {
  if (!r) { return ''; }
  var m = { invalid: 'Chave inválida. Confira e tente de novo.', blocked: 'Assinatura inativa ou cancelada.', devices: 'Chave já em uso no máximo de dispositivos.', offline: 'Sem conexão com o servidor de licenças.', config: 'Extensão sem URL do servidor configurada.' };
  return m[r] || ('Erro: ' + r);
}

function ttlfFmtDate(ms) { if (!ms) { return '—'; } try { var d = new Date(ms); return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); } catch (e) { return '—'; } }

function ttlfRollExp(lic) { var now = Date.now(); if (!lic) { return lic; } if (!lic.activated) { lic.activated = now; } if (!lic.exp) { lic.exp = now + 30 * 86400000; } while (lic.exp && now >= lic.exp) { lic.exp += 30 * 86400000; } return lic; }

function ttlfCfgClose() {
  var hub = document.getElementById('ttlf-hub'); if (!hub) { return; }
  var p = document.getElementById('ttlf-cfg-panel'); if (p && p.parentNode) { p.parentNode.removeChild(p); }
  Array.prototype.slice.call(hub.querySelectorAll('[data-ttlf-disp]')).forEach(function (k) {
    k.style.display = k.getAttribute('data-ttlf-disp') || '';
    k.removeAttribute('data-ttlf-disp');
  });
}

function ttlfCfgPanel() {
  var hub = document.getElementById('ttlf-hub'); if (!hub) { return; }
  if (document.getElementById('ttlf-cfg-panel')) { ttlfCfgClose(); return; }
  ttlfStGet(function (lic) {
    lic = lic || {};
    var rawEm = (lic.email && lic.email !== 'cliente@email.com') ? lic.email : '';
    var email = rawEm.replace(/^(liveinfinity|livecam):/i, '').trim();
    var key = lic.key ? lic.key : '—';

    if (!email || email === 'cliente@email.com' || lic.email === 'cliente@email.com') {
      fetch('https://api.valoranegocios.com.br/api/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: key, device: lic.device || '' })
      }).then(function(r) { return r.json(); }).then(function(data) {
        if (data && data.email) {
          var realEmail = data.email.replace(/^(liveinfinity|livecam):/i, '').trim();
          lic.email = realEmail;
          ttlfStSet(lic);
          var elEm = document.querySelector('#ttlf-cfg-panel b');
          if (elEm) elEm.textContent = realEmail;
        }
      }).catch(function() {});
    }

    if (!email || email === 'cliente@email.com') {
      email = 'afiliadodiegoalves@gmail.com';
    }

    var venc = ttlfFmtDate(lic.exp);
    Array.prototype.slice.call(hub.children).forEach(function (k) {
      k.setAttribute('data-ttlf-disp', k.style.display || '');
      k.style.display = 'none';
    });
    var p = document.createElement('div');
    p.id = 'ttlf-cfg-panel';
    p.style.cssText = 'background:#070a12;border-radius:14px';
    p.innerHTML = '<div style="display:flex;align-items:center;padding:12px 14px;border-bottom:1px solid rgba(255,208,0,0.2)">' +
      '<div id="ttlf-cfg-back" style="cursor:pointer;font-size:22px;line-height:1;padding:0 10px 0 2px;color:#ffd000" title="Voltar">←</div>' +
      '<div style="font-weight:bold;font-size:14px;color:#fff">⚙️ Minha assinatura</div></div>' +
      '<div style="padding:14px 16px 18px">' +
      '<div style="background:#0d111d;border:1px solid rgba(255,208,0,0.25);border-radius:10px;padding:12px;font-size:12px;line-height:1.7;color:#fff">' +
      '<div><span style="color:rgba(255,255,255,0.6)">Status:</span> <b style="color:#ffd000">🟢 Ativa</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">E-mail de compra:</span><br><b style="word-break:break-all;color:#fff">' + email + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">Chave:</span><br><b style="font-family:monospace;color:#ffd000;word-break:break-all">' + key + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">Vence em:</span> <b style="color:#ff1717">' + venc + '</b></div>' +
      '</div>' +
      '<div style="color:#ffd000;font-size:10px;margin-top:10px;text-align:center">Renova automaticamente enquanto a assinatura estiver ativa.</div>' +
      '<div style="margin-top:16px;display:flex;align-items:center">' +
      '<div style="flex:1;font-weight:bold;font-size:12px;color:#fff">📋 Log de Eventos</div>' +
      '<div id="ttlf-log-clear" style="cursor:pointer;font-size:11px;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:6px;padding:3px 8px">Limpar</div>' +
      '</div>' +
      '<div style="color:rgba(255,255,255,0.5);font-size:10px;margin-top:2px">Registro em tempo real de todas as ações</div>' +
      '<div id="ttlf-log-box" style="margin-top:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:8px;padding:10px;font-family:monospace;font-size:10px;line-height:1.5;color:#ffd000;white-space:pre-wrap;word-break:break-word;height:150px;overflow:auto"></div>' +
      '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:11px;margin-top:12px">Live Infinity</div>' +
      '<button id="ttlf-cfg-voltar" style="width:100%;margin-top:14px;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:bold;font-size:13px;cursor:pointer">← Voltar para a extensão</button>' +
      '</div>';
    hub.appendChild(p);
    var b1 = document.getElementById('ttlf-cfg-back'); if (b1) { b1.addEventListener('click', ttlfCfgClose); }
    var b2 = document.getElementById('ttlf-cfg-voltar'); if (b2) { b2.addEventListener('click', ttlfCfgClose); }
    var lb = document.getElementById('ttlf-log-box'); if (lb) { lb.textContent = (window.ttlfLogArr || []).join('\n'); lb.scrollTop = lb.scrollHeight; }
    var lc = document.getElementById('ttlf-log-clear'); if (lc) { lc.addEventListener('click', function () { window.ttlfLogArr = []; var bx = document.getElementById('ttlf-log-box'); if (bx) { bx.textContent = ''; } }); }
  });
}

function ttlfShowUI() {
  var g = document.getElementById('ttlf-gate'); if (g) { g.style.display = 'flex'; return; }
  var h = document.getElementById('ttlf-hub'); var b = document.getElementById('ttlf-bolha');
  if (h) { h.style.display = 'block'; if (b) { b.style.display = 'none'; } return; }
  ttlfBoot();
}

function ttlfShowGate(reason) {
  if (!document.body) { setTimeout(function () { ttlfShowGate(reason); }, 1500); return; }
  var ex = document.getElementById('ttlf-gate');
  if (ex) { var s0 = document.getElementById('ttlf-gate-st'); if (s0) { s0.textContent = ttlfMsg(reason); } return; }
  var d = document.createElement('div');
  d.id = 'ttlf-gate';
  d.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(4,6,15,.9);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;font-family:sans-serif;font-size:13px;padding:16px;box-sizing:border-box';
  var WM = '<div style="display:flex;justify-content:center;margin-bottom:14px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAABwCAYAAADPC1QxAAAQAElEQVR4AXS8B6ClVXX3/V/PObfNnT70LgLSmyAgFuxGrNHE3ktsiYXXaNToq7GlWKIx8dUYjb2CYsTYRQULIiigMAMzA0zvc/u955xnf7//es65gybfvnvt1ddeuzz7KWegqqpWaQ2gZbpdWq0DYP0AIqJIKmNjY+Xggw8up59+ern//S8uFz/ggeVBD76kPPiSh5QHPeiS8sA/hgc+GJsHHYCLH1juf/EDykX3b+DCiy6Gvrjcn1gXXfSAcmHCxWDD/cHAhfcvF1x4Ubmf4QJo4H7A+Rcguyek/sJyv/tdUM6/34Xl/PMvKOcZzrug3Pe888t5wACfe+555dxz7ptwzrn3LYazzzm3JJx9bjnr7HPK2cBZZ51TzjjzrHL6GWeBzy5nJj6rnInsrLPOKmcB1hvONI3+9DPOxN5wRvE8ncZcnXbqaeWUU04tp5x6ajn55FPKKcCp0KecAo38jDPOKPe5z0nlyCOOKsuWrWAdhkpEq0RrqFR9aPWx+VZruLSBe8oqlVwjrxNLBZJ54z5EYFKAWkuXjuu000/TueeepxNOuI/aQ6Pas3eftmzZqo0b79L69Ru1YeOd0Hdq/YaNwIY+bETW8BvWWwZtW2w2ABvxse8d1q2/Q+sNd6zXHXfcARgD69cj36D1dwDob7/jdiXcfrvWrV2ntWvXJtx261rdargNfNutuu2223Tb2gZscyt2t2F/623rtHYdcDsAvi3ljgGP3rZrwbZfu26t1tHP7diu69Pr8FkL3Eac27Azn3ncij821q0l5lp0a9fdrsTEWEfe6+A9NsdcR8zbPbaNHtdG7dy+S1UVOvywQ3Xv44/VQQetESzzL0WwFoAWS1Fd6lyxUEjoKtoUeBkXgUUuBkl1XWt4ZFinnHq6zjr7vhpiEbdu3a7NmzZrz+7dmp2dpbOiVqv6Axhqt9SuGmi1WuhaGmq31bI8oa02csMQeLgN38YuMfRQW0NAG76F/o/BfgbHbGNnPNTChxhDQ/TVl2V/+LeRO1aDK7Xbzpf+0LWsw7cNPdQH22ZM+l+UQw+1h9TYt5r8232MX8tzQNwh7IaJZ9xAK8diehh/44w/RCzsWlXltVCv19X07Iy2bd+ujXfeqW07dmrp+LhOOvFEHbR6hQprkWekKCwWNf2Ua1VARURCHGoUubRSMqx2TQcHrV6tCy64UMuWLtPWrVu1jyuyqFZ7uCVPZKtqsaMqSSH1gfgEryXieWPAmIKlL0sbhAxmsUXoms42LXYzYaOEjIW9sc0gscEJAmtadqsViAY2ZlGknWUQuUmTTgWhsTcJpZoZIwokEXG2Xd3Hpg0o0xwLMM5NtThnADZp2xr+wL8eeDVWYQ+TBuiKefcG8rzOz83r7s2b8wQ8+JBDdK/jjlEVTAkxsgOago8ShKLIK9FnsUSGlFoYdE9HH32sTj/jLO3atUs7d+zALtRqt1VFCxtcy8AnPE/IBBQ3DBSUtUAjozoP5ialg6YQNS1QeOCWexJwUsGhWACgpnU/AwldpRHeKO0Dwga5Ccwsg8OqTrkbNrkEm7q0S0PRmczKYxqILIC2X8k8G8q+Btty4qk0AYlBLdjgV1thEq3wDccV+ijmIKjYZRzkjVkBGRpBVVVqA7Mz01q37g51uj2dcOIJebUXUWgIgU8TC4lYFU8SpDUg17ru6VgW87jj7qW7776bY3VOVZtFRIk13swINETT2pe1dSr0kTL3YtpgAeNgIFC2ZbAlZ9ZavLxwluOUAySWrxLPgXmDZ7vxaWIUYliWOdjXoawCCIPKAmLDp5rGtw9YORG6SJvGKqPQwGEnSuljx0pwg8xyQxDEGFP8qNbBWLYI6TPQERu960BPAlgckJsfQEqJibeCy7ICNnO17t23V/e+97011PZK2GoAUkSo8kSLYjGIK7PWoYcepmOOPVabN29SYbIdLJOwQXYCAfZ0NXJ7A+HuwVQyNYMhFTm9KRGskhL6IvefcWCzYkToJN3Aph2JEBLLeyhNGkS8zAOGih0utKZBciluEqAISpsqIqqQhLHVjmPvpGWpLRuJKYN1B8ASAqYA2iSIincKcb4Hl6Qb6zD2rjUJDKSJs0HI2JQg+b67k/vq/v37dOwxx4rAwB/WKm2Ja+wdvGzZMvEYrW3btjeWlVhkBtafnYIUTraPxWQIsEjbAjW7Rf1ywE6KCIUGJTissEdmSXaR2sJCFwkB+8kqIFJjmSc9os+jwVIR8ABOTGRKpKACciHWgFyMYYPU4YV+8Zjsu1tlkxwv+ggiWIfCstwIKbJwAMQiA/eR4AD4FeZnMe+oFIEjlUuKaFTcPU9FFjYxegzefaTI9sRtc1Lu2LFdC52ODjnoYBWfdEWY4Ad2ZHuLmZXP7JNOPll79uzVwvyChJn6xckUjrkcCIGNaztZ76DQgbwiqF9XrXcOdIMFXAGgamMgMnYjwwUNNaSCLgHWtYnVyAlvUYI3n71tK/KqkTqOZZCYmsMPSsQktFH22hfBY40uY+AU4REgw6CRmUdBDTwLExzQjoozqOTGs21hwQQ0NHLblaZpfEzbpagutUr+ISP3Aoj5s0yWJ19YawIQM0DZn81LUVQVF9xWrVy5XEuWjKLCE7njVA4QQeIIjjjiSI2Njmnfvn2qWs0rakGOmlAikZDXzjKDhTWdEw6yACH6pwMxUC0WQkBjBWErGKp5IzATlfFQhm0SajkQZGLmk9gYCKDiacrIZmlDGDDTh5MnIWM1YdIGDbhx9kapsXMQL5QDeZMYG5xPYWzBgA/42beQSgD6ozEyDhZFlABcjQt9GNyfZcWNwUQ/tohWAA2KJ7wwlOQd1wQCUGBXoa8Z7E5eGw85+GBl7ECpUC6oKC0u5WOOPka79+xhMdtI0oKoLFITCxqCBD0JzEzD9y0LK+nEC0ELsgQ30FlLnwE5xZrJsr1jGVs9wEEMywd+jRwvjKioCIKSzGgP1IZvdCSXKQZqA07wfR3IcRobGGzcB8hmCYs+CK2jdyh7GPW5NHJjaGSOZhCTbrzYj90cuRHIHo1okYK1R4NMZcRUm0PuCu8QFVfp5MSUWkMtrtIlg8S8oExDr2jNmoPU5kV3ZmaWBa0UgScBMijxHKSUnmoWoiYxREyQDZIiYFomRjqwADecW0ekN2zMgbiM0ou+jAcTZ2yLmv4KHTfQXGp51ZGDgJTTgzMQdgNIOUL3Ry8OJcEgwsQZQFFxVRZ0ETSLRilVRCOzaXrRh2P76jAu3sQEsV5McMA7P3unDH/EsCH7QyziRm9JjUxASshPFNMG+wX8H9UUWV9r3979WrN6FX51GlVyqCji26ympqeb8WMb1uAY1gtxQeiE4QOMqB+ksMhFvnnnYNLOtshMczR48DV0zZFUCznO2fZ19gtkWbEztk/Ql+kGPCV4hXMJ+rTUDLjpjnwgYCOQU7EW645tUc3x1oQmg+wX7FyiyH0ZiEwlBobm0STv/EQuaPAgsAQX6UcoiXHZxhE9TtmKGBhQ7YXGCMs+gupX5jL7WlQURUQCzuRNtALI/YGhCY9zYzM9NaXh4VFgGJlUFUbsx+EVK1drampGvpStyQnAs5AsyCIgRFwRlr7YEXQsBAHYprgRxYNBZt4LjYRKJh49ukLMkhgxtU6eeMhgM7ZJUiMifghtr3Lgvo4R1boGGC5WmZlqHG3v7vzlx1KRj3FNYOcUEXKBtfgeUDIurcQmSDcMHQ9ELXKMmswERNM9PjWmRRFN3DotsSiSw2CKjRL6DRZUm+PDuiLGGFFTUSBH6IrIOmQyOE7Dd3s9dXsdjYyMYFe8oEVLxsbkx+GFhQX3i6JubviNjxyXiOgQUE3LGajwR3ALmJliGfqS4IbOjRCA+rb4mLfAfgZoLE0BMLSOWlhoO91zMpP2LKbDwNYOKZDbcEsugdjQWBVCAWbQGaFuxmnC4LyMDWnQbBPMmZMUWKMIRyVDEBElcLhJEAUOc6eZokgRTVNRkYtpxzcHTScRkeaWZFwTgY5ApCYnmw9AGhQrpZmZGX44WYqw+B4qjS8ZVy4mO5s0M3nHMp09wzSudENwPEXf2EGhawhojH1VpAi6OB6Z4EUot9YkiQu8dYCHVdsRn6aicz90WrOomBywtwFdOZJ9DAWDMugLmh7SokDXXB7GRFTwVwUqqv1t574NppnTvqavta1JA74Zh5gkw9yWRSBF3Ev6uh/bwZApMmrFZNnN4RpA6Gohho09nvDOIXn0EVhTMaEiQO/TAUuykby4EaG5uTm1h9ryODhyi0bHRtVZ6HA01P3EJLT9PItqT5akiMpjIVFRQv4rcHjRQvUXxQnRNzYO1yRi3q8H1jETqXOwvPfgZ3mdmGhpbF/McIeC6NccMRJsIyKF9rUZGRCykC96NIWsQMjgidnYWVrUvI54CtBhZJ3NCzQDk8Ey87gqj2kJsSVqiklSMCLr7MfjafwsxQxn8zgyn+4bB5hsaVDLUmcRYYHkvWyfms3ooEjxwALjRdpedBER6nQWrESi5gptDw/z4beTwpRiWAjm5MzDoqsJWgD9jxJI6EuF4E7O4EScVA9FXZi4Qoi+HSPrM0YokEc4inIxCCQhtn+CGWwSEc+yZKGNbWyZWUPyaYyWOBmZ+LapawQALSlmpmA87JhCaPSNOzRy+zmxxIS0g03vORnWNYABfeWquGOAEARCnk41oekXYaEf+6D5g5pmSHwFgrIO7IwHeqKkrmatWlUlP//wLKvMq9erJSgbLYI7JSHErAFS+GSJCJeJ0TTJioKe2vAQ7sj6QRK4MRf2lEPKBTOjxgfKWgPkogwnKhPBSeFYjYJoOBfL0rhpfCUV5DhQicR2p8UFeyeDGfsLnUWOCbYswTYQVMcwpCG8yDgAh8h4EO5GWewXUGxcbHwh0C2BsUTl9c04mCSNjRKUV1RoUGyPw4DF5oBOiogG+n3DySVyQJL5XFAn1uwWD9DgwMpFDMe3gSjQHiRa8iu5CZGqIYpER8JLYNuIBIw9TDHxIg4VNVICe/LDXgiRmEJHNW974uTkWJMy92E9YBmAidyl88oNhCwUUn+QiZEhyNaNo7i/YjsVRCWpxqbAN5Tz7VOLMmuJjsoUUchLTmAxjuVCbygZ17lhacGiHEZMD16O1kCGoifPl8HG9m3mwDYoqQVwtU4KDo8C+IJUbhBiFwKDBGDtwAZhbE2IgtyvACD3g0YEQYthbgbiZcc2yGj49GttG9Pg6Ovs40BEkAdmeZNgGrrB0lr3I5s2MjYCHBUd8Ti1mM6aXEjAHgh6HEF1f0MUcMGOSozGB4I+PapQENUAStqYMOzRHIgyt0GfKG2bPaHOmBgb4yChpAdLyKeYTVqUJge0aQzuawrZMxhbAFIEQdQvpgFHKhaxSfvu2CmhML7GXxKueYWaSFBTAiZMpjfm4AyYMngwIlpoFAO6hoD1fKFjieCTcSJICIsDFXkBlAJlSR5naroIH4N5CzKfxrJpU0GsnBBEbJ+GpAAAEABJREFUOXDlvFpqH1HSz33ZPsENFsgKv/uqYRN5oXBpKo6+h9VsEEwbGYTNI0JUBdLIVrSmrBWlyHqIrDm2pCJbgSJoGu7/ty19TYMLQzJl6CsS/WGcZkGtINlENKX/yY0I7LQ6B2vac0dYSGTYO1GWDQ9PhTsCqCLZmp2TG1t02FTssIaGsDRje8IMhFMKk2DC6cx9ZefEc9jBCVHbBkHTvwMmI3v16Dd9kqMhaADWOV5YxCI5t+Z1Aql5yzMMPAEcu7Cp6BoNsgIgV8Zv6GyRR2RUtCGTiPChx0iUTch/SUKBsy9wYJc0DRGQ0DJPSbgHyTFFMWcrCSc1frIScL6I+kculE0iIvVuIJE21YGkkIsDBrQD+Ig19gCMxQTYtnDkBca2BWXP1htkY9kKjQ3Mg6moCpHtic5UMXZzwL70J9+SBPypGdE4ou8P4/68+E0EKaKZqFDIpZFnlMzRV6TlBtwzH6VtY9+QxEilshAy7dxXMx8pbho6oKZb0xQ19nRHSNPBnKWxmYKc2CZTJozg6UCWRYSqqKCdgyTU1skFO7OV6QgM4KjY0FKJLSEXHUYyzcBNN1RRjyBKXZNIypF5cAakXGc1JlzByJvOsUofGsvkAt1HaKFo0TXShk5fZKQGiQYagtronZd1xu6XIOjEENCTgZkmJ7QYWSpKRCjA5h0SbXI0ssI+hpRjYLsDCw+HjBCENy3MmtzsY0BBRYfK1RvS2IuPMWShG4A4BU7moJWlkWSbDR7oCqeEc/awBmbMsFgq5YKm8B6NjZ10pkEAEayAnUwhmLgCyRIPNkIqIakFG7OQqPGGd+JBkveUkRZ6JGFwDCTY0g2Cxg8JNJsBYcaFK2RcHKugLTSmkWefsLZbBIQZGTnWtkq4pz5D0NgERE7uGzML8EfQZyxPYYYq5GHCkoTiti/x6gIROTj8LQfZJkU0jXlfYWSBQUo3HShYK4WpcB6eE7Dz64M5R7FtLqiJAwNtHDjZbINL4SpLMmkzzs32MpPSxgeS2iRGFmpKTmtD9lv7RzTyZpPYx1momUNBM2nFYB+zxo7Og4z7Lqa9ucACGh5/aBG7b57xuCBh3QfItUCzpQv+UCK8qipkNwPd2uoeEKl3aFGK/YU9zo5doBFnbXQmi/pPaHKBk8cq+4bz9PgBaOFfANF5+tvGuSVgC64B6yICs9A9S6j5c365oAWtE4tFHOQSREKQFQuqHZoHE5jsVKrBBnfm90phVOhcwYz1fUnb0uTUn62CnwdY+pvCJ0LjW+S/GrkxPeUcWGcgK5G/a4KVhMJHB4r7R2J/xg+FJ4GojY2FGQgWIZUwzhcqg4FR2QxEP0RCTkss63BOHq2NoKGyolEEI8YsFCmr4H1SCWyIsBwDxmgqwSzR0yFYlgRrirw2jarhGY1kUv1impgFFk/avtaTXHvC0TSLI4KZaYaCT1oGbURYqQyOiVl36hgIEXtQ+KFLGdj61NFYFsSRT32czWMtSAX6ewIsE26tKeISyNNfg+2HUuwslAVfPD0GOJhUYWZOZjz3BphGhtIxfBcxmLZdoyyY0QsOVEWE/IcQdQCmCjItgqlBptbiosVSlHaD+BHEcGBRvGrooagNEbbGpuEkSEkhGRCaUr80Onk2+xIQNuRQmBuoGvBgkasfAFZZ3LmhYayFCqAoIhJgFrFpQ3GART+6gs4rs1gLDDCkTY08+IDwMprOGLbzRBhbZwOwF6P21Ulc2H61R9+QoI5jKF50cjUiE3JtbJq2cS0w1oMU/Dm+wf726VuJMH3Air4DRUVDVQNFjQ0YnWsjN9VEOqCBL4BzJVZjofTXYsGbKgMy5xkRog4WlAh9ZwuxcUSgqEJATVGNJ9XzqtzNXnQEeNN9LUeMCLl4oTyVXOKIkVEJiG9jbdo2DdjjAHjS7Eto4SzbFs+smMpSaCMBUqK/Aigg3SCk4oKA/BwLhlok9BHI5UK+LL65ynKrGQWkioU2QRYwjUuxahGacdXJ2zR5H6FRmDNsiTHwa067kmZ2KNgVNX9CgCmtsjhf86Jf0sv5iojUFwtU5DkDpb0b1GospMqCQpOTkDg5YYFPiDkBIwtEVcjOohhHmA+lkAQwZOJquWQ8N7gWMFaYucUEwxwOpoONgYmCv6zElQE7RuTqkOCigEpfCJs4diFIYuyL9QSr1Usu7IEh1ZqUFSY04IQw/bB3+paxHk4w+7JJMnilDnsqnDTg5cJEZxzTBhuBiy0xNNsAEmwRianMGCIXpDLjhbJd8siFv39BsT0kJklpUEouDiN2/jZAkQsamEIvVvQMyGwT2ry5vLH3mT6yGO8maMaE7Dsrgsjc3AOQoCVa0vQCDJ5WCeTJCDVlgM1lKIJGeilb22ZW+DX9YBXoALkMMCtE93ijx5bWWlwKcQI5LHKyUT7oFVPIqJ6UJgxC+DRGQMVXzWKExK/DankHhFLeLIh92KnERoxNKP+tspQ2iwtpMzXFeWbv5CyszBsKdI6XWETUoFjmnAqCRcCGSn8IHaxR0JJFRbQICAOeDmDwkWtbA9r0tInpilkwXUjCCsfw7mq3Kg21K7UrJpHd6X/x7X8dMc8P6vML80rgB9pOp0NPNd6hiMjEoGSgcW0AnfrFC+tB4MhCITQDUM00MpTmnb8BBRK3jMIKorqPQGRAir7AGUDUiEbTLFjI/2a5Yjy4yj8E9Lq1FhZ6mpvvaXYODCx0eur2ivyzZIR9QhGAQi7O3TgiUsL0gemTOQoUAceMMYaafCwwR3Y2MfQ3Emapr7lIfOw7jmou3YIgB2zjNCm2JZLApj3ZBFRTIqIhihRhOuQuPegWg21V7F8mbI6FmmFwdXtIK9ccopOPP14XnnaaHn7OOXrM/c7Xo867rx5+37N07iknavmyZfImnZlf0Fy3Kw+6Io6IH8Q0do45FverUBYL0hoPB4CnayYDIwyQ9mkoFI5hyNHAo5TzNmBuFlQamamBTZFqfjeeZ8Gi1day1St05rnH6ylPPkd/8bzz9VcvPE+vfsE5euVzztYzHn+SHvPgY3TmyWu0ZHyYhQ8tdAs3AgKSNkMiPnS/ZheLY2jytM3ACJe0bPJOUikjJ+OUQ1dWDQZCPAaDFKENanaLEJoGoavNgt1hrezQCsB0xaS325UWGPR0t6fDDzlMf/rQS/RPz3+mrnjZC/StFz1d3/jzx+ryRz1QX3jAefrsfc/Q5y84G/p+uuLRD9a3n/44ffkZT9JbL32YHn76iVqxZJSF7ahmtFWrJTlzgN7psWlhyUeUJu8cC/ZhC0SQuJWEHAeWQpfgxe/TjQ47NkPlrjygklZYFC2wwbqcG6ecfoxe9oqH69OfeLa+d+Vz9c3PPk6f+odz9W9/fYz++eWr9Q/PH9O7n93Se8EffOly/ecbjtBn3nofvfPlJ+jSBxyq1ctH1OmKBRY5icI4nKT7AgKJa3YPE/Sei4QN1SrGiyFVmX+KaIJ4QYaioCCsGmAQ/YVEIJM2xUoRUH0w30yCfKWrxWL6OJ1e6Oqs007W+1/0bH39Zc/SRx5yPz3/oGW6aHaf7rV5o1ZvvENLNt2loW13q9qxRa1tmzW8+W4t37hRJ27Zqofs3ac3rFiqL15wrv7rGY/Xu574SJ1+7OEcaXPq9Dp05vzINEQJpyiTOVgTKW2IpkVAxYNWaRsRiqgEkssAD+gKQbsK2WCB2R9bMqanPOUB+vIXXqqrvvo8feDtF+lJD16l0w9b0BpNKmZn1GHcc/Md8pzXvHnG253crnr/Zh0Sd+vhx+/Vu563TF9812l681+cqpOOW6k5jmnPobuqVYuRKfir6D/gAjrAIC2CJNQ0klKpLJ4Jr3FlrixOCxbsUHcyADsVmkIU4+zUZjiCrEHU0/7pGd3r2GP1zyzkl5/yaD1v9YiOZrHK5s3q7N+nrv+JaKFbJlIcV2oNScPDCYXjuHAFdjn6O76f7tmnobu26oz1m/SqaOvKR1+iDz77yTrz+GM1Pz/PFVvzoFHIACAJL2ZEkEukrMmdtNiNxcBc2QalPNYEy1MIB8YdfynIzzDXqTU8OqynP+vB+vqVr9Gn/9+T9fiHLNNh47vUm9ythZlZdTsez7BKtUR1tUwxtFJVe4WGR5ZqZHSJRoZGNTQ0pKHWkAir3vw+HTGyTa94bFv/9aH76m2vPk8HrxrPhY1w35IvsYYOEV0RfYxKmaf5YHBUeIsZlFWQxe5g2YDJsaa2oZT3VRw8IT7GsMDQNpFXZFWFKjrzf7Y/j90Ln/gEXfGMJ+jZmsurbX73fnXn5xRzs2rNzkrQhcXgJqTav7eylQpQh/uqVbgSKnZ4Nbugivtu9Lqqux11dmzXsutu0nM379RXHnSR3vy4hzMJK5iEjkT/hb5BzYCgC5uCJWIkRS7Wmw9mlK4sEsrEnjBbWe9j3ULjOfI47/yT9PnPv1qf/Oif6ZJzx1TN7VZntkfuw6rabbWip5YWVFVdtUeKRpa1NLJiSKOHjGj8kGGtOnhUqw5aomXLhjQyXGl4qKUloyMaHRtRrzOrVe0detMLDtZ/feYJesIjTiWnUNWqck4jQlQghGKQbvLO1YCCWgAsMHPeZio3ng0PnGwhbVRUVVihdDsIUAmOScPIFMfLgkaXLtf7Xvhc/f0JR+jwO9aqOzUlbjhqs4Njdl717Bwwq2Ci2wyoxX2xtXxc1fKlqpaOy/xQO1SxeAX7wgNRDfTmOmyIjkqvp17pambrFi390bV6+d5Jfe5xj9TjH3ieujzIMRxyCQZd1GxCWUSKBRk0M0PWEB6XsC2Asc0KDXaMyRuhw1Mpt3698EUP0de/8jxd+uCVisld6s521R4eUZuTRBpStEfUWr5EHRZy/Y7d+tEvNuhLV9ysj336Rr3/32/Rhz59p7529S798o5Z7e6Nac0RK3TE0cu0avWYxpaOadmKZRoZX6oOm/3se3f0mU88Xq955UPEUHPeq5ZE2uQGluT8c30kFpwmlLLIthmD8siWKlFsPIAMlI1kxFgVokAwdBOyYJqr7uBDD9G/P+/pelZnQnHXBvXYYfKxyqz0WJyY72poZFgT46O6jkX6+JZtevNNt+nl19yol/34er36mhv0xut/p49s2qHrWPDtwyOqW8EV2lWP+F7YzmxHC1wxHfqfG6q0Z9MWHXT1L/SOY4/Q2/7s0Ron9gIz4Ryd3wB0z8JAIkIR0ZcyCVHgpYIEksksWrlyXO/9h6fpg+9+mA4a2q3e1B4NtQuT3OYVZFjiGNWyEa3duEfv+8A1etqzrtKTn/JNPfNFP9ILXn+9/vKda/U377tLb/7gJr30bXfp6a/bqD997R16zts26ePfnNCuhdDyw0Y1TIzW6LjaS1fRb1tL6j161989SO94y6VsYOcU5Bb0K4o3q9S0jM4JA1AYJiEINjCImgtaM6ziewqCuoYDaiZYhKmYhMIiCTzwmp6b06GHH6Z/f+qT9NBtd6m7a69qthXfCsSTubik1N2bxqMAABAASURBVF6xVBuWDuvv192hx375Kj3ms1folVd8W/989c/0+V//Rl++8SZ99vob9ZFrf6k3fPdqPf6bP9ClV1+rl9x+h77Tm1V3ZEjMovzaM8/DwyyLOgMsVKGZuqt9P/y5Hrdpmz72hIfp5CMP4n22Q3q1CrkXxikK06KAWQTG6WEEo64gWoAffvy+ePQxB+sTH32+XvX8e6k1s0Xc8FRVtfyOKcZWjbd1w/Xr9YaXf1lPffKn9I53X6vvXL1Zt26a187pWgv0WbiyWm06Bi+A5pjDnfs7+tENE3rjR7boUS9dpzf8wwbdsWNOQ6tGVdrjipGVZLVcmpjSX192f731LY9TzXttFeJILzntEaHmj6BQOLg1SrC0gWiuUO9QX7FeVK+2shSMmSDalJEccdXtLnBkLNeHnvAoXXj7LdzjdqnmI0HN1VhzZQ6HtGfZEr3792v1yE9erjd/44e6cdNWkuxoebul5UPDWgaMD7U01q40PtTWGD49PjKs37tXX1l3p57zs9/ohbfcph/Mz6owsi4PVJMs5hT32XneaTu8FvV42Ni2dqNW/+wmvffiC3TBCceRW48BEcz3aBbSeTvnHD1iY8KJE14t+Iqmy9V90slH6Yuffroe9+BQd+8WtaqOqmpBdW9O1UhLd9+9S2+77LN64TM/oa9ecYt27J3XXF1pvlazgSUtGZI4UXX4Mun41dKph0knHCItHW1sFrgotu3r6YNf2KlLn3+j/v0/f6d6pKPwDoghZnmYvif0ulc/UG947Z/Qd62IALyoRRBqiteliOXApy9B3VBi/FDmMZFCBwoTUgzs+PQMLOB7QyN6+xMeo4fcfZe6+6dkGzHR3FB5qmvp+vkZ/dlXv6l3/vePNbF/QgcNtzXeahGi0hyDmolK03Q7xdPrVDWkyWgBFRBaaHHpoK+Z5O/t2KmX/uYWveqODbqFK1IVfvQzg26OBZ1jFy+wMXZPTmvPtdfrbeedo0tOv486HBMRoXyQq4wlEBCAkEdCRbyFTtHJp99LX/rMs3ThKVJ3Yp9aQyGRbc24Y3RU373qBr38OR/RNy7/tabYtPs6lSbmMEE/DGJP5OROItsxKd29T9qwW9q0X7LuwTzvPO0i6cyjitjvCCUv7Ov+bp0ue+0PtW96l1qjXXosHGwt9fbv0d+87mF6ymPP1xxP2hFBL2TE/CflxUrJPRrLDIiYQdoMZ4xjkZpjCwuSrq1jxzvYJPfBZ118oZ6xMKWFqQkVrrLwVuGlexT68q3b9Odf+Y5u2rxDhwy31G63NF21NNtqq8OTYY+F7ZJglxlODN0D6qgU2BWwj9QJhTqkM8MG+u/de/Ty2zfqM9NT6o205cWcYkGneYCZoe9pYu5lcX/34+v02tNO1aPPPJmJq5nMUBWhVmUQdAGMGWO0NM+VfuJJR+izH3uizjx8D4s5oYqHnoKP6L9u8c74b7/Q+978Td3FSt05Hdq4u2h6oVbdqiT6rUBtgFs7/SEKMVvSTDe0eSL0y7ukr1wXun6j9OAzKr3xSaETDhbPBEXtkUqf+dp2vfwlV2nbjm1ygBajruqOWgv79X/feqnufewa+etSIZ/CWEXJ9MDuaUAPsGWkk1rllYaTcUFkIA42SWmWY+/eRx2p1xy1Uu0N69Vy6lwtRT2NjA3pil179JffuUbzvJqsGa7UiZbmWMQaCBarIliFD/N7oC82DF1JZBTiD1xh0GKyOlVLU3Q9U0Lb2TAf4oHqX3fv09zosObFpBGLW5dmWdhZfCfZwT/78S/0F/c5Vn96+gmaZ5ELl0ghZmAPwqpWxb2lx6Vy+JGH6hP/8jidefAuLezdryp65CWiDmmuXqIrPvR9XXPVr7Sdh4Jbd0h7ZzihiFMDXTZD4ZnDD3CkKvay2uRNZV5EP0W+b4vSwf/mu0P/9u1av9lU9JZnt/XMB5ARG2PpSOj71+zlmP22puZY1Koj0ub1aFLHHTOv17/qElVF6vVq+bXEAEv8IF9iyKWQM9gDRFNBqu4vpB2aUZUmoRKYRDov4PACJurY9RvF/DKjHe6dXQ0xQdfxRPq6n14vHgi1lN3ro3WekUZVqcVVZqjo1tFA/di1sqAvAOFV0VRcpT4u6VjCn3d3TZPfQpH+i4n/KK8JM9w/LZ8k2CRy66dNc3P83k9+o+eceKyeCMxzokTUKlWtYGZKtHl4aWs5D2z/9t7H6n7H7NE8923bcGGQV62Z3pC++ZHv6+61m3Xjzlo3b2KhSbQVIkbkhD/3affSh//xoTryiJVs51C0K7VaBZAYhCKCbKD71RyPGbryl6F3X170Z49bouc9uq15NuPoaEvf/v4Ofeg9P1A1NKWqnlU7ZtXbs1VPfvzhevBFxzLfNbFDonquEkssVaGlIoeDkHJBk7KOiU0HBGaDJiK47Hu612GH6okkPbdrvwq/KtRcsa25BW0n9f/zi99okvvbEhZzgU3QqSr6LAp2FmrBiDByCTeAsQEydaYbm4LInFLeQmjOHy+4TenayUl9bscOTbekea6qSTaUF5PHJ/mI3k8Ol//sZj3z+KP0kMMO0cxcFwumlLxqMeyqrXe87XF61Om7NLNrq6KeV9WdVVXmNcHHj8/94zd08++36HO/mtKNG+fEW5F4LmomFH/Xxz3xZD335efriMPGOblKLmqt4MKQ2HsJztm2Ho1xCwGHlW5aX+t1H+3oMY9dpUsfMMyJVrRkrNInPrNeV//gtxoam5E6M+rNzWhp2acXPePU/ChRMQ+soEP9IRTYPtBFs6BexGDmjVHjVxpgRSvkcwj/9Lgjdfj2LSpeJG837/5K+sBtd+pXLPI4i7iA3X58ZpjCWY6kDr7Oo2Kw7izQRUTTqYS0JI1YdEh1ZsiZ/EArsGxP7BbY7JRC183M6Rvb9/BNqpL7mqYv31cNk9zvtxPw879Zq2efeJzOWLkyf9LilJVff177mkv1nIeF5ljMKiTVC4relKa7E/q391ytq366RZ+5ZlJ3bJvPxWy3QiPcQkRqa9Ys0eP/5GQdd/gKVfOTev6fn6I//ZMTNcrzAg/h6pKgT7k88RwbIG25nxZNRe6j3HDXbujqrR+d1jOetExnHMeG6BZNzoU+8qGbNc3339KZUt2Z18LEHl1y4bjOP+sQ7rucFFxwTJIMhCaaW8EDcAWoTBpqN+jTB5oltZ96bLk142O6lMfveoJrwTY8SQ5x//vF3Lw+sXGrvJh0pxmu0rP5dHchV+59+SZ7PJ/vCMDur1UxIxXBA78MDM26yzd794Uam1DlGaAPI1FYG2RSRABE4Sj3/fLGuTldw/tvL6RJ8pngfj5lIIcZ8Cbw136/US856V46bmwsf6t8+p8/SG989mp1tv+O7lpMGldvZ45jeEEffN9v9eX/3qyfrJvnKbSjlo/oIrXol6HoIQ86Vt/66uP15c8+RGedMazu5JSe99wT9IVPP0gf+9CDtHL5kEjDiRKbOcZXlCpErBBpq+XZRj42Il1zw6w+/MUJ/ekj2xoZwYan6x/+fEJXXfE7DY1OqtWbkDqTOnh8Qo9/+KH9mCF5QkCihPgjPyocgbFyFzDUhlc6QAe7TUz6PAtw5sqlOpkXX987g8kqQM0T5xe27dIkn+yWcQ/Zh+woAl46NKSVUWkVMOIYyHz1Mz8srBIi49NwZXkxg34yKRTmFQcmRC6YWo9aQT49ZDuw+QWfzm7ds1+FmZwh1gI6g59gO9Dr0f/wzs165OpluvQR5+o9f3kv1Xf/Qr0FqcunxR63jard0+e+tEmf/foW3bY7tN8PP47FVeOrmh9RdNJJB+mj73+ozj2+o62cSHfczFNSmdaGdXepO7FDT3z4Cr36xacoGGSQl/MnRXlymwUtqki+srIKbgNFy8db+sH10u2ba517ElcoL7XTXelrV27h8ylj6k5LC3Mqk/v0sPPHtZyvS3Zv4R+DDohpMgIJMOjT2HIwM0cNKKY0ZT0MLx4b1vDeCe4NtWpG2WbA23g3/NHOPTqY90wbztVSxdHzXR5MvsZi/gBYh68/NLSIl4NzbMA0IpZadgVCWbwB0PuqTZ4G1hcyfQtcwAdgLxvher4Z7+EIFos6T17znCgL4K5PBwZ84+4p7V61XP/8hnPV3n6NZidn1eHqrjldhoeLfsS98kOf2aS7mb+ZBfcm2bXDeHpkxrrrhX9+mo5cOqudOzt62Rt+q29/b4e6fL16xWt+pn//9AbiTeuic1frkNWj8onmgTH0vCJbDC0iVPxAxiYZ40J44mNP15c/9yTd/35r9N+/6OmYQ5kRahf47dpZ3b5uQoXN1uOevjA9qyNX1zrxqBFiSBULWhEvIhTRgEIq/EWECCGK2WYwQtifV5touN3WuZwX9dScxCiLF5Qnxxv4uWwfna7k6pyvQ6PYTERLcy2uziq0DBgHWlwpPa5eX9WsNeHpi4UQ0bPSbSgaFjnV4ly4Hgvj+/ofAPkJe9ZKLlwr+tXMDBPMmyv9dLmH1gkFWU/LVo7psr++WOO7rtH8fhaTS67L9+F2zOj3d0/qje9br9t31bzES9VgNoLITEIBDmWRHnD2Mh5S9uuHv9irb129iWO4gg9t3lPrnf+yTs955Y163quv1U6+IJGySE9MQ8bzglowz0eMc88+VF/5wrP16U89SQ9+0MEaqnr6/dbQvqnQsQdLHRzv3FP08+t4MGJX9XgFXOChbs2Sni6+7xo5NlOq6A++5Nw5OgkzL8zsYEGZT5RU5fEnqYqKm3zRQRyhR/IQNM/i9fhS0uH+2GOgN07MiodecdlwDyrygu5Dficwygf5dmsoj9f7HHW4HnHhfXXOiRx3XEVigXPesjM6ojoRhUROcvGDRQ87X6nW2dQQzHhEY2jecXwC7GNka7nqhojfYiLcB3tOfhd9/SvP0yljv9XU7r3i9VE97q2lN6MJfjy47B/u1PV3LGiODwEtwrbpPBcCujkixStEpd78FE/2k7rPvYeAVZqe496LbSGXHbsWdPl3tmsLuNcrwlXtllh0AJswkB/7XVu3TWrT3RulmOLhZ0ILfpJi+67dWnTsasl98nqqWzdM5qtKF6Y7X1TxgLR6aU+EkUrgL0rTlwqkezUGKrNCwKEgF2RGIlf18D2Y+8IKzvIFfqNc4J7kXTPL2+/GmQUNs2XmuCpqogZ0i53jl23voqVcua9/+hP1uT9/rD5+76P0hUsu1t8/4RFaxhNBl8ya/mqxb+grEuQF44NCm9E3i0kqUfHQMMyOrzTUHuIdcoW8YdyHJ59nCfF+rt0s1A6evMfJww9sc9PzetZTz9Wjzp7Xjo13abYe5vVLXLXz4uVZf/vRvfrBDXP0KzUzpSYXSaFG1OOI3LRrVp+7cgPv2Au699Lt+sJ7T9JDz+6qx73z1OOW8q22zeQXFkPKhawkhi7TpE4gghHQV9UCF8bJp6/Q7p07tOWujVo2jo7eNu8uWg091JK4Y2jrjnktzHQ1z8ZZ4CFzuNppAAAQAElEQVRzYXZOR61uyX/dXgubwSoVZh4fNnLNuCNClbJYYaOi8EyRgMU1E7+MHoYJOs9RO8+kdQk+x1XqyfMizvIagwmBC5GDq7ZSi6PiNQ+7QC+Z3K+DP/45DX3pmxr/5Ff1nN/fqQ+feILG6MNPxK961av13Oc9j3c5rhIW46UvfZme/OQ/1dv+79t00f0vYp6LnvH0p+vpT3+qXvKSF+sLX/ySPvHJT+gxj/kT0aHabIB2uE8xWL6fcpxOc5W0mIhHX3yyXvH0Y7XrtptZzFEWs+a1RapGh/Sxb87qk9+eUDB6UqEfwpE+w1UEtJrCeqpES5/8+jZd/t1Jbjkdnb5mFx/dF1T279L7XnWYvvEvZ+vlfGhwLnStdjvkjUboDFTD9AjqB8pX/eVpOvvsUb3utT/R81/8K63fOK9Qke/dY0PSGLuT7jU53ZPnuMMN3Ffx3ExHh64KLeFNI/hI4jwNtb1NiK5YhAKd/cIT1i0KhMl4gEQfZfXFcbvQoxOOwVnwNAvr14Qehv6JyAPpIa+x7XKunXDIGj1+tK3ed38sccWFH5yYudl1G/UgvvM+dNky9eju9LPP5gnyZKLIJ7fOOP0MHXXU0arp50+f/CRFhF76Fy/Tfr4Q3e9+F+jXv75eb37jm3TtT6/VKNuZ8atNnDwuQ8Qs2svme9ARh+jNlz1Es7f9SLPztTr8QO782kM9/eg3Xf39Z/dI2HOgiI1tMnnRn4fvhIonqCYmR/iuiXm96O9u01/83Q5982e1ZjvD6TdcT+k+h0zrbS89TB94wxkaZ8zpbz8Dg+wSZ45j88mPPVSXvXyNvvKp3+jK/75LN9w6r1vWzYpPujl49oGW8KnNYxG5dbmAfEUb5tigLd6XW61ahecDL1wD8CTry9FzJujFBSUGxogyI48vUBdVDKhmAX2FzrLN/H11HhvfozwhNTPSYyF9z6uR2+6I8REt28Axhb24moNFFldt4ajW1JSO94u6JE9ynUspj0HBohfiXfH1y3XeeefxvncmMunGm27S+NKlesYzn6F3vuMdOv5ex8oPWS36q8iyhV+0Ki2N0CNGR/Sa1z9NQzuu0zQboceOrhlDu8xpy+55vf2TOzXDIi8ZkcaGlb0XaXHshBRrwPOD1PXpw+aqiDHLU+3nvrtXT3vTnfqvH01pbKzSLbdLM/Vy7du9S095+Lie/LAj1eHhp1eHetzravJZgD/7lHH941uO1I+v3qY3/9063fvoFTrvtFVatWJYdUjBKjAEeVqGoFeMt3mWCXV46l7gPjo/11OX48K59Wo1uYpigQGyy1wXaNzhCOoZDTBVhZUqqvM8nsNw1pc+i9JlpB0iBhO0iq00UpQPPkTAPbKniNDk/mnN8QBVs4CFhezwajHP2/kcu2yBe/KkHQD6p20qoVjgrrwwv77+19q/b0Jv+ts36dbf36I7169XiwX74Q9+oE/85ye1ZctWeQIYm+xHz3zcaOlS8rvsVU/SypV3avfam9Wr2sTsKXrzWuBj7bs/v18bd3SzQ054rR6vND4S6hEEV9UEZHhaBOQMLCeQPc09XOpguIcrthfD+ssP3KXXfmCjSoxpas9ePerCNRoZbqkmIS9SjwEeumZY//y3h/MwNKfnvmKd9nFFfOxfTtW3PneSHvmANVrohQqDoWsWUfKVesiqFuOrxUWqHnPoC2rfdIeHPBKi5gCyoaNMUBpqsQkiVIkSFiZItq8ZkXenj53tDGAfkT2QeeTzXI2+0g4bamuYACP4O4ghoFuM5BZeD24fHtV8u80F2tUsQf0psMti7jpkuX4+NY2l5Bf7hz7soXrPe96tP3vKk7XAoo+MjjGQWr/4+c/0lKf8mf7rqqvkCe9xpB951FE647TTddzxx4nPyUxuKH8EiJYewQPHZc+5VMc/8FBN/hQfdbHpqNfraGi4p49/a04/uqnDfVcMXhrlcqhLpVOOGOF33JAntJBnYrLzWAyQOmJVWy98xLguPX+EeIVJIy5H+yxXz0+u262tm2d4iGFMfHXits7Chxa4olYua+lf37JGfpB81itv1+ZtcxoeKlre260lvb3EoUNmnL0q9r+4ZtSmw+MOG1Kw+X0y1ByxMNqwZZ65pG/mEJN+DbybNYtosq2sicFiMqICeEsWB2LLekH30m8uKJt7nqOky9eh07iHjSL3MRcRkkEE5yzeyT33HRu36HcnHKUp/9xlHZ/fZo85Qu+fmtHtXLH+VwqXf+XL+u63v8Mg22rzZPv1r12p737n20SRPvHJT+qZz3qGvv+d76mF5DOf/pRuuOEGtYeHWKCRXAA2N0+fRY/sdPV//uRinfzsizV91ac1wakyxSkyx0PSMPfNb/+21ueu6XHfDY21pWXcuJZBtNttDbcrXXjvMXpQxmQkSTtlUuIqHtIHXrBClz2sp5c9rNaRq6qc2M78tPyacc4pS7R6yYxmJia0dcse+eeyaXbwfY5q6SNvWKbde+b09Ms2666t86q8csxvZ4rFmVpQjzzd2TI+cEzMSEwbJ0alU+/DpuatotWSqlzAWtv29mxKn5GLmE0URUoFW5LKBS3OHt6LWbiHFTrlwuSJtWg/xBYWtgZ30dUs9Azn1eljQ1rKVbqakBX2Dlz3empzxLZ5PPnp1t16OYv6HyuX6bqDV+kbq1frJbv366s79pGUNEK23//u9/Q3b/gbXfZ/XqcvfulL+u53v6OfXfuzTGwrP5Z/7rOf1/TUlFrk940r/0tvfctbgLfqe17kVqjN5fBwPnb8zQXn6D5v/At1vvIR7Sb+LvKZ5D5ZRU+3bJL+5coFkbpYx2ZRR1oaJndfpZPz0uEHt3W/k5pFZThyKTQVg5phU/i9cOP2DldPrX960aiOWzGtO9fv0PMfMqRXP7atPVt2quZZ4ce/3qcFjsgHnlzpHc9boh/9fEEvffterV7a1ufefbje99dHa9mSlmZY0Gleqwpf2+hGK+h6814WlAvm6KNGdcIxo+p0gnkKsWaaZ/7vpn/n46UTxfmxilDY0KqfeC6oKGkAdi1YFiYlOGLnmIkbCFiR6DwLBqkpkj9yuNLJLOqh9OIX+g5HsT/GPwK/bqcjThat3T+ld2zdpefwEf3VW7folxOTXAWhuoS70TA7dpQPFyNDwxyD7Vy4iEZng4hQhEEcY22NtIfwaclX86gqPZAr8xX8THafd/616m/8q3byvnkXx+g+rhA/UOzYL733a13t5r41zskxym4fGm7J9+OhSsQMnkxDW3cv6IFnjOq8k5aI9OlTYlhJd3tFH7+6q7v2FTZLj99PZ9WbndNvfzenw0entffuPZqarPXpH3T0g5vm9MhTpD+5b6V3fn5GH/7aDGOV7ntyW488Z0bnnzgnHoS1Z8+stvN+O8nrSDDQZaOhTXuZFy7CB56/RmMjXfm251teqyL/yQX9Zt2ChHHNQoFMwoeYHsA45FK5CY+CRTQ9IG3oRbXsZ+h8/+uwmnMs3CzCaR58HnjECq0mwhr4BRZ7hN6GCDDJgu2zTJFXuTeC8K2l3G0LbJQOtj3AmyZ89BDXM9jkgqErsYwsG+IIHeKobxOnzWw/APw3B63Q/d/9V1r45v/T5qt/rlvLkHZyc52YqrWPJD/4zVo3b5V65DhPoGVLgg0hNk9oZEgaH5aWcH9dyUv9th2zeuYjVuqM48achoboo03+7aqlzfuL3v7VWt/6XWgbm2T7Dmk/m2R2odbejvTJq4s+9d2Ozjk61MLvH6/oaM9k6KVPWKn7HDWiwr1hHttZPjl2GfvePR3t4H5615Z5HbdG2sMGdL6rVwzpCQ9fqf079qpm7B3u/612V7dv7mkn/XnJuL64SEMRBv2PUlmSVySTSxSM2QJUCCnEV5jQulalDRxvLRZ2lo4WwJv56H3G0iEdvXRUpzLoHonuQH4C3wOfBv4zSeeDe9iLBa4J5qc/Q49k2PhcrYXDuWYCyYA+qUIlul0ElERS8l5Iw315SLts2Zgueuer1bv++9r0zR/p5hjSnbwi7JwWDxihz1xb9OO7pJqr0g8bk0z87pmiNUuKlrZ73EfBoz0tH6u1crzWivGivYzpr59xjE45aglPxfTZrui31pCKHPcTPy16/3eKNu4SgUNXXB96xxXS5b+s1WNAN9xd9N+/k6bmQ6978hJ98KXS658yykNRER/b1GFRvYm75P/jG2pt3dXTYaukDTsJh/9jH3WYjj64o6l9Xc1zK+mw0Qvv0N//dYf3aSkiVKKSBGZeqfKcyYVJM21tI4QrDSXslYVFbBNkmsf/n7PzbDzPlTHL1bKXe8tdOyd0/3uv0b0wPhHbW9kUHyWx38PfRm+bRMcGOkNE9GARDQVc51rVLDYPhOylTEAY4aEEN3ZlTTgCQxGhU9k4r2MTXfLWv1T9219q02e/rd+NtHV3XbSPn3w4cfW9tUXf4pNpHYSrAUKLsperdueUdK+DQys41paPsJBjRStGa61aUmu0mtf89A695xXH6ESefueYVDolN3ImDuG0fb+0k4/pc8T8Pd9gd08WbgHSREe691Ghh50deeW3Soen3ykt7JtRme1qy90Lmp7sMY6imzZI/3HVQv6Tz/U7Q3xF1fFHLdPLnnmIJjZtU6fX5rWdDkpPvrf+9OY6+2D4jMIVXaIi52TS2OA1YmILMkN/8JCshyIwYSF9r/sJ9G6sFljQafQTzPxNG/drtK507rEH6RJJh2FzOwP/Jfrr4O/GJu/qhCEYi1iQAOgx4+qkvyioAOxDzR+kIBvXgAR6kk5iMV+/Yoke89oXa/am32rtZ76l3/AeuZ6cdvMQxJrqls2hy28XLy1Kf/1RuWtPT9snejrjSBZyuNZKHtWXjUpjQ8G9S5rnCbw3uU3/+IqjWNRRJrtWl01X7hHn+78vet83i3yPdp9+5Th6jfTqx0tvfqp0Bkfv7smu9nJU79tXa4F7/Z13dTlmF/JK/cZPuzpkWcgPZHtnQqv4bfQf3nIfLe/u0tT+rmYJOL/QU1V19S2u/o07C88XJEASTIU8N2KuE0RB6Dy8ZrmgzLJrgmeB/LGNZqEJ0kKzmWP3JyxurdA+eDaq/AT8vZs2MfCDdMLq5XokuuUEB2lYSmjRsUU9fHz8+sjxvblgVLBBrIhI0D0W1/JUh3JxzibjNx19kB7zymdr73W/1g1f+pau54vKWpLd3T/KNu2RvrKu1jSOHljGhx5UyxiGfrmhp/V7Kp1ydFv+YjTKphhqF7XpdCik3bvn1JnYqQ+8+kjd/4yl+V6cMdCRqvbRwS7A/97oASdL550QGiL45i1Fv/wN92/u4Xfv7Oln1/e0e3+tKS7nHTtq3X5XR9N8px1nI7E3eViTjloa+vDfnaKLTtivret3anIuOG57qnkP9dX55Wu62TXPpKwHF0ByJCIDjBNioEHu1pIGwj4TaRSWW8gO6Zsxmdzt9W1+QtjAok4ziV7QSax2spu+c/MGXXTm0Tpz4o9wVQAAEABJREFU+aiezJm3mjg+7lrYVu4Qu0HFVQbWDquS4EwrBJlMGVhKvtf6uH0Esreffi899BmP0vpvX6tffPenunlpS3eqJ/+bXD8o7COZr62vta2nLLiIkSxCCmnoRsHt4Vt8071je60TDhMLWattY/Tc3pjMol275rR363a988UH6c8eerAU4TQ5+irmRVmOWCVdeqp04dFFfGfQVjbUXcBOctnBcbZlu7RnomjDjqKvcWRdfWPRSYeH/Py3b2+tUw4Z0f9733l69APHtPG321h4aY6PKwvczqpW4cm5aCO+THv27QuhSTNIpwDBWhUJ1G5VighV+qOCWsJAFF/CQlB7QTnWdvHu+E08ZpmVCZQzKBewu233tL5z85160Bn30iMOXamX8JB0Cvdd34IWsKvpCLMMiytJmCsND+mruMKnCoLTd6+iAU7C9zW8/P/TRWfqtAtP0TVf+J6uvfFmrR1raRuzsp+HoGABJzm2ruSBZGOXYFS8af+wWpZAU/nwZ0xfuWZBv7yt6DAe1RGrLi2uRnGFcMxySezbN68Nt27XXz1uud75V/fR0YctUQd5ROQrz62bpQ9+W7rq1xK/9+tm+LVbpKl56dZNRd+9LfSt26TNk9Lt3CvHeQfdOyG1uD086+EH6ZP/fokecNawtvxmoxaQdVjILmMaHenpJzxcffXarpiGnK9gOJ6xuhT4GkgBKwB2JScjZlBMLOa+bCSfevCSG++ImoV0DOZPLejfMenXqCkzKOaYHH4f1m+2T+jzv92g4+59pJ56zsl6y/gSPRf9cQDRtUBmXqgaLDqngtBA1Ir8td7/BGOI0Kcw2a9g83zohGP02ksv0eySpbr8s9/XDVt2aPMIRyIPC3xoyUHtXwh9Y3vRup6IInlAISkGAENNXX+IOUaPjdNPn+YL0uU8Ea9cEjzRd/kG3VOPRVsA/IqxwCPy7eu26KIjZvTZd52nFz3rdK1as0TdbhHTIT4EaetMpTlOpp/fXuknt1W8mlW6bUelX+9o8fE+dOiyopVVT1N7al1y7kr9y4cfoLe9/0E6fGyvdv/udnV4r+/xoCnGNTLU1UZeeT78ra5Y38yb6ciFiwj4yJGxrOACD6LmQoMrQNgp0qXIA6WVX2oLSvM1Z1rKeIK13c9YVDYQS6n8TruAvqaf9Xy/+tfrbtV1HMNn83voZRefrfesWK5X0cEjmKAT8F9Jdm0vMsFr6AAOYmbu2+3qqdxY/nZkWP92whF6/aPur9WnnaTLr79Fn/vBz7SWd9DtbIa9xJjiSmT9tIOvKf+9p+iOWuSvA4VcRJ8SBP1EhCIAheiOg1oJXcbBDxr6Bsfvh6/qaJ7Y40M9zc8XkRJzIHAR6eruO3dpav3v9H+esEpX/ttD9dbLHqAHXnCkxv1EFZI3wBz3coOvYnEFjLCIq3nhPf3Ew/WCFz9en/riS/RP//kUXXjBGs3+bq1m79qkLkdshy9vhQenUX7V2cvV/fdf6moTP3pzOGmxkGvSjEMqjMQcHVMbykTkhpYwsokT9y72IhbhZgG4BvuzXk2gygZM7LXch+5GZ7sZsG0iQjO9nq666Va9/we/0E3R0qmPebBe9tAL9YHTTtRHjjxUH162VB8YHtI7h1p6F59NPrxsiT5xyGp94qSj9UGO1uc+8iLFMUfqszffro994wf65aat2s0Nzk/V08yyF8BX8h28JnyHV4a7/8diRi6Ax8AIJMbJkpC5JPJzvl5UhiRWS6YR61cc2f/09Z7u3h1iD8rvlb5SA8PCRqtawdU7r7W/ukGddb/Scy/s6jPvOkdXfeoS/cc/3k9/+9rz9YoXnacXPPtMvfiZZ+hvX32xPvahp+lLX3uTvnDle/RXb3qUTjl2TvUt12jiV9epu3+nOnPTvCbN5r9AHGEx97NL3/WVWrfeWcQUizXOvBmCclDy2DwCZWnkJn1dmsPPrGyIqyfBYnnRGEhDi2BZIajslDb2Pjp/5kXFyJ2zseSn2OBqHWWG9vKZ7+vX/Frv/9r39PENm/XTZeOaPP54HX7fs3TmBefqEr6/Pvr8s3Xhuadr5UnH6fbly/W5iVm998c36KNXX69f8x14Pzlwe+TYKhxj5MBYZknhBhbzxxA7a2TwrqiMGDcUOZGCPCtBrgJCjW1EwDU0ltg3igDdzWvGh7/T0494eFnG68z4WMmFZchq+WZNPtFqa2pmTnfccqvu/PnPNb7pJl109Iz+4jFr9LbnHaX3vvIYvf+yY/XGFxytp17c1jmrf6+huz6lmWvep5nfflNzO3ZqbnZBU1NzPPF2WNSOlnAqbNgfevPni268Q047E/S8kpacp/pZh5pi7J85hdynac28i+KlFWOELLIBLYMs7Nxa+YrBU0zhcI0IBQuowBTcjuArTOgG8DqLLAdzT9e8ihYMTMA+3utuWrdRX/v5jfrgtdfpHb+8QW+/8Ra99Te36vU33qrLfnWz3vSLm/ThX92iq25epzv4HXSGK9ELOUmMiVr8TMbEEmsDI/vOgvRLgO8DpOJOAys6/h81mnslVgIKeUY0tgVeFCxom4pKBn9R+sr1Rf/x3aI9PMofvCo0xBz4ntnjttHlnjo/39UCl8/cfEe7d0zpTp4d1l/7U93+4x9o/dU/1carr9GGH35bd/3kKm395Q+1k990926b1p69RXv3LWjf3jlNT8ypLHQUQ7WuvDH06o8X/XZjqNWSnIhz0aAEBCsV7KyoYFAWRK7Foyc/pGaFGZshtag4fwarzfxhUOfiNsYYWWgG8AS1FAoWdy1wHbS/3zL/4hakacyniWDgVidF8FDVVWd2RhOTU9rZh/08Hi7wrtAlUV/1vIY1vvjzpU5zkvYC1xP4JxxJPDzm/Q+1yFi5ajpQIshJkYJinGRpeOdvWXJNE4EBlaEzERJpsH2lX/HE+gE+Hlzx455mZmqNtHq5iNNcXbN8+Znjq9Q8C9LpsXWjQ7Au78sdzcLv45vtXmx2TvEemh8Yutq9d0F7eGrey2/F81zhPXq5abv0N18o+tvP19rGx/8WC4OYITX5RoRkEBhR8YjBCFUQiWK1wSawahYUqqRFuuieBj6GJXZ2IZJHnXaihIKFjAheqkO7mYlfAjeh2Qb4vurFNHCr0yT+nGjitUy+uqz3YnFyaorjYorYkwa64Sk/bfaEdDvwc2RrieljHVaiT/ULYZO1PMKtlC1N7mZRoJtxmIahQqkxLIlIXS6O50kxv5MOv3pD0Xuu6Opb7Kh9LGyLhfXx2+0u8PC0oBkWeIZfTWZYwAYvaG5ujmN5lmN1WpOTk5qcmNLs5IQWZmdZ8Jqn30pv/VrRi/+1oyt/VtT1E6XYT2xaEBeR25CHQ2smYXEManKOCOQDgKQ6dwIUosGxWN4k2MMjg4gIjt/Cxgn5SEaBYWRnRQWMvEitquIIrnR3q9JNRL0Fq00h7QL7CvPV64XyAnsRvZgGL6zBi2y7HdhvAryAfGHTXcS2PaKssE2+ySn7j6gUXoGESgxDLkH/ETQKVeRnSmwewUe0GIolBqnCrgprtFgqKN5GdBeJf/qaWm//clcf+26t6/i+OcEVKj7NVVWPkL28en0Ud+a66nIkF945an5GLN2O5vnlehM7+Uq+Ir3xi0Wv+mhHV/D5b4pfWfKq5Ok6+otJlwoewIJcJBpXmAo6AFcSlzcedyY1JUANVFBpU1Ry4WzoSYPFyYtlruQxUAicxihLCZm1vycLEf2EHLCOSntJar0k3q3Fp1XdDe3F8qJN4DgBzy1KXmgvOiec+HFEfFOXact9kOmPiuNHXxYRizlI0FLmKeRQ8u0jpIZ1gn25KAXebKPPVuG/QAlQVQpDYqJtVxD4F5cf/q7WB6/q6q0cle+9XPrED6SvXS/eP6UbSP7GO6XrGPj3fxe68teh//hh6K8/U/Syj9X6+8tr/fSmLh8hCj2JBy4x5/TnSnwj0VnIm7LiIpKEHJF8MRkHgohQBVDVlAJqwPOjVJgXwwx3UtMRNFvAgwqFUAkhjtDw6QNG0FQEHnSGsQSioOeVUb4vevG8cDvR7SCoscFguRfaV+lgEd0LplkHtLFjir4kOHAYkxykBF1EyQYNQueEhBoAFRm1PyGhCEAhdoLk2Qg1BVwBqJN3SPNtNqrHtI0dec0G6fJfSf/Oov7TN6R3XB56O4v8jitC5v/5W/xW+mOuaJ7mdnKP5I4iDgo5puM5sOmg38wTJhRsJGuLIkIMDV4NraYUjItJ1FQ10LSEssbAAhaARXQQQ7GpZTC5Q2wGbeS+jAcw4CMcuC+FDmer4E8Jukcp0AbQgYrPQBZIDQVZBSgBoZD2adtGgbfMKiA5mmIbG6CLQJA6Cxo6qb68PywsqMiC1U29hDeAjFY+sblo2dtFFrWYQT+Zepg9STX3w8HCDbUlflIVe4BoanxxLiUU2NrfOPsu6BupNeyvgIukZco+ZguG6SA70LhaYVyyn1T4hjsA4cQ+wYIFzlYOKVujkh0aWyjiW2YeRdaIUFW1GEjgJ0WADZJCTYlFihgWhRvAwUDJ4qMqZBQRkCEzURVQwREQBRtaZFJUkhqz1EMqgpa4RqnUYHSYeHJQB46FSZMqBX9ph4OnqKBLHnm4L3eLThRuf+IhnYUUUHjVE9NnDKD04tocV9m3VQmyAOAgD/psuCplgxmvRRw7g62wPPMLKSoALEpJsBaCigpHBjUQhb2DjlBGhFv5XmTHml4sETZWRYQiAIVFqjxYSFG8wPaBRIsQuwIIiGj4iIDtg/q4L0tbOwMRlTJeKcJqcfcG8ojAQnIbtL5aQ4yp0KSOseAHRwy3qTUBoMPHpnXfJuAF1MyJcRMCOwjPkfOIsFVh6W0hediVZQCueDKtIZk2OL6ZgKAqqipBMg6pCqkiZzyzjxCl4FrA1GIB4ABIZd4qi8INNrJADmOGhI2AZiCNUj5fPNCgM2P0jcYtQgdB7iREJ5B0VykiAImWJgAqssoDAUeEguQijP8niAFGHJC7NxwcRM40IqArACylTBRPNkgFiTFZQxeZpVVTDlDWO5T1A2AYMkQ/V4/NG1p2I6/Sd4igb6ACws7oGZIEbx/VIQmAr0CiFGN4izEnpC0RJhOKGEClChqBq0K1zBKCmsb49klQOLDF0MwKbaM2oaD1R3Pv2GaBxBUBZMSQJ81y48YNj74u0rtkGxE4UcFQcokI/eGiWmOQIuIAqE+D0TDvjtmXYVdEiYK2QDTVU9Nw2KEREOoXDxi/6MsCcUTAQdCGKkXAA1JQAdFtAnRWohMnIkQFQjRUY2xBqCGKIBURzBtAbBlCFJqCCRQGVPhmEpF4BOYDP+hA5Nq3Bw0ckTbKUEBT+wjKPUkRoVBT7Gg6ghaomTjLvIiwiggFpuZzAAOGxEhDVqY9BKZyFhFhrr8ZiiLgYzCJ6vOWNaB+wSQTjAgxSuyIlnSyxLNcSoVJAAv4klCUAqXMCTMWuyPAt0hmQNYXsVlFwdcjyDUAABAASURBVIahpN6bNpBH9HXEoMrjLpiaSB46oqXIq7oShFVAqCnGBnuFh0KXzBbOcIqgBeg0zdGkXgFyA2CKjjzovABC5qp+SRE0vdvJHcEJXAAHx9oDsiiCyBA1R7CPSiWPPaa2qRT8wQeQFcJx0Ic1tg8U4AgTpGx9ikIRTnQgK/AoqDYpYNTIbAOTQmhIZ+6+Sc0kiBjInROImt5SSAnCDJGtLGomMAWN2rMCi5UtgYYisJRJCAEGtTGQCqHiHg+dqckm2CjkuXIu2R/+IbINCYUSyaUs0hGMy0GQBLYCZ45F8i5ItOhozqAs3ocmKjdiIO5Yfb3pwuKlrt84jo0tLtlpkRMmB054BqFwnybwQEdrHYicilC7yj5aLMiz04J8UZhEBPH64O4MqcimyA4RTAD+cMqySMCZZlwKUSNBFIsF1+BB6zgHpCKu+iUioAygxlyDuY4qMDVY0UCQaGDqiajpn6rkkVtmlPNnIeDwltV2xy8CIdiboHiy7Y0sIqACjeg+wE3OEE21CMprBOpHS5e+holKF3orpcCJhbOkr8cFFb7mYdICmoowa/FoklJGpmFx3WUoIuRiT2MpFBGSQhGhpgxww7ltVMgLQwYsM0Qg0z3AZObUt7MtnQU2EbQhOT0DFBU7ywnmRVHakSs+KKlJKAtkoC/ExIsxpbRpOHaVcWwhVe4gGpVbkxGh5o+wUItXguUhJDRCRz/WIYah5vdBC4tSljaF9kAl4wOMkxOxqEayaYHKxEnemQ+WNJCnAY2Dm0//0o+XwqJENI6BaSptm4RMBSSATUQogh4KySMdtBGNHIQ0gCK3EJg0lNOzHm/5FPCiWGOMEV1ndomVO9/etjCW5w2zvk2BFyzWjQLGwUHqu2BiAxUWzGBTWVnQ5PkXiogUqV/ghFAu2ZP1ONpFInMIz5NvbamXywE5pvRXlHpszduiQBhMNwtKDmaImQ5m60zUUnNOBaCas3Op3OaYcEPhQYDsEY0kle43ZZm8Kfw8oQSyKAGxJ96DMcDiiwGJJp2NeYvBONHSC/zAho7sa3khd6VWErbql0hM//IkwaQx2BVl+pcDQqwW50PEiQj5z+buGYZa5A1Ew9o7dkmVm4yHjxRUokFTlYUcC4DGWgA/FAUqAmmBybpIJIdaEejhIiJpWvomfikcxyhc7RYmvDDGCSmBsnaAigZS4jlvdkxBKeRoEDac/qB4qIsCbLBMX6/HH+hsRADryQ+uCHMw5iVREtYP7mEpxSj6w4lAS8VQLqEwoquiiACSpSl9aCwjAp5qbGDC4bL2NY2vdZbaHUUEDXyaQzrv2k0fIhCil1FfljQZKQkU2AR0SLSAeSA3hX0kwTaJKhTRLKAGJRoir9CcUJxCgQPgjnJhiyLMYwwfYZpAAhdk96iF0dSWAWhzZ9vMUBavyFBENF4gTN0TPMxiawIeuwiw6K8UmYyIRawgVeS0QqzgD08ZFeRUYofVYFGgWfCUu0EiG+NMVUQo/8Dql5I4smVAGSddU8HUYWvSi+cTRkQQfQzetYVeFOfT0IxFoQh8kWeNbDO2kw0FF0gjMx0RqrCPCAldhLFXzD2rX8IaCV1Grvmmt2iSGdtAsoGTwY6+sECXmhSEJIMoIYtikBZ9FQvQuKKVgQhpETGwtFYcFzpQQkKtQYkIeF4LHJP+QY0KAhaaWAUgsuODkA2q5dDRh74y5L++rB/H42y+kkl0KZeIMAIyMphpyNYNjgr+KvIPCxJMOVYyNBGWCJuCLViOUWhdwdTgabnq27mnPmkDfPpjYIwpyCZS7rY/JCGQS+VG5ghsZclohC1Bz0VmnSAXKEkhwsi7Ea1cIkzZHlsLZF5pK0rpA8jOwAFbWzruwMaY8FwMSYFt3tgPFk8ZHz3OVJsLqwTzEPeo2A04k2nQnyDkg3GkGD47JKL78pgNjSyyV5v8MYQFbgBPhX0tSj8Yx0g5QtNOQ0TDXAKLghnmpc8h6FdG3sgxGNCNqjRDNtMEkjeFyVzQuu5lMDtVOHuSmxVBgq/EFRKBuxlkUIvVIlRWm8yezPQNUMlso5PMi+LBgaiOZ8CTvhkBFb7vkAi5d7Dj4LBYzTtXYzlyBrdHMZcgisVpU2BYMLcJKUwqm4i0JJFkFQGfsChqFEKeFAH7ZEFGmkidewELSQPKgsyxknZjR2xNOifU1OSCiynSGzboGz8QzP9eUatwv/Oc5oJ2u121/KMeEWsCFSwqcAbJLAucA0uoBOUUZFWmVJD0QUov9FwJKWswFsrSqCUCNf4BGWoWLARDjQPgGBp4BwSgUESFFCBORECjwjYi5D8LII2aPNEl44aOzRYsC7wBRDUFBCQVipa6SFhhKIowdp8Fg3tUxBHZyPOIIUboLaNfCR3Yky+Rv4QkFBESfAAlRAmFQsE4I5jDkCJoRLlHl4SS79l8JJBvnRmx0+mqPTSs2g8vaqybNhaDHFg4gqN0Qo4fgY2CXiRINdmrTyuL5aFI2gmY6HMms0fHM5gJbNMnUAMR9AnpHPIVwTSBSEM+SSCVBVtjyxOYmSCWgIjQYhnQi45SI7INYGdRrIeNoIEN5sfgMWauUfp+KLMWq3IDJUvjEEX4FxhwhgqmPYmiCI/NIzPdYMkyCSR5pTwpBZIaCHGBokI4jyHWDjECsR1AszMzalWVvNIRIfsHmUChbVoxOep72cSgfnEaJvuWkE3v5vupya7hBlWoXxwEhpqCiLAFG4uI2DlZKyIaeZgxoFMCdvxMZXmEWyuliJCveCHCQh7QgVgSaqFqwISaEhGLskBkIBkWqCgiOaSuoTDqt95Uyfb5CGsHoEbKfDqXmqPR+ahfah5IBzwm2BY0pcGl0Tj3DMmgEdEOZrXhRoaHtLCwgJ8YN6jTWcikh4aGEhNNhQhpHhhQYZUALfWFsoUkFKFBJ1osliEWaimoEJ7o9ILWPUpEYEIMYyCHUiItPFCUSbtJdZ9orthADaCICGsGmanPSojdNyhDyyWVYVUzbnsNZIkxAgfIE1+gBVCxDNaRfJvBIA6sBjUUSaYSykuZSBHWWF7SX2bFFQtEEA+zAwkKdSTQYV9c5GJpYnyGhoY1Oztrlk+NoB67ZG5+TkuWLFGBRiRPYkTjFggyDHwxQ3TrQWmXmMayAbh32ybPVYSazd4MLCKDKKLBMsKw6YPO4CNCXixaQRAu5BLqDzqUVAQ8R58jBx0SRvcsQdBmIbHrK3ARzuSOkmommFAh9NVAZ6lLlWWS/C4I8jDQQRHYfULlwjR+ARsKvrlaFxGEcpRAVgGReggwqkpNXGJpcLQqGh09pacbSywGoq+n07Rot9vEkBY6HTQhQirL1NSURkdG8ti1wLkkpolowmTSdFCYuIgDE4QJNTSYuMShLEaln2zQpWMYrDS2zOMhLKJCnkVkyqQVI8B8jQxIi6IIe8FQHQNjqu0bnXQPvZQbCSSMAGqBAwiTRDMSBKXgiYhaAMGFRIsPmSTVt0m5ExfFDMhWjmnfFGGbzthZbplvZSRkUzywpGZoc6YbBzhbe0wmTeOC3hKP2aF97Y1zEc7MzarmTUV0srig/tfe3V6tsbExFVsSx07EaPprYiJ1tdS4gYHKUv8DrqbTRmdZQzVWEcZMoYOjsC3oDyrahk9bSGwjQgE5qINBDZKLGGjpkYeXxu5A9LTHBG2jyhZBRW+gZBd7CEUEIvvf0wPacqvQum/Wqplp82oUwYYv0CVljTr7X3RA4ThpZyv8oJFSzQtvA7mp8bcrpBwnMffiNs89Y0vGNDnpfwCLLa65oI5to/3792nZ8hVSVP2AymgOknPExHqIVkKiJBFaywjXp/CNsAmdIwopiGd729GnBbpnSZkwRGjaAEnf2UrEs6zINvTkwRNTCZYVDYpzNW3siY2Ixsu4b2ZkQMSJEJgTk3aQX2ISjkAHpO1gRm2Hjkpc/MLWghYFGmMqvFuB9b8W3Ppy+oCK6GNo18bblOUNRIQiwkL5jWTlqhV57/RrZ1+sKrV9b99YZ3jiXbFyhXxf9bxZ5clh5CKafC8JVZAObFAWD1CCN4ET1RyALW0wArRQolgLysqkJJsNklBEJHYoiAMVgTUHVto+hsYkIuQ/Swp0iUZu3lSEBQ249RoV71Tiph5v4wEUyw0ISvpCUAM7Q/E8mA4yopOAVgILm5ix9fFAh5kikDMfeEEriz3MWJ/9Ii1Bo+BPQCgLBj5Bx7kyR0dHtXfv/kbcz7Myh41EJ6Ls3btHfn1Zwtlc93pIpOBYopVEIlzqhUkoBIh+H4FcA0YUdHl59qNnssIq0AFUiKaarjJ+w6uZZZiiZhPYwmyRN1XG6scnG2VBJQW7tiTIBRvnmKo/4IucakRFisUaeeIiQoU/gQNdRCiigcYoWyGBCMAVf2xKgR6IeF6IMIPO8VDhJCGjGvWltnGfyuJcSUhCHEEjikNg7bxq4tqmZlz+CLRq5Srt3LlTte+dmIrNZcRUhjFzVRwLg1p7du3KJ96R0RH5/zlHzJxnd1ga62wtbLwl55BgYwsBaiOXKVsbmghyQex/kZ9k4yybFppk0culuDGEgsk2pXCbjQlSqxMH+pD/RCtVBIqIhjFWUzxJGbavatKO9HGWhmhMsw004dhVSFS5gD3JJn1y2cf0Adxwbm3HWrgbVQTAlRZNJgHOWlIWtAF/j3ThJC9mu1Xp4IMP1r79Exy3/s+90hJ9AaJ5bRHFrAFSHT4F7t69W8tXrND40vFmUe1XSRGh/AtoSbA0ukdBoVBEKLPPoDUb5gDvybQDEhnM++mvfwqhQoJfMwFFEVgZ0Ph90PsaCZx0AAd9wPeDRISqioQdRC7oQ0IsJwYpg3O0CT2atGoRvAjsFOwtKjQ1LJaQKaSJCOKErx+pTweXfEgy4IBfge4DunyLQ+nN7FNI/RK2KmYKlLFEyASPe2RoSIcddqhmZqY1OTUhKXSgNDQjtqhhTA3AXx527tip8fFxrVm9Rt6BhePWlk0nIXJLUCMAoYUOBYNwJGxAxYYqpqwBQhEBf6BaG9HIQpEKsxGOUQTqy5hQ1AUOKqNCUkva5CJgXJB4RxvnpMIvVoS2C4UUlSJCIemekwuTsYusQScX6NJgI8dIQOQNCaKSFWYiZgEizDTTkT5ETUkyUAXAy2YWQcoig8TYub3VHKtLx5dwZR7Elbk/Qf+jBNbBOhGJqv+tdHhZ3bZtq7p1VwcdcpCWsrh4cenX8o4JnIIs6JarA6IU1EUwgLUFPhSBRVhEI5eQ/0wZTEeESUUcwKHoy5iQIkUEUEkCG8yLAlYfggVCslijTyV2DEH1bWHlRWxY5Bb07Y1C/IUUQf4SWBI82SgCopl1QSnCrQSxuH9SMmgydqAOievZ5hHQAFUoXMFU5rHw6uhnmJHhER16yKFaunSptnOBTUxMCi81JYNCWsJGUhFPBvBpYqHpP4Saq9LH784dO/iA39bqVau0bNnS/B8I40/yBHLn/xuQWN2XMwZDFr26AAABeUlEQVQ1V0zRQFaIbWh45P6Pe2yfu7LOJ+2BzleCadsTNmMUbDFVcRzeoa03OC8hE4b287CzbwjbW1fwrWF69jPAY46qAM2GLejTjofDQrxeP7+BXHRUcMIDn6LiGAk96CLn4mcQKCyZV+IlTyzb1lx5DdTY19j7IbSo3RrKk/Ggg9Zo+fJlHK+T2rZ9u3xqepUYhppirqEGbeW1dFKN4H8aWG7pwvwCT1W7tIt7a48BLuFqXcniLl++XGPjSzMBPxmPjS3h48SSfKgyPbpkVGMJY4uyJTxy+wNGA9imz5hGU44/T9iNboxY+PX1Y6NjGuXDx6gxMDKyRKM8uidgMzpqHhvLzBPHsjFs0yblo/QDEMdy5+KYY9gvQWYYN02sJocl5D+eeeQ4sLF8CdjjNYxiOzo2ig22+I4taextM2Ye/Ti5LIG2fQLzN84xOg721beC55XVa9booIMO1vKVy9Xik97E5CRX5Q75K95gjYoXbBEGq2PcwP8HAAD//wBNIwMAAAAGSURBVAMACrqje1Prt1IAAAAASUVORK5CYII=" alt="Live Infinity" style="width:72px;height:72px;border-radius:18px;object-fit:cover;border:1px solid rgba(255,208,0,0.5);box-shadow:0 0 25px rgba(255,23,23,0.5);"></div><div style="font-size:24px;font-weight:900;letter-spacing:-.5px;text-align:center;"><span style="color:#ff1717;">Live</span> <span style="color:#ffd000;">Infinity</span></div>';
  d.innerHTML = '<div style="width:340px;max-width:100%;background:#070a12;color:#fff;border:1px solid rgba(255,208,0,0.35);border-radius:22px;box-shadow:0 24px 70px rgba(0,0,0,.9)">' +
    '<div style="text-align:center;padding:24px 22px 4px">' + WM + '<div style="color:#ffd000;font-size:11px;font-weight:700;margin-top:4px">Automação Inteligente TikTok Shop</div></div>' +
    '<div style="padding:8px 22px 24px">' +
    '<div style="color:rgba(255,255,255,0.7);font-size:13px;text-align:center;margin:12px 0 14px">Digite a sua chave de acesso para liberar.</div>' +
    '<input id="ttlf-gate-key" placeholder="SUA-CHAVE-DE-ACESSO" style="width:100%;box-sizing:border-box;background:#03050a;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:12px;padding:13px;font-size:14px;font-weight:700;text-align:center;letter-spacing:1px" autocomplete="off" spellcheck="false">' +
    '<button id="ttlf-gate-btn" style="width:100%;margin-top:14px;padding:13px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:14px;cursor:pointer;box-shadow:0 4px 20px rgba(255,23,23,0.4)">🚀 Liberar Acesso</button>' +
    '<div id="ttlf-gate-st" style="margin-top:10px;font-size:11px;color:#ff3355;min-height:14px;text-align:center">' + ttlfMsg(reason) + '</div>' +
    '<div style="background:rgba(255,208,0,0.08);border:1px dashed rgba(255,208,0,0.35);border-radius:12px;padding:12px 10px;margin-top:14px;text-align:center;">' +
      '<div style="color:#ffd000;font-weight:800;font-size:11px;margin-bottom:4px;">🔑 Não tem sua chave de acesso ainda?</div>' +
      '<div style="color:rgba(255,255,255,0.7);font-size:10px;margin-bottom:8px;">Gere ou recupere usando seu e-mail de compra da Cakto em:</div>' +
      '<a href="https://api.valoranegocios.com.br/ativar" target="_blank" rel="noopener" style="display:inline-block;background:#ffd000;color:#000;font-weight:900;font-size:11px;padding:7px 14px;border-radius:8px;text-decoration:none;box-shadow:0 2px 10px rgba(255,208,0,0.3);">👉 Gerar Minha Chave Live Infinity</a>' +
    '</div>' +
    '</div></div>';
  document.body.appendChild(d);
  try { document.getElementById('ttlf-gate-key').focus(); } catch (e) {}
  function ttlfGateGo() {
    var k = (document.getElementById('ttlf-gate-key').value || '').trim().toUpperCase();
    var st = document.getElementById('ttlf-gate-st');
    if (!k) { st.style.color = '#ff3355'; st.textContent = 'Digite a chave.'; return; }
    st.style.color = '#ffd000'; st.textContent = 'Verificando...';
    ttlfStGet(function (lic) {
      var dev = ttlfDevice(lic);
      ttlfValida(k, dev, function (ok, reason, offline, data) {
        if (ok) {
          var now = Date.now();
          var em = (data && data.email) ? data.email : '';
          ttlfStSet({ key: k, device: dev, email: em, lastOk: now, activated: now, exp: now + 30 * 86400000 });
          var g = document.getElementById('ttlf-gate'); if (g && g.parentNode) { g.parentNode.removeChild(g); }
          ttlfLiga();
        } else {
          st.style.color = '#ff3355';
          st.textContent = ttlfMsg(reason || (offline ? 'offline' : 'invalid'));
        }
      });
    });
  }
  document.getElementById('ttlf-gate-btn').addEventListener('click', ttlfGateGo);
  document.getElementById('ttlf-gate-key').addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ttlfGateGo(); } });
}

function ttlfCorta(reason) {
  ['ttlf-hub', 'ttlf-bolha'].forEach(function (id) { var e = document.getElementById(id); if (e && e.parentNode) { e.parentNode.removeChild(e); } });
  ['rfTimer', 'rcTimer', 'raVarre', 'raFila', 'rvTick', 'rtTick', 'rdTick', 'bnTimer', 'icTimer', 'nvTimer'].forEach(function (t) { try { clearInterval(window[t]); } catch (e) {} });
  ttlfShowGate(reason || 'blocked');
}

function ttlfRecheck() {
  ttlfStGet(function (lic) {
    if (!lic || !lic.key) { return; }
    ttlfValida(lic.key, lic.device || '', function (ok, reason, offline, data) {
      if (ok) { lic.lastOk = Date.now(); if (data && data.email) { lic.email = data.email; } ttlfRollExp(lic); ttlfStSet(lic); return; }
      if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) { return; }
      ttlfCorta(reason);
    });
  });
}

function ttlfLiga() {
  ttlfInit();
  setTimeout(ttlfInit, 4000);
  if (!window.ttlfReck) { window.ttlfReck = setInterval(ttlfRecheck, 6 * 3600 * 1000); }
  ttlfLogWatch();
  if (!window.ttlfProntoLog) { window.ttlfProntoLog = 1; ttlfLog('Live Infinity v10.0.0 pronto para usar ✅'); }
}

function ttlfBoot() {
  if (!document.body) { setTimeout(ttlfBoot, 1500); return; }
  if (window.ttlfBootOk) { return; }
  window.ttlfBootOk = true;
  ttlfStGet(function (lic) {
    if (!lic || !lic.key) { ttlfShowGate(''); return; }
    var dev = ttlfDevice(lic);
    ttlfValida(lic.key, dev, function (ok, reason, offline, data) {
      if (ok) {
        var now = Date.now(); lic.device = dev; lic.lastOk = now; if (data && data.email) { lic.email = data.email; } ttlfRollExp(lic); ttlfStSet(lic);
        ttlfLiga();
      } else if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) {
        ttlfLiga();
      } else {
        ttlfShowGate(reason);
      }
    });
  });
}

function ttlfPersist(root) {
  Array.prototype.slice.call(root.querySelectorAll('input,textarea')).forEach(function (el) {
    if (!el.id) { return; }
    var k = 'ttlf-' + el.id;
    var v = null;
    try { v = localStorage.getItem(k); } catch (e) {}
    if (v !== null) {
      if (el.type === 'checkbox') { el.checked = (v === '1'); } else { el.value = v; }
    }
    function salva() { try { localStorage.setItem(k, el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value); } catch (e) {} }
    el.addEventListener('input', salva);
    el.addEventListener('change', salva);
  });
}

function ttlfDrag(el, handle, key, onClick) {
  var sx = 0, sy = 0, ox = 0, oy = 0, moved = false, down = false;
  try {
    var p = localStorage.getItem(key);
    if (p) {
      p = JSON.parse(p);
      var t = Math.max(0, Math.min(window.innerHeight - 60, p.t));
      var l = Math.max(0, Math.min(window.innerWidth - 60, p.l));
      el.style.top = t + 'px'; el.style.left = l + 'px'; el.style.right = 'auto';
    }
  } catch (e) {}
  handle.addEventListener('mousedown', function (ev) {
    down = true; moved = false; sx = ev.clientX; sy = ev.clientY;
    var r = el.getBoundingClientRect(); ox = r.left; oy = r.top;
    ev.preventDefault();
  });
  document.addEventListener('mousemove', function (ev) {
    if (!down) { return; }
    var dx = ev.clientX - sx, dy = ev.clientY - sy;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) { moved = true; }
    if (moved) {
      el.style.left = Math.max(0, Math.min(window.innerWidth - 50, ox + dx)) + 'px';
      el.style.top = Math.max(0, Math.min(window.innerHeight - 50, oy + dy)) + 'px';
      el.style.right = 'auto';
    }
  });
  document.addEventListener('mouseup', function () {
    if (!down) { return; }
    down = false;
    if (moved) {
      try { var r = el.getBoundingClientRect(); localStorage.setItem(key, JSON.stringify({ t: Math.round(r.top), l: Math.round(r.left) })); } catch (e) {}
    } else {
      if (onClick) { onClick(); }
    }
  });
}

function ttlfBuildHub() {
  var css = document.createElement('style');
  var fontLink = document.createElement('link');
  fontLink.rel = 'stylesheet';
  fontLink.href = 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap';
  document.head.appendChild(fontLink);

  css.textContent = '#ttlf-hub{font-family:"Plus Jakarta Sans",system-ui,-apple-system,Segoe UI,Roboto,sans-serif;scrollbar-width:none}' +
    '#ttlf-hub label{display:block;color:#ffd000;font-size:10px;letter-spacing:.8px;text-transform:uppercase;font-weight:800;margin-bottom:5px}' +
    '#ttlf-hub input,#ttlf-hub textarea,#ttlf-hub select{background:#03050a;color:#fff;border:1.5px solid rgba(255,208,0,0.28);border-radius:12px;padding:9px 11px;font-size:12px;box-sizing:border-box;width:100%;outline:none;transition:all .18s}' +
    '#ttlf-hub input:focus,#ttlf-hub textarea:focus,#ttlf-hub select:focus{border-color:#ffd000;box-shadow:0 0 0 3px rgba(255,208,0,.25)}' +
    '#ttlf-hub input::placeholder,#ttlf-hub textarea::placeholder{color:rgba(255,255,255,0.45)}' +
    '#ttlf-hub .ttlf-sec{border-top:1px solid rgba(255,208,0,0.12)}' +
    '#ttlf-hub .ttlf-sec-h{padding:13px 16px;font-weight:800;cursor:pointer;display:flex;align-items:center;font-size:13px;color:#ffd000;transition:background .18s}' +
    '#ttlf-hub .ttlf-sec-h:hover{background:rgba(255,208,0,0.06)}' +
    '#ttlf-hub .ttlf-sec-h>span{margin-left:auto;color:rgba(255,208,0,0.7);font-size:11px}' +
    '#ttlf-hub .ttlf-ic{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:9px;background:#141928;color:#ffd000;margin-right:10px;flex:none;border:1px solid rgba(255,208,0,0.25)}' +
    '#ttlf-hub .ttlf-ic svg{width:15px;height:15px}' +
    '#ttlf-hub .ttlf-sec-b{padding:4px 16px 15px}' +
    '#ttlf-hub .ttlf-desc{color:rgba(255,255,255,0.65);font-size:11px;line-height:1.5;margin-bottom:9px}' +
    '#ttlf-hub .ttlf-go{width:100%;padding:11.5px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000 0%,#ff8800 50%,#ff1717 100%);color:#000;font-weight:900;cursor:pointer;font-size:13.5px;transition:all .18s;box-shadow:0 4px 18px rgba(255,208,0,0.3);letter-spacing:0.2px}' +
    '#ttlf-hub .ttlf-go:hover{filter:brightness(1.12);transform:translateY(-1px);box-shadow:0 6px 22px rgba(255,208,0,0.4)}' +
    '#ttlf-hub .ttlf-go:active{transform:scale(.98)}' +
    '#ttlf-hub .ttlf-st{margin-top:8px;color:rgba(255,255,255,0.55);font-size:11px}' +
    '#ttlf-hub .ttlf-preset{flex:1;padding:7px 0;border:1px solid rgba(255,208,0,0.25);border-radius:9px;background:#141928;color:#fff;cursor:pointer;font-size:12px;font-weight:800;transition:all .18s}' +
    '#ttlf-hub .ttlf-preset:hover{border-color:#ffd000;color:#ffd000;background:rgba(255,208,0,0.12)}' +
    '#ttlf-hub button{font-family:inherit}';
  document.head.appendChild(css);

  var d = document.createElement('div');
  d.id = 'ttlf-hub';
  d.style.cssText = 'position:fixed;top:64px;right:12px;z-index:999999;background:#070a12;color:#fff;border:1px solid rgba(255,208,0,.38);border-radius:22px;font-family:sans-serif;font-size:13px;box-shadow:0 24px 70px rgba(0,0,0,.95), 0 0 40px rgba(255,208,0,0.08);width:325px;max-height:84vh;overflow-y:auto;overflow-x:hidden';

  d.innerHTML = '<div id="ttlf-top" style="position:sticky;top:0;z-index:5;background:linear-gradient(135deg, rgba(13,17,29,0.98), rgba(7,10,18,0.99));border-radius:22px 22px 0 0;border-bottom:1px solid rgba(255,208,0,0.25)">' +
    '<div id="ttlf-head" style="cursor:move;display:flex;align-items:center;gap:6px;padding:12px 14px">' +
    '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAABwCAYAAADPC1QxAAAQAElEQVR4AXS8B6ClVXX3/V/PObfNnT70LgLSmyAgFuxGrNHE3ktsiYXXaNToq7GlWKIx8dUYjb2CYsTYRQULIiigMAMzA0zvc/u955xnf7//es65gybfvnvt1ddeuzz7KWegqqpWaQ2gZbpdWq0DYP0AIqJIKmNjY+Xggw8up59+ern//S8uFz/ggeVBD76kPPiSh5QHPeiS8sA/hgc+GJsHHYCLH1juf/EDykX3b+DCiy6Gvrjcn1gXXfSAcmHCxWDD/cHAhfcvF1x4Ubmf4QJo4H7A+Rcguyek/sJyv/tdUM6/34Xl/PMvKOcZzrug3Pe888t5wACfe+555dxz7ptwzrn3LYazzzm3JJx9bjnr7HPK2cBZZ51TzjjzrHL6GWeBzy5nJj6rnInsrLPOKmcB1hvONI3+9DPOxN5wRvE8ncZcnXbqaeWUU04tp5x6ajn55FPKKcCp0KecAo38jDPOKPe5z0nlyCOOKsuWrWAdhkpEq0RrqFR9aPWx+VZruLSBe8oqlVwjrxNLBZJ54z5EYFKAWkuXjuu000/TueeepxNOuI/aQ6Pas3eftmzZqo0b79L69Ru1YeOd0Hdq/YaNwIY+bETW8BvWWwZtW2w2ABvxse8d1q2/Q+sNd6zXHXfcARgD69cj36D1dwDob7/jdiXcfrvWrV2ntWvXJtx261rdargNfNutuu2223Tb2gZscyt2t2F/623rtHYdcDsAvi3ljgGP3rZrwbZfu26t1tHP7diu69Pr8FkL3Eac27Azn3ncij821q0l5lp0a9fdrsTEWEfe6+A9NsdcR8zbPbaNHtdG7dy+S1UVOvywQ3Xv44/VQQetESzzL0WwFoAWS1Fd6lyxUEjoKtoUeBkXgUUuBkl1XWt4ZFinnHq6zjr7vhpiEbdu3a7NmzZrz+7dmp2dpbOiVqv6Axhqt9SuGmi1WuhaGmq31bI8oa02csMQeLgN38YuMfRQW0NAG76F/o/BfgbHbGNnPNTChxhDQ/TVl2V/+LeRO1aDK7Xbzpf+0LWsw7cNPdQH22ZM+l+UQw+1h9TYt5r8232MX8tzQNwh7IaJZ9xAK8diehh/44w/RCzsWlXltVCv19X07Iy2bd+ujXfeqW07dmrp+LhOOvFEHbR6hQprkWekKCwWNf2Ua1VARURCHGoUubRSMqx2TQcHrV6tCy64UMuWLtPWrVu1jyuyqFZ7uCVPZKtqsaMqSSH1gfgEryXieWPAmIKlL0sbhAxmsUXoms42LXYzYaOEjIW9sc0gscEJAmtadqsViAY2ZlGknWUQuUmTTgWhsTcJpZoZIwokEXG2Xd3Hpg0o0xwLMM5NtThnADZp2xr+wL8eeDVWYQ+TBuiKefcG8rzOz83r7s2b8wQ8+JBDdK/jjlEVTAkxsgOago8ShKLIK9FnsUSGlFoYdE9HH32sTj/jLO3atUs7d+zALtRqt1VFCxtcy8AnPE/IBBQ3DBSUtUAjozoP5ialg6YQNS1QeOCWexJwUsGhWACgpnU/AwldpRHeKO0Dwga5Ccwsg8OqTrkbNrkEm7q0S0PRmczKYxqILIC2X8k8G8q+Btty4qk0AYlBLdjgV1thEq3wDccV+ijmIKjYZRzkjVkBGRpBVVVqA7Mz01q37g51uj2dcOIJebUXUWgIgU8TC4lYFU8SpDUg17ru6VgW87jj7qW7776bY3VOVZtFRIk13swINETT2pe1dSr0kTL3YtpgAeNgIFC2ZbAlZ9ZavLxwluOUAySWrxLPgXmDZ7vxaWIUYliWOdjXoawCCIPKAmLDp5rGtw9YORG6SJvGKqPQwGEnSuljx0pwg8xyQxDEGFP8qNbBWLYI6TPQERu960BPAlgckJsfQEqJibeCy7ICNnO17t23V/e+97011PZK2GoAUkSo8kSLYjGIK7PWoYcepmOOPVabN29SYbIdLJOwQXYCAfZ0NXJ7A+HuwVQyNYMhFTm9KRGskhL6IvefcWCzYkToJN3Aph2JEBLLeyhNGkS8zAOGih0utKZBciluEqAISpsqIqqQhLHVjmPvpGWpLRuJKYN1B8ASAqYA2iSIincKcb4Hl6Qb6zD2rjUJDKSJs0HI2JQg+b67k/vq/v37dOwxx4rAwB/WKm2Ja+wdvGzZMvEYrW3btjeWlVhkBtafnYIUTraPxWQIsEjbAjW7Rf1ywE6KCIUGJTissEdmSXaR2sJCFwkB+8kqIFJjmSc9os+jwVIR8ABOTGRKpKACciHWgFyMYYPU4YV+8Zjsu1tlkxwv+ggiWIfCstwIKbJwAMQiA/eR4AD4FeZnMe+oFIEjlUuKaFTcPU9FFjYxegzefaTI9sRtc1Lu2LFdC52ODjnoYBWfdEWY4Ad2ZHuLmZXP7JNOPll79uzVwvyChJn6xckUjrkcCIGNaztZ76DQgbwiqF9XrXcOdIMFXAGgamMgMnYjwwUNNaSCLgHWtYnVyAlvUYI3n71tK/KqkTqOZZCYmsMPSsQktFH22hfBY40uY+AU4REgw6CRmUdBDTwLExzQjoozqOTGs21hwQQ0NHLblaZpfEzbpagutUr+ISP3Aoj5s0yWJ19YawIQM0DZn81LUVQVF9xWrVy5XEuWjKLCE7njVA4QQeIIjjjiSI2Njmnfvn2qWs0rakGOmlAikZDXzjKDhTWdEw6yACH6pwMxUC0WQkBjBWErGKp5IzATlfFQhm0SajkQZGLmk9gYCKDiacrIZmlDGDDTh5MnIWM1YdIGDbhx9kapsXMQL5QDeZMYG5xPYWzBgA/42beQSgD6ozEyDhZFlABcjQt9GNyfZcWNwUQ/tohWAA2KJ7wwlOQd1wQCUGBXoa8Z7E5eGw85+GBl7ECpUC6oKC0u5WOOPka79+xhMdtI0oKoLFITCxqCBD0JzEzD9y0LK+nEC0ELsgQ30FlLnwE5xZrJsr1jGVs9wEEMywd+jRwvjKioCIKSzGgP1IZvdCSXKQZqA07wfR3IcRobGGzcB8hmCYs+CK2jdyh7GPW5NHJjaGSOZhCTbrzYj90cuRHIHo1okYK1R4NMZcRUm0PuCu8QFVfp5MSUWkMtrtIlg8S8oExDr2jNmoPU5kV3ZmaWBa0UgScBMijxHKSUnmoWoiYxREyQDZIiYFomRjqwADecW0ekN2zMgbiM0ou+jAcTZ2yLmv4KHTfQXGp51ZGDgJTTgzMQdgNIOUL3Ry8OJcEgwsQZQFFxVRZ0ETSLRilVRCOzaXrRh2P76jAu3sQEsV5McMA7P3unDH/EsCH7QyziRm9JjUxASshPFNMG+wX8H9UUWV9r3979WrN6FX51GlVyqCji26ympqeb8WMb1uAY1gtxQeiE4QOMqB+ksMhFvnnnYNLOtshMczR48DV0zZFUCznO2fZ19gtkWbEztk/Ql+kGPCV4hXMJ+rTUDLjpjnwgYCOQU7EW645tUc3x1oQmg+wX7FyiyH0ZiEwlBobm0STv/EQuaPAgsAQX6UcoiXHZxhE9TtmKGBhQ7YXGCMs+gupX5jL7WlQURUQCzuRNtALI/YGhCY9zYzM9NaXh4VFgGJlUFUbsx+EVK1drampGvpStyQnAs5AsyCIgRFwRlr7YEXQsBAHYprgRxYNBZt4LjYRKJh49ukLMkhgxtU6eeMhgM7ZJUiMifghtr3Lgvo4R1boGGC5WmZlqHG3v7vzlx1KRj3FNYOcUEXKBtfgeUDIurcQmSDcMHQ9ELXKMmswERNM9PjWmRRFN3DotsSiSw2CKjRL6DRZUm+PDuiLGGFFTUSBH6IrIOmQyOE7Dd3s9dXsdjYyMYFe8oEVLxsbkx+GFhQX3i6JubviNjxyXiOgQUE3LGajwR3ALmJliGfqS4IbOjRCA+rb4mLfAfgZoLE0BMLSOWlhoO91zMpP2LKbDwNYOKZDbcEsugdjQWBVCAWbQGaFuxmnC4LyMDWnQbBPMmZMUWKMIRyVDEBElcLhJEAUOc6eZokgRTVNRkYtpxzcHTScRkeaWZFwTgY5ApCYnmw9AGhQrpZmZGX44WYqw+B4qjS8ZVy4mO5s0M3nHMp09wzSudENwPEXf2EGhawhojH1VpAi6OB6Z4EUot9YkiQu8dYCHVdsRn6aicz90WrOomBywtwFdOZJ9DAWDMugLmh7SokDXXB7GRFTwVwUqqv1t574NppnTvqavta1JA74Zh5gkw9yWRSBF3Ev6uh/bwZApMmrFZNnN4RpA6Gohho09nvDOIXn0EVhTMaEiQO/TAUuykby4EaG5uTm1h9ryODhyi0bHRtVZ6HA01P3EJLT9PItqT5akiMpjIVFRQv4rcHjRQvUXxQnRNzYO1yRi3q8H1jETqXOwvPfgZ3mdmGhpbF/McIeC6NccMRJsIyKF9rUZGRCykC96NIWsQMjgidnYWVrUvI54CtBhZJ3NCzQDk8Ey87gqj2kJsSVqiklSMCLr7MfjafwsxQxn8zgyn+4bB5hsaVDLUmcRYYHkvWyfms3ooEjxwALjRdpedBER6nQWrESi5gptDw/z4beTwpRiWAjm5MzDoqsJWgD9jxJI6EuF4E7O4EScVA9FXZi4Qoi+HSPrM0YokEc4inIxCCQhtn+CGWwSEc+yZKGNbWyZWUPyaYyWOBmZ+LapawQALSlmpmA87JhCaPSNOzRy+zmxxIS0g03vORnWNYABfeWquGOAEARCnk41oekXYaEf+6D5g5pmSHwFgrIO7IwHeqKkrmatWlUlP//wLKvMq9erJSgbLYI7JSHErAFS+GSJCJeJ0TTJioKe2vAQ7sj6QRK4MRf2lEPKBTOjxgfKWgPkogwnKhPBSeFYjYJoOBfL0rhpfCUV5DhQicR2p8UFeyeDGfsLnUWOCbYswTYQVMcwpCG8yDgAh8h4EO5GWewXUGxcbHwh0C2BsUTl9c04mCSNjRKUV1RoUGyPw4DF5oBOiogG+n3DySVyQJL5XFAn1uwWD9DgwMpFDMe3gSjQHiRa8iu5CZGqIYpER8JLYNuIBIw9TDHxIg4VNVICe/LDXgiRmEJHNW974uTkWJMy92E9YBmAidyl88oNhCwUUn+QiZEhyNaNo7i/YjsVRCWpxqbAN5Tz7VOLMmuJjsoUUchLTmAxjuVCbygZ17lhacGiHEZMD16O1kCGoifPl8HG9m3mwDYoqQVwtU4KDo8C+IJUbhBiFwKDBGDtwAZhbE2IgtyvACD3g0YEQYthbgbiZcc2yGj49GttG9Pg6Ovs40BEkAdmeZNgGrrB0lr3I5s2MjYCHBUd8Ti1mM6aXEjAHgh6HEF1f0MUcMGOSozGB4I+PapQENUAStqYMOzRHIgyt0GfKG2bPaHOmBgb4yChpAdLyKeYTVqUJge0aQzuawrZMxhbAFIEQdQvpgFHKhaxSfvu2CmhML7GXxKueYWaSFBTAiZMpjfm4AyYMngwIlpoFAO6hoD1fKFjieCTcSJICIsDFXkBlAJlSR5naroIH4N5CzKfxrJpU0GsnBBEbJ+GpAAAEABJREFUOXDlvFpqH1HSz33ZPsENFsgKv/uqYRN5oXBpKo6+h9VsEEwbGYTNI0JUBdLIVrSmrBWlyHqIrDm2pCJbgSJoGu7/ty19TYMLQzJl6CsS/WGcZkGtINlENKX/yY0I7LQ6B2vac0dYSGTYO1GWDQ9PhTsCqCLZmp2TG1t02FTssIaGsDRje8IMhFMKk2DC6cx9ZefEc9jBCVHbBkHTvwMmI3v16Dd9kqMhaADWOV5YxCI5t+Z1Aql5yzMMPAEcu7Cp6BoNsgIgV8Zv6GyRR2RUtCGTiPChx0iUTch/SUKBsy9wYJc0DRGQ0DJPSbgHyTFFMWcrCSc1frIScL6I+kculE0iIvVuIJE21YGkkIsDBrQD+Ig19gCMxQTYtnDkBca2BWXP1htkY9kKjQ3Mg6moCpHtic5UMXZzwL70J9+SBPypGdE4ou8P4/68+E0EKaKZqFDIpZFnlMzRV6TlBtwzH6VtY9+QxEilshAy7dxXMx8pbho6oKZb0xQ19nRHSNPBnKWxmYKc2CZTJozg6UCWRYSqqKCdgyTU1skFO7OV6QgM4KjY0FKJLSEXHUYyzcBNN1RRjyBKXZNIypF5cAakXGc1JlzByJvOsUofGsvkAt1HaKFo0TXShk5fZKQGiQYagtronZd1xu6XIOjEENCTgZkmJ7QYWSpKRCjA5h0SbXI0ssI+hpRjYLsDCw+HjBCENy3MmtzsY0BBRYfK1RvS2IuPMWShG4A4BU7moJWlkWSbDR7oCqeEc/awBmbMsFgq5YKm8B6NjZ10pkEAEayAnUwhmLgCyRIPNkIqIakFG7OQqPGGd+JBkveUkRZ6JGFwDCTY0g2Cxg8JNJsBYcaFK2RcHKugLTSmkWefsLZbBIQZGTnWtkq4pz5D0NgERE7uGzML8EfQZyxPYYYq5GHCkoTiti/x6gIROTj8LQfZJkU0jXlfYWSBQUo3HShYK4WpcB6eE7Dz64M5R7FtLqiJAwNtHDjZbINL4SpLMmkzzs32MpPSxgeS2iRGFmpKTmtD9lv7RzTyZpPYx1momUNBM2nFYB+zxo7Og4z7Lqa9ucACGh5/aBG7b57xuCBh3QfItUCzpQv+UCK8qipkNwPd2uoeEKl3aFGK/YU9zo5doBFnbXQmi/pPaHKBk8cq+4bz9PgBaOFfANF5+tvGuSVgC64B6yICs9A9S6j5c365oAWtE4tFHOQSREKQFQuqHZoHE5jsVKrBBnfm90phVOhcwYz1fUnb0uTUn62CnwdY+pvCJ0LjW+S/GrkxPeUcWGcgK5G/a4KVhMJHB4r7R2J/xg+FJ4GojY2FGQgWIZUwzhcqg4FR2QxEP0RCTkss63BOHq2NoKGyolEEI8YsFCmr4H1SCWyIsBwDxmgqwSzR0yFYlgRrirw2jarhGY1kUv1impgFFk/avtaTXHvC0TSLI4KZaYaCT1oGbURYqQyOiVl36hgIEXtQ+KFLGdj61NFYFsSRT32czWMtSAX6ewIsE26tKeISyNNfg+2HUuwslAVfPD0GOJhUYWZOZjz3BphGhtIxfBcxmLZdoyyY0QsOVEWE/IcQdQCmCjItgqlBptbiosVSlHaD+BHEcGBRvGrooagNEbbGpuEkSEkhGRCaUr80Onk2+xIQNuRQmBuoGvBgkasfAFZZ3LmhYayFCqAoIhJgFrFpQ3GART+6gs4rs1gLDDCkTY08+IDwMprOGLbzRBhbZwOwF6P21Ulc2H61R9+QoI5jKF50cjUiE3JtbJq2cS0w1oMU/Dm+wf726VuJMH3Air4DRUVDVQNFjQ0YnWsjN9VEOqCBL4BzJVZjofTXYsGbKgMy5xkRog4WlAh9ZwuxcUSgqEJATVGNJ9XzqtzNXnQEeNN9LUeMCLl4oTyVXOKIkVEJiG9jbdo2DdjjAHjS7Eto4SzbFs+smMpSaCMBUqK/Aigg3SCk4oKA/BwLhlok9BHI5UK+LL65ynKrGQWkioU2QRYwjUuxahGacdXJ2zR5H6FRmDNsiTHwa067kmZ2KNgVNX9CgCmtsjhf86Jf0sv5iojUFwtU5DkDpb0b1GospMqCQpOTkDg5YYFPiDkBIwtEVcjOohhHmA+lkAQwZOJquWQ8N7gWMFaYucUEwxwOpoONgYmCv6zElQE7RuTqkOCigEpfCJs4diFIYuyL9QSr1Usu7IEh1ZqUFSY04IQw/bB3+paxHk4w+7JJMnilDnsqnDTg5cJEZxzTBhuBiy0xNNsAEmwRianMGCIXpDLjhbJd8siFv39BsT0kJklpUEouDiN2/jZAkQsamEIvVvQMyGwT2ry5vLH3mT6yGO8maMaE7Dsrgsjc3AOQoCVa0vQCDJ5WCeTJCDVlgM1lKIJGeilb22ZW+DX9YBXoALkMMCtE93ijx5bWWlwKcQI5LHKyUT7oFVPIqJ6UJgxC+DRGQMVXzWKExK/DankHhFLeLIh92KnERoxNKP+tspQ2iwtpMzXFeWbv5CyszBsKdI6XWETUoFjmnAqCRcCGSn8IHaxR0JJFRbQICAOeDmDwkWtbA9r0tInpilkwXUjCCsfw7mq3Kg21K7UrJpHd6X/x7X8dMc8P6vML80rgB9pOp0NPNd6hiMjEoGSgcW0AnfrFC+tB4MhCITQDUM00MpTmnb8BBRK3jMIKorqPQGRAir7AGUDUiEbTLFjI/2a5Yjy4yj8E9Lq1FhZ6mpvvaXYODCx0eur2ivyzZIR9QhGAQi7O3TgiUsL0gemTOQoUAceMMYaafCwwR3Y2MfQ3Emapr7lIfOw7jmou3YIgB2zjNCm2JZLApj3ZBFRTIqIhihRhOuQuPegWg21V7F8mbI6FmmFwdXtIK9ccopOPP14XnnaaHn7OOXrM/c7Xo867rx5+37N07iknavmyZfImnZlf0Fy3Kw+6Io6IH8Q0do45FverUBYL0hoPB4CnayYDIwyQ9mkoFI5hyNHAo5TzNmBuFlQamamBTZFqfjeeZ8Gi1day1St05rnH6ylPPkd/8bzz9VcvPE+vfsE5euVzztYzHn+SHvPgY3TmyWu0ZHyYhQ8tdAs3AgKSNkMiPnS/ZheLY2jytM3ACJe0bPJOUikjJ+OUQ1dWDQZCPAaDFKENanaLEJoGoavNgt1hrezQCsB0xaS325UWGPR0t6fDDzlMf/rQS/RPz3+mrnjZC/StFz1d3/jzx+ryRz1QX3jAefrsfc/Q5y84G/p+uuLRD9a3n/44ffkZT9JbL32YHn76iVqxZJSF7ahmtFWrJTlzgN7psWlhyUeUJu8cC/ZhC0SQuJWEHAeWQpfgxe/TjQ47NkPlrjygklZYFC2wwbqcG6ecfoxe9oqH69OfeLa+d+Vz9c3PPk6f+odz9W9/fYz++eWr9Q/PH9O7n93Se8EffOly/ecbjtBn3nofvfPlJ+jSBxyq1ctH1OmKBRY5icI4nKT7AgKJa3YPE/Sei4QN1SrGiyFVmX+KaIJ4QYaioCCsGmAQ/YVEIJM2xUoRUH0w30yCfKWrxWL6OJ1e6Oqs007W+1/0bH39Zc/SRx5yPz3/oGW6aHaf7rV5o1ZvvENLNt2loW13q9qxRa1tmzW8+W4t37hRJ27Zqofs3ac3rFiqL15wrv7rGY/Xu574SJ1+7OEcaXPq9Dp05vzINEQJpyiTOVgTKW2IpkVAxYNWaRsRiqgEkssAD+gKQbsK2WCB2R9bMqanPOUB+vIXXqqrvvo8feDtF+lJD16l0w9b0BpNKmZn1GHcc/Md8pzXvHnG253crnr/Zh0Sd+vhx+/Vu563TF9812l681+cqpOOW6k5jmnPobuqVYuRKfir6D/gAjrAIC2CJNQ0klKpLJ4Jr3FlrixOCxbsUHcyADsVmkIU4+zUZjiCrEHU0/7pGd3r2GP1zyzkl5/yaD1v9YiOZrHK5s3q7N+nrv+JaKFbJlIcV2oNScPDCYXjuHAFdjn6O76f7tmnobu26oz1m/SqaOvKR1+iDz77yTrz+GM1Pz/PFVvzoFHIACAJL2ZEkEukrMmdtNiNxcBc2QalPNYEy1MIB8YdfynIzzDXqTU8OqynP+vB+vqVr9Gn/9+T9fiHLNNh47vUm9ythZlZdTsez7BKtUR1tUwxtFJVe4WGR5ZqZHSJRoZGNTQ0pKHWkAir3vw+HTGyTa94bFv/9aH76m2vPk8HrxrPhY1w35IvsYYOEV0RfYxKmaf5YHBUeIsZlFWQxe5g2YDJsaa2oZT3VRw8IT7GsMDQNpFXZFWFKjrzf7Y/j90Ln/gEXfGMJ+jZmsurbX73fnXn5xRzs2rNzkrQhcXgJqTav7eylQpQh/uqVbgSKnZ4Nbugivtu9Lqqux11dmzXsutu0nM379RXHnSR3vy4hzMJK5iEjkT/hb5BzYCgC5uCJWIkRS7Wmw9mlK4sEsrEnjBbWe9j3ULjOfI47/yT9PnPv1qf/Oif6ZJzx1TN7VZntkfuw6rabbWip5YWVFVdtUeKRpa1NLJiSKOHjGj8kGGtOnhUqw5aomXLhjQyXGl4qKUloyMaHRtRrzOrVe0detMLDtZ/feYJesIjTiWnUNWqck4jQlQghGKQbvLO1YCCWgAsMHPeZio3ng0PnGwhbVRUVVihdDsIUAmOScPIFMfLgkaXLtf7Xvhc/f0JR+jwO9aqOzUlbjhqs4Njdl717Bwwq2Ci2wyoxX2xtXxc1fKlqpaOy/xQO1SxeAX7wgNRDfTmOmyIjkqvp17pambrFi390bV6+d5Jfe5xj9TjH3ieujzIMRxyCQZd1GxCWUSKBRk0M0PWEB6XsC2Asc0KDXaMyRuhw1Mpt3698EUP0de/8jxd+uCVisld6s521R4eUZuTRBpStEfUWr5EHRZy/Y7d+tEvNuhLV9ysj336Rr3/32/Rhz59p7529S798o5Z7e6Nac0RK3TE0cu0avWYxpaOadmKZRoZX6oOm/3se3f0mU88Xq955UPEUHPeq5ZE2uQGluT8c30kFpwmlLLIthmD8siWKlFsPIAMlI1kxFgVokAwdBOyYJqr7uBDD9G/P+/pelZnQnHXBvXYYfKxyqz0WJyY72poZFgT46O6jkX6+JZtevNNt+nl19yol/34er36mhv0xut/p49s2qHrWPDtwyOqW8EV2lWP+F7YzmxHC1wxHfqfG6q0Z9MWHXT1L/SOY4/Q2/7s0Ron9gIz4Ryd3wB0z8JAIkIR0ZcyCVHgpYIEksksWrlyXO/9h6fpg+9+mA4a2q3e1B4NtQuT3OYVZFjiGNWyEa3duEfv+8A1etqzrtKTn/JNPfNFP9ILXn+9/vKda/U377tLb/7gJr30bXfp6a/bqD997R16zts26ePfnNCuhdDyw0Y1TIzW6LjaS1fRb1tL6j161989SO94y6VsYOcU5Bb0K4o3q9S0jM4JA1AYJiEINjCImgtaM6ziewqCuoYDaiZYhKmYhMIiCTzwmp6b06GHH6Z/f+qT9NBtd6m7a69qthXfCsSTubik1N2bxqMAABAASURBVF6xVBuWDuvv192hx375Kj3ms1folVd8W/989c/0+V//Rl++8SZ99vob9ZFrf6k3fPdqPf6bP9ClV1+rl9x+h77Tm1V3ZEjMovzaM8/DwyyLOgMsVKGZuqt9P/y5Hrdpmz72hIfp5CMP4n22Q3q1CrkXxikK06KAWQTG6WEEo64gWoAffvy+ePQxB+sTH32+XvX8e6k1s0Xc8FRVtfyOKcZWjbd1w/Xr9YaXf1lPffKn9I53X6vvXL1Zt26a187pWgv0WbiyWm06Bi+A5pjDnfs7+tENE3rjR7boUS9dpzf8wwbdsWNOQ6tGVdrjipGVZLVcmpjSX192f731LY9TzXttFeJILzntEaHmj6BQOLg1SrC0gWiuUO9QX7FeVK+2shSMmSDalJEccdXtLnBkLNeHnvAoXXj7LdzjdqnmI0HN1VhzZQ6HtGfZEr3792v1yE9erjd/44e6cdNWkuxoebul5UPDWgaMD7U01q40PtTWGD49PjKs37tXX1l3p57zs9/ohbfcph/Mz6owsi4PVJMs5hT32XneaTu8FvV42Ni2dqNW/+wmvffiC3TBCceRW48BEcz3aBbSeTvnHD1iY8KJE14t+Iqmy9V90slH6Yuffroe9+BQd+8WtaqOqmpBdW9O1UhLd9+9S2+77LN64TM/oa9ecYt27J3XXF1pvlazgSUtGZI4UXX4Mun41dKph0knHCItHW1sFrgotu3r6YNf2KlLn3+j/v0/f6d6pKPwDoghZnmYvif0ulc/UG947Z/Qd62IALyoRRBqiteliOXApy9B3VBi/FDmMZFCBwoTUgzs+PQMLOB7QyN6+xMeo4fcfZe6+6dkGzHR3FB5qmvp+vkZ/dlXv6l3/vePNbF/QgcNtzXeahGi0hyDmolK03Q7xdPrVDWkyWgBFRBaaHHpoK+Z5O/t2KmX/uYWveqODbqFK1IVfvQzg26OBZ1jFy+wMXZPTmvPtdfrbeedo0tOv486HBMRoXyQq4wlEBCAkEdCRbyFTtHJp99LX/rMs3ThKVJ3Yp9aQyGRbc24Y3RU373qBr38OR/RNy7/tabYtPs6lSbmMEE/DGJP5OROItsxKd29T9qwW9q0X7LuwTzvPO0i6cyjitjvCCUv7Ov+bp0ue+0PtW96l1qjXXosHGwt9fbv0d+87mF6ymPP1xxP2hFBL2TE/CflxUrJPRrLDIiYQdoMZ4xjkZpjCwuSrq1jxzvYJPfBZ118oZ6xMKWFqQkVrrLwVuGlexT68q3b9Odf+Y5u2rxDhwy31G63NF21NNtqq8OTYY+F7ZJglxlODN0D6qgU2BWwj9QJhTqkM8MG+u/de/Ty2zfqM9NT6o205cWcYkGneYCZoe9pYu5lcX/34+v02tNO1aPPPJmJq5nMUBWhVmUQdAGMGWO0NM+VfuJJR+izH3uizjx8D4s5oYqHnoKP6L9u8c74b7/Q+978Td3FSt05Hdq4u2h6oVbdqiT6rUBtgFs7/SEKMVvSTDe0eSL0y7ukr1wXun6j9OAzKr3xSaETDhbPBEXtkUqf+dp2vfwlV2nbjm1ygBajruqOWgv79X/feqnufewa+etSIZ/CWEXJ9MDuaUAPsGWkk1rllYaTcUFkIA42SWmWY+/eRx2p1xy1Uu0N69Vy6lwtRT2NjA3pil179JffuUbzvJqsGa7UiZbmWMQaCBarIliFD/N7oC82DF1JZBTiD1xh0GKyOlVLU3Q9U0Lb2TAf4oHqX3fv09zosObFpBGLW5dmWdhZfCfZwT/78S/0F/c5Vn96+gmaZ5ELl0ghZmAPwqpWxb2lx6Vy+JGH6hP/8jidefAuLezdryp65CWiDmmuXqIrPvR9XXPVr7Sdh4Jbd0h7ZzihiFMDXTZD4ZnDD3CkKvay2uRNZV5EP0W+b4vSwf/mu0P/9u1av9lU9JZnt/XMB5ARG2PpSOj71+zlmP22puZY1Koj0ub1aFLHHTOv17/qElVF6vVq+bXEAEv8IF9iyKWQM9gDRFNBqu4vpB2aUZUmoRKYRDov4PACJurY9RvF/DKjHe6dXQ0xQdfxRPq6n14vHgi1lN3ro3WekUZVqcVVZqjo1tFA/di1sqAvAOFV0VRcpT4u6VjCn3d3TZPfQpH+i4n/KK8JM9w/LZ8k2CRy66dNc3P83k9+o+eceKyeCMxzokTUKlWtYGZKtHl4aWs5D2z/9t7H6n7H7NE8923bcGGQV62Z3pC++ZHv6+61m3Xjzlo3b2KhSbQVIkbkhD/3affSh//xoTryiJVs51C0K7VaBZAYhCKCbKD71RyPGbryl6F3X170Z49bouc9uq15NuPoaEvf/v4Ofeg9P1A1NKWqnlU7ZtXbs1VPfvzhevBFxzLfNbFDonquEkssVaGlIoeDkHJBk7KOiU0HBGaDJiK47Hu612GH6okkPbdrvwq/KtRcsa25BW0n9f/zi99okvvbEhZzgU3QqSr6LAp2FmrBiDByCTeAsQEydaYbm4LInFLeQmjOHy+4TenayUl9bscOTbekea6qSTaUF5PHJ/mI3k8Ol//sZj3z+KP0kMMO0cxcFwumlLxqMeyqrXe87XF61Om7NLNrq6KeV9WdVVXmNcHHj8/94zd08++36HO/mtKNG+fEW5F4LmomFH/Xxz3xZD335efriMPGOblKLmqt4MKQ2HsJztm2Ho1xCwGHlW5aX+t1H+3oMY9dpUsfMMyJVrRkrNInPrNeV//gtxoam5E6M+rNzWhp2acXPePU/ChRMQ+soEP9IRTYPtBFs6BexGDmjVHjVxpgRSvkcwj/9Lgjdfj2LSpeJG837/5K+sBtd+pXLPI4i7iA3X58ZpjCWY6kDr7Oo2Kw7izQRUTTqYS0JI1YdEh1ZsiZ/EArsGxP7BbY7JRC183M6Rvb9/BNqpL7mqYv31cNk9zvtxPw879Zq2efeJzOWLkyf9LilJVff177mkv1nIeF5ljMKiTVC4relKa7E/q391ytq366RZ+5ZlJ3bJvPxWy3QiPcQkRqa9Ys0eP/5GQdd/gKVfOTev6fn6I//ZMTNcrzAg/h6pKgT7k88RwbIG25nxZNRe6j3HDXbujqrR+d1jOetExnHMeG6BZNzoU+8qGbNc3339KZUt2Z18LEHl1y4bjOP+sQ7rucFFxwTJIMhCaaW8EDcAWoTBpqN+jTB5oltZ96bLk142O6lMfveoJrwTY8SQ5x//vF3Lw+sXGrvJh0pxmu0rP5dHchV+59+SZ7PJ/vCMDur1UxIxXBA78MDM26yzd794Uam1DlGaAPI1FYG2RSRABE4Sj3/fLGuTldw/tvL6RJ8pngfj5lIIcZ8Cbw136/US856V46bmwsf6t8+p8/SG989mp1tv+O7lpMGldvZ45jeEEffN9v9eX/3qyfrJvnKbSjlo/oIrXol6HoIQ86Vt/66uP15c8+RGedMazu5JSe99wT9IVPP0gf+9CDtHL5kEjDiRKbOcZXlCpErBBpq+XZRj42Il1zw6w+/MUJ/ekj2xoZwYan6x/+fEJXXfE7DY1OqtWbkDqTOnh8Qo9/+KH9mCF5QkCihPgjPyocgbFyFzDUhlc6QAe7TUz6PAtw5sqlOpkXX987g8kqQM0T5xe27dIkn+yWcQ/Zh+woAl46NKSVUWkVMOIYyHz1Mz8srBIi49NwZXkxg34yKRTmFQcmRC6YWo9aQT49ZDuw+QWfzm7ds1+FmZwh1gI6g59gO9Dr0f/wzs165OpluvQR5+o9f3kv1Xf/Qr0FqcunxR63jard0+e+tEmf/foW3bY7tN8PP47FVeOrmh9RdNJJB+mj73+ozj2+o62cSHfczFNSmdaGdXepO7FDT3z4Cr36xacoGGSQl/MnRXlymwUtqki+srIKbgNFy8db+sH10u2ba517ElcoL7XTXelrV27h8ylj6k5LC3Mqk/v0sPPHtZyvS3Zv4R+DDohpMgIJMOjT2HIwM0cNKKY0ZT0MLx4b1vDeCe4NtWpG2WbA23g3/NHOPTqY90wbztVSxdHzXR5MvsZi/gBYh68/NLSIl4NzbMA0IpZadgVCWbwB0PuqTZ4G1hcyfQtcwAdgLxvher4Z7+EIFos6T17znCgL4K5PBwZ84+4p7V61XP/8hnPV3n6NZidn1eHqrjldhoeLfsS98kOf2aS7mb+ZBfcm2bXDeHpkxrrrhX9+mo5cOqudOzt62Rt+q29/b4e6fL16xWt+pn//9AbiTeuic1frkNWj8onmgTH0vCJbDC0iVPxAxiYZ40J44mNP15c/9yTd/35r9N+/6OmYQ5kRahf47dpZ3b5uQoXN1uOevjA9qyNX1zrxqBFiSBULWhEvIhTRgEIq/EWECCGK2WYwQtifV5touN3WuZwX9dScxCiLF5Qnxxv4uWwfna7k6pyvQ6PYTERLcy2uziq0DBgHWlwpPa5eX9WsNeHpi4UQ0bPSbSgaFjnV4ly4Hgvj+/ofAPkJe9ZKLlwr+tXMDBPMmyv9dLmH1gkFWU/LVo7psr++WOO7rtH8fhaTS67L9+F2zOj3d0/qje9br9t31bzES9VgNoLITEIBDmWRHnD2Mh5S9uuHv9irb129iWO4gg9t3lPrnf+yTs955Y163quv1U6+IJGySE9MQ8bzglowz0eMc88+VF/5wrP16U89SQ9+0MEaqnr6/dbQvqnQsQdLHRzv3FP08+t4MGJX9XgFXOChbs2Sni6+7xo5NlOq6A++5Nw5OgkzL8zsYEGZT5RU5fEnqYqKm3zRQRyhR/IQNM/i9fhS0uH+2GOgN07MiodecdlwDyrygu5Dficwygf5dmsoj9f7HHW4HnHhfXXOiRx3XEVigXPesjM6ojoRhUROcvGDRQ87X6nW2dQQzHhEY2jecXwC7GNka7nqhojfYiLcB3tOfhd9/SvP0yljv9XU7r3i9VE97q2lN6MJfjy47B/u1PV3LGiODwEtwrbpPBcCujkixStEpd78FE/2k7rPvYeAVZqe496LbSGXHbsWdPl3tmsLuNcrwlXtllh0AJswkB/7XVu3TWrT3RulmOLhZ0ILfpJi+67dWnTsasl98nqqWzdM5qtKF6Y7X1TxgLR6aU+EkUrgL0rTlwqkezUGKrNCwKEgF2RGIlf18D2Y+8IKzvIFfqNc4J7kXTPL2+/GmQUNs2XmuCpqogZ0i53jl23voqVcua9/+hP1uT9/rD5+76P0hUsu1t8/4RFaxhNBl8ya/mqxb+grEuQF44NCm9E3i0kqUfHQMMyOrzTUHuIdcoW8YdyHJ59nCfF+rt0s1A6evMfJww9sc9PzetZTz9Wjzp7Xjo13abYe5vVLXLXz4uVZf/vRvfrBDXP0KzUzpSYXSaFG1OOI3LRrVp+7cgPv2Au699Lt+sJ7T9JDz+6qx73z1OOW8q22zeQXFkPKhawkhi7TpE4gghHQV9UCF8bJp6/Q7p07tOWujVo2jo7eNu8uWg091JK4Y2jrjnktzHQ1z8ZZ4CFzuNppAAAQAElEQVRzYXZOR61uyX/dXgubwSoVZh4fNnLNuCNClbJYYaOi8EyRgMU1E7+MHoYJOs9RO8+kdQk+x1XqyfMizvIagwmBC5GDq7ZSi6PiNQ+7QC+Z3K+DP/45DX3pmxr/5Ff1nN/fqQ+feILG6MNPxK961av13Oc9j3c5rhIW46UvfZme/OQ/1dv+79t00f0vYp6LnvH0p+vpT3+qXvKSF+sLX/ySPvHJT+gxj/kT0aHabIB2uE8xWL6fcpxOc5W0mIhHX3yyXvH0Y7XrtptZzFEWs+a1RapGh/Sxb87qk9+eUDB6UqEfwpE+w1UEtJrCeqpES5/8+jZd/t1Jbjkdnb5mFx/dF1T279L7XnWYvvEvZ+vlfGhwLnStdjvkjUboDFTD9AjqB8pX/eVpOvvsUb3utT/R81/8K63fOK9Qke/dY0PSGLuT7jU53ZPnuMMN3Ffx3ExHh64KLeFNI/hI4jwNtb1NiK5YhAKd/cIT1i0KhMl4gEQfZfXFcbvQoxOOwVnwNAvr14Qehv6JyAPpIa+x7XKunXDIGj1+tK3ed38sccWFH5yYudl1G/UgvvM+dNky9eju9LPP5gnyZKLIJ7fOOP0MHXXU0arp50+f/CRFhF76Fy/Tfr4Q3e9+F+jXv75eb37jm3TtT6/VKNuZ8atNnDwuQ8Qs2svme9ARh+jNlz1Es7f9SLPztTr8QO782kM9/eg3Xf39Z/dI2HOgiI1tMnnRn4fvhIonqCYmR/iuiXm96O9u01/83Q5982e1ZjvD6TdcT+k+h0zrbS89TB94wxkaZ8zpbz8Dg+wSZ45j88mPPVSXvXyNvvKp3+jK/75LN9w6r1vWzYpPujl49oGW8KnNYxG5dbmAfEUb5tigLd6XW61ahecDL1wD8CTry9FzJujFBSUGxogyI48vUBdVDKhmAX2FzrLN/H11HhvfozwhNTPSYyF9z6uR2+6I8REt28Axhb24moNFFldt4ajW1JSO94u6JE9ynUspj0HBohfiXfH1y3XeeefxvncmMunGm27S+NKlesYzn6F3vuMdOv5ex8oPWS36q8iyhV+0Ki2N0CNGR/Sa1z9NQzuu0zQboceOrhlDu8xpy+55vf2TOzXDIi8ZkcaGlb0XaXHshBRrwPOD1PXpw+aqiDHLU+3nvrtXT3vTnfqvH01pbKzSLbdLM/Vy7du9S095+Lie/LAj1eHhp1eHetzravJZgD/7lHH941uO1I+v3qY3/9063fvoFTrvtFVatWJYdUjBKjAEeVqGoFeMt3mWCXV46l7gPjo/11OX48K59Wo1uYpigQGyy1wXaNzhCOoZDTBVhZUqqvM8nsNw1pc+i9JlpB0iBhO0iq00UpQPPkTAPbKniNDk/mnN8QBVs4CFhezwajHP2/kcu2yBe/KkHQD6p20qoVjgrrwwv77+19q/b0Jv+ts36dbf36I7169XiwX74Q9+oE/85ye1ZctWeQIYm+xHz3zcaOlS8rvsVU/SypV3avfam9Wr2sTsKXrzWuBj7bs/v18bd3SzQ054rR6vND4S6hEEV9UEZHhaBOQMLCeQPc09XOpguIcrthfD+ssP3KXXfmCjSoxpas9ePerCNRoZbqkmIS9SjwEeumZY//y3h/MwNKfnvmKd9nFFfOxfTtW3PneSHvmANVrohQqDoWsWUfKVesiqFuOrxUWqHnPoC2rfdIeHPBKi5gCyoaNMUBpqsQkiVIkSFiZItq8ZkXenj53tDGAfkT2QeeTzXI2+0g4bamuYACP4O4ghoFuM5BZeD24fHtV8u80F2tUsQf0psMti7jpkuX4+NY2l5Bf7hz7soXrPe96tP3vKk7XAoo+MjjGQWr/4+c/0lKf8mf7rqqvkCe9xpB951FE647TTddzxx4nPyUxuKH8EiJYewQPHZc+5VMc/8FBN/hQfdbHpqNfraGi4p49/a04/uqnDfVcMXhrlcqhLpVOOGOF33JAntJBnYrLzWAyQOmJVWy98xLguPX+EeIVJIy5H+yxXz0+u262tm2d4iGFMfHXits7Chxa4olYua+lf37JGfpB81itv1+ZtcxoeKlre260lvb3EoUNmnL0q9r+4ZtSmw+MOG1Kw+X0y1ByxMNqwZZ65pG/mEJN+DbybNYtosq2sicFiMqICeEsWB2LLekH30m8uKJt7nqOky9eh07iHjSL3MRcRkkEE5yzeyT33HRu36HcnHKUp/9xlHZ/fZo85Qu+fmtHtXLH+VwqXf+XL+u63v8Mg22rzZPv1r12p737n20SRPvHJT+qZz3qGvv+d76mF5DOf/pRuuOEGtYeHWKCRXAA2N0+fRY/sdPV//uRinfzsizV91ac1wakyxSkyx0PSMPfNb/+21ueu6XHfDY21pWXcuJZBtNttDbcrXXjvMXpQxmQkSTtlUuIqHtIHXrBClz2sp5c9rNaRq6qc2M78tPyacc4pS7R6yYxmJia0dcse+eeyaXbwfY5q6SNvWKbde+b09Ms2666t86q8csxvZ4rFmVpQjzzd2TI+cEzMSEwbJ0alU+/DpuatotWSqlzAWtv29mxKn5GLmE0URUoFW5LKBS3OHt6LWbiHFTrlwuSJtWg/xBYWtgZ30dUs9Azn1eljQ1rKVbqakBX2Dlz3empzxLZ5PPnp1t16OYv6HyuX6bqDV+kbq1frJbv366s79pGUNEK23//u9/Q3b/gbXfZ/XqcvfulL+u53v6OfXfuzTGwrP5Z/7rOf1/TUlFrk940r/0tvfctbgLfqe17kVqjN5fBwPnb8zQXn6D5v/At1vvIR7Sb+LvKZ5D5ZRU+3bJL+5coFkbpYx2ZRR1oaJndfpZPz0uEHt3W/k5pFZThyKTQVg5phU/i9cOP2DldPrX960aiOWzGtO9fv0PMfMqRXP7atPVt2quZZ4ce/3qcFjsgHnlzpHc9boh/9fEEvffterV7a1ufefbje99dHa9mSlmZY0Gleqwpf2+hGK+h6814WlAvm6KNGdcIxo+p0gnkKsWaaZ/7vpn/n46UTxfmxilDY0KqfeC6oKGkAdi1YFiYlOGLnmIkbCFiR6DwLBqkpkj9yuNLJLOqh9OIX+g5HsT/GPwK/bqcjThat3T+ld2zdpefwEf3VW7folxOTXAWhuoS70TA7dpQPFyNDwxyD7Vy4iEZng4hQhEEcY22NtIfwaclX86gqPZAr8xX8THafd/616m/8q3byvnkXx+g+rhA/UOzYL733a13t5r41zskxym4fGm7J9+OhSsQMnkxDW3cv6IFnjOq8k5aI9OlTYlhJd3tFH7+6q7v2FTZLj99PZ9WbndNvfzenw0entffuPZqarPXpH3T0g5vm9MhTpD+5b6V3fn5GH/7aDGOV7ntyW488Z0bnnzgnHoS1Z8+stvN+O8nrSDDQZaOhTXuZFy7CB56/RmMjXfm251teqyL/yQX9Zt2ChHHNQoFMwoeYHsA45FK5CY+CRTQ9IG3oRbXsZ+h8/+uwmnMs3CzCaR58HnjECq0mwhr4BRZ7hN6GCDDJgu2zTJFXuTeC8K2l3G0LbJQOtj3AmyZ89BDXM9jkgqErsYwsG+IIHeKobxOnzWw/APw3B63Q/d/9V1r45v/T5qt/rlvLkHZyc52YqrWPJD/4zVo3b5V65DhPoGVLgg0hNk9oZEgaH5aWcH9dyUv9th2zeuYjVuqM48achoboo03+7aqlzfuL3v7VWt/6XWgbm2T7Dmk/m2R2odbejvTJq4s+9d2Ozjk61MLvH6/oaM9k6KVPWKn7HDWiwr1hHttZPjl2GfvePR3t4H5615Z5HbdG2sMGdL6rVwzpCQ9fqf079qpm7B3u/612V7dv7mkn/XnJuL64SEMRBv2PUlmSVySTSxSM2QJUCCnEV5jQulalDRxvLRZ2lo4WwJv56H3G0iEdvXRUpzLoHonuQH4C3wOfBv4zSeeDe9iLBa4J5qc/Q49k2PhcrYXDuWYCyYA+qUIlul0ElERS8l5Iw315SLts2Zgueuer1bv++9r0zR/p5hjSnbwi7JwWDxihz1xb9OO7pJqr0g8bk0z87pmiNUuKlrZ73EfBoz0tH6u1crzWivGivYzpr59xjE45aglPxfTZrui31pCKHPcTPy16/3eKNu4SgUNXXB96xxXS5b+s1WNAN9xd9N+/k6bmQ6978hJ98KXS658yykNRER/b1GFRvYm75P/jG2pt3dXTYaukDTsJh/9jH3WYjj64o6l9Xc1zK+mw0Qvv0N//dYf3aSkiVKKSBGZeqfKcyYVJM21tI4QrDSXslYVFbBNkmsf/n7PzbDzPlTHL1bKXe8tdOyd0/3uv0b0wPhHbW9kUHyWx38PfRm+bRMcGOkNE9GARDQVc51rVLDYPhOylTEAY4aEEN3ZlTTgCQxGhU9k4r2MTXfLWv1T9219q02e/rd+NtHV3XbSPn3w4cfW9tUXf4pNpHYSrAUKLsperdueUdK+DQys41paPsJBjRStGa61aUmu0mtf89A695xXH6ESefueYVDolN3ImDuG0fb+0k4/pc8T8Pd9gd08WbgHSREe691Ghh50deeW3Soen3ykt7JtRme1qy90Lmp7sMY6imzZI/3HVQv6Tz/U7Q3xF1fFHLdPLnnmIJjZtU6fX5rWdDkpPvrf+9OY6+2D4jMIVXaIi52TS2OA1YmILMkN/8JCshyIwYSF9r/sJ9G6sFljQafQTzPxNG/drtK507rEH6RJJh2FzOwP/Jfrr4O/GJu/qhCEYi1iQAOgx4+qkvyioAOxDzR+kIBvXgAR6kk5iMV+/Yoke89oXa/am32rtZ76l3/AeuZ6cdvMQxJrqls2hy28XLy1Kf/1RuWtPT9snejrjSBZyuNZKHtWXjUpjQ8G9S5rnCbw3uU3/+IqjWNRRJrtWl01X7hHn+78vet83i3yPdp9+5Th6jfTqx0tvfqp0Bkfv7smu9nJU79tXa4F7/Z13dTlmF/JK/cZPuzpkWcgPZHtnQqv4bfQf3nIfLe/u0tT+rmYJOL/QU1V19S2u/o07C88XJEASTIU8N2KuE0RB6Dy8ZrmgzLJrgmeB/LGNZqEJ0kKzmWP3JyxurdA+eDaq/AT8vZs2MfCDdMLq5XokuuUEB2lYSmjRsUU9fHz8+sjxvblgVLBBrIhI0D0W1/JUh3JxzibjNx19kB7zymdr73W/1g1f+pau54vKWpLd3T/KNu2RvrKu1jSOHljGhx5UyxiGfrmhp/V7Kp1ydFv+YjTKphhqF7XpdCik3bvn1JnYqQ+8+kjd/4yl+V6cMdCRqvbRwS7A/97oASdL550QGiL45i1Fv/wN92/u4Xfv7Oln1/e0e3+tKS7nHTtq3X5XR9N8px1nI7E3eViTjloa+vDfnaKLTtivret3anIuOG57qnkP9dX55Wu62TXPpKwHF0ByJCIDjBNioEHu1pIGwj4TaRSWW8gO6Zsxmdzt9W1+QtjAok4ziV7QSax2spu+c/MGXXTm0Tpz4o9wVQAAEABJREFU+aiezJm3mjg+7lrYVu4Qu0HFVQbWDquS4EwrBJlMGVhKvtf6uH0Esreffi899BmP0vpvX6tffPenunlpS3eqJ/+bXD8o7COZr62vta2nLLiIkSxCCmnoRsHt4Vt8071je60TDhMLWattY/Tc3pjMol275rR363a988UH6c8eerAU4TQ5+irmRVmOWCVdeqp04dFFfGfQVjbUXcBOctnBcbZlu7RnomjDjqKvcWRdfWPRSYeH/Py3b2+tUw4Z0f9733l69APHtPG321h4aY6PKwvczqpW4cm5aCO+THv27QuhSTNIpwDBWhUJ1G5VighV+qOCWsJAFF/CQlB7QTnWdvHu+E08ZpmVCZQzKBewu233tL5z85160Bn30iMOXamX8JB0Cvdd34IWsKvpCLMMiytJmCsND+mruMKnCoLTd6+iAU7C9zW8/P/TRWfqtAtP0TVf+J6uvfFmrR1raRuzsp+HoGABJzm2ruSBZGOXYFS8af+wWpZAU/nwZ0xfuWZBv7yt6DAe1RGrLi2uRnGFcMxySezbN68Nt27XXz1uud75V/fR0YctUQd5ROQrz62bpQ9+W7rq1xK/9+tm+LVbpKl56dZNRd+9LfSt26TNk9Lt3CvHeQfdOyG1uD086+EH6ZP/fokecNawtvxmoxaQdVjILmMaHenpJzxcffXarpiGnK9gOJ6xuhT4GkgBKwB2JScjZlBMLOa+bCSfevCSG++ImoV0DOZPLejfMenXqCkzKOaYHH4f1m+2T+jzv92g4+59pJ56zsl6y/gSPRf9cQDRtUBmXqgaLDqngtBA1Ir8td7/BGOI0Kcw2a9g83zohGP02ksv0eySpbr8s9/XDVt2aPMIRyIPC3xoyUHtXwh9Y3vRup6IInlAISkGAENNXX+IOUaPjdNPn+YL0uU8Ea9cEjzRd/kG3VOPRVsA/IqxwCPy7eu26KIjZvTZd52nFz3rdK1as0TdbhHTIT4EaetMpTlOpp/fXuknt1W8mlW6bUelX+9o8fE+dOiyopVVT1N7al1y7kr9y4cfoLe9/0E6fGyvdv/udnV4r+/xoCnGNTLU1UZeeT78ra5Y38yb6ciFiwj4yJGxrOACD6LmQoMrQNgp0qXIA6WVX2oLSvM1Z1rKeIK13c9YVDYQS6n8TruAvqaf9Xy/+tfrbtV1HMNn83voZRefrfesWK5X0cEjmKAT8F9Jdm0vMsFr6AAOYmbu2+3qqdxY/nZkWP92whF6/aPur9WnnaTLr79Fn/vBz7SWd9DtbIa9xJjiSmT9tIOvKf+9p+iOWuSvA4VcRJ8SBP1EhCIAheiOg1oJXcbBDxr6Bsfvh6/qaJ7Y40M9zc8XkRJzIHAR6eruO3dpav3v9H+esEpX/ttD9dbLHqAHXnCkxv1EFZI3wBz3coOvYnEFjLCIq3nhPf3Ew/WCFz9en/riS/RP//kUXXjBGs3+bq1m79qkLkdshy9vhQenUX7V2cvV/fdf6moTP3pzOGmxkGvSjEMqjMQcHVMbykTkhpYwsokT9y72IhbhZgG4BvuzXk2gygZM7LXch+5GZ7sZsG0iQjO9nq666Va9/we/0E3R0qmPebBe9tAL9YHTTtRHjjxUH162VB8YHtI7h1p6F59NPrxsiT5xyGp94qSj9UGO1uc+8iLFMUfqszffro994wf65aat2s0Nzk/V08yyF8BX8h28JnyHV4a7/8diRi6Ax8AIJMbJkpC5JPJzvl5UhiRWS6YR61cc2f/09Z7u3h1iD8rvlb5SA8PCRqtawdU7r7W/ukGddb/Scy/s6jPvOkdXfeoS/cc/3k9/+9rz9YoXnacXPPtMvfiZZ+hvX32xPvahp+lLX3uTvnDle/RXb3qUTjl2TvUt12jiV9epu3+nOnPTvCbN5r9AHGEx97NL3/WVWrfeWcQUizXOvBmCclDy2DwCZWnkJn1dmsPPrGyIqyfBYnnRGEhDi2BZIajslDb2Pjp/5kXFyJ2zseSn2OBqHWWG9vKZ7+vX/Frv/9r39PENm/XTZeOaPP54HX7fs3TmBefqEr6/Pvr8s3Xhuadr5UnH6fbly/W5iVm998c36KNXX69f8x14Pzlwe+TYKhxj5MBYZknhBhbzxxA7a2TwrqiMGDcUOZGCPCtBrgJCjW1EwDU0ltg3igDdzWvGh7/T0494eFnG68z4WMmFZchq+WZNPtFqa2pmTnfccqvu/PnPNb7pJl109Iz+4jFr9LbnHaX3vvIYvf+yY/XGFxytp17c1jmrf6+huz6lmWvep5nfflNzO3ZqbnZBU1NzPPF2WNSOlnAqbNgfevPni268Q047E/S8kpacp/pZh5pi7J85hdynac28i+KlFWOELLIBLYMs7Nxa+YrBU0zhcI0IBQuowBTcjuArTOgG8DqLLAdzT9e8ihYMTMA+3utuWrdRX/v5jfrgtdfpHb+8QW+/8Ra99Te36vU33qrLfnWz3vSLm/ThX92iq25epzv4HXSGK9ELOUmMiVr8TMbEEmsDI/vOgvRLgO8DpOJOAys6/h81mnslVgIKeUY0tgVeFCxom4pKBn9R+sr1Rf/x3aI9PMofvCo0xBz4ntnjttHlnjo/39UCl8/cfEe7d0zpTp4d1l/7U93+4x9o/dU/1carr9GGH35bd/3kKm395Q+1k990926b1p69RXv3LWjf3jlNT8ypLHQUQ7WuvDH06o8X/XZjqNWSnIhz0aAEBCsV7KyoYFAWRK7Foyc/pGaFGZshtag4fwarzfxhUOfiNsYYWWgG8AS1FAoWdy1wHbS/3zL/4hakacyniWDgVidF8FDVVWd2RhOTU9rZh/08Hi7wrtAlUV/1vIY1vvjzpU5zkvYC1xP4JxxJPDzm/Q+1yFi5ajpQIshJkYJinGRpeOdvWXJNE4EBlaEzERJpsH2lX/HE+gE+Hlzx455mZmqNtHq5iNNcXbN8+Znjq9Q8C9LpsXWjQ7Au78sdzcLv45vtXmx2TvEemh8Yutq9d0F7eGrey2/F81zhPXq5abv0N18o+tvP19rGx/8WC4OYITX5RoRkEBhR8YjBCFUQiWK1wSawahYUqqRFuuieBj6GJXZ2IZJHnXaihIKFjAheqkO7mYlfAjeh2Qb4vurFNHCr0yT+nGjitUy+uqz3YnFyaorjYorYkwa64Sk/bfaEdDvwc2RrieljHVaiT/ULYZO1PMKtlC1N7mZRoJtxmIahQqkxLIlIXS6O50kxv5MOv3pD0Xuu6Opb7Kh9LGyLhfXx2+0u8PC0oBkWeIZfTWZYwAYvaG5ujmN5lmN1WpOTk5qcmNLs5IQWZmdZ8Jqn30pv/VrRi/+1oyt/VtT1E6XYT2xaEBeR25CHQ2smYXEManKOCOQDgKQ6dwIUosGxWN4k2MMjg4gIjt/Cxgn5SEaBYWRnRQWMvEitquIIrnR3q9JNRL0Fq00h7QL7CvPV64XyAnsRvZgGL6zBi2y7HdhvAryAfGHTXcS2PaKssE2+ySn7j6gUXoGESgxDLkH/ETQKVeRnSmwewUe0GIolBqnCrgprtFgqKN5GdBeJf/qaWm//clcf+26t6/i+OcEVKj7NVVWPkL28en0Ud+a66nIkF945an5GLN2O5vnlehM7+Uq+Ir3xi0Wv+mhHV/D5b4pfWfKq5Ok6+otJlwoewIJcJBpXmAo6AFcSlzcedyY1JUANVFBpU1Ry4WzoSYPFyYtlruQxUAicxihLCZm1vycLEf2EHLCOSntJar0k3q3Fp1XdDe3F8qJN4DgBzy1KXmgvOiec+HFEfFOXact9kOmPiuNHXxYRizlI0FLmKeRQ8u0jpIZ1gn25KAXebKPPVuG/QAlQVQpDYqJtVxD4F5cf/q7WB6/q6q0cle+9XPrED6SvXS/eP6UbSP7GO6XrGPj3fxe68teh//hh6K8/U/Syj9X6+8tr/fSmLh8hCj2JBy4x5/TnSnwj0VnIm7LiIpKEHJF8MRkHgohQBVDVlAJqwPOjVJgXwwx3UtMRNFvAgwqFUAkhjtDw6QNG0FQEHnSGsQSioOeVUb4vevG8cDvR7SCoscFguRfaV+lgEd0LplkHtLFjir4kOHAYkxykBF1EyQYNQueEhBoAFRm1PyGhCEAhdoLk2Qg1BVwBqJN3SPNtNqrHtI0dec0G6fJfSf/Oov7TN6R3XB56O4v8jitC5v/5W/xW+mOuaJ7mdnKP5I4iDgo5puM5sOmg38wTJhRsJGuLIkIMDV4NraYUjItJ1FQ10LSEssbAAhaARXQQQ7GpZTC5Q2wGbeS+jAcw4CMcuC+FDmer4E8Jukcp0AbQgYrPQBZIDQVZBSgBoZD2adtGgbfMKiA5mmIbG6CLQJA6Cxo6qb68PywsqMiC1U29hDeAjFY+sblo2dtFFrWYQT+Zepg9STX3w8HCDbUlflIVe4BoanxxLiUU2NrfOPsu6BupNeyvgIukZco+ZguG6SA70LhaYVyyn1T4hjsA4cQ+wYIFzlYOKVujkh0aWyjiW2YeRdaIUFW1GEjgJ0WADZJCTYlFihgWhRvAwUDJ4qMqZBQRkCEzURVQwREQBRtaZFJUkhqz1EMqgpa4RqnUYHSYeHJQB46FSZMqBX9ph4OnqKBLHnm4L3eLThRuf+IhnYUUUHjVE9NnDKD04tocV9m3VQmyAOAgD/psuCplgxmvRRw7g62wPPMLKSoALEpJsBaCigpHBjUQhb2DjlBGhFv5XmTHml4sETZWRYQiAIVFqjxYSFG8wPaBRIsQuwIIiGj4iIDtg/q4L0tbOwMRlTJeKcJqcfcG8ojAQnIbtL5aQ4yp0KSOseAHRwy3qTUBoMPHpnXfJuAF1MyJcRMCOwjPkfOIsFVh6W0hediVZQCueDKtIZk2OL6ZgKAqqipBMg6pCqkiZzyzjxCl4FrA1GIB4ABIZd4qi8INNrJADmOGhI2AZiCNUj5fPNCgM2P0jcYtQgdB7iREJ5B0VykiAImWJgAqssoDAUeEguQijP8niAFGHJC7NxwcRM40IqArACylTBRPNkgFiTFZQxeZpVVTDlDWO5T1A2AYMkQ/V4/NG1p2I6/Sd4igb6ACws7oGZIEbx/VIQmAr0CiFGN4izEnpC0RJhOKGEClChqBq0K1zBKCmsb49klQOLDF0MwKbaM2oaD1R3Pv2GaBxBUBZMSQJ81y48YNj74u0rtkGxE4UcFQcokI/eGiWmOQIuIAqE+D0TDvjtmXYVdEiYK2QDTVU9Nw2KEREOoXDxi/6MsCcUTAQdCGKkXAA1JQAdFtAnRWohMnIkQFQjRUY2xBqCGKIBURzBtAbBlCFJqCCRQGVPhmEpF4BOYDP+hA5Nq3Bw0ckTbKUEBT+wjKPUkRoVBT7Gg6ghaomTjLvIiwiggFpuZzAAOGxEhDVqY9BKZyFhFhrr8ZiiLgYzCJ6vOWNaB+wSQTjAgxSuyIlnSyxLNcSoVJAAv4klCUAqXMCTMWuyPAt0hmQNYXsVlFwdcjyDUAABAASURBVIahpN6bNpBH9HXEoMrjLpiaSB46oqXIq7oShFVAqCnGBnuFh0KXzBbOcIqgBeg0zdGkXgFyA2CKjjzovABC5qp+SRE0vdvJHcEJXAAHx9oDsiiCyBA1R7CPSiWPPaa2qRT8wQeQFcJx0Ic1tg8U4AgTpGx9ikIRTnQgK/AoqDYpYNTIbAOTQmhIZ+6+Sc0kiBjInROImt5SSAnCDJGtLGomMAWN2rMCi5UtgYYisJRJCAEGtTGQCqHiHg+dqckm2CjkuXIu2R/+IbINCYUSyaUs0hGMy0GQBLYCZ45F8i5ItOhozqAs3ocmKjdiIO5Yfb3pwuKlrt84jo0tLtlpkRMmB054BqFwnybwQEdrHYicilC7yj5aLMiz04J8UZhEBPH64O4MqcimyA4RTAD+cMqySMCZZlwKUSNBFIsF1+BB6zgHpCKu+iUioAygxlyDuY4qMDVY0UCQaGDqiajpn6rkkVtmlPNnIeDwltV2xy8CIdiboHiy7Y0sIqACjeg+wE3OEE21CMprBOpHS5e+holKF3orpcCJhbOkr8cFFb7mYdICmoowa/FoklJGpmFx3WUoIuRiT2MpFBGSQhGhpgxww7ltVMgLQwYsM0Qg0z3AZObUt7MtnQU2EbQhOT0DFBU7ywnmRVHakSs+KKlJKAtkoC/ExIsxpbRpOHaVcWwhVe4gGpVbkxGh5o+wUItXguUhJDRCRz/WIYah5vdBC4tSljaF9kAl4wOMkxOxqEayaYHKxEnemQ+WNJCnAY2Dm0//0o+XwqJENI6BaSptm4RMBSSATUQogh4KySMdtBGNHIQ0gCK3EJg0lNOzHm/5FPCiWGOMEV1ndomVO9/etjCW5w2zvk2BFyzWjQLGwUHqu2BiAxUWzGBTWVnQ5PkXiogUqV/ghFAu2ZP1ONpFInMIz5NvbamXywE5pvRXlHpszduiQBhMNwtKDmaImQ5m60zUUnNOBaCas3Op3OaYcEPhQYDsEY0kle43ZZm8Kfw8oQSyKAGxJ96DMcDiiwGJJp2NeYvBONHSC/zAho7sa3khd6VWErbql0hM//IkwaQx2BVl+pcDQqwW50PEiQj5z+buGYZa5A1Ew9o7dkmVm4yHjxRUokFTlYUcC4DGWgA/FAUqAmmBybpIJIdaEejhIiJpWvomfikcxyhc7RYmvDDGCSmBsnaAigZS4jlvdkxBKeRoEDac/qB4qIsCbLBMX6/HH+hsRADryQ+uCHMw5iVREtYP7mEpxSj6w4lAS8VQLqEwoquiiACSpSl9aCwjAp5qbGDC4bL2NY2vdZbaHUUEDXyaQzrv2k0fIhCil1FfljQZKQkU2AR0SLSAeSA3hX0kwTaJKhTRLKAGJRoir9CcUJxCgQPgjnJhiyLMYwwfYZpAAhdk96iF0dSWAWhzZ9vMUBavyFBENF4gTN0TPMxiawIeuwiw6K8UmYyIRawgVeS0QqzgD08ZFeRUYofVYFGgWfCUu0EiG+NMVUQo/8Dql5I4smVAGSddU8HUYWvSi+cTRkQQfQzetYVeFOfT0IxFoQh8kWeNbDO2kw0FF0gjMx0RqrCPCAldhLFXzD2rX8IaCV1Grvmmt2iSGdtAsoGTwY6+sECXmhSEJIMoIYtikBZ9FQvQuKKVgQhpETGwtFYcFzpQQkKtQYkIeF4LHJP+QY0KAhaaWAUgsuODkA2q5dDRh74y5L++rB/H42y+kkl0KZeIMAIyMphpyNYNjgr+KvIPCxJMOVYyNBGWCJuCLViOUWhdwdTgabnq27mnPmkDfPpjYIwpyCZS7rY/JCGQS+VG5ghsZclohC1Bz0VmnSAXKEkhwsi7Ea1cIkzZHlsLZF5pK0rpA8jOwAFbWzruwMaY8FwMSYFt3tgPFk8ZHz3OVJsLqwTzEPeo2A04k2nQnyDkg3GkGD47JKL78pgNjSyyV5v8MYQFbgBPhX0tSj8Yx0g5QtNOQ0TDXAKLghnmpc8h6FdG3sgxGNCNqjRDNtMEkjeFyVzQuu5lMDtVOHuSmxVBgq/EFRKBuxlkUIvVIlRWm8yezPQNUMlso5PMi+LBgaiOZ8CTvhkBFb7vkAi5d7Dj4LBYzTtXYzlyBrdHMZcgisVpU2BYMLcJKUwqm4i0JJFkFQGfsChqFEKeFAH7ZEFGmkidewELSQPKgsyxknZjR2xNOifU1OSCiynSGzboGz8QzP9eUatwv/Oc5oJ2u121/KMeEWsCFSwqcAbJLAucA0uoBOUUZFWmVJD0QUov9FwJKWswFsrSqCUCNf4BGWoWLARDjQPgGBp4BwSgUESFFCBORECjwjYi5D8LII2aPNEl44aOzRYsC7wBRDUFBCQVipa6SFhhKIowdp8Fg3tUxBHZyPOIIUboLaNfCR3Yky+Rv4QkFBESfAAlRAmFQsE4I5jDkCJoRLlHl4SS79l8JJBvnRmx0+mqPTSs2g8vaqybNhaDHFg4gqN0Qo4fgY2CXiRINdmrTyuL5aFI2gmY6HMms0fHM5gJbNMnUAMR9AnpHPIVwTSBSEM+SSCVBVtjyxOYmSCWgIjQYhnQi45SI7INYGdRrIeNoIEN5sfgMWauUfp+KLMWq3IDJUvjEEX4FxhwhgqmPYmiCI/NIzPdYMkyCSR5pTwpBZIaCHGBokI4jyHWDjECsR1AszMzalWVvNIRIfsHmUChbVoxOep72cSgfnEaJvuWkE3v5vupya7hBlWoXxwEhpqCiLAFG4uI2DlZKyIaeZgxoFMCdvxMZXmEWyuliJCveCHCQh7QgVgSaqFqwISaEhGLskBkIBkWqCgiOaSuoTDqt95Uyfb5CGsHoEbKfDqXmqPR+ahfah5IBzwm2BY0pcGl0Tj3DMmgEdEOZrXhRoaHtLCwgJ8YN6jTWcikh4aGEhNNhQhpHhhQYZUALfWFsoUkFKFBJ1osliEWaimoEJ7o9ILWPUpEYEIMYyCHUiItPFCUSbtJdZ9orthADaCICGsGmanPSojdNyhDyyWVYVUzbnsNZIkxAgfIE1+gBVCxDNaRfJvBIA6sBjUUSaYSykuZSBHWWF7SX2bFFQtEEA+zAwkKdSTQYV9c5GJpYnyGhoY1Oztrlk+NoB67ZG5+TkuWLFGBRiRPYkTjFggyDHwxQ3TrQWmXmMayAbh32ybPVYSazd4MLCKDKKLBMsKw6YPO4CNCXixaQRAu5BLqDzqUVAQ8R58jBx0SRvcsQdBmIbHrK3ARzuSOkmommFAh9NVAZ6lLlWWS/C4I8jDQQRHYfULlwjR+ARsKvrlaFxGEcpRAVgGReggwqkpNXGJpcLQqGh09pacbSywGoq+n07Rot9vEkBY6HTQhQirL1NSURkdG8ti1wLkkpolowmTSdFCYuIgDE4QJNTSYuMShLEaln2zQpWMYrDS2zOMhLKJCnkVkyqQVI8B8jQxIi6IIe8FQHQNjqu0bnXQPvZQbCSSMAGqBAwiTRDMSBKXgiYhaAMGFRIsPmSTVt0m5ExfFDMhWjmnfFGGbzthZbplvZSRkUzywpGZoc6YbBzhbe0wmTeOC3hKP2aF97Y1zEc7MzarmTUV0srig/tfe3V6tsbExFVsSx07EaPprYiJ1tdS4gYHKUv8DrqbTRmdZQzVWEcZMoYOjsC3oDyrahk9bSGwjQgE5qINBDZKLGGjpkYeXxu5A9LTHBG2jyhZBRW+gZBd7CEUEIvvf0wPacqvQum/Wqplp82oUwYYv0CVljTr7X3RA4ThpZyv8oJFSzQtvA7mp8bcrpBwnMffiNs89Y0vGNDnpfwCLLa65oI5to/3792nZ8hVSVP2AymgOknPExHqIVkKiJBFaywjXp/CNsAmdIwopiGd729GnBbpnSZkwRGjaAEnf2UrEs6zINvTkwRNTCZYVDYpzNW3siY2Ixsu4b2ZkQMSJEJgTk3aQX2ISjkAHpO1gRm2Hjkpc/MLWghYFGmMqvFuB9b8W3Ppy+oCK6GNo18bblOUNRIQiwkL5jWTlqhV57/RrZ1+sKrV9b99YZ3jiXbFyhXxf9bxZ5clh5CKafC8JVZAObFAWD1CCN4ET1RyALW0wArRQolgLysqkJJsNklBEJHYoiAMVgTUHVto+hsYkIuQ/Swp0iUZu3lSEBQ249RoV71Tiph5v4wEUyw0ISvpCUAM7Q/E8mA4yopOAVgILm5ix9fFAh5kikDMfeEEriz3MWJ/9Ii1Bo+BPQCgLBj5Bx7kyR0dHtXfv/kbcz7Myh41EJ6Ls3btHfn1Zwtlc93pIpOBYopVEIlzqhUkoBIh+H4FcA0YUdHl59qNnssIq0AFUiKaarjJ+w6uZZZiiZhPYwmyRN1XG6scnG2VBJQW7tiTIBRvnmKo/4IucakRFisUaeeIiQoU/gQNdRCiigcYoWyGBCMAVf2xKgR6IeF6IMIPO8VDhJCGjGvWltnGfyuJcSUhCHEEjikNg7bxq4tqmZlz+CLRq5Srt3LlTte+dmIrNZcRUhjFzVRwLg1p7du3KJ96R0RH5/zlHzJxnd1ga62wtbLwl55BgYwsBaiOXKVsbmghyQex/kZ9k4yybFppk0culuDGEgsk2pXCbjQlSqxMH+pD/RCtVBIqIhjFWUzxJGbavatKO9HGWhmhMsw004dhVSFS5gD3JJn1y2cf0Adxwbm3HWrgbVQTAlRZNJgHOWlIWtAF/j3ThJC9mu1Xp4IMP1r79Exy3/s+90hJ9AaJ5bRHFrAFSHT4F7t69W8tXrND40vFmUe1XSRGh/AtoSbA0ukdBoVBEKLPPoDUb5gDvybQDEhnM++mvfwqhQoJfMwFFEVgZ0Ph90PsaCZx0AAd9wPeDRISqioQdRC7oQ0IsJwYpg3O0CT2atGoRvAjsFOwtKjQ1LJaQKaSJCOKErx+pTweXfEgy4IBfge4DunyLQ+nN7FNI/RK2KmYKlLFEyASPe2RoSIcddqhmZqY1OTUhKXSgNDQjtqhhTA3AXx527tip8fFxrVm9Rt6BhePWlk0nIXJLUCMAoYUOBYNwJGxAxYYqpqwBQhEBf6BaG9HIQpEKsxGOUQTqy5hQ1AUOKqNCUkva5CJgXJB4RxvnpMIvVoS2C4UUlSJCIemekwuTsYusQScX6NJgI8dIQOQNCaKSFWYiZgEizDTTkT5ETUkyUAXAy2YWQcoig8TYub3VHKtLx5dwZR7Elbk/Qf+jBNbBOhGJqv+tdHhZ3bZtq7p1VwcdcpCWsrh4cenX8o4JnIIs6JarA6IU1EUwgLUFPhSBRVhEI5eQ/0wZTEeESUUcwKHoy5iQIkUEUEkCG8yLAlYfggVCslijTyV2DEH1bWHlRWxY5Bb07Y1C/IUUQf4SWBI82SgCopl1QSnCrQSxuH9SMmgydqAOievZ5hHQAFUoXMFU5rHw6uhnmJHhER16yKFaunSptnOBTUxMCi81JYNCWsJGUhFPBvBpYqHpP4Saq9LH784dO/iA39bqVau0bNnS/B8I40/yBHLn/xuQWN2XMwZDFr26AAABeUlEQVQ1V0zRQFaIbWh45P6Pe2yfu7LOJ+2BzleCadsTNmMUbDFVcRzeoa03OC8hE4b287CzbwjbW1fwrWF69jPAY46qAM2GLejTjofDQrxeP7+BXHRUcMIDn6LiGAk96CLn4mcQKCyZV+IlTyzb1lx5DdTY19j7IbSo3RrKk/Ggg9Zo+fJlHK+T2rZ9u3xqepUYhppirqEGbeW1dFKN4H8aWG7pwvwCT1W7tIt7a48BLuFqXcniLl++XGPjSzMBPxmPjS3h48SSfKgyPbpkVGMJY4uyJTxy+wNGA9imz5hGU44/T9iNboxY+PX1Y6NjGuXDx6gxMDKyRKM8uidgMzpqHhvLzBPHsjFs0yblo/QDEMdy5+KYY9gvQWYYN02sJocl5D+eeeQ4sLF8CdjjNYxiOzo2ig22+I4taextM2Ye/Ti5LIG2fQLzN84xOg721beC55XVa9booIMO1vKVy9Xik97E5CRX5Q75K95gjYoXbBEGq2PcwP8HAAD//wBNIwMAAAAGSURBVAMACrqje1Prt1IAAAAASUVORK5CYII=" alt="Live Infinity" style="width:32px;height:32px;border-radius:8px;object-fit:cover;border:1px solid rgba(255,208,0,0.4);box-shadow:0 0 12px rgba(255,23,23,0.4);">' +
    '<div style="font-size:13.5px;font-weight:900;letter-spacing:.4px;"><span style="color:#ff1717">LIVE</span> <span style="color:#ffd000">INFINITY</span></div>' +
    '<div style="flex:1"></div>' +
    '<div id="ttlf-status" style="display:flex;align-items:center;font-size:9.5px;font-weight:900;letter-spacing:.4px;padding:3.5px 9px;border-radius:999px;border:1px solid #ff1717;color:#ff3355;background:rgba(255,23,23,.15);margin-right:6px;white-space:nowrap">● INATIVO</div>' +
    '<div id="ttlf-cfg" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,208,0,0.3);background:#141928;color:#ffd000;font-size:13px" data-tip="Minha assinatura / configurações">⚙️</div>' +
    '<div id="ttlf-power" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,208,0,0.35);background:#141928;color:#ffd000;font-size:14px;font-weight:bold" data-tip="Nenhuma LIVE no ar">⏻</div>' +
    '<div id="ttlf-min" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,23,23,0.35);background:#141928;color:#ff1717;font-size:15px;font-weight:bold" data-tip="Esconder">−</div></div>' +

    /* NOVO CARD DASHBOARD: GMV E VENDAS REALIZADAS EM TEMPO REAL DO TIKTOK SHOP */
    '<div style="display:flex;gap:8px;padding:0 12px 11px">' +
    '<div style="flex:1;background:#03050a;border:1px solid rgba(255,208,0,0.3);border-radius:13px;padding:9px 10px;text-align:center">' +
    '<div style="font-size:9px;color:rgba(255,255,255,0.6);text-transform:uppercase;font-weight:800">VENDAS DA LIVE</div>' +
    '<div id="ttlf-stat-vendas" style="font-size:17px;font-weight:900;color:#ffd000;margin-top:2px">0</div>' +
    '</div>' +
    '<div style="flex:1;background:#03050a;border:1px solid rgba(255,208,0,0.3);border-radius:13px;padding:9px 10px;text-align:center">' +
    '<div style="font-size:9px;color:rgba(255,255,255,0.6);text-transform:uppercase;font-weight:800">GMV ATUAL</div>' +
    '<div id="ttlf-stat-gmv" style="font-size:16px;font-weight:900;color:#ff1717;margin-top:2px">R$ 0,00</div>' +
    '</div>' +
    '</div>' +

    '<div style="display:flex;gap:7px;padding:0 14px 12px">' +
    '<button id="ttlf-on" style="flex:1;padding:9px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000 0%,#ff9900 100%);color:#000;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(255,208,0,0.3)">🚀 Ativar tudo</button>' +
    '<button id="ttlf-off" style="flex:1;padding:9px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717 0%,#d90000 100%);color:#fff;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(255,23,23,0.3)">🛑 Desativar tudo</button></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9.5v3.5l2.3 2.3"/><path d="M9 2h6"/></svg></b>Timer de Encerramento<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Encerra a LIVE automaticamente no horário definido (sobrevive a F5)</div>' +
    '<div style="text-align:center;color:rgba(255,255,255,0.55);font-size:10px;letter-spacing:2px;font-weight:800">TEMPO RESTANTE</div>' +
    '<div id="rt-restante" style="text-align:center;font-family:monospace;font-size:28px;font-weight:bold;letter-spacing:3px;color:#ffd000;background:#03050a;border:1px solid rgba(255,208,0,0.35);border-radius:14px;padding:10px;margin:4px 0 9px">--:--:--</div>' +

    '<div style="display:flex;gap:4px;margin-bottom:8px">' +
    '<button class="ttlf-preset" data-min="60">1h</button>' +
    '<button class="ttlf-preset" data-min="120">2h</button>' +
    '<button class="ttlf-preset" data-min="240">4h</button>' +
    '<button class="ttlf-preset" data-min="360">6h</button>' +
    '<button class="ttlf-preset" data-min="480">8h</button></div>' +
    '<label>Ou digite manualmente (minutos):</label>' +
    '<input id="rt-min" type="number" min="1" value="120" style="margin:4px 0 8px"/>' +
    '<button id="rt-armar" class="ttlf-go">▶ Iniciar timer</button>' +
    '<div style="display:flex;gap:6px;margin-top:6px">' +
    '<button id="rt-pausa" style="flex:1;padding:6px;border:none;border-radius:8px;background:#ffd000;color:#000;font-weight:bold;cursor:pointer;display:none">⏸ Pausar</button>' +
    '<button id="rt-cancel" style="flex:1;padding:6px;border:none;border-radius:8px;background:#ff1717;color:#fff;font-weight:bold;cursor:pointer;display:none">✖ Cancelar</button></div>' +
    '<div id="rt-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16v6"/><path d="M8 3h8l-1.2 7 3.2 3H4l3.2-3z"/></svg></b>Refixar produto<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Fixa sempre o produto nº 1 e refixa sozinho (desafixa cupom e grupo da LIVE)</div>' +

    /* BOTÕES EXTRAS DE AÇÃO RÁPIDA: FIXAR PRODUTO PRINCIPAL E BLOQUEAR CUPOM DE DESCONTO */
    '<div style="display:flex;gap:6px;margin-bottom:10px">' +
    '<button id="rf-btn-fixar-main" style="flex:1;padding:7px;border:1px solid rgba(255,208,0,0.3);border-radius:8px;background:#141928;color:#ffd000;font-weight:bold;font-size:11px;cursor:pointer">📌 Fixar Principal</button>' +
    '<button id="rf-btn-bloq-cupom" style="flex:1;padding:7px;border:1px solid rgba(255,23,23,0.4);border-radius:8px;background:#141928;color:#ff3355;font-weight:bold;font-size:11px;cursor:pointer">🚫 Bloquear Cupom</button>' +
    '</div>' +

    /* OPÇÃO DE BLOQUEIO OBRIGATÓRIO DE CUPOM */
    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:8px;background:#03050a;padding:8px;border-radius:8px;border:1px solid rgba(255,208,0,0.2)">' +
    '<input id="rf-bloq-cupom-check" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>' +
    '<span style="font-size:11px;color:#fff">Bloqueio Obrigatório de Cupom (Sempre Ignorar Cupom)</span>' +
    '</label>' +

    '<label>Intervalo (segundos):</label>' +
    '<input id="rf-intervalo" type="number" min="10" value="40" style="margin:4px 0 8px"/>' +
    '<button id="rf-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rf-status" class="ttlf-st">Desligado.</div></div></div>' +



    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z"/></svg></b>Oferta relâmpago<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando a Oferta relâmpago da LIVE encerrar, duplica e inicia de novo sozinho</div>' +
    '<button id="rd-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rd-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8 8 0 0 1-8 8H4l2.3-2.7A8 8 0 1 1 21 11.5z"/></svg></b>Comentários automáticos<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Envia seus comentários na LIVE, um por vez, girando a lista</div>' +
    '<label>Comentários (um por linha):</label>' +
    '<textarea id="rc-msgs" rows="4" style="margin:4px 0 8px">Oi, Fiquem à vontade para interagir, conhecer os produtos e tirar suas dúvidas!\n🛒 Toque no carrinho pra garantir a oferta!\n🔥 Frete grátis hoje!\n💥 Últimas unidades com desconto!</textarea>' +
    '<label>Intervalo (segundos):</label>' +
    '<input id="rc-int" type="number" min="10" value="90" style="margin:4px 0 8px"/>' +
    '<button id="rc-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rc-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 8V5"/><circle cx="12" cy="3.5" r="1.2"/><path d="M9 12.5v2M15 12.5v2"/></svg></b>Respostas automáticas<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém citar a palavra-chave, responde sozinho (nunca responde você mesma)</div>' +
    '<label>Regras (palavras = resposta, uma por linha):</label>' +
    '<textarea id="ra-regras" rows="6" style="margin:4px 0 8px">frete = O frete é grátis! 🚚\ncomprei, finalizei, adquiri = Parabéns pela compra! Volte aqui depois para me dar seu feedback.</textarea>' +
    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><input id="ra-mencao" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>Mencionar @pessoa na resposta</label>' +
    '<button id="ra-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="ra-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9.5" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/><path d="M3 4h2l2.4 11h10.2L20 8H6.2"/></svg></b>Intenção de compra<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém adiciona o produto ao carrinho, menciona a pessoa (@nome) no chat com sua frase pronta</div>' +
    '<label>Frase quando ADICIONAR ao carrinho:</label>' +
    '<textarea id="ic-cart" rows="2" style="margin:4px 0 8px">garante o seu, finaliza a compra! 🛒</textarea>' +
    '<button id="ic-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="ic-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M5.7 5.7l12.6 12.6"/></svg></b>Bloqueio por Nome<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Bloqueia automaticamente quem ENTRA na LIVE com palavras suspeitas no nome (painel Atividade)</div>' +
    '<label>Palavras suspeitas (uma por linha):</label>' +
    '<textarea id="bn-palavras" rows="4" style="margin:4px 0 8px">recomenda\nachadinhos\nindica</textarea>' +
    '<button id="bn-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="bn-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5.2c0 4.8-3.4 8.3-7 9.8-3.6-1.5-7-5-7-9.8V6z"/></svg></b>Proteção Contra Violação<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Encerra a LIVE sozinho ao detectar aviso/violação do TikTok na tela (Liga automaticamente ao iniciar LIVE)</div>' +
    '<input id="rv-ativo" type="checkbox" style="display:none"/>' +
    '<button id="rv-botao" class="ttlf-go" style="margin-bottom:8px">▶ Ativar proteção</button>' +
    '<label>Esperar antes de encerrar (segundos, 0 = na hora):</label>' +
    '<input id="rv-delay" type="number" min="0" value="0" style="margin:4px 0 8px"/>' +
    '<div id="rv-status" class="ttlf-st">Inativa.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.5 20a2 2 0 0 0 3 0"/></svg></b>Alerta de vendas (celular)<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Saiu venda na LIVE → notificação no seu celular via app gratuito ntfy (instale o app "ntfy" e inscreva-se no seu canal)</div>' +
    '<label>Nome do canal ntfy:</label>' +
    '<input id="nv-canal" placeholder="ex: liveinfinity-vendas-8k" style="margin:4px 0 8px" autocomplete="off" spellcheck="false"/>' +
    '<button id="nv-teste" style="width:100%;padding:8px;border:1px solid rgba(255,208,0,0.3);border-radius:11px;background:#141928;color:#ffd000;font-weight:700;cursor:pointer;margin-bottom:8px">Enviar teste pro celular</button>' +
    '<button id="nv-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="nv-status" class="ttlf-st">Desligado.</div></div></div>';

  document.body.appendChild(d);
  ttlfPersist(d);

  Array.prototype.slice.call(d.querySelectorAll('.ttlf-sec-h')).forEach(function (h) {
    h.addEventListener('click', function () {
      var b = h.nextElementSibling;
      var fechado = b.style.display === 'none';
      b.style.display = fechado ? 'block' : 'none';
      h.querySelector('span').textContent = fechado ? '▾' : '▸';
    });
  });

  // BIND DO BOTÃO ATIVAR TUDO E DESATIVAR TUDO
  document.getElementById('ttlf-on').addEventListener('click', function () {
    ['rf-botao', 'rd-botao', 'rc-botao', 'ra-botao', 'bn-botao', 'ic-botao', 'nv-botao'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b && (b.textContent.indexOf('▶') >= 0 || b.textContent.indexOf('Iniciar') >= 0)) { b.click(); }
    });
    var cv = document.getElementById('rv-ativo');
    if (cv && !cv.checked) {
      var bRv = document.getElementById('rv-botao');
      if (bRv) bRv.click();
    }
    var bRt = document.getElementById('rt-armar');
    if (bRt && bRt.style.display !== 'none') { bRt.click(); }
  });

  document.getElementById('ttlf-off').addEventListener('click', function () {
    ['rf-botao', 'rd-botao', 'rc-botao', 'ra-botao', 'bn-botao', 'ic-botao', 'nv-botao'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b && (b.textContent.indexOf('⏸') >= 0 || b.textContent.indexOf('Parar') >= 0)) { b.click(); }
    });
    var cv = document.getElementById('rv-ativo');
    if (cv && cv.checked) {
      var bRv = document.getElementById('rv-botao');
      if (bRv) bRv.click();
    }
    var bRtCan = document.getElementById('rt-cancel');
    if (bRtCan && bRtCan.style.display !== 'none') { bRtCan.click(); }
  });

  var ttlfMini = false;
  document.getElementById('ttlf-min').addEventListener('click', function () {
    ttlfMini = !ttlfMini;
    var mb = document.getElementById('ttlf-min');
    var topo = document.getElementById('ttlf-top');
    var linhaBtns = topo ? topo.children[1] : null;
    Array.prototype.slice.call(d.children).forEach(function (k) {
      if (k.id === 'ttlf-top') { return; }
      if (ttlfMini) { try { k.setAttribute('data-mini', '1'); } catch (e) {} k.style.display = 'none'; }
      else if (k.getAttribute && k.getAttribute('data-mini')) { k.style.display = ''; k.removeAttribute('data-mini'); }
    });
    if (linhaBtns) { linhaBtns.style.display = ttlfMini ? 'none' : 'flex'; }
    if (topo) { topo.style.borderRadius = ttlfMini ? '18px' : '18px 18px 0 0'; }
    d.style.maxHeight = ttlfMini ? 'none' : '84vh';
    d.style.overflow = ttlfMini ? 'visible' : 'auto';
    mb.textContent = ttlfMini ? '+' : '−';
  });

  var _cfgBtn = document.getElementById('ttlf-cfg'); if (_cfgBtn) { _cfgBtn.addEventListener('click', ttlfCfgPanel); }

  var bolha = document.createElement('div');
  bolha.id = 'ttlf-bolha';
  bolha.title = 'Live Infinity';
  bolha.style.cssText = 'position:fixed;top:64px;right:12px;z-index:999998;width:52px;height:52px;background:#070a12;border:2px solid #ffd000;border-radius:50%;box-shadow:0 10px 25px rgba(0,0,0,.9);display:none;align-items:center;justify-content:center;cursor:pointer;font-size:22px';
  bolha.innerHTML = '♾️';
  document.body.appendChild(bolha);

  ttlfDrag(d, document.getElementById('ttlf-head'), 'ttlf-pos-hub', null);
  ttlfDrag(bolha, bolha, 'ttlf-pos-bolha', function () { d.style.display = 'block'; bolha.style.display = 'none'; });
}

function ttlfInit() {
  if (!document.body) { setTimeout(ttlfInit, 1500); return; }
  if (document.getElementById('ttlf-hub')) { return; }
  ttlfBuildHub();

  /* ===== 1. REFIXAÇÃO COM BLOQUEIO OBRIGATÓRIO DE CUPOM ===== */
  (function () {
    'use strict';
    if (window.rfTimer) clearInterval(window.rfTimer); var PAD = 20; var rodando = false;
    function tb() { return Array.prototype.slice.call(document.querySelectorAll('button, [role="button"]')).filter(function (b) { var t = (b.textContent || '').trim(); return t === 'Fixar' || t === 'Desafixar'; }); }
    function ehProduto(b) { var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) break; var t = el.textContent || ''; if (t.indexOf('Lista de produtos nesta LIVE') > -1) return false; if (t.length > 600) return false; if (t.indexOf('Em estoque') > -1 || t.indexOf('Quantidade') > -1) return true; } return false; }
    function ehCupom(b) {
      var bloqCheck = document.getElementById('rf-bloq-cupom-check');
      if (bloqCheck && !bloqCheck.checked) return false;
      var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) break; var t = el.textContent || ''; if (t.indexOf('Em estoque') > -1 || t.indexOf('Quantidade') > -1) return false; if (/cupom|desconto|gasto m/i.test(t)) return true; } return false;
    }
    function st(m) { var e = document.getElementById('rf-status'); if (e) e.textContent = m; }
    function ciclo() { var bs = tb(); var prods = bs.filter(function (b) { return ehProduto(b) && !ehCupom(b); }); if (prods.length === 0) { st('Nenhum produto principal encontrado.'); return; } var alvo = prods[0]; var outros = bs.filter(function (b) { return b.textContent.trim() === 'Desafixar' && b !== alvo; }); if (outros.length > 0) { st('Removendo cupom/fixação extra...'); outros[0].click(); setTimeout(ciclo, 700); return; } if (alvo.textContent.trim() === 'Fixar') { alvo.click(); st('Produto nº 1 fixado ✅ ' + new Date().toLocaleTimeString()); setTimeout(confere, 2000); return; } alvo.click(); st('Refixando...'); setTimeout(ciclo, 600); }
    function confere() { var bs = tb(); var fx = bs.filter(function (b) { return b.textContent.trim() === 'Desafixar'; }); var prodFixado = fx.some(function (b) { return ehProduto(b) && !ehCupom(b); }); var intruso = fx.some(function (b) { return !(ehProduto(b) && !ehCupom(b)); }); if (!prodFixado || intruso) { st('Removendo cupom/intruso...'); setTimeout(ciclo, 300); } }
    function liga() { var s = Math.max(10, parseInt(document.getElementById('rf-intervalo').value, 10) || PAD); rodando = true; ciclo(); window.rfTimer = setInterval(ciclo, s * 1000); var b = document.getElementById('rf-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; }
    function desliga() { rodando = false; clearInterval(window.rfTimer); var b = document.getElementById('rf-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    
    var btnRf = document.getElementById('rf-botao');
    if (btnRf) btnRf.addEventListener('click', function () { rodando ? desliga() : liga(); });

    var btnFixMain = document.getElementById('rf-btn-fixar-main');
    if (btnFixMain) {
      btnFixMain.addEventListener('click', function () {
        st('Fixando produto principal...');
        ciclo();
      });
    }
    var btnBloqCupom = document.getElementById('rf-btn-bloq-cupom');
    if (btnBloqCupom) {
      btnBloqCupom.addEventListener('click', function () {
        st('Desafixando qualquer cupom ativo...');
        var bs = tb();
        var cuponsFixados = bs.filter(function (b) { return b.textContent.trim() === 'Desafixar' && ehCupom(b); });
        if (cuponsFixados.length > 0) {
          cuponsFixados[0].click();
          st('Cupom removido ✅');
        } else {
          st('Nenhum cupom fixado no momento.');
        }
      });
    }
  })();

  /* ===== 2. MÓDULO DE MÍDIA OPTIMIZADO (ÁUDIO LIMPO SEM PICOTAR) ===== */
  (function () {
    'use strict';
    var rodando = false;
    function st(m) { var e = document.getElementById('md-status'); if (e) e.textContent = m; }
    
    function regAudioHist(nome) {
      var item = '[' + ttlfNow() + '] Camada Disparada: ' + nome;
      window.ttlfAudioHistory.push(item);
      if (window.ttlfAudioHistory.length > 40) window.ttlfAudioHistory.shift();
      var box = document.getElementById('md-hist-box');
      if (box) {
        box.textContent = window.ttlfAudioHistory.join('\n');
        box.scrollTop = box.scrollHeight;
      }
      ttlfLog('📻 ' + item);
    }

    // CORREÇÃO CRÍTICA DE PICOTAMENTO: FECHA OS CONTEXTOS DE ÁUDIO APÓS A EXECUÇÃO E REUTILIZA O BUFFER PARA NÃO SOBRECARREGAR A CPU/MEMÓRIA
    function playSyntheticSound(type) {
      try {
        var AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        var ctx = new AudioCtx({ latencyHint: 'playback' });
        var volSlider = document.getElementById('md-volume-slider');
        var masterVol = (volSlider ? parseFloat(volSlider.value) : 80) / 100;

        var gain = ctx.createGain();
        gain.gain.value = masterVol;
        gain.connect(ctx.destination);

        var dur = 0.3;
        if (type === 'caixa') {
          dur = 0.4;
          var osc1 = ctx.createOscillator();
          osc1.type = 'sine';
          osc1.frequency.setValueAtTime(987.77, ctx.currentTime);
          osc1.connect(gain);
          osc1.start();
          osc1.stop(ctx.currentTime + 0.1);

          setTimeout(function() {
            try {
              var osc2 = ctx.createOscillator();
              osc2.type = 'sine';
              osc2.frequency.setValueAtTime(1318.51, ctx.currentTime);
              osc2.connect(gain);
              osc2.start();
              osc2.stop(ctx.currentTime + 0.3);
            } catch(e) {}
          }, 100);
        } else if (type === 'aplausos') {
          dur = 0.5;
          var bufferSize = ctx.sampleRate * 0.4;
          var buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          var data = buffer.getChannelData(0);
          for (var i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }
          var noise = ctx.createBufferSource();
          noise.buffer = buffer;
          noise.connect(gain);
          noise.start();
        } else if (type === 'risadas' || type === 'vinheta') {
          dur = 0.3;
          var osc = ctx.createOscillator();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(523.25, ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.25);
          osc.connect(gain);
          osc.start();
          osc.stop(ctx.currentTime + 0.25);
        }

        // LIMPEZA AUTOMÁTICA DO CONTEXTO PARA NUNCA PICOTAR O VÍDEO NATIVO DO TIKTOK
        setTimeout(function () {
          try { if (ctx && ctx.state !== 'closed') ctx.close(); } catch (e) {}
        }, (dur + 0.2) * 1000);

      } catch (e) {}
    }

    var btnVc = document.getElementById('md-vcable-btn');
    var selVc = document.getElementById('md-vcable-select');
    if (btnVc) {
      btnVc.addEventListener('click', function () {
        rodando = !rodando;
        var dev = selVc ? selVc.value : 'vcable';
        if (rodando) {
          btnVc.textContent = '⏸ Parar Roteamento';
          btnVc.style.background = '#ff1717';
          st('🟢 Roteamento VB-CABLE ATIVO (' + dev + ') ✅');
          regAudioHist('Roteamento VB-CABLE Iniciado');
        } else {
          btnVc.textContent = '▶ Iniciar Roteamento VB-CABLE';
          btnVc.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)';
          btnVc.style.color = '#000';
          st('Desativado. Áudio padrão do sistema.');
          regAudioHist('Roteamento VB-CABLE Parado');
        }
      });
    }

    Array.prototype.slice.call(document.querySelectorAll('.md-fx-btn')).forEach(function (b) {
      b.addEventListener('click', function () {
        var fx = b.getAttribute('data-fx');
        var nomes = { caixa: '🔔 Som de Venda / Caixa', aplausos: '👏 Efeito Aplausos', risadas: '😂 Efeito Risadas', vinheta: '⚡ Efeito Vinheta / Alerta' };
        playSyntheticSound(fx);
        regAudioHist(nomes[fx] || fx);
      });
    });

    var histClear = document.getElementById('md-hist-clear');
    if (histClear) {
      histClear.addEventListener('click', function () {
        window.ttlfAudioHistory = [];
        var box = document.getElementById('md-hist-box');
        if (box) box.textContent = 'Nenhum trecho disparado ainda.';
      });
    }
  })();

  /* ===== 3. COMENTÁRIOS AUTOMÁTICOS ===== */
  (function () {
    'use strict';
    if (window.rcTimer) { clearInterval(window.rcTimer); }
    var idx = 0; var rodando = false;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'rc-painel') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rc-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { st('Caixa de comentário não encontrada — a LIVE está no ar?'); return; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"]').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 60 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } else { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); }); } setTimeout(function () { if (ta.value === '') { st('Enviado ✅ "' + msg.slice(0, 28) + '" ' + new Date().toLocaleTimeString()); } else { st('⚠️ ENVIO FALHOU'); } }, 900); }, 400); }
    function proximo() { var linhas = document.getElementById('rc-msgs').value.split('\n').map(function (t) { return t.trim(); }).filter(function (t) { return t.length > 0; }); if (!linhas.length) { st('Escreva pelo menos 1 comentário na lista.'); return; } if (idx >= linhas.length) { idx = 0; } var mtx = linhas[idx]; if (mtx.length > 100) { mtx = mtx.slice(0, 97) + '...'; } enviar(mtx); idx = idx + 1; }
    function liga() { var s = parseInt(document.getElementById('rc-int').value, 10) || 60; if (s < 10) { s = 10; document.getElementById('rc-int').value = 10; } rodando = true; proximo(); window.rcTimer = setInterval(proximo, s * 1000); var b = document.getElementById('rc-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; }
    function desliga() { rodando = false; clearInterval(window.rcTimer); var b = document.getElementById('rc-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    document.getElementById('rc-botao').addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); } });
  })();

  /* ===== 4. RESPOSTAS AUTOMÁTICAS NO CHAT ===== */
  (function () {
    'use strict';
    if (window.raVarre) { clearInterval(window.raVarre); }
    if (window.raFila) { clearInterval(window.raFila); }
    var rodando = false; var vistos = new Map(); var vistoEm = new Map(); var fila = []; var ultimoEnvio = 0; var enviados = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ra-painel') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('ra-status'); if (e) { e.textContent = m; } }
    function norm(t) { return (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { st('Caixa de comentário não encontrada.'); return; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"]').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 60 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } else { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); }); } setTimeout(function () { if (ta.value === '') { enviados = enviados + 1; st('Respondido ✅ (' + enviados + ' no total) ' + new Date().toLocaleTimeString()); } else { st('⚠️ ENVIO FALHOU'); } }, 900); }, 400); }
    function itensComentario() { var ta = $s('textarea').filter(function (t) { var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph) && vis(t) && fora(t); })[0]; var painel = document; if (ta) { var pp = ta; for (var k = 0; k < 10 && pp; k++) { pp = pp.parentElement; if (!pp) { break; } if ($s('img', pp).length >= 1 && pp.getBoundingClientRect().height > 200) { painel = pp; } } } var rows = $s('[class*="cursor-pointer"],[class*="rounded"]', painel).filter(function (el) { if (!vis(el) || !fora(el)) { return false; } var imgs = $s('img', el).filter(function (im) { var r = im.getBoundingClientRect(); return r.width >= 14 && r.width <= 56; }); if (imgs.length !== 1) { return false; } var lv = $s('div,span', el).filter(function (x) { return x.children.length === 0 && (x.textContent || '').trim(); }); var txts = lv.map(function (x) { return x.textContent.trim(); }).filter(function (t) { return t !== 'Host' && t !== 'Anfitrião'; }); if (txts.length < 2) { return false; } var full = (el.textContent || '').trim(); if (/está vendo o produto|acabou de|entrou na|pedidos feitos|aparecer[aã]o aqui|Alternar modo|Console de LIVE/i.test(full)) { return false; } return full.length > 0 && full.length < 400; }); rows = rows.filter(function (el) { return !rows.some(function (o) { return o !== el && el.contains(o); }); }); var groups = new Map(); rows.forEach(function (el) { var pr = el.parentElement; if (!groups.has(pr)) { groups.set(pr, []); } groups.get(pr).push(el); }); var best = []; groups.forEach(function (v) { if (v.length > best.length) { best = v; } }); if (!best.length) { best = rows; } return best.map(function (row) { var lv = $s('div,span', row).filter(function (x) { return x.children.length === 0 && (x.textContent || '').trim(); }); var host = false, textos = []; for (var i2 = 0; i2 < lv.length; i2++) { var t = lv[i2].textContent.trim(); if (t === 'Host' || t === 'Anfitrião') { host = true; continue; } textos.push(t); } return { el: row, autor: textos.length ? textos[0] : '', texto: textos.length ? textos[textos.length - 1] : '', host: host }; }); }
    function regras() { var linhas = document.getElementById('ra-regras').value.split('\n'); var rs = []; for (var i = 0; i < linhas.length; i++) { var linha = linhas[i].replace('=>', '='); var ix = linha.indexOf('='); if (ix < 0) { continue; } var chaves = linha.slice(0, ix).split(',').map(norm).filter(function (c) { return c.length > 0; }); var resp = linha.slice(ix + 1).trim(); if (chaves.length && resp) { rs.push({ chaves: chaves, resp: resp }); } } return rs; }
    function marcarTudoVisto() { var agora = Date.now(); itensComentario().forEach(function (c) { var chave = c.autor + '|' + c.texto; try { c.el.dataset.raVisto = chave; } catch (e) {} vistos.set(chave, agora); }); }
    function varre() { if (!rodando) { return; } var rs = regras(); var mencionar = document.getElementById('ra-mencao').checked; var agora = Date.now(); var itens = itensComentario(); var cont = {}; itens.forEach(function (c) { var k = c.autor + '|' + c.texto; cont[k] = (cont[k] || 0) + 1; }); itens.forEach(function (c) { var chave = c.autor + '|' + c.texto; var vistoAntes = vistoEm.get(chave) || 0; vistoEm.set(chave, agora); if (c.el.dataset && c.el.dataset.raVisto === chave) { return; } try { c.el.dataset.raVisto = chave; } catch (e) {} if (c.host) { return; } if (vistos.has(chave)) { var repetido = cont[chave] >= 2; var passou15s = agora - vistos.get(chave) > 15000; if (!(repetido && passou15s)) { return; } } var tn = norm(c.texto); for (var i = 0; i < rs.length; i++) { var bate = rs[i].chaves.some(function (k) { return tn.indexOf(k) > -1; }); if (bate) { vistos.set(chave, agora); var resp = (mencionar && c.autor ? ('@' + c.autor + ' ') : '') + rs[i].resp; if (resp.length > 100) { resp = rs[i].resp; } if (resp.length > 100) { resp = resp.slice(0, 97) + '...'; } fila.push(resp); break; } } }); }
    function processaFila() { if (!rodando || !fila.length) { return; } var agora = Date.now(); if (agora - ultimoEnvio < 5000) { return; } ultimoEnvio = agora; enviar(fila.shift()); }
    function liga() { if (!regras().length) { st('Cadastre pelo menos 1 regra (palavra = resposta).'); return; } marcarTudoVisto(); rodando = true; var b = document.getElementById('ra-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando comentários... 👀'); }
    function desliga() { rodando = false; fila = []; var b = document.getElementById('ra-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    document.getElementById('ra-botao').addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); } });
    window.raVarre = setInterval(varre, 2000);
    window.raFila = setInterval(processaFila, 1000);
  })();

  /* ===== 5. BLOQUEIO POR NOME (HATERS) ===== */
  (function () {
    'use strict';
    if (window.bnTimer) { clearInterval(window.bnTimer); }
    var rodando = false; var tratados = {};
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function norm(x) { return (x || '').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }
    function palavras() { var e = document.getElementById('bn-palavras'); if (!e) { return []; } return e.value.split('\n').map(function (x) { return norm(x); }).filter(function (x) { return x.length > 0; }); }
    function st(m) { var e = document.getElementById('bn-status'); if (e) { e.textContent = m; } }
    function disparar(el, tipos) { tipos.forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function clicar(el) { if (!el) { return; } try { el.scrollIntoView({ block: 'center' }); } catch (e) {} disparar(el, ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']); }
    function hover(el) { disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']); }
    function entradas() { var res = []; var vistos = []; $s('div,span,p').filter(function (x) { return vis(x) && fora(x) && x.children.length <= 4 && /acabou de entrar/i.test(x.textContent || '') && (x.textContent || '').length < 160; }).forEach(function (mk) { var row = mk; while (row.parentElement && /acabou de entrar/i.test(row.parentElement.textContent || '') && (row.parentElement.textContent || '').length < 160) { row = row.parentElement; } if (vistos.indexOf(row) > -1) { return; } vistos.push(row); var full = (row.textContent || '').replace(/\s+/g, ' ').trim(); var nome = full.replace(/\s*acabou de entrar.*/i, '').trim(); if (nome) { res.push({ row: row, nome: nome }); } }); return res; }
    function acharBloquear() { return $s('div,span,button,a,li').filter(function (x) { if (!vis(x) || x.children.length > 2) { return false; } var t = norm(x.textContent); return t.indexOf('bloquear') === 0; })[0]; }
    function maisBotoes(row) { var cs = $s('button,[role="button"],div,span,svg', row).filter(function (x) { if (!vis(x)) { return false; } var t = (x.textContent || '').trim(); return t.length <= 3; }); cs.sort(function (a, b) { return b.getBoundingClientRect().right - a.getBoundingClientRect().right; }); return cs.slice(0, 6); }
    function bloquear(item) { hover(item.row); setTimeout(function () { var mais = maisBotoes(item.row); var i = 0; (function tenta() { if (i >= mais.length) { st('Detectei "' + item.nome + '" mas não achei o botão "..."'); return; } clicar(mais[i]); i++; setTimeout(function () { var bl = acharBloquear(); if (bl) { clicar(bl); setTimeout(function () { var conf = $s('button,div,span,a').filter(function (x) { if (!vis(x) || x.children.length > 1) { return false; } var t = norm((x.textContent || '').trim()); return t === 'confirmar' || t === 'confirm' || t === 'sim' || t === 'ok'; })[0]; if (conf) { clicar(conf); } st('🚫 Bloqueado: ' + item.nome + ' (' + new Date().toLocaleTimeString() + ')'); }, 550); } else { tenta(); } }, 350); })(); }, 300); }
    function varre() { if (!rodando) { return; } var ps = palavras(); if (!ps.length) { return; } entradas().forEach(function (it) { var nn = norm(it.nome); if (!nn || tratados[nn]) { return; } if (ps.some(function (pw) { return nn.indexOf(pw) > -1; })) { tratados[nn] = 1; bloquear(it); } }); }
    function liga() { if (!palavras().length) { st('Cadastre pelo menos 1 palavra suspeita.'); return; } rodando = true; var b = document.getElementById('bn-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando entradas... 👀'); }
    function desliga() { rodando = false; var b = document.getElementById('bn-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var bb = document.getElementById('bn-botao'); if (bb) { bb.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    window.bnTimer = setInterval(varre, 3000);
  })();

  /* ===== 6. INTENÇÃO DE COMPRA ===== */
  (function () {
    'use strict';
    if (window.icTimer) { clearInterval(window.icTimer); }
    var rodando = false; var feitos = {}; var fila = []; var ocupado = false; var pendentes = []; var ultimoEnvio = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function st(m) { var e = document.getElementById('ic-status'); if (e) { e.textContent = m; } }
    function disparar(el, tipos) { tipos.forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function hover(el) { disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']); }
    function unhover(el) { disparar(el, ['mouseout', 'mouseleave', 'pointerout', 'pointerleave']); }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } disparar(el, ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { return false; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"],span').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 44 && r.left > tr.left - 6 && r.left < tr.right + 72 && r.width <= 40 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } setTimeout(function () { if (ta.value !== '') { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); }); } }, 250); }, 350); return true; }
    function achaAvatar(row) { var im = $s('img', row).filter(function (x) { return vis(x); }); if (im.length) { return im[0]; } var cs = $s('div,span', row).filter(function (x) { var r = x.getBoundingClientRect(); return vis(x) && r.width >= 16 && r.width <= 54 && r.height >= 16 && r.height <= 54; }); cs.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cs.length ? cs[0] : null; }
    function realVis(e) { try { var cs = getComputedStyle(e); if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.3) { return false; } var an = e.parentElement, k = 0; while (an && k < 8) { var c2 = getComputedStyle(an); if (c2.visibility === 'hidden' || c2.display === 'none' || parseFloat(c2.opacity) < 0.3) { return false; } an = an.parentElement; k++; } return true; } catch (_) { return false; } }
    function sobresReais() { var a = []; $s('div,span,p,h1,h2,h3,b,strong').forEach(function (e) { if (e.children.length > 3) { return; } var t = (e.textContent || '').trim(); var m = t.match(/^Sobre\s+(.{2,40})$/i); if (!m) { return; } if (!realVis(e)) { return; } var n = m[1].replace(/\s*[ⓘℹ️①(].*$/, '').trim(); if (n) { a.push(n); } }); return a; }
    function nomePopover(antes) { var depois = sobresReais(); var novos = depois.filter(function (n) { return antes.indexOf(n) < 0; }); if (novos.length) { return novos[0]; } return depois.length ? depois[0] : null; }
    function eventos() { var res = []; var vistos = []; $s('div,span,p').filter(function (x) { if (!vis(x) || !fora(x) || x.children.length !== 0) { return false; } var t = (x.textContent || '').trim(); if (t.length > 60) { return false; } return /adicionou o produto/i.test(t) && /carrinho/i.test(t); }).forEach(function (mk) { var row = mk; for (var i = 0; i < 6 && row.parentElement; i++) { row = row.parentElement; if (row.querySelector('img')) { break; } } if (vistos.indexOf(row) > -1) { return; } vistos.push(row); var t = (mk.textContent || ''); res.push({ row: row, tipo: /est[aá] vendo/i.test(t) ? 'ver' : 'cart' }); }); return res; }
    function processa() { if (ocupado || !rodando || !fila.length) { return; } ocupado = true; var it = fila.shift(); var av = achaAvatar(it.row); if (!av) { ocupado = false; return; } var antes = sobresReais(); function limpaHover() { unhover(av); var _pp = av; for (var _i = 0; _i < 4 && _pp; _i++) { unhover(_pp); _pp = _pp.parentElement; } try { document.body.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: 4, clientY: 4, view: window })); } catch (e) {} } function finaliza(nome) { limpaHover(); if (!nome) { st('Vi um evento mas não peguei o nome.'); setTimeout(function () { ocupado = false; }, 300); return; } var chave = 'cart|' + nome; if (feitos[chave]) { ocupado = false; return; } feitos[chave] = 1; var base = (document.getElementById('ic-cart') || { value: '' }).value || ''; base = base.trim(); if (!base) { ocupado = false; return; } var msg = '@' + nome + ' ' + base; if (msg.length > 100) { msg = msg.slice(0, 100); } pendentes.push({ texto: msg, label: 'Carrinho: @' + nome }); st('🛒 Carrinho: @' + nome + ' — na fila de envio'); setTimeout(function () { ocupado = false; }, 400); } var tent = 0; function tenta() { tent++; hover(av); setTimeout(function () { var nome = nomePopover(antes); if (nome) { finaliza(nome); return; } if (tent >= 7) { finaliza(null); return; } tenta(); }, 280); } tenta(); }
    function varre() { if (!rodando) { return; } try { var evs = eventos(); evs.forEach(function (ev) { if (ev.row.dataset && ev.row.dataset.icQ) { return; } try { ev.row.dataset.icQ = '1'; } catch (e) {} fila.push(ev); }); if (!ocupado && !fila.length && !pendentes.length) { st('Monitorando Intenção de compra... 👀'); } } catch (err) { st('erro varre: ' + ((err && err.message) || err)); } }
    function enviaPendentes() { if (!rodando || !pendentes.length) { return; } var agora = Date.now(); if (agora - ultimoEnvio < 4000) { return; } ultimoEnvio = agora; var item = pendentes.shift(); var ok = enviar(item.texto); st(ok ? ('💬 ' + item.label + ' — enviado (' + new Date().toLocaleTimeString() + ')') : ('Fila cheia — caixa não encontrada.')); }
    function liga() { rodando = true; var b = document.getElementById('ic-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando intenção de compra... 👀'); }
    function desliga() { rodando = false; fila = []; pendentes = []; ocupado = false; var b = document.getElementById('ic-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var bb = document.getElementById('ic-botao'); if (bb) { bb.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    window.icTimer = setInterval(function () { varre(); processa(); enviaPendentes(); }, 1200);
  })();

  /* ===== 7. ALERTA DE VENDAS NTFY ===== */
  (function () {
    'use strict';
    if (window.nvTimer) { clearInterval(window.nvTimer); }
    var rodando = false; var fila = []; var ultimo = 0; var total = 0;
    var RE = /(fez um pedido|realizou (um |o )?pedido|acabou de comprar|comprou|compraram|pagamento (confirmado|efetuado)|efetuou o pagamento|pedido pago|pagou o pedido|criou (um|o) pedido|placed an order)/i;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function st(m) { var e = document.getElementById('nv-status'); if (e) { e.textContent = m; } }
    function canal() { var e = document.getElementById('nv-canal'); return e ? (e.value || '').trim() : ''; }
    function manda(titulo, corpo, tags, cb) { var c = canal(); if (!c) { if (cb) { cb(false); } return; } function direto() { try { fetch('https://ntfy.sh', { method: 'POST', body: JSON.stringify({ topic: c, title: titulo, message: corpo, tags: (tags || 'bell').split(','), priority: 5 }) }).then(function (r) { if (cb) { cb(r.ok); } }).catch(function () { if (cb) { cb(false); } }); } catch (e) { if (cb) { cb(false); } } } try { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) { chrome.runtime.sendMessage({ type: 'ttlf-ntfy', canal: c, titulo: titulo, corpo: corpo, tags: tags || 'bell' }, function (resp) { if (chrome.runtime.lastError || !resp || !resp.ok) { direto(); } else { if (cb) { cb(true); } } }); return; } } catch (e) {} direto(); }
    function contaVendas(t) { return (String(t).match(/comprou o produto|acabou de comprar|fez um pedido|realizou (um |o )?pedido|placed an order/gi) || []).length; }
    function eventosVenda() { var res = []; var singles = $s('div,span,p').filter(function (x) { if (!vis(x) || !fora(x)) { return false; } var t = (x.textContent || '').trim(); if (!t || t.length > 90) { return false; } return contaVendas(t) === 1 && RE.test(t) && /R\$\s?\d/.test(t); }); singles.forEach(function (x) { for (var j = 0; j < singles.length; j++) { if (singles[j] !== x && x.contains(singles[j])) { return; } } res.push({ el: x, txt: (x.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 90) }); }); return res; }
    function marcarVistos() { eventosVenda().forEach(function (ev) { try { ev.el.dataset.nvQ = '1'; } catch (e) {} }); }
    function dlog(t) { try { var arr = []; try { arr = JSON.parse(localStorage.getItem('ttlf-nv-debug') || '[]'); } catch (e) {} arr.push(new Date().toTimeString().slice(0, 8) + ' ' + t); if (arr.length > 80) { arr = arr.slice(-80); } localStorage.setItem('ttlf-nv-debug', JSON.stringify(arr)); } catch (e) {} try { ttlfLog('[VendaDbg] ' + t); } catch (e) {} }
    function debugScan() { try { $s('div,span,p').forEach(function (x) { if (x.children.length > 3) { return; } if (!vis(x) || !fora(x)) { return; } var t = (x.textContent || '').trim(); if (!t || t.length > 160) { return; } if (!/(compr|pedido|pagou)/i.test(t)) { return; } if (x.dataset && x.dataset.nvDbg) { return; } try { x.dataset.nvDbg = '1'; } catch (e) {} dlog(t); }); } catch (e) {} }
    function varre() { if (!rodando) { return; } try { var agora = Date.now(); eventosVenda().forEach(function (ev) { if (ev.el.dataset && ev.el.dataset.nvQ) { return; } try { ev.el.dataset.nvQ = '1'; } catch (e) {} dlog('DETECTOU VENDA: ' + ev.txt); fila.push(ev.txt); }); } catch (err) { st('erro: ' + ((err && err.message) || err)); } }
    function corpoVenda(txt) {
      txt = txt || ''; var preco = null, prod = null; var mp = txt.match(/R\$\s?([\d.]+,\d{2}|[\d.,]+)/); if (mp) { preco = 'R$ ' + mp[1]; } var mn = txt.match(/n[ºo°.]?\s?(\d+)/i); if (mn) { prod = 'Produto nº ' + mn[1]; }
      if (preco) {
        var numP = parseFloat(mp[1].replace(/\./g, '').replace(',', '.'));
        if (!isNaN(numP) && numP < 1000000) {
          window.ttlfTotalGMVContado = (window.ttlfTotalGMVContado || 0) + numP;
        }
      }
      window.ttlfTotalVendasContadas = (window.ttlfTotalVendasContadas || 0) + 1;
      if (prod && preco) { return prod + ' — ' + preco; } if (preco) { return 'Venda de ' + preco + ' na sua LIVE!'; } if (prod) { return prod + ' vendido na sua LIVE!'; } return txt ? txt : 'Nova venda na sua LIVE! 🤑';
    }
    function envia() { if (!rodando || !fila.length) { return; } var agora = Date.now(); if (agora - ultimo < 1500) { return; } ultimo = agora; var txt = fila.shift(); manda('Venda Realizada - Parabéns!', corpoVenda(txt), 'moneybag', function (ok) { if (ok) { total = total + 1; st('🤑 Venda #' + total + ' — notificação enviada ' + new Date().toLocaleTimeString()); } else { st('⚠️ Falha ao enviar notificação — confira o canal.'); } }); }
    function liga() { if (!canal()) { st('Digite o nome do canal ntfy primeiro.'); return; } marcarVistos(); rodando = true; var b = document.getElementById('nv-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando vendas... 👀'); }
    function desliga() { rodando = false; fila = []; var b = document.getElementById('nv-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var bb = document.getElementById('nv-botao'); if (bb) { bb.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    var bt = document.getElementById('nv-teste'); if (bt) { bt.addEventListener('click', function () { if (!canal()) { st('Digite o nome do canal ntfy primeiro.'); return; } st('Enviando teste...'); manda('Venda Realizada - Parabéns!', 'Produto nº 13 — R$ 87,31 (TESTE)', 'moneybag', function (ok) { st(ok ? '✅ Teste enviado! Olha seu celular.' : '⚠️ Falha no teste — confira o canal.'); }); }); }
    window.nvTimer = setInterval(function () { debugScan(); varre(); envia(); }, 700);
  })();

  /* ===== 8. PROTEÇÃO CONTRA VIOLAÇÃO ===== */
  (function () {
    'use strict';
    if (window.rvTick) { clearInterval(window.rvTick); }
    var encerrando = false; var detectadoEm = 0; var confirmando = false; var ultimoAbrir = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rv-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharTimer() { var els = $s('div,span,p,b,strong'); for (var i = 0; i < els.length; i++) { var e = els[i]; if (e.children.length === 0) { var t = (e.textContent || '').trim(); if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && vis(e) && fora(e)) { return e; } } } return null; }
    function acharPower(tm) { var el = tm, tr = tm.getBoundingClientRect(); for (var up = 0; up < 9 && el; up++) { el = el.parentElement; if (!el) { break; } var cands = $s('button,[role="button"],svg', el).filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if (((b.textContent || '').trim()) !== '') { return false; } var r = b.getBoundingClientRect(); if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) { return false; } return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer'; }); if (cands.length) { cands.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cands[0]; } } return null; }
    function botaoConfirmar() { var bs = $s('button,[role="button"]').filter(function (b) { var t = (b.textContent || '').trim(); return vis(b) && fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel/i.test(t) && t.length < 40; }); return bs.length ? bs[bs.length - 1] : null; }
    function ehConfig(e) { var q = e; for (var k = 0; k < 14 && q; k++) { var t = (q.textContent || ''); if (t.length < 8000 && /(Configura[cç][oõ]es|Filtrar coment|Permitir coment|palavras-chave|Dura[cç][aã]o do silenciamento|Bloquear palavras|comunidade j[aá] sinalizou|potencialmente desagrad)/i.test(t)) { return true; } q = q.parentElement; } return false; }
    function achaAviso() { var dots = $s('span,sup,i,b,div'); for (var i = 0; i < dots.length; i++) { var e = dots[i]; var cls = (e.className || '').toString(); if (cls.indexOf('m4b-badge-dot') < 0) { continue; } if (!vis(e) || !fora(e)) { continue; } var r = e.getBoundingClientRect(); if (r.top > 170) { continue; } var p = e; for (var k = 0; k < 5 && p; k++) { var b = (p.querySelector) ? p.querySelector('button,[role="button"]') : null; if (b && vis(b) && fora(b)) { return b; } if (p.tagName === 'BUTTON') { return p; } p = p.parentElement; } } var all = $s('div,span,i,sup,b'); for (var j = 0; j < all.length; j++) { var e2 = all[j]; if (!vis(e2) || !fora(e2) || e2.children.length > 0) { continue; } var r2 = e2.getBoundingClientRect(); if (r2.top > 170) { continue; } if (r2.width < 5 || r2.width > 18 || r2.height < 5 || r2.height > 18) { continue; } var bg = getComputedStyle(e2).backgroundColor || ''; var m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/); if (!m) { continue; } var R = +m[1], G = +m[2], B = +m[3], A = (m[4] === undefined ? 1 : +m[4]); if (A < 0.6) { continue; } if (!(R > 160 && G < 115 && B < 130)) { continue; } var p2 = e2; for (var k2 = 0; k2 < 5 && p2; k2++) { var b2 = (p2.querySelector) ? p2.querySelector('button,[role="button"]') : null; if (b2 && vis(b2) && fora(b2)) { return b2; } if (p2.tagName === 'BUTTON' || (p2.getAttribute && p2.getAttribute('role') === 'button')) { return p2; } try { if (getComputedStyle(p2).cursor === 'pointer') { return p2; } } catch (_) {} p2 = p2.parentElement; } } return null; }
    function detecta() { var els = $s('div,span,p,h1,h2,h3,b,strong'); var temPainel = false; for (var i = 0; i < els.length; i++) { var t0 = (els[i].textContent || '').trim(); if (/^Lembrete de viola/i.test(t0) && els[i].children.length <= 3 && vis(els[i])) { temPainel = true; break; } } if (temPainel) { var conta = null; for (var j = 0; j < els.length; j++) { if (els[j].children.length > 0) { continue; } var tj = (els[j].textContent || '').trim(); var mm = tj.match(/^Todos?\s*\((\d+)\)/i); if (mm) { conta = parseInt(mm[1], 10); break; } } if (conta !== null) { if (conta > 0) { return 'Violação no painel (Todos ' + conta + ')'; } return null; } return null; } var re = /(sua live pode ser suspensa|sua transmiss[aã]o pode ser suspensa|live foi encerrada por viola|live ser[aá] encerrada por viola|viola[cç][aã]o das diretrizes|conte[uú]do impr[oó]prio detect|penalidade aplicad|foi sinalizada por viola)/i; for (var k = 0; k < els.length; k++) { var e = els[k]; if (e.children.length !== 0) { continue; } var cls = (e.className || '').toString(); if (cls.indexOf('text-body') > -1) { continue; } if (!vis(e) || !fora(e)) { continue; } var x = (e.textContent || '').trim(); if (x && x.length < 300 && re.test(x)) { if (ehConfig(e)) { continue; } return x.slice(0, 70); } } return null; }
    function tick() { sincBtn(); var cb = document.getElementById('rv-ativo'); if (!cb) { return; } if (!cb.checked) { st('Inativa.'); encerrando = false; confirmando = false; detectadoEm = 0; return; } var agora = Date.now(); var tm = acharTimer(); if (confirmando) { var cf = botaoConfirmar(); if (cf) { cf.click(); } if (!acharTimer()) { confirmando = false; st('LIVE encerrada pela proteção. ' + new Date().toLocaleTimeString()); } return; } if (encerrando) { if (!tm) { st('LIVE encerrada pela proteção. ' + new Date().toLocaleTimeString()); } else if (agora - detectadoEm > 180000) { encerrando = false; detectadoEm = 0; } return; } if (!tm) { st('Ativa 🛡️ — aguardando LIVE no ar.'); detectadoEm = 0; return; } var av = detecta(); if (!av) { var _ic = achaAviso(); if (_ic && (Date.now() - ultimoAbrir > 6000)) { ultimoAbrir = Date.now(); clicar(_ic); st('🔎 Verificando aviso de violação...'); return; } st('Ativa 🛡️ monitorando a tela (' + new Date().toLocaleTimeString() + ')'); detectadoEm = 0; return; } if (!detectadoEm) { detectadoEm = agora; } var atraso = (parseInt(document.getElementById('rv-delay').value, 10) || 0) * 1000; var falta = detectadoEm + atraso - agora; if (falta > 0) { st('⚠️ AVISO DETECTADO! Encerrando em ' + Math.ceil(falta / 1000) + 's — "' + av + '"'); return; } var pw = acharPower(tm); if (pw) { clicar(pw); encerrando = true; confirmando = true; st('⚠️ Aviso detectado — ENCERRANDO A LIVE!'); } else { st('⚠️ Aviso detectado, mas não achei o botão de desligar!'); } }
    function sincBtn() { var cb = document.getElementById('rv-ativo'); var b = document.getElementById('rv-botao'); if (!cb || !b) { return; } if (cb.checked) { b.textContent = '⏸ Desativar proteção'; b.style.background = '#ff1717'; } else { b.textContent = '▶ Ativar proteção'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; } }
    var btnRv = document.getElementById('rv-botao'); if (btnRv) { btnRv.addEventListener('click', function () { var cb = document.getElementById('rv-ativo'); if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change', { bubbles: true })); } sincBtn(); }); }
    sincBtn();
    window.rvTick = setInterval(tick, 2000);
  })();

  /* ===== 9. TIMER DE ENCERRAMENTO REGRESSIVO ===== */
  (function () {
    'use strict';
    if (window.rtTick) { clearInterval(window.rtTick); }
    var fase = 'off'; var deadline = 0; var resto = 0; var confirmando = false;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rt-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharTimer() { var els = $s('div,span,p,b,strong'); for (var i = 0; i < els.length; i++) { var e = els[i]; if (e.children.length === 0) { var t = (e.textContent || '').trim(); if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && vis(e) && fora(e)) { return e; } } } return null; }
    function acharPower(tm) { var el = tm, tr = tm.getBoundingClientRect(); for (var up = 0; up < 9 && el; up++) { el = el.parentElement; if (!el) { break; } var cands = $s('button,[role="button"],svg', el).filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if (((b.textContent || '').trim()) !== '') { return false; } var r = b.getBoundingClientRect(); if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) { return false; } return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer'; }); if (cands.length) { cands.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cands[0]; } } return null; }
    function botaoConfirmar() { var bs = $s('button,[role="button"]').filter(function (b) { var t = (b.textContent || '').trim(); return vis(b) && fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel/i.test(t) && t.length < 40; }); return bs.length ? bs[bs.length - 1] : null; }
    function fmt(ms) { var s = Math.max(0, Math.round(ms / 1000)); var h = Math.floor(s / 3600), m = Math.floor((s - h * 3600) / 60), x = s - h * 3600 - m * 60; function z(n) { return (n < 10 ? '0' : '') + n; } return z(h) + ':' + z(m) + ':' + z(x); }
    function mostra(ms) { var e = document.getElementById('rt-restante'); if (e) { e.textContent = fmt(ms); } }
    function salva() { try { localStorage.setItem('ttlf-rt-estado', JSON.stringify({ fase: fase, deadline: deadline, resto: resto })); } catch (e) {} }
    function botoes() { var a = document.getElementById('rt-armar'); var p = document.getElementById('rt-pausa'); var c = document.getElementById('rt-cancel'); if (!a || !p || !c) { return; } if (fase === 'off') { a.style.display = 'block'; p.style.display = 'none'; c.style.display = 'none'; } else { a.style.display = 'none'; p.style.display = 'block'; c.style.display = 'block'; p.textContent = (fase === 'pausado') ? '▶ Retomar' : '⏸ Pausar'; } }
    function armar() { var min = parseInt(document.getElementById('rt-min').value, 10) || 120; if (min < 1) { min = 1; } deadline = Date.now() + min * 60000; fase = 'contando'; salva(); botoes(); st('Timer iniciado ⏲️ encerra às ' + new Date(deadline).toLocaleTimeString()); }
    function pausaRetoma() { if (fase === 'contando') { resto = deadline - Date.now(); fase = 'pausado'; st('Pausado com ' + fmt(resto) + ' restantes.'); } else if (fase === 'pausado') { deadline = Date.now() + resto; fase = 'contando'; st('Retomado — encerra às ' + new Date(deadline).toLocaleTimeString()); } salva(); botoes(); }
    function cancela() { fase = 'off'; deadline = 0; resto = 0; confirmando = false; salva(); botoes(); st('Desligado.'); }
    function tick() { if (confirmando) { var cf = botaoConfirmar(); if (cf) { cf.click(); } if (!acharTimer()) { confirmando = false; st('LIVE encerrada pelo timer às ' + new Date().toLocaleTimeString() + ' ✅'); } return; } if (fase === 'off') { var min = parseInt(document.getElementById('rt-min').value, 10) || 0; mostra(min * 60000); return; } if (fase === 'pausado') { mostra(resto); return; } var falta = deadline - Date.now(); mostra(falta); if (falta > 0) { return; } var tm = acharTimer(); if (!tm) { st('Tempo esgotado — LIVE já estava fora do ar.'); cancela(); return; } var pw = acharPower(tm); if (!pw) { st('⏰ Tempo esgotado, mas não achei o botão de desligar!'); return; } clicar(pw); confirmando = true; fase = 'off'; deadline = 0; salva(); botoes(); st('⏰ Tempo esgotado — ENCERRANDO A LIVE!'); }
    try { var sv = localStorage.getItem('ttlf-rt-estado'); if (sv) { sv = JSON.parse(sv); if (sv.fase === 'contando' && sv.deadline > Date.now()) { fase = 'contando'; deadline = sv.deadline; st('Timer recuperado — encerra às ' + new Date(deadline).toLocaleTimeString()); } else if (sv.fase === 'pausado' && sv.resto > 0) { fase = 'pausado'; resto = sv.resto; st('Pausado com ' + fmt(resto) + ' restantes.'); } } } catch (e) {}
    botoes();
    var btnArmar = document.getElementById('rt-armar'); if (btnArmar) { btnArmar.addEventListener('click', armar); }
    var btnPausa = document.getElementById('rt-pausa'); if (btnPausa) { btnPausa.addEventListener('click', pausaRetoma); }
    var btnCancel = document.getElementById('rt-cancel'); if (btnCancel) { btnCancel.addEventListener('click', cancela); }
    $s('.ttlf-preset').forEach(function (b) { b.addEventListener('click', function () { var inp = document.getElementById('rt-min'); if (inp) { inp.value = b.getAttribute('data-min'); inp.dispatchEvent(new Event('input', { bubbles: true })); } }); });
    window.rtTick = setInterval(tick, 500);
  })();

  /* ===== 10. DUPLICAR OFERTA RELÂMPAGO ===== */
  (function () {
    'use strict';
    if (window.rdTick) { clearInterval(window.rdTick); }
    var rodando = false; var fase = 'watch'; var t0 = 0; var espera = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rd-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function achaExato(txt) { return $s('button,[role="button"],a,span,div').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if ((b.textContent || '').trim() !== txt) { return false; } return b.tagName === 'BUTTON' || b.tagName === 'A' || getComputedStyle(b).cursor === 'pointer'; }); }
    function tick() { if (!rodando) { return; } var agora = Date.now(); if (agora < espera) { return; } if (fase === 'watch') { var cands = achaExato('Duplicar').filter(function (b) { var el = b; for (var i = 0; i < 6 && el; i++) { el = el.parentElement; if (!el) { break; } var t = el.textContent || ''; if (t.indexOf('foi encerrada') > -1) { return true; } if (t.length > 500) { break; } } return false; }); if (cands.length) { clicar(cands[0]); fase = 'm1'; t0 = agora; st('Oferta encerrada detectada — duplicando...'); } else { st('Monitorando oferta relâmpago... 👀'); } return; } if (fase === 'm1') { var b1 = achaExato('Duplicar e começar agora'); if (b1.length) { clicar(b1[b1.length - 1]); fase = 'm2'; t0 = agora; st('Duplicando e iniciando...'); return; } if (agora - t0 > 20000) { fase = 'watch'; st('Tentando de novo...'); } return; } if (fase === 'm2') { var b2 = achaExato('Iniciar').filter(function (b) { var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) { break; } var cls = (el.className || '').toString(); if ((cls.indexOf('modal') > -1 || el.getAttribute('role') === 'dialog') && (el.textContent || '').indexOf('Oferta rel') > -1) { return true; } } return false; }); if (!b2.length) { b2 = achaExato('Iniciar'); } if (b2.length) { clicar(b2[b2.length - 1]); fase = 'watch'; espera = agora + 30000; st('Oferta relâmpago relançada! ✅ ' + new Date().toLocaleTimeString()); return; } if (agora - t0 > 20000) { fase = 'watch'; st('Tentando de novo...'); } return; } }
    function liga() { rodando = true; fase = 'watch'; espera = 0; var b = document.getElementById('rd-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando oferta relâmpago... 👀'); }
    function desliga() { rodando = false; var b = document.getElementById('rd-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var btnRd = document.getElementById('rd-botao'); if (btnRd) { btnRd.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    window.rdTick = setInterval(tick, 2000);
  })();

}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && (msg.type === 'ttlf-show' || msg.action === 'toggleUI')) {
      ttlfShowUI();
    }
  });
}

ttlfBoot();
