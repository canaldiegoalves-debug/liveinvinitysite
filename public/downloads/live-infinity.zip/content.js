/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "90a6d478d9909e1b";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
/* Live Infinity Enterprise Security Shield v10.1.0 - Protected & Encrypted */
var _0xinfSig = "6ee03d5dd850410a";

  (function _infShieldInit() {
    const _secCheck = function() {
      const _startTime = performance.now();
      debugger;
      const _endTime = performance.now();
      if (_endTime - _startTime > 100) {
        window.location.reload();
      }
    };
    try { setInterval(_secCheck, 800); } catch(e) {}
  })();
  
'use strict';
/* ============================================================================
   ♾️ LIVE INFINITY v10.0.0 — ÁUDIO CRISTALINO SEM PICOTAMENTO,
   GMV, MÍDIA/VB-CABLE COMPLETO, DRIVER DOWNLOAD, SOUNDBOARD FX, 
   BLOQUEIO OBRIGATÓRIO DE CUPOM E AUTO-PROTEÇÃO DE LIVE ON-AIR
   ============================================================================ */

var TTLF_API = 'https://licencas.liveinfinity.online';
var TTLF_GRACE = 72 * 3600 * 1000;
window.ttlfLogArr = window.ttlfLogArr || [];
window.ttlfAudioHistory = window.ttlfAudioHistory || [];

function ttlfNow() { return new Date().toTimeString().slice(0, 8); }

function ttlfLog(msg) {
  var line = '[' + ttlfNow() + '] ' + msg;
  window.ttlfLogArr.push(line);
  if (window.ttlfLogArr.length > 400) { window.ttlfLogArr.shift(); }
  var box = document.getElementById('ttlf-log-box');
  if (box) { box.textContent = window.ttlfLogArr.join('\n'); box.scrollTop = box.scrollHeight; }
}

var TTLF_LOG_LABELS = {
  'rt-status': 'Timer',
  'rf-status': 'Refixar',
  'rd-status': 'Oferta',
  'rc-status': 'Coment.',
  'ra-status': 'Respostas',
  'rv-status': 'Proteção',
  'bn-status': 'Bloqueio',
  'ic-status': 'Intenção',
  'nv-status': 'Venda',
  'md-status': 'Mídia'
};

function ttlfLogWatch() {
  if (window.ttlfLogTimer) { return; }
  var last = {};
  window.ttlfLogTimer = setInterval(function () {
    for (var id in TTLF_LOG_LABELS) {
      var e = document.getElementById(id);
      if (!e) { continue; }
      var t = (e.textContent || '').trim();
      if (!t) { continue; }
      if (last[id] === undefined) { last[id] = t; continue; }
      if (t !== last[id]) { last[id] = t; ttlfLog('[' + TTLF_LOG_LABELS[id] + '] ' + t); }
    }
    try { ttlfUpdStatus(); } catch (e) {}
    try { ttlfUpdPower(); } catch (e) {}
    try { ttlfScanStats(); } catch (e) {}
  }, 1200);
}

function ttlfLiveNoAr() {
  try {
    var els = document.querySelectorAll('div,span,p,b,strong');
    for (var i = 0; i < els.length; i++) {
      var e = els[i];
      if (e.children.length !== 0) { continue; }
      var t = (e.textContent || '').trim();
      if (!/^\d{1,2}:\d{2}:\d{2}$/.test(t)) { continue; }
      var r = e.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) { continue; }
      var p = e, dentro = false;
      while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { dentro = true; break; } p = p.parentElement; }
      if (dentro) { continue; }
      return true;
    }
  } catch (e) {}
  return false;
}

/* LEITOR AUTOMÁTICO E RIGOROSO DE GMV E VENDAS REALIZADAS DO TIKTOK SHOP */
function ttlfScanStats() {
  var vEl = document.getElementById('ttlf-stat-vendas');
  var gEl = document.getElementById('ttlf-stat-gmv');
  if (!vEl || !gEl) return;

  var totalVendas = 0;
  var totalGMV = 0.00;
  var encontrouLiveCard = false;

  try {
    var allCards = document.querySelectorAll('div, section, article');
    for (var c = 0; c < allCards.length; c++) {
      var cardText = (allCards[c].textContent || '');
      if (/(Análise da transmissão|Análise da live|Desempenho da transmissão|Live Stream Analytics)/i.test(cardText)) {
        encontrouLiveCard = true;

        var mGmv = cardText.match(/R$s?([d.,]+)/);
        if (mGmv) {
          var valG = parseFloat(mGmv[1].replace(/\./g, '').replace(',', '.'));
          if (!isNaN(valG) && valG >= 0) {
            totalGMV = valG;
          }
        }

        var mVnd = cardText.match(/(?:Pedidos|Vendas|Produtos vendidos|Itens pagos)\s*[:\s]*(\d+)/i);
        if (!mVnd) {
          mVnd = cardText.match(/(\d+)\s*(?:pedidos|vendas|unidades)/i);
        }
        if (mVnd) {
          var valV = parseInt(mVnd[1], 10);
          if (!isNaN(valV) && valV >= 0) {
            totalVendas = valV;
          }
        }
        break;
      }
    }

    if (!encontrouLiveCard) {
      totalVendas = window.ttlfTotalVendasContadas || 0;
      totalGMV = window.ttlfTotalGMVContado || 0.00;
    } else {
      if (window.ttlfTotalVendasContadas !== undefined) {
        totalVendas = Math.max(totalVendas, window.ttlfTotalVendasContadas);
      }
      if (window.ttlfTotalGMVContado !== undefined) {
        totalGMV = Math.max(totalGMV, window.ttlfTotalGMVContado);
      }
    }
  } catch (e) {}

  vEl.textContent = totalVendas;
  gEl.textContent = 'R$ ' + totalGMV.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function ttlfTipEl() {
  var t = document.getElementById('ttlf-tip');
  if (t) { return t; }
  t = document.createElement('div');
  t.id = 'ttlf-tip';
  t.style.cssText = 'position:fixed;z-index:2147483647;display:none;pointer-events:none;background:#070a12;color:#ffd000;border:1px solid rgba(255,208,0,0.4);border-radius:8px;padding:5px 9px;font:600 11px/1.2 -apple-system,Segoe UI,Roboto,Arial,sans-serif;white-space:nowrap;box-shadow:0 4px 14px rgba(0,0,0,.85)';
  document.body.appendChild(t);
  return t;
}

function ttlfTipHide() { var t = document.getElementById('ttlf-tip'); if (t) { t.style.display = 'none'; } }

function ttlfTipBind(el) {
  if (!el || el.getAttribute('data-tipbind')) { return; }
  try { el.setAttribute('data-tipbind', '1'); } catch (e) {}
  el.addEventListener('mouseenter', function () {
    var tx = el.getAttribute('data-tip') || '';
    if (!tx) { return; }
    var t = ttlfTipEl();
    t.textContent = tx;
    t.style.display = 'block';
    t.style.left = '-9999px'; t.style.top = '-9999px';
    var r = el.getBoundingClientRect();
    var tr = t.getBoundingClientRect();
    var left = r.left + r.width / 2 - tr.width / 2;
    if (left < 6) { left = 6; }
    if (left + tr.width > window.innerWidth - 6) { left = window.innerWidth - 6 - tr.width; }
    var top = r.bottom + 6;
    if (top + tr.height > window.innerHeight - 6) { top = r.top - tr.height - 6; }
    t.style.left = left + 'px';
    t.style.top = top + 'px';
  });
  el.addEventListener('mouseleave', ttlfTipHide);
  el.addEventListener('mousedown', ttlfTipHide);
}

function ttlfUpdPower() {
  var pw = document.getElementById('ttlf-power'); if (!pw) { return; }
  ['ttlf-cfg', 'ttlf-power', 'ttlf-min'].forEach(function (bid) {
    var be = document.getElementById(bid);
    if (!be) { return; }
    ttlfTipBind(be);
    try { be.removeAttribute('title'); } catch (e) {}
  });
  var no = ttlfLiveNoAr();
  if (no === window.ttlfPwState) { return; }
  window.ttlfPwState = no;
  if (no) {
    pw.style.borderColor = '#ff1717';
    pw.style.background = 'rgba(255,23,23,.2)';
    pw.style.color = '#ff3355';
    pw.setAttribute('data-tip', 'Encerrar a LIVE agora');

    try {
      var cbRv = document.getElementById('rv-ativo');
      if (cbRv && !cbRv.checked) {
        cbRv.checked = true;
        cbRv.dispatchEvent(new Event('change', { bubbles: true }));
        var btnRv = document.getElementById('rv-botao');
        if (btnRv) {
          btnRv.textContent = '⏸ Desativar proteção';
          btnRv.style.background = '#ff1717';
        }
        ttlfLog('🛡️ LIVE entrou no ar! Proteção Anti-Ban ATIVADA AUTOMATICAMENTE ✅');
      }
    } catch (e) {}
  } else {
    pw.style.borderColor = 'rgba(255,208,0,0.3)';
    pw.style.background = '#141928';
    pw.style.color = '#ffd000';
    pw.setAttribute('data-tip', 'Nenhuma LIVE no ar');
  }
}

function ttlfUpdStatus() {
  var badge = document.getElementById('ttlf-status'); if (!badge) { return; }
  var ativo = false;
  ['rf-botao', 'rc-botao', 'ra-botao', 'rd-botao', 'bn-botao', 'ic-botao', 'nv-botao', 'rv-botao', 'md-vcable-btn'].forEach(function (id) {
    var b = document.getElementById(id);
    if (b && (b.textContent || '').indexOf('⏸') > -1) { ativo = true; }
  });
  var arm = document.getElementById('rt-armar');
  if (arm && arm.style.display === 'none') { ativo = true; }
  if (ativo) { badge.textContent = '● ATIVO'; badge.style.color = '#ffd000'; badge.style.background = 'rgba(255,208,0,.15)'; badge.style.borderColor = '#ffd000'; }
  else { badge.textContent = '● INATIVO'; badge.style.color = '#ff3355'; badge.style.background = 'rgba(255,23,23,.15)'; badge.style.borderColor = '#ff1717'; }
}

function ttlfStGet(cb) {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['liveinfinity_lic'], function (r) { cb(r && r.liveinfinity_lic ? r.liveinfinity_lic : null); });
      return;
    }
  } catch (e) {}
  try { var v = localStorage.getItem('liveinfinity_lic'); cb(v ? JSON.parse(v) : null); } catch (e) { cb(null); }
}

function ttlfStSet(lic) {
  try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) { chrome.storage.local.set({ liveinfinity_lic: lic }); } } catch (e) {}
  try { localStorage.setItem('liveinfinity_lic', JSON.stringify(lic)); } catch (e) {}
}

function ttlfDevice(lic) {
  if (lic && lic.device) { return lic.device; }
  return 'dv-li-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function ttlfValida(key, device, cb) {
  var k = (key || '').trim().toUpperCase();
  if (!k || k.length < 6) { cb(false, 'invalid', false, null); return; }

  fetch('https://api.valoranegocios.com.br/api/check', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: k, device: device })
  }).then(function(r) { return r.json(); }).then(function(data) {
    if (data && data.ok) {
      var cleanEm = (data.email || '').replace(/^(liveinfinity|livecam):/i, '').trim();
      var expMs = data.expiresAt ? new Date(data.expiresAt).getTime() : (Date.now() + 30 * 86400000);
      cb(true, 'ok', false, { email: cleanEm, exp: expMs });
    } else {
      cb(false, (data && data.reason) || 'invalid', false, null);
    }
  }).catch(function() {
    cb(true, 'ok', true, { email: 'afiliadodiegoalves@gmail.com', exp: Date.now() + 30 * 86400000 });
  });
}

function ttlfMsg(r) {
  if (!r) { return ''; }
  var m = { invalid: 'Chave inválida. Confira e tente de novo.', blocked: 'Assinatura inativa ou cancelada.', devices: 'Chave já em uso no máximo de dispositivos.', offline: 'Sem conexão com o servidor de licenças.', config: 'Extensão sem URL do servidor configurada.' };
  return m[r] || ('Erro: ' + r);
}

function ttlfFmtDate(ms) { if (!ms) { return '—'; } try { var d = new Date(ms); return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); } catch (e) { return '—'; } }

function ttlfRollExp(lic) { var now = Date.now(); if (!lic) { return lic; } if (!lic.activated) { lic.activated = now; } if (!lic.exp) { lic.exp = now + 30 * 86400000; } while (lic.exp && now >= lic.exp) { lic.exp += 30 * 86400000; } return lic; }

function ttlfCfgClose() {
  var hub = document.getElementById('ttlf-hub'); if (!hub) { return; }
  var p = document.getElementById('ttlf-cfg-panel'); if (p && p.parentNode) { p.parentNode.removeChild(p); }
  Array.prototype.slice.call(hub.querySelectorAll('[data-ttlf-disp]')).forEach(function (k) {
    k.style.display = k.getAttribute('data-ttlf-disp') || '';
    k.removeAttribute('data-ttlf-disp');
  });
}

function ttlfCfgPanel() {
  var hub = document.getElementById('ttlf-hub'); if (!hub) { return; }
  if (document.getElementById('ttlf-cfg-panel')) { ttlfCfgClose(); return; }
  ttlfStGet(function (lic) {
    lic = lic || {};
    var rawEm = (lic.email && lic.email !== 'cliente@email.com') ? lic.email : '';
    var email = rawEm.replace(/^(liveinfinity|livecam):/i, '').trim();
    var key = lic.key ? lic.key : '—';

    if (!email || email === 'cliente@email.com' || lic.email === 'cliente@email.com') {
      fetch('https://api.valoranegocios.com.br/api/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: key, device: lic.device || '' })
      }).then(function(r) { return r.json(); }).then(function(data) {
        if (data && data.email) {
          var realEmail = data.email.replace(/^(liveinfinity|livecam):/i, '').trim();
          lic.email = realEmail;
          ttlfStSet(lic);
          var elEm = document.querySelector('#ttlf-cfg-panel b');
          if (elEm) elEm.textContent = realEmail;
        }
      }).catch(function() {});
    }

    if (!email || email === 'cliente@email.com') {
      email = 'afiliadodiegoalves@gmail.com';
    }

    var venc = ttlfFmtDate(lic.exp);
    Array.prototype.slice.call(hub.children).forEach(function (k) {
      k.setAttribute('data-ttlf-disp', k.style.display || '');
      k.style.display = 'none';
    });
    var p = document.createElement('div');
    p.id = 'ttlf-cfg-panel';
    p.style.cssText = 'background:#070a12;border-radius:14px';
    p.innerHTML = '<div style="display:flex;align-items:center;padding:12px 14px;border-bottom:1px solid rgba(255,208,0,0.2)">' +
      '<div id="ttlf-cfg-back" style="cursor:pointer;font-size:22px;line-height:1;padding:0 10px 0 2px;color:#ffd000" title="Voltar">←</div>' +
      '<div style="font-weight:bold;font-size:14px;color:#fff">⚙️ Minha assinatura</div></div>' +
      '<div style="padding:14px 16px 18px">' +
      '<div style="background:#0d111d;border:1px solid rgba(255,208,0,0.25);border-radius:10px;padding:12px;font-size:12px;line-height:1.7;color:#fff">' +
      '<div><span style="color:rgba(255,255,255,0.6)">Status:</span> <b style="color:#ffd000">🟢 Ativa</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">E-mail de compra:</span><br><b style="word-break:break-all;color:#fff">' + email + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">Chave:</span><br><b style="font-family:monospace;color:#ffd000;word-break:break-all">' + key + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:rgba(255,255,255,0.6)">Vence em:</span> <b style="color:#ff1717">' + venc + '</b></div>' +
      '</div>' +
      '<div style="color:#ffd000;font-size:10px;margin-top:10px;text-align:center">Renova automaticamente enquanto a assinatura estiver ativa.</div>' +
      '<div style="margin-top:16px;display:flex;align-items:center">' +
      '<div style="flex:1;font-weight:bold;font-size:12px;color:#fff">📋 Log de Eventos</div>' +
      '<div id="ttlf-log-clear" style="cursor:pointer;font-size:11px;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:6px;padding:3px 8px">Limpar</div>' +
      '</div>' +
      '<div style="color:rgba(255,255,255,0.5);font-size:10px;margin-top:2px">Registro em tempo real de todas as ações</div>' +
      '<div id="ttlf-log-box" style="margin-top:6px;background:#03050a;border:1px solid rgba(255,208,0,0.2);border-radius:8px;padding:10px;font-family:monospace;font-size:10px;line-height:1.5;color:#ffd000;white-space:pre-wrap;word-break:break-word;height:150px;overflow:auto"></div>' +
      '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:11px;margin-top:12px">Live Infinity</div>' +
      '<button id="ttlf-cfg-voltar" style="width:100%;margin-top:14px;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:bold;font-size:13px;cursor:pointer">← Voltar para a extensão</button>' +
      '</div>';
    hub.appendChild(p);
    var b1 = document.getElementById('ttlf-cfg-back'); if (b1) { b1.addEventListener('click', ttlfCfgClose); }
    var b2 = document.getElementById('ttlf-cfg-voltar'); if (b2) { b2.addEventListener('click', ttlfCfgClose); }
    var lb = document.getElementById('ttlf-log-box'); if (lb) { lb.textContent = (window.ttlfLogArr || []).join('\n'); lb.scrollTop = lb.scrollHeight; }
    var lc = document.getElementById('ttlf-log-clear'); if (lc) { lc.addEventListener('click', function () { window.ttlfLogArr = []; var bx = document.getElementById('ttlf-log-box'); if (bx) { bx.textContent = ''; } }); }
  });
}

function ttlfShowUI() {
  var g = document.getElementById('ttlf-gate'); if (g) { g.style.display = 'flex'; return; }
  var h = document.getElementById('ttlf-hub'); var b = document.getElementById('ttlf-bolha');
  if (h) { h.style.display = 'block'; if (b) { b.style.display = 'none'; } return; }
  ttlfBoot();
}

function ttlfShowGate(reason) {
  if (!document.body) { setTimeout(function () { ttlfShowGate(reason); }, 1500); return; }
  var ex = document.getElementById('ttlf-gate');
  if (ex) { var s0 = document.getElementById('ttlf-gate-st'); if (s0) { s0.textContent = ttlfMsg(reason); } return; }
  var d = document.createElement('div');
  d.id = 'ttlf-gate';
  d.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(4,6,15,.9);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;font-family:sans-serif;font-size:13px;padding:16px;box-sizing:border-box';
  var WM = '<div style="display:flex;justify-content:center;margin-bottom:14px;"><img src="data:image/jpeg;base64,/9j/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADASIAAhEBAxEB/8QAHgAAAgIDAQEBAQAAAAAAAAAAAAEHCAUGCQQDAgr/xABdEAABAwMCBAIEBwgMCAsJAAABAgMEAAURBgcIEiExQVEJEyJhFDJCUnGBkRUzcnWCsrO0FyMkJTdDYnN0kqGxFhkoOGOUwdIYJic0NTZUVZOVo0RTVmSDw9HT4v/EAB0BAAEEAwEBAAAAAAAAAAAAAAADBQYHAQQIAgn/xABCEQABAwMBBQQHBgMGBwEAAAABAAIDBAURIQYSMUFREyJhcQcygZGhseEUFULB0fAjktIWNTaCsvFDRUdSYnLCw//aAAwDAQACEQMRAD8A6p0UhUG8WfFppbhQ0D92Lx++N9m8zdosTTgS7NdA6knryNJyCpeOmQBlRAOQM6BCkfczdXSWzmlZOo9Z36Hp+zMdFSZjmOdXghCRlS1nwSkEnyrmzv56Y6dIfk2zaLTTUaOCUC/6iQVuL/lNxkkBPuLij70iqIb78QetuI3WrupNa3VU18FQiQWsoiQWyfvbDecJHmeqld1E1G/atlsQHFJl3RTBr/i/3p3OedXqDcvULzThJVEhSzCj/QGmORP9lRNNnyri8Xpcl+W6e7j7qnFH61EmvhRSuAOC8ZTpUGnWVhFFFKhCdFFKhCdFFKhCdFKihCdFIU6EIopU6EIopU6EIopUUIToopUIX3hz5NveD0SS/EdByHGHVNqH1pINSxoDi93o2wdbVp7crUMdpsgpiS5hmR/raf50/wBlRDSrBAPFZyumuwnpjrhGfj23dzTTUuMcIN+06jkcR/KcjKOFe8tqHuSa6UbZ7raS3j0rH1Hoy/Q9Q2d/omRDczyK8ULScKQseKVAEeVfzR1I2xXEDrbhz1o1qXRV2XBkEpTKhO5XFnNg/e3284UO+D0UnOUkGknRA8F7Duq/pCoqCuEri20txX6C+61oxbb/AAQlu72J1wKdhuEdCD8tpWDyrx1wQcKBFTrWsRjQpRalutubY9m9ur/rPUcj4NZ7NFVJeUPjLx0S2geK1qKUpHiVCv56uILfbUfEbujdta6lePwiUr1cWElRLUGMCfVsN+5IPU/KUVKPU1fD0x+/Lsi7aY2ktskiOw2m+XhKFfGWoqTGaV9ADjhH8pB8K5kVsxtwMpJx5J0Us0UsvCdFKgUITopGihCeKPCilQhFOikaEJ0YzSFFCE6VFOhCKKVOhCB0opdaBQhOikaKEJ0Us0daEIp0qM0ITopUUITopUUIUjcP++mo+HTdC061006fhMRXq5UJSiGp0YkesYc9ygOh+SoJUOor+hbafc6x7y7dWDWmnJHwmz3iKmSyT8ZBPRTax4LQoKSoeBSa/mjzmumvob9+HY941PtLcpJMaQ2b5aErV0Q4kpTJbT+EC25j+Ss+NIytyMpRp5KlXF9uA5ufxOblahU6p1l29PxYylHP7QwfUND6OVofbUP1958xy4z5Mp0lTsh1byyfFSlFR/tNfGlRoMLwiikaBWVhGKdImjOaEJ0UdqWaEJ0YopA9aELftO7L37U9miXOI9BTHkpKkB11QUBkjqAk+VaROhrt82RFd5S4w4ppRScjKSQcfZVptoP4N7D/ADSv0iqrLqg/8Zbv/THvzzUbtlfNVVU8MmMMOnvIVtbW7M0Fms1trqUHfnaC7JyM7jTp01JWNrbtG7X3bXMF+Xb3YqGmXfVKD7hSc4B6YB6dRWoVYPhz/wCqtz/pv/201t3erkoqUzRcQQmTYey0t/vTKGtzuFrjocHQZGqicbcXI6zXpgyIabilHOFKcIbV7AVgHlznB8vA199YbU3rRNsbnz1RnY63A0THWVFJIJGcgdDjFZPda5v2Pd+RcIxxIjLjvI95Daen19vrqdLrFibi6HcQ2QWLjGC2VH5CiMpP0hQH2GmeoulTTCmndjs3gb2nPn9PJTq17G2m7vu1vh3hU073iPvaFoJDcjGuowT4hVHrN6R0hP1rdTb7eGw6lsuqW8ohCUjA6kA+JArDyGHYshxh5BQ80strSe6VA4I+2rEbA6X+5elnLo6jEm5K5kE9w0non7Tk/ZTzda77DSmZvrHQef8AsoFsbs5/aO8MopgRG3Ln40IA5eBJwPaoh1Xtnc9HP25mc/DU7Pd9W0hlwqPcDmOUjAyRWwHh61N1Hr7d5fflf7teHXuqv8Kd0WnEL5okSU1FYx25UuDmUPpVk/ZU+7gXuTpzSF1ucPk+Ex2+dHrE8yc8wHUfXTDV3Gvp207ARvycdOZIx89VZFk2W2auct1neH/Z6Y93DtSGh28eGuS3I8FCH/B71MP4+3f+Mr/drEaq2ivWj7M5cprsNcdC0oKWXFKVlRwOhSKyH7P+qB0Krf8A6v8A/wBVitTbs33Vtocts4xDGWpK1epZ5VZScjrk05Qi8do3tizdzrjjhRS4O2ENJL9hbN226d3OMb2NM68MrTcU8UdqWakiqZGM08UUs0ITpYoFFCE6VFOhCMYqXuEPcFza7ib221El1TLLN6YjSVJOMsPn1Do+jldJ+qogFfaFKcgTI8lpXK6w4h1Ch4KSoKB+0VgjOizwXxp0qdZWEqKdKhCME06KKEJYzQBToNCEjTA6iigd6FlWr2h/g3sP80r9Iqqzao66mu/9Me/PNWa2g/g3sX80r89VRzeOH67XG7zpbd0gpRIfcdSlSV5AUokA9PfVe22sgpK6pM7t3JPzK6i2usVyveztoZboTIWsaTjGmY2Y4kKGMVYLhz/6q3P+mn9GmtRuHD7d7fAkyl3SCtDDSnVJSleSEgkgdPdW38ORB0rcseM3P/pppxvNZBV295gdvYIyorsFY7lY9qKdlxhMZcx5Gca4GvAlRtvb/CTdPwGf0aakPh61T8MtEuxPLy7DPrmQfFpR6j6lfnVHm9p/5Sbn+Az+jTWH0BqY6Q1bAuRJDCV+rfA8WldFfZ3+qtqSk+22hkY47rSPMD8+CZ6W9/cG3NRVuOGGaRr/AP1c8gn2HDvYt63R26dlbnQG4iOVm+rCioDohY++n7Pa+upO3CvjWgdAv/BMMrS0mHDSPBRHKk/UkE/VW2Ljx5TjEkoQ6trKmnMZ5eYYJB94qv3EBqj7qakYtDS8sW5OXAD0Lqhk/YnA+s1FqOSS7TU9NIO7GNfHH7A96uO/01LsPQXO60x/i1bgGeBcNceRL3+4clHFjGb3bv6S11/LTVv7/Nt9utMuRdvVi3NjL3rkc6MZ8U4OeuPCqg2I4vdu/pLX56athriwvap0rc7XHcbafko5Erdzyg8wPXH0U6bRhpqKcPOBrk9BkaqIeil0zLXdHU7A94A3WngTuvwD4E6LUzrbbM/Ktf8AqB/3KjLeG96bvD1qOnTGKW0uB74Mx6rqSnlz7Iz41kTw7X3P/SVu+1z/AHaxmptk7vpixy7rInwnWYyQpSGufmOSB0yMeNL0TLbBUNfHUlzuABOhzp0TbtBPtbcbZNBV2pkceMuc1uCA07xOd89NdOCjvvRjFOipqufUsUYp0E0LCVGM0U6EJdqKKdCEsU6VFCE6KKKEJUU6VCEd6AKdFZWUiaAK+jbSlnoK9rFqW4fik0k6RrOKyATwWOpgHyrZI+m1rTkjHvNe1OknVD2W1K/BGa1HVsTeaVETiiy7t6l09a41uhSWURY6SltKoyVEDJPUnv1Ne79nXV//AGyN/qiKxz2lFsjK08n4XSsdI086nOEHFaHZW+VxcY2knwCk8e0l/p42xRVkjWtAAAe4AAaADXks7K3r1XMjPR3ZcctPIU2sCKgZBGD/AGGsVpbcW96NhOxLU+00y6561QcZSs5wB3PuArCPwFsnsa8xSU9+lbzKSk3DG2Nu6eIwFqv2ivL52VT6uQyNBAdvHIB4gHORnmvfqC/zNT3Z65XBaXJToSFKQgJHQADoPcKx1Mmit5jWxtDWjACYZppKiR00zi5ziSSdSSeJJ6lbvbt59VWuBGhszGSzHbS2j1kdKlcoGBknv0rTp0164zZEuSsuyH3FOuLPdSick18aXekIqaCFxdEwAnjgJxrLvcLhGyGrndI1nqhziQOWmfBfSM+uLJafbIDjS0uJJGRkHI/urfP2ddXg5+GRsk/9lRWgJBPQCvSzb1vHsa8VEFPNgzsDsdRle7feLlbA5tBUPjDuO64jOOGcLdTvrq8/+1xv9VRXivO7WpdRWqTbp0lhcWQkJcSiOlJIyD3HbqKxcXTzi8ZQceZrJNaTccGUJ5/wetNpit8Tg5sTQR4BOsm0l/qI3RS1kjmuBBBe4gg6EHXgVqBB8qWK3JWkngPabKfwhivFJ02tsdE594rfbWxO4FRcxOC1rNGKyD9pcaPxSK8a2lN9CK22yNdwKSIIXz7Ud6KdKLyjFKjxp0ISp0UUIRRRRQhLvRTooQlnNeqJDU+odOtEKKXlgYzU37E7B3rd7UbdvtrYYjNYcmT3Uktxm89z5qPZKR1J8gCQz3K5QW2B087g1rRkkraggfO8MYMkrTdC7Y3rWl3Yttmtki5TnfisR0cxx5nwSPMnAFXQ2r4BorEdmXre5H1pGTbLWoYT7lvEfmj66srthtVp7abTyLVYYgayB8IluAF+UofKWr+5I6DwFbga5Q2i9JNdXvdFbT2cfX8R/p9mvjyVjUNjhhAdP3ndOX1WgaY2F290clH3M0jbEuJ/j5LPwh0+/mc5j9lbtHgRYqORiMwwgdktNJSPsAr0UVU09ZU1Tt+eRzj4kn5qRsijjGGNA8ljrjp21XhtTU+1wprahgpkRm3AftFRjrLhR211gw5iwIskpfaTaFeoIPmUdUH+rUv0VsUtzraFwdSzOYfAkf7pOSCKYYkaD7Fzr3l4I9T6LakXGyEanszYK1KjN8sppPmtrrzAeaCfoFVau1hciqIKT0rt12xjoR5VXbiJ4S7VugxJvWnGmLVqjBWtsAIYnHyX4IWfnjofleYvLZb0lyNkbTXjgdA8afzDh7R7RzUSr7E0tMlN7v0XLB1gtE9K+ea3rWmiZ+mLrLt9wiOw5sZwtvMPJ5VoUO4IrSnmS2s5FdNU1SyoYHsOQVA3xlhwV8u9fRplThAApsMlxWAK3TRmip+pbnFgW+G7MmyVhtmOykqW4o9gBRU1LKdhe84ARHGZDgBYm1WBySoYSatLstwTal1syxcb5/xZszgCkqkt5lOp80NdMD3rI+g1Yzh24TbVtjFjXnUbTF01PgLQ2QFsQT5I8FrHzz0HyfM2HPUk+J8a5k2o9JkjpHUtn4DQvOv8o/M+wc1PrfYWgCSp936qINHcKG2mjmmz9wEXqWjvJu6vXkn3I6IH9WpPt+n7XaWktwrbChNp6BMeMhsD7BWQxijwqjau5Vtc7fqpnPPiSVLI4IoRiNoHsXnkQIspBQ/GYfSfkutJUP7RWkap2D291mlX3U0lbFOq/j4zXwd0e/mb5TW/0UjBWVNK7fp5XMPUEj5L26OOQYe0HzVO90+AaI/GelaJuavWgZFtuihhXuQ8B3/CH11TDXW1950Xdn7beba/bZzXxmZCOU48weygfMZFdk61Hcza3T27Gnl2m/Qw6ACY8tsAPxlH5TavD3g9D4irZ2d9JFfb3tiuR7SPr+If1e3Xx5KOVtjhmBdB3XdOX0XF2VCUwojFeQ9D1qe9+tg7ztBqRyBcUB+K6C5DntJw3Jbz3HkodApPgfMEEwdMillZBFdXWy5QXGBs8Dg5rhkEKup4HwPLHjBC8tFOkBTwtRAp0UqEJ0UUqEIzX7aRzrAxX5xXvtUb1zwHvrxI7daSvQGThbrtxoafrK/2+02yOZE+Y8lllseKj5nwA7k+ABrrHtFtfbNo9EQrBbglxxA9ZLl8uFSXiPaWfd4AeAAFVj4Atr0A3XWktrPqP3vglQ7LIBeWPoSUp/KVV0K4+9JW0T66u+7Infw4/W8XfQfHPQKzbFRCGHt3DvO4eX1Sr8uOIZbW44tKEIBUpayAEgdySew99Na0tpUpSghKQSVKOAAO5J8q5+8U/FHJ1tPlafsMpUfSzCihSmzymeoH46v9Hn4qfHue4xANndnqraKq+zwaNHrO5AfmTyCea2tjoo99/HkFYjcXjL0Rop92JbPXammt5BVDUERgfL1p+N+SCPfUL3L0gl/U8r4Hp+zxm89EurddOPeeZP8AdVLLnqJx5avbOKxCro6o5ya6bt3o0s1NGBLH2jurifkMD4KAz36pe7unA8Ff3TPpAZi5KE3rTUJ9gn2lwJC2lj6AvmB+0VY7bTfjR+6yUtWa5eruXLzKtswBuQB4lIzhY96SfqrjuxeHW1fGIradOawk2+YxIZkOMPtLC23WllK0KHYgjqD7xWhePRjbKmMmkBifyIyR7QT8sJalv87DiTvBdoAeYU6rDw0cWTOt/gumtWyUN3pWG4lyXhKZZ8EOeAc8j2V7j3s8T/Z3rmO7WirstSaWrbgjgeRHUHp+yp5TVMdVH2kR0UIcSnDjB3nsyrhb2242q4jeGHuiUy0Dsy4fzVeB6dj05mao0hKtNzkwpEdyPJYcU06y6nlUhYOCkjwINdou4qtvFXw9R9XwX9YWSL+/cdGZzLaesppI++Y8VoHfzSPMCrR2D2zfbZG22tdmM6NJ/CenkeXQ+HBhu9rFQ0zxDvDj4/Vc7tM6RlXW5RoceO5IkvuJaaZbTzKWtRwEgeJJrppw1cOMLZmypuFwbbk6rlt4fe6KTEQf4ls+fzleJ6DoOut8KfD3H0hBZ1he4gF6kIzAYcT1itKH3wjwWsHp5JPmasnijbzbN9zkdbaJ2Ixo4j8R6eQ59T4cS0WsU4E8o73Lw+qKO1PGaq7xOcWTehRK0zpGQhy9py3LuacKTEPihvwLnmeyfee1XWi0Vd6qhS0bck8TyA6k9P2FIKmpjpYzJIdPmpf3P350ftKgt3q4etuPLzJtsMByQR4EjOED3qI+uq46k9IFLL6k2XTMOOyD0XcJC3Vn6QjlA+01S3Ues5V0mPyJEhyQ+6srcddWVLWo9yonqT7zWrv3dxZOFE105ZvRjbKaMGrBlfzJyB7AD88qA1V/ne7EXdCvPbPSB39Lw+GWCzyG89Q0t1pX28yv7qmbbrjL0TrR9qJcw9pmYvACpaguOT5etHxfygB765XIurqT8YisvbdROtLT7dOFx9GlmqYyIo9x3VpPyOR8EjBfqlju8cjxXbRp1D7aHG1JW2sBSVoOQoHsQR3Hvr91z64WeKGToi4RbDfpSpGlX1BALhKjAUflo/kZ+Mnt4jqOvQRtSXEJWhSVoUAUqScgg9iD4iuZNotnqrZyq7CfVp9V3Ij8iOYU9oa2Otj32ceY6LT929sbZu5ombYLkkIWsFyLL5cqjPgeyse7wI8QSK5M7k6Gn6M1BcbRc45jz4TymHm/JQPcHxB6EHxBFdl6phx/bXoV9ydaxGQPX/vfOKR3WASys/SkKT+Smp96Ndon0Nd92Su/hyer4O+o+OOpTPfaJs0PbtGrePl9Fz1cQULINfnNZC6xyy6fDBrH4zXYMbt9oKrIjBRToor2vKKKKVCE62TTUcLfQSOla0O4rdNIMh15KT8r2ft6U31rt2IlLwjLl1j4eNMJ0jsvpODyBDrkNMt7p3cd/bDn6lAfVUiV5LVDTBtcKKjohiO20APJKAP9leuvnhXTuq6qWodxe4n3nKuyJgjjawchhQVxi7jOaF2ndgxHS1PvjhhhSThSWQOZ4j6RhP5Zrl9qO5qeeX16VdT0hF3cXqvTtuCj6uPbVvcvhzOOkZ+xsVRO5rKnzmutvRnbY6azRy470mXH34HwAVb36cvqi3kNF5FKKzkmkTSoAq6Qoqivo08ppXQ18zRjNBGeKAtrsF/XGdT7RGCPGuj/AAn8Rqdw7YzpfUEoK1DHb/cspxXWa2kdj5uJH9YDPcGuXTLpaUCDW/6D1HMtd0iS4klyLKjuJdaeaVhTawchQPmDVcbXbMU99o3Rv0cNWu6H9DzHPzwny2176SUEcOYXZYHNOo32J3ej7t6Oblr5GrzECWp7Ceg58dHEj5qsZ9xyPCpIJwK4mq6SahnfTTtw9pwf30PJWpHI2Vgew6FLNMUgKjjfbd2NtHox6YkocvMoKat8dXXK8dXFD5qc5PmcDxopKSaunZTQDLnHA/fhzXqSRsTC95wAo04tuI8bdWx7S+nZQRqGS3+6pTZ6wmlDsPJxQ7fNBz3IrnBf7+5LdWVLKiT1yazOvNSTLtdJcuZJclSZDinXXnVZU4snJUT5k1oL7pcWevSu2dkdmKew0bYmDLjq53U/oOQ5eeVVVyuD6uUk8OQQ66XDkmvnmjGaKscAAYCYk6ErKTkGlRihC2bTlzU08nrXUHg83Fc1ztS3BlOl2dY3BDKlHJUyRzNE/QMp/JFcprW4UPj6avZ6Pm7uJ1XqK3lR9XItqHuXwy26AD9jhqlvSZbY6mzySkd6Mhw9+D8CVKbDO5lSG8naK8NR1xE6WTq/ZbVkHkC3W4apbPTqHGf2wY+pJH11IteW6xEz7VNjLGUPsONEeYUgj/bXJFDUOpKqKobxY4H3HKsiZgkjcw8wQuKWpo4Q+sgdD1Fa3W56vZDT60gdE+z9nStMPc19EaJ29ECqUlGHI70dqMUVvpBOlRRQhMeFbpo90NvJUfkkK+ytK71s2mJAQ8gHse9N9a3eiIS8Rw4LtXaZKZtshSUHKHmG3QfcpAP+2vVUd8PeqU6v2Z0nO5wt1ENMR73ONftZz/VB+upEr5311O6lqpad/FjiPccK7IniSNrxzAKo96QezrTqrTtw5T6uRbVs82OnM26Tj7HBVErogoeP011a4xNuHNd7TuzYrZdnWNwzUpSMqUyRyugfQMK/Irl5qK2qaeV06V1v6M7lHU2aOLPejJaffkfAhVvfoCyqLuTtVrlBNCklBwe9KrpGqiuEU6VfttpTpGBQSBqUAZTZbLqx5VIGgtOTLrc4sWFGclSpDiWmmWk5U4snASB5k1grBYly3UJCSST2xXSDhK4cP2Oba1qjUMYJ1DJb/csVxPWE0odz5OKHf5oOO5NVxtdtPT2KjdI85cdGt6n9BzP54T7baB9ZKAOA4nopN2K2kj7S6MZhrCHLzKCXZ76euV46NpPzU9vecnxqRqeKK4nq6uaunfUznLnHJ/fTorTjjbEwMZoAjNRtvvtDH3d0Y7ERyNXmIFO2+QroAvHVtR+Yrt7jg+FSQOtOsUlXNQVDKmndh7Tkfv5+CzJE2VhjfqCuMuvNOTbTdJcSZHciyo7imnWXU4U2sHBSR5g1oT7ZaWa6icWnDeNxrW9qfT0UK1HGb/dUVsdZzSR3Hm4kdvnAY7gVzevthXEdWFIIIOMEdRXbOyO09PfqNsrNHDRzeYP6HkefnlVVcqB9HKQeHIrWaVft1pTSsEV+BVjggjITHjCdBNKhKSs4oRhe21oK3h9NXs9HzaXF6s1DcMH1ce2pZJ8OZx1JA+xs1SnT1tU88np0z3rqHwd7cuaF2obnS2i1PvjgmKSoYKWQOVoH6RlX5YqlvSZco6azSRZ70mGj35PwBUpsMDpKoP5N1U615rpLTBtc2So4Qyw46onySgn/AGV6ajviF1SnR+zGrJ/OEPLhqiM9epce/axj+sT9Vck0VO6rqoqdvF7gPeQFZMrxHG555DK5OawdDr61g5Cva+3rWmE9TWy6ofCn1gHoOgrWSa+h9C3diAVJynLk6VFOnBIIooooQishaZBaeHXtWO8a/bS/VrBpORu+0hegcHK6F8Au5yD91dGS3sF/93wQo91gAOoHvKQlX5KqubXGzbXXE7SF/t91tsgx50J5LzLg8FA+PmD2I8QTXWHaXc62btaLh323KS24oBuXE5sqjPAe0g+7xB8QR764+9JOzz6Gu+84m/w5PW8HfUfHPUKzLFWiaHsHHVvDy+i3FSEuJKVJCkqGClQyCPEEVz94quFyToq4StQ2CKp/S76ytSWxkwFHuhX+jz8VXh2PYZ6B1+XG0PNrbcQlxtYKVIWAQoHuCD3HuqA7O7Q1WztX9og1adHN5EfkRyKea2ijro9x/HkVxIuWn3GXD7JrEqtriT2NdUdx+DDRGtnnZdqL2l5rhKlJhoDkZR/mjjl/JIHuqFrn6PbUKXlfAtQWaQ3nop5LrR+scqv766dt3pLstTGDLL2bujgfmMj4qAz2GqjdhrcjwVGmrW44R7JNbNpzSEm5zWI7Edx995YQ200gqWtR7AAdSfcKunpj0fExMhC73qeEyx8pFvjrdWfoK+UD7DVkNsdhNG7TJDtltvrLly8qrnMIckEeIScYQPckD66b7z6T7XTRkUhMr+QGQPaSPllL0tgqHuzL3Qog4Z+ElnQyomp9Wx0O3pOHIlsVhSIh8FueCnPIdk+89rRUdqK5iu14q71UmqrHZJ4DkB0A6fsqe01NHSsEcQwPmjtVb+KriBj6SgP6QssvF5kIxPeaV1jNKH3sHwWsd/JJ8yK2XiS4ioWzVkVBgONydVS28sMn2hFQf45wfmp8T17DrzL1RrCVdbnJmSJLkiS+4p1151XMpaiclRPiSatDYPY2S5yNuVY3EY9UH8R6+Q5dT4cWC73NtODDEe8ePh9V0P4VuIGPq6Ezo+8yh92YyMQHnD1lNJH3snxWgdvNI8washXGHS2sZVquceZHkuR5LDiXWnmlcqkLByFA+BBrpnw3cRULeSyJgT3G42qojeX2R7KZSB/HNj85PgevY9DbzY19tkdcqNuYz6wH4T18jz6Hw4FnugqGiCU94cPH6qbB0qr/ABOcJjOvBK1NpKMhq+KyuXbU4SiYfFaPBLnmOyvce9n6Kq+0XerslSKqjdgjiORHQjp+wpBU00dVGY5RouLGotISrZNfjSIzjD7Kyhxl1BStCh3CgeoPuNa09a3EE+yRXYrc7YfR27KC5e7aG7jy8qbnDIbkAeAJxhY9ygfqqtupfR7zFSFqsuqIb7B+Ki4RltLH0qRzA/YK6ds3pOtlTGBVkxP5g5I9hA+eFAarZ+oY7+F3gqCItrij2NZW3WBx1Y9k1dO2+j31Cp8fDNQWaM3nqppLrpx7hyp/vqaduOC/Q+in2pl19bqec2QQJaQ3GSf5ofG/KJHupwuPpKs1NGTHJ2jujQfmcD4pGCw1Uju83A8VXjhW4W5Ot50XUF+iqY0qyoLCXAUqnqB+In/R5+Mrx7DucdBEIS2hKEJCUpAASkYAA7ACk22hltDbaEobQAlKEjASB2AA7D3V+q5i2i2hqtoqr7RPo0eq3kB+ZPMqe0VFHRR7jOPM9UVTPj63PbH3L0VEeBLGLhPCT2WQQyg/QCpX5Sas1u1uja9o9Fy79clJW4keriRObCpL5HsoHu8SfAA+6uTu5Wt52r9Q3K7XGQZE6a8p95zwKiewHgB0AHgAKn3o22dkrq77zlb/AA4/V8XfQfHHQpnvtaIYewae87j5fVaTd5PrnVdfGsfX6dX6xZJr8E12DG3caAqyJyU6KXeilF5TopUUITxRSooQvXBlqjuAg1Omw2/N42m1I3cLe4Ho7gDcuC4rDclvPY+Sh3Cu4PuJBgHNeuFPVHUOuKZrlbILlA6Cdoc1wwQVtU874Hh7DghdodtN1NP7r2BFzsUwOEAfCIjhAfjK+atP9yh0Pga26uOGhNzrxo67R7lZ7nIts5r4r8dfKceIPgQfEHINXO2x49or0ZmLrS2q9YAEm5WtI9r3rZJ/NP1VyhtF6N6+gkdLbR2kfT8Q/q9mvhzVjUN8imaGz913Xl9FcGitB0vv1t/rBCfuZqu2qcV/ESXfg7o93K5g1uzFyiy0c7Eph5J7KadSofaDVTT0dTSu3J43NPQgj5qRslZIMsIPkvRTrG3DUNrtLSnJ1zhQm091SJKGwP6xFRnrLis230ew5i+ovclHaNaU+uJPkV9ED7aWpbZW1zgylhc8+AJ+PALxJPFFrI4BS936Duar3xCcWFp2wjybPp91m66nAKFKBC2IR81nspY+YO3yvI1z3k42tSazZkW6ygaatDgKVJjOFUl1Pkt3pgHyQB9JqrV41E5KUcrzV5bL+jOR721N44DUMGv8x/Ie08lE7hfmgFlN7/0WZ1vrmdqe6S7hcJjs2bJcLj0h5XMpaj4k1oj76nlnrSefU8oknpX4rpympWUzAxgwAoDJI55ySvqw+plYOelb3onXM7TV0izrfMdhzYzgcZkMq5VoUPEGo+719WX1MqyDRU0rKlhY8ZBRHI6M5BXVTh74rbTudGjWfULzFr1NgISskIYmnzQeyVn5h6H5PkLBdjjsa4mWjUjkVScK6eVWj2c41tS6MbYt95I1LaEAJS3JcKZDSfJDvXI9ygfpFcx7UejORsjqm0cDqWHT+U/kfYeSntvvzSBHU+/9V0Qp1D+jeK/bfV7LfNfE2SUrvHuyfU4PuX1QftqTrdqO03htLkG6QprahkKjSUOA/Yao6rtlbQuLaqFzD4gj48CpbHURSjMbgVke9OvM/cosVBU9JYYQPlOupSPtJrTdUb6aA0g2tVy1XbUuJH3iM8JDp/Jbya14KOpqXbkEbnHwBPyXt0rIxl7gFvVahubutp3aWwqul/mBrmBEeI2QX5Kh8lCf71HoPE1Wzczj7ix2nomjLUr1hBAuV0AwPelkH84/VVM9wNz7vre8P3S8XF+5TnvjPvryceCQOyQPADAFW1s76N6+4SNluQ7OPp+I/wBPt18OajlbfIYWlsHed15fVbhv9vtdt3dTOXGe56mM0C3Dgtqy3Gbz2Hmo91K8T7gBUGzZan1nrmnLnqfUcnvXjzXV9ttsFtgZBA0Na0YACrmed87y95ySnSxRmnTytVFI9qKD2oQnRRSoQjHSinSFCEYoqXNqeFrcDejTLt+0vBgSbc3JXEUuTPQyr1iQkqHKrrjCh1rQ9wdDXbbLV1z01fmmmbrblBEhDDodQCUBYwodD0UKbIbnRVFS+jhma6VnrNBBcOWo4jiFsOp5mRiVzSGngeSwSHlN9jXvjXdxkj2iKmlrgf3bk6YbvsWywpkJyGmc23HuLa3nGygLAS33Kik/F756VAqgUqKSCCDggjBB99J0lfb7pvikmbJu6HdIOD444L1JDNT47RpbnhkLaI2qnG04KsjyNe1vWTyR7LhT+CcUbS7Oan3t1DJsulY8eTPjxTMcTJkpYSGwpKSeZXc5WnpXv3f2G1fsXItTGrI8WK5ckOORhFlpf5ggpCs8vbqoVpvltn2wUDpW9sRncyN7GM8OPDVKhtR2XbBp3evJY6RrBx4e2vm/C61jJWpHXPlnFSDtjwm7jbv6Ua1HpuDAkWpx5yOlci4NsrK2zhXsnrjJrbP8X7vJ/wB1Wj/zdqm6W87P0croZquNr2nBBc0EEciMpdtLWytD2xuIPgVX1+5LeJ6mvIolZ69ascPR+7yEgC1Wg+H/AEu1UWaQ2V1RrncuboO0R4ruo4a5LbzTslKGgWCQ5hw9Dgg486cqW+2eoZJJTVLHNjGXEOB3R1OugWvJSVUZaHxkE6DTitEApGpS3d4bNc7H2q33HVkOFFiz5CozBjTUPkrCeY5Cewx40bQ8Nmud8bXcLhpOHClRYL6Yz6pU1DBCynmAAV3GPGtn76tv2T7f9oZ2PDf3hu5zjjw46Lx9ln7Tsdw73TGqi0Cg1tG5O22oNptWytN6mg/ALowlLhSlQW24hQylaFjopJ69R4gjuK16FEcnzI8VkAvPuJaQFHA5lKCRk+HUinOKeKeJs8Tg5hGQQcgjqD0Wu5jmOLHDBC+KSUnINeuPcnGT3qadccF26G3mk7tqO9W62s2u1sl+Stm5NuLCQQOiR1PUio72r2m1HvPqlWntMMR5FzTHclFEmQllHq0EBR5j0z7Q6U0xXe2VdM+riqGOiZ6zg4EDTOp4DRbLqaojeI3MIceAxqsfF1I6jpznFZJjV62R7BCT/J6Vmd4eHbWmxMW1v6tiwoqLktxuP8FmIfJKACrPL26KFb9G4BN4pTDbyLXaShxAWnN2aHQjI/vprmutjZCypkqoxG/O6S4YdjQ4OdcHithlNWFxjbGcjiMcMqKndYOvD23Cv8I5rxPapd5eUKwPIdKmf/F/by/912n/AM3apH0fu8nf7l2n/wA3arSbtBs03hWxfzt/VKmirz/wne4qBJV4ceJ6k14HHVudSTU92zgb3Wu0q4xokGzPSLdI+CS203drmZd5ErCVD3pWlQ8waibcXby+7V6unaa1JDEK6xOUrQlYWhSVJCkrQodFJIPQj3+VSChutrrZTBRzse8DOGuBONNcDlqNfFaU1PURN35WEDqQtZoAr6RY7syS1HYbW8+8sNttNjKlqJwlIHiSSBj31OequCndHRWl7hqC9wbTb7XAjGVJddurWW0gduUd1ZwMDuSBW3V3OioHsjqpmsc/RoJALjpwB48Rw6pOKnmmBdG0kDjjkoJpYoz2/wBtOnJa6MUjRRQhFGadFCEqMYp0UIXS/wBHD/ADP/H0r9EzVOONQf5TO4H8+3+rN1cf0cI/5AZ/4+k/omapxxq/5zG4H8+3+rN1QGyv+Pbp5O/1MU1uP9z0/mPkV1M2zPLtppHHT954X6BFUl47OFc2d+ZudpWJiA8vnvkFlPRhwn/nSQOyFH448FHm7E4uLp+U7A2Jt0lhxTL7Gl23W3E90KTCBSoe8EA1H/C3xG27iN28VCuiGBqeFGSxeLetIKJKFJ5fXJT2La+oUPBRI7EZqCxVlzsVZPfaJu9FG/dkHVriePhpoeTsdVJKuKCsjZRynDnDLT4j9+5VV9Gsrl3s1APH/B939YYraPSfDN928/ok39I1UvbJ8MTmw/Etf7paW1uaLu1ke+ArJyYbvr2VKjKPuGSg+KRjuk1EXpPTm+7ef0Sb+kaqy6O50149IFNXUbt5j48jw/huyD0IOhCYpYJKWyyRSDBDv/oKaPR8HHDbA911nfnpqI96ePPXG2+7Oq9L26xafkQbTPXFZdktvlxSUgYKsOAZ6+AFS36Pgf5N0DPb7qz/AM9NZXW/BBtnuFq+76ku6L0bndJCpUgx7j6tvnOM8qeU4HSogayx0W1VyffoTJGXPDQBnDt7jxHLKcuyq5bdAKN26cDPlhVb/wAZXuKMEac0wCOufVSP/wBtYzgl1A/q7i8cvsptpmVc2LpNebYBCErcTzqCcknGScZNTzuPwGbWaW281ReoKL58Ot1rlTGPW3PmR6xtpSk8w5OoyB0quXo+jniStZPc2ucT/wCEKsqGfZyt2dulRYYOzxG5rsjBPdJHMpic2uiradlY/e7wI96n/wBJz/B1oj8cPfq5r9ejJONt9a/jlr9XFfn0nH8HWiPxw9+rmv16Mn+DfWv45a/VxUL/AOmX+f8A/VOf/PvZ+SmDij4cYG/+h1NshqLqu2pU5ap6+gKj1Uw4f/drx+ScK888rrfaJun9eQ7Zc4jsG4Q7oyxIjPp5VtOJeSFJI8wa6YucTTOk+Kq+7a6mkIYs01uGq0TF4SmPJWwkllZ+Y4T7JPZRx2V0wfF1wufsi3K2680xFzqe3SI5uERpPWfHQ4n2gPF1sD6VJBHcJrZ2N2gqtmeztF4OIJ2B8TuQ3xnGehJwf+12vA5Xm50cdfvVNN67Dhw64/P5hSXxeDPDZuP+LFfpUVSL0dX+cO9+JJn5zVXe4vMf8GzcfHUfcxXX/wCoiqQ+jp68Q734kl/nNVr7I/4Gu3m//Q1erl/e1P7PmVLHpQE5sO3ZIyfhc39G1UeRPSSa7ix2GE6X04UNoS2CfhGcAAfP91SJ6T7rYtu/6XN/RtVQVPxh9NWBsTY7betlqMXCESbhkxnOmXnPAjoEz3asnpbhL2Dt3O7n3BdodjNcS90NqdKapuEdiJMu8UPvMxeb1aCVqThPMScYHiTVKNSekc11adQ3S3s6Z06tqJLejpUsSOZQQ4pIJ/bO+BVtOEA/5N+2/wCLkfpV1ya1x01tqL8Zyv0y6hGxGz1quV5utPVwB7In4aDnQb7xpr0ATrdq2ogpad8TyC4a+OgVldhOMKdB4jrpqLUqI9vsuslsRrmzHKvURXUIS2zIHMScJxhWT8VZ8hU/8e+wqtxdBo1lZ43rdRacaUp9LYyqTB+MtPTuWzlY93OPEVzQxnIPUeINdPuBnfxO6e2/+C93fD2p9PNJYWXTzKlw/itOnPcp+9q+hJPxqk22lofs5U0201nZjsd1j2jgWAboz4Y7h/ynllaFqqRXMkoKk53skHx4n9feoA9H1sKnWWrHtwrsxzWiwu+rtyFj2X5uM8/vDQIP4Sk/NrM+kN38N2uTG19ofzEgLRKvLiD0cfxlpjPkgHnUPnFI+TVm929a6d4Stj3n7HAjQUsc0WzWtHxXJThUsZHcpBKlqPknHiK5L3S6S71cpdwnyFy50t1b8iQ6cqdcUSpSj7ySTWdl4pNsb5JtPVtxDF3YWnqOfszk/wDkdD3UXBzbXSNt8Z77tXH9/vA8V5AMUGn3oq+1DUsU6KVCE1JKVEEYIOCKK3ffHRru3m82utNPN+rXar5MigeaA8rkI9xSUkfTWkUcUJUU6KyhdL/Rw/wBT/x9J/RM1TjjV6cTG4H8+3+rN17tkeL/AFXsPo17TljtFmmxHZjkwu3BDpcC1pSkj2VpGPYHh51GO6W4U/drXV41XdY8aLPui0reZhhQaSQ2lHshRJ7JHcmqmsWzlfQbVV12nA7GUENOcnVzTqOXAqS1dfDNboaZh7zcZ9xXXG2f5v8AFB/+E0/qNcjNrNyL1tLrG06osEj1FwhYPIrPq32yBztODxQodD9RHUCp4jekC13H0ejTgsOnlQkW4W0OFt/1nq/Veq5vvmObHXtjNVgSnkSlI8ABSOxWy1XaGV8V0Y0sncMDIII72Qfes3W4xVJhdTk5YPLXRdodn94LJvdoaDqaxLKWnf2uTEWoFyI+AOdpfvGcg+III71T30no/fvbw/8Ayk39I1VbNjOIHVOwF8m3DTqo8hia16qVb5yVKjvY+IshJBC09cEHsSDkGvXv1xGag4hZdlkX+322Au1NutMi3JcAUHCknm51K+aMYxTBZNgKqwbUMrqcg0rd7BJ7w3mkAEc8E4zzGvVbtXeo6y3mF+khx5aEaq93o+Dnhsg/jWd+emqLcUtxltcRe4qES5CEC8vAJS8oAdE+ANbFs5xmau2S0KxpWyWeyy4TUh6SHpyHi6VOEFQPKsDAx06VEe4OtZm4+t73qi4MsR512lKlvNRgQ0hSsZCeYk46eJNSPZ7Zqut20lwudS0dlNvbuoJ1cDqOWi0a2vhnoYYGE7zcZ9ywxuUxaSlUySpJGCC8sgj7asP6Pz/OUtf4snfoxVcK3jZndu6bI66j6qs0SHNnMx3o6WZwUWilxPKSeVQOR4danV+oZK+01VHTgb8jHNHIZIICaKKZsNTHLJwBBV1fScddutEfjh79Xr9ejKONt9a+f3Za/VxVWd+eKvU/EHZLTa79a7TAZt0lcppduQ6FKUpHIQrnWoYx5UbD8Vep+H6xXW1WK1WmezcZSZbjlwQ6VpUEcmE8i0jGB41VP9kLr/Yr7j3R2+9nG8MY397j5KQ/edP96/a8ncx08MLNcev+c5qM+cWF+rpq1PBFxRp3MsDeitTS86vtjP7mlOq9q4xkjvnxdQMBXzhhXzqoNu/unc959eTtWXeLEhz5bbTS2YQUGgG0BAxzEnqB161rVhv1x0ve4N3tMt2Bc4LyZEaSycLbWk5BH/48RkHoalNbsfHeNm6e1VgDZomNDXcd14aAfNpxg9RrxAWhFczTV76iLVricjqCfmut/Fsc8NG4h87Ur9IiqR+jqOOId78SS/zmq8G4nHhrnczQV40pdLLYGYV0i/BX34rTyXQMpJUnLhSDlPljrUWbJ7z3bYrWi9TWWFCnTVRHIZanhZb5VlJJ9lQOfZHjUXsGyF0t2zFfap2t7WUu3cOBGrWgZPLUJwrLnTz18NQwndbjOnirdek+62Lbz+lzf0bVUGR8YfTUw798T2pOIaJZY9/tlrt6LU466ybclwFRcCQebnWr5oxioeBwc1P9jLVVWSxw0FYAJG72cHI1cSNfIpmutTHV1bpouBx8guv3CD04b9t/xcj9KuuTeuOutdRfjOV+mXU9baceWt9sNEWPS9tsVgkwbQwGGXZTb5cWkKKsq5XAM9T2Aqu12uK7xdZs91KUOy33JC0o+KlS1lRA92TUc2Q2cuFmutyq6toDJnZbg503nnXpoQt2510NVTwRxHVo19wXjzirR+jmVjiDf/Ecv85qquVIGyW8122J1mrUtlhQp81URyH6qeFlvkWUkn2VA59keNTbaOhmuVoqaOnGXvYQM6DJ8U1UMzKepjlfwByVbv0nqj9wtvAe3wuaf/TaqghNTFv5xPak4h4llj362Wu3otTjrjJtyXAVFwJB5udavmjGKh4U2bGWqpsljgoawASN3s4ORq4ka+RWxdamOrq3TRcDj5BIUE06KmyaEhTAJIA6k9AKK3TZTRru4e8Oh9MMo9Yu7XuHEI/kqeTzk+4JCifcKCeaFbr0umyL2h9+IWvokcps+sIqQ84hOEonMJCFg/hNBpQ8yF+VURr+ijiu4erbxNbK3rRkxTcaesCVap7gz8EmIB9U5+CclCvNK1V/PhrTR152+1XdtNaggO2y92qSuLLiOj2m3Enr9IPQgjoQQR0NJRuyML24arC5oFGKdKrykTRmjFOhYSozRinQsopZzRTAoQkKCaDRihYRRmnRQhKnRSrKyjJp0YpULCCadLFOsISJoop4xWVlGaVGKeMVhYS7UZoNGKEJ0iadLFCyiinSxQsIq9fojtkntdb+y9dy45VZ9HxVKacWnKVzn0lttI96Wy6v3Eo86pZo/SF419qm1ac0/Adul6ukhEWJDZGVOuKOAPcO5JPQAEnoK/oN4TOHi38Mmyll0dFU3JuQBl3ac2MfCpqwPWLH8kYCE/yUJ8c0lI7AwvbQpjqnvHrwGW7idsv+E2mUx7VuVb2eRp9z2Gbo0nsw+fBQ+Q54dj7J9m4dFaoJGoSq/mP1fo6+bf6luGntSWqVZL3AcLUmDMbKHG1e8eIPcKGQRggkVh6/ol4h+E7bjibsyYusrKlVxYQUQ73CIZnRfchzBynPyFhSfdnrXMTe70R+6ehZMiXoOXC3Bs4ypDKVph3BCfJTaz6tZ96V5PzRW02QHiki3oqK0q3TWWym4O3khbOp9EahsS0HqZ1seQj6Qvl5SPeDitNKSCQRgjwNKrwlSzT5c0cvShCQop4oxQhKnRijloQlToxijFCEs06MUctCEs0CnijFCEqKeDRihCVFPBox1oQilTIoxQhFLNPGaMUISozTAJOAMk+Vbjo3ZnX+4UhtnTOidQ35xZwkwLY84n6Srl5QPeTijhxWVptZfSekb1rzUcCwadtcq9Xqe4Go0GE2XHXVe4DwHck4AHUkCrpbJeiQ3V15Ijy9dSYe3tnJCltOLTMuCk+SWkHkQfw15HzTXTvh24StuOGOzrjaOsw+6b6AiZfJxD06V7lOYHKnPyEBKfdnrSTpAOC9BpUO8BHAVA4ZLQNU6pEe6blT2Shx1shbNqaV3YZPis/LcHf4qfZ6quPRRWqTnUpXgv/Z" alt="Live Infinity" style="width:72px;height:72px;border-radius:18px;object-fit:cover;border:1px solid rgba(255,208,0,0.5);box-shadow:0 0 25px rgba(255,23,23,0.5);"></div><div style="font-size:24px;font-weight:900;letter-spacing:-.5px;text-align:center;"><span style="color:#ff1717;">Live</span> <span style="color:#ffd000;">Infinity</span></div>';
  d.innerHTML = '<div style="width:340px;max-width:100%;background:#070a12;color:#fff;border:1px solid rgba(255,208,0,0.35);border-radius:22px;box-shadow:0 24px 70px rgba(0,0,0,.9)">' +
    '<div style="text-align:center;padding:24px 22px 4px">' + WM + '<div style="color:#ffd000;font-size:11px;font-weight:700;margin-top:4px">Automação Inteligente TikTok Shop</div></div>' +
    '<div style="padding:8px 22px 24px">' +
    '<div style="color:rgba(255,255,255,0.7);font-size:13px;text-align:center;margin:12px 0 14px">Digite a sua chave de acesso para liberar.</div>' +
    '<input id="ttlf-gate-key" placeholder="SUA-CHAVE-DE-ACESSO" style="width:100%;box-sizing:border-box;background:#03050a;color:#ffd000;border:1px solid rgba(255,208,0,0.3);border-radius:12px;padding:13px;font-size:14px;font-weight:700;text-align:center;letter-spacing:1px" autocomplete="off" spellcheck="false">' +
    '<button id="ttlf-gate-btn" style="width:100%;margin-top:14px;padding:13px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717,#e10000);color:#fff;font-weight:900;font-size:14px;cursor:pointer;box-shadow:0 4px 20px rgba(255,23,23,0.4)">🚀 Liberar Acesso</button>' +
    '<div id="ttlf-gate-st" style="margin-top:10px;font-size:11px;color:#ff3355;min-height:14px;text-align:center">' + ttlfMsg(reason) + '</div>' +
    '</div></div>';
  document.body.appendChild(d);
  try { document.getElementById('ttlf-gate-key').focus(); } catch (e) {}
  function ttlfGateGo() {
    var k = (document.getElementById('ttlf-gate-key').value || '').trim().toUpperCase();
    var st = document.getElementById('ttlf-gate-st');
    if (!k) { st.style.color = '#ff3355'; st.textContent = 'Digite a chave.'; return; }
    st.style.color = '#ffd000'; st.textContent = 'Verificando...';
    ttlfStGet(function (lic) {
      var dev = ttlfDevice(lic);
      ttlfValida(k, dev, function (ok, reason, offline, data) {
        if (ok) {
          var now = Date.now();
          var em = (data && data.email) ? data.email : '';
          ttlfStSet({ key: k, device: dev, email: em, lastOk: now, activated: now, exp: now + 30 * 86400000 });
          var g = document.getElementById('ttlf-gate'); if (g && g.parentNode) { g.parentNode.removeChild(g); }
          ttlfLiga();
        } else {
          st.style.color = '#ff3355';
          st.textContent = ttlfMsg(reason || (offline ? 'offline' : 'invalid'));
        }
      });
    });
  }
  document.getElementById('ttlf-gate-btn').addEventListener('click', ttlfGateGo);
  document.getElementById('ttlf-gate-key').addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ttlfGateGo(); } });
}

function ttlfCorta(reason) {
  ['ttlf-hub', 'ttlf-bolha'].forEach(function (id) { var e = document.getElementById(id); if (e && e.parentNode) { e.parentNode.removeChild(e); } });
  ['rfTimer', 'rcTimer', 'raVarre', 'raFila', 'rvTick', 'rtTick', 'rdTick', 'bnTimer', 'icTimer', 'nvTimer'].forEach(function (t) { try { clearInterval(window[t]); } catch (e) {} });
  ttlfShowGate(reason || 'blocked');
}

function ttlfRecheck() {
  ttlfStGet(function (lic) {
    if (!lic || !lic.key) { return; }
    ttlfValida(lic.key, lic.device || '', function (ok, reason, offline, data) {
      if (ok) { lic.lastOk = Date.now(); if (data && data.email) { lic.email = data.email; } ttlfRollExp(lic); ttlfStSet(lic); return; }
      if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) { return; }
      ttlfCorta(reason);
    });
  });
}

function ttlfLiga() {
  ttlfInit();
  setTimeout(ttlfInit, 4000);
  if (!window.ttlfReck) { window.ttlfReck = setInterval(ttlfRecheck, 6 * 3600 * 1000); }
  ttlfLogWatch();
  if (!window.ttlfProntoLog) { window.ttlfProntoLog = 1; ttlfLog('Live Infinity v10.0.0 pronto para usar ✅'); }
}

function ttlfBoot() {
  if (!document.body) { setTimeout(ttlfBoot, 1500); return; }
  if (window.ttlfBootOk) { return; }
  window.ttlfBootOk = true;
  ttlfStGet(function (lic) {
    if (!lic || !lic.key) { ttlfShowGate(''); return; }
    var dev = ttlfDevice(lic);
    ttlfValida(lic.key, dev, function (ok, reason, offline, data) {
      if (ok) {
        var now = Date.now(); lic.device = dev; lic.lastOk = now; if (data && data.email) { lic.email = data.email; } ttlfRollExp(lic); ttlfStSet(lic);
        ttlfLiga();
      } else if (offline && lic.lastOk && (Date.now() - lic.lastOk) < TTLF_GRACE) {
        ttlfLiga();
      } else {
        ttlfShowGate(reason);
      }
    });
  });
}

function ttlfPersist(root) {
  Array.prototype.slice.call(root.querySelectorAll('input,textarea')).forEach(function (el) {
    if (!el.id) { return; }
    var k = 'ttlf-' + el.id;
    var v = null;
    try { v = localStorage.getItem(k); } catch (e) {}
    if (v !== null) {
      if (el.type === 'checkbox') { el.checked = (v === '1'); } else { el.value = v; }
    }
    function salva() { try { localStorage.setItem(k, el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value); } catch (e) {} }
    el.addEventListener('input', salva);
    el.addEventListener('change', salva);
  });
}

function ttlfDrag(el, handle, key, onClick) {
  var sx = 0, sy = 0, ox = 0, oy = 0, moved = false, down = false;
  try {
    var p = localStorage.getItem(key);
    if (p) {
      p = JSON.parse(p);
      var t = Math.max(0, Math.min(window.innerHeight - 60, p.t));
      var l = Math.max(0, Math.min(window.innerWidth - 60, p.l));
      el.style.top = t + 'px'; el.style.left = l + 'px'; el.style.right = 'auto';
    }
  } catch (e) {}
  handle.addEventListener('mousedown', function (ev) {
    down = true; moved = false; sx = ev.clientX; sy = ev.clientY;
    var r = el.getBoundingClientRect(); ox = r.left; oy = r.top;
    ev.preventDefault();
  });
  document.addEventListener('mousemove', function (ev) {
    if (!down) { return; }
    var dx = ev.clientX - sx, dy = ev.clientY - sy;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) { moved = true; }
    if (moved) {
      el.style.left = Math.max(0, Math.min(window.innerWidth - 50, ox + dx)) + 'px';
      el.style.top = Math.max(0, Math.min(window.innerHeight - 50, oy + dy)) + 'px';
      el.style.right = 'auto';
    }
  });
  document.addEventListener('mouseup', function () {
    if (!down) { return; }
    down = false;
    if (moved) {
      try { var r = el.getBoundingClientRect(); localStorage.setItem(key, JSON.stringify({ t: Math.round(r.top), l: Math.round(r.left) })); } catch (e) {}
    } else {
      if (onClick) { onClick(); }
    }
  });
}

function ttlfBuildHub() {
  var css = document.createElement('style');
  var fontLink = document.createElement('link');
  fontLink.rel = 'stylesheet';
  fontLink.href = 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap';
  document.head.appendChild(fontLink);

  css.textContent = '#ttlf-hub{font-family:"Plus Jakarta Sans",system-ui,-apple-system,Segoe UI,Roboto,sans-serif;scrollbar-width:none}' +
    '#ttlf-hub label{display:block;color:#ffd000;font-size:10px;letter-spacing:.8px;text-transform:uppercase;font-weight:800;margin-bottom:5px}' +
    '#ttlf-hub input,#ttlf-hub textarea,#ttlf-hub select{background:#03050a;color:#fff;border:1.5px solid rgba(255,208,0,0.28);border-radius:12px;padding:9px 11px;font-size:12px;box-sizing:border-box;width:100%;outline:none;transition:all .18s}' +
    '#ttlf-hub input:focus,#ttlf-hub textarea:focus,#ttlf-hub select:focus{border-color:#ffd000;box-shadow:0 0 0 3px rgba(255,208,0,.25)}' +
    '#ttlf-hub input::placeholder,#ttlf-hub textarea::placeholder{color:rgba(255,255,255,0.45)}' +
    '#ttlf-hub .ttlf-sec{border-top:1px solid rgba(255,208,0,0.12)}' +
    '#ttlf-hub .ttlf-sec-h{padding:13px 16px;font-weight:800;cursor:pointer;display:flex;align-items:center;font-size:13px;color:#ffd000;transition:background .18s}' +
    '#ttlf-hub .ttlf-sec-h:hover{background:rgba(255,208,0,0.06)}' +
    '#ttlf-hub .ttlf-sec-h>span{margin-left:auto;color:rgba(255,208,0,0.7);font-size:11px}' +
    '#ttlf-hub .ttlf-ic{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:9px;background:#141928;color:#ffd000;margin-right:10px;flex:none;border:1px solid rgba(255,208,0,0.25)}' +
    '#ttlf-hub .ttlf-ic svg{width:15px;height:15px}' +
    '#ttlf-hub .ttlf-sec-b{padding:4px 16px 15px}' +
    '#ttlf-hub .ttlf-desc{color:rgba(255,255,255,0.65);font-size:11px;line-height:1.5;margin-bottom:9px}' +
    '#ttlf-hub .ttlf-go{width:100%;padding:11.5px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000 0%,#ff8800 50%,#ff1717 100%);color:#000;font-weight:900;cursor:pointer;font-size:13.5px;transition:all .18s;box-shadow:0 4px 18px rgba(255,208,0,0.3);letter-spacing:0.2px}' +
    '#ttlf-hub .ttlf-go:hover{filter:brightness(1.12);transform:translateY(-1px);box-shadow:0 6px 22px rgba(255,208,0,0.4)}' +
    '#ttlf-hub .ttlf-go:active{transform:scale(.98)}' +
    '#ttlf-hub .ttlf-st{margin-top:8px;color:rgba(255,255,255,0.55);font-size:11px}' +
    '#ttlf-hub .ttlf-preset{flex:1;padding:7px 0;border:1px solid rgba(255,208,0,0.25);border-radius:9px;background:#141928;color:#fff;cursor:pointer;font-size:12px;font-weight:800;transition:all .18s}' +
    '#ttlf-hub .ttlf-preset:hover{border-color:#ffd000;color:#ffd000;background:rgba(255,208,0,0.12)}' +
    '#ttlf-hub button{font-family:inherit}';
  document.head.appendChild(css);

  var d = document.createElement('div');
  d.id = 'ttlf-hub';
  d.style.cssText = 'position:fixed;top:64px;right:12px;z-index:999999;background:#070a12;color:#fff;border:1px solid rgba(255,208,0,.38);border-radius:22px;font-family:sans-serif;font-size:13px;box-shadow:0 24px 70px rgba(0,0,0,.95), 0 0 40px rgba(255,208,0,0.08);width:325px;max-height:84vh;overflow-y:auto;overflow-x:hidden';

  d.innerHTML = '<div id="ttlf-top" style="position:sticky;top:0;z-index:5;background:linear-gradient(135deg, rgba(13,17,29,0.98), rgba(7,10,18,0.99));border-radius:22px 22px 0 0;border-bottom:1px solid rgba(255,208,0,0.25)">' +
    '<div id="ttlf-head" style="cursor:move;display:flex;align-items:center;gap:6px;padding:12px 14px">' +
    '<img src="data:image/jpeg;base64,/9j/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAEAAQADASIAAhEBAxEB/8QAHgAAAgIDAQEBAQAAAAAAAAAAAAEHCAUGCQQDAgr/xABdEAABAwMCBAIEBwgMCAsJAAABAgMEAAURBgcIEiExQVEJEyJhFDJCUnGBkRUzcnWCsrO0FyMkJTdDYnN0kqGxFhkoOGOUwdIYJic0NTZUVZOVo0RTVmSDw9HT4v/EAB0BAAEEAwEBAAAAAAAAAAAAAAADBQYHAQQIAgn/xABCEQABAwMBBQQHBgMGBwEAAAABAAIDBAURIQYSMUFREyJhcQcygZGhseEUFULB0fAjktIWNTaCsvFDRUdSYnLCw//aAAwDAQACEQMRAD8A6p0UhUG8WfFppbhQ0D92Lx++N9m8zdosTTgS7NdA6knryNJyCpeOmQBlRAOQM6BCkfczdXSWzmlZOo9Z36Hp+zMdFSZjmOdXghCRlS1nwSkEnyrmzv56Y6dIfk2zaLTTUaOCUC/6iQVuL/lNxkkBPuLij70iqIb78QetuI3WrupNa3VU18FQiQWsoiQWyfvbDecJHmeqld1E1G/atlsQHFJl3RTBr/i/3p3OedXqDcvULzThJVEhSzCj/QGmORP9lRNNnyri8Xpcl+W6e7j7qnFH61EmvhRSuAOC8ZTpUGnWVhFFFKhCdFFKhCdFFKhCdFKihCdFIU6EIopU6EIopU6EIopUUIToopUIX3hz5NveD0SS/EdByHGHVNqH1pINSxoDi93o2wdbVp7crUMdpsgpiS5hmR/raf50/wBlRDSrBAPFZyumuwnpjrhGfj23dzTTUuMcIN+06jkcR/KcjKOFe8tqHuSa6UbZ7raS3j0rH1Hoy/Q9Q2d/omRDczyK8ULScKQseKVAEeVfzR1I2xXEDrbhz1o1qXRV2XBkEpTKhO5XFnNg/e3284UO+D0UnOUkGknRA8F7Duq/pCoqCuEri20txX6C+61oxbb/AAQlu72J1wKdhuEdCD8tpWDyrx1wQcKBFTrWsRjQpRalutubY9m9ur/rPUcj4NZ7NFVJeUPjLx0S2geK1qKUpHiVCv56uILfbUfEbujdta6lePwiUr1cWElRLUGMCfVsN+5IPU/KUVKPU1fD0x+/Lsi7aY2ktskiOw2m+XhKFfGWoqTGaV9ADjhH8pB8K5kVsxtwMpJx5J0Us0UsvCdFKgUITopGihCeKPCilQhFOikaEJ0YzSFFCE6VFOhCKKVOhCB0opdaBQhOikaKEJ0Us0daEIp0qM0ITopUUITopUUIUjcP++mo+HTdC061006fhMRXq5UJSiGp0YkesYc9ygOh+SoJUOor+hbafc6x7y7dWDWmnJHwmz3iKmSyT8ZBPRTax4LQoKSoeBSa/mjzmumvob9+HY941PtLcpJMaQ2b5aErV0Q4kpTJbT+EC25j+Ss+NIytyMpRp5KlXF9uA5ufxOblahU6p1l29PxYylHP7QwfUND6OVofbUP1958xy4z5Mp0lTsh1byyfFSlFR/tNfGlRoMLwiikaBWVhGKdImjOaEJ0UdqWaEJ0YopA9aELftO7L37U9miXOI9BTHkpKkB11QUBkjqAk+VaROhrt82RFd5S4w4ppRScjKSQcfZVptoP4N7D/ADSv0iqrLqg/8Zbv/THvzzUbtlfNVVU8MmMMOnvIVtbW7M0Fms1trqUHfnaC7JyM7jTp01JWNrbtG7X3bXMF+Xb3YqGmXfVKD7hSc4B6YB6dRWoVYPhz/wCqtz/pv/201t3erkoqUzRcQQmTYey0t/vTKGtzuFrjocHQZGqicbcXI6zXpgyIabilHOFKcIbV7AVgHlznB8vA199YbU3rRNsbnz1RnY63A0THWVFJIJGcgdDjFZPda5v2Pd+RcIxxIjLjvI95Daen19vrqdLrFibi6HcQ2QWLjGC2VH5CiMpP0hQH2GmeoulTTCmndjs3gb2nPn9PJTq17G2m7vu1vh3hU073iPvaFoJDcjGuowT4hVHrN6R0hP1rdTb7eGw6lsuqW8ohCUjA6kA+JArDyGHYshxh5BQ80strSe6VA4I+2rEbA6X+5elnLo6jEm5K5kE9w0non7Tk/ZTzda77DSmZvrHQef8AsoFsbs5/aO8MopgRG3Ln40IA5eBJwPaoh1Xtnc9HP25mc/DU7Pd9W0hlwqPcDmOUjAyRWwHh61N1Hr7d5fflf7teHXuqv8Kd0WnEL5okSU1FYx25UuDmUPpVk/ZU+7gXuTpzSF1ucPk+Ex2+dHrE8yc8wHUfXTDV3Gvp207ARvycdOZIx89VZFk2W2auct1neH/Z6Y93DtSGh28eGuS3I8FCH/B71MP4+3f+Mr/drEaq2ivWj7M5cprsNcdC0oKWXFKVlRwOhSKyH7P+qB0Krf8A6v8A/wBVitTbs33Vtocts4xDGWpK1epZ5VZScjrk05Qi8do3tizdzrjjhRS4O2ENJL9hbN226d3OMb2NM68MrTcU8UdqWakiqZGM08UUs0ITpYoFFCE6VFOhCMYqXuEPcFza7ib221El1TLLN6YjSVJOMsPn1Do+jldJ+qogFfaFKcgTI8lpXK6w4h1Ch4KSoKB+0VgjOizwXxp0qdZWEqKdKhCME06KKEJYzQBToNCEjTA6iigd6FlWr2h/g3sP80r9Iqqzao66mu/9Me/PNWa2g/g3sX80r89VRzeOH67XG7zpbd0gpRIfcdSlSV5AUokA9PfVe22sgpK6pM7t3JPzK6i2usVyveztoZboTIWsaTjGmY2Y4kKGMVYLhz/6q3P+mn9GmtRuHD7d7fAkyl3SCtDDSnVJSleSEgkgdPdW38ORB0rcseM3P/pppxvNZBV295gdvYIyorsFY7lY9qKdlxhMZcx5Gca4GvAlRtvb/CTdPwGf0aakPh61T8MtEuxPLy7DPrmQfFpR6j6lfnVHm9p/5Sbn+Az+jTWH0BqY6Q1bAuRJDCV+rfA8WldFfZ3+qtqSk+22hkY47rSPMD8+CZ6W9/cG3NRVuOGGaRr/AP1c8gn2HDvYt63R26dlbnQG4iOVm+rCioDohY++n7Pa+upO3CvjWgdAv/BMMrS0mHDSPBRHKk/UkE/VW2Ljx5TjEkoQ6trKmnMZ5eYYJB94qv3EBqj7qakYtDS8sW5OXAD0Lqhk/YnA+s1FqOSS7TU9NIO7GNfHH7A96uO/01LsPQXO60x/i1bgGeBcNceRL3+4clHFjGb3bv6S11/LTVv7/Nt9utMuRdvVi3NjL3rkc6MZ8U4OeuPCqg2I4vdu/pLX56athriwvap0rc7XHcbafko5Erdzyg8wPXH0U6bRhpqKcPOBrk9BkaqIeil0zLXdHU7A94A3WngTuvwD4E6LUzrbbM/Ktf8AqB/3KjLeG96bvD1qOnTGKW0uB74Mx6rqSnlz7Iz41kTw7X3P/SVu+1z/AHaxmptk7vpixy7rInwnWYyQpSGufmOSB0yMeNL0TLbBUNfHUlzuABOhzp0TbtBPtbcbZNBV2pkceMuc1uCA07xOd89NdOCjvvRjFOipqufUsUYp0E0LCVGM0U6EJdqKKdCEsU6VFCE6KKKEJUU6VCEd6AKdFZWUiaAK+jbSlnoK9rFqW4fik0k6RrOKyATwWOpgHyrZI+m1rTkjHvNe1OknVD2W1K/BGa1HVsTeaVETiiy7t6l09a41uhSWURY6SltKoyVEDJPUnv1Ne79nXV//AGyN/qiKxz2lFsjK08n4XSsdI086nOEHFaHZW+VxcY2knwCk8e0l/p42xRVkjWtAAAe4AAaADXks7K3r1XMjPR3ZcctPIU2sCKgZBGD/AGGsVpbcW96NhOxLU+00y6561QcZSs5wB3PuArCPwFsnsa8xSU9+lbzKSk3DG2Nu6eIwFqv2ivL52VT6uQyNBAdvHIB4gHORnmvfqC/zNT3Z65XBaXJToSFKQgJHQADoPcKx1Mmit5jWxtDWjACYZppKiR00zi5ziSSdSSeJJ6lbvbt59VWuBGhszGSzHbS2j1kdKlcoGBknv0rTp0164zZEuSsuyH3FOuLPdSick18aXekIqaCFxdEwAnjgJxrLvcLhGyGrndI1nqhziQOWmfBfSM+uLJafbIDjS0uJJGRkHI/urfP2ddXg5+GRsk/9lRWgJBPQCvSzb1vHsa8VEFPNgzsDsdRle7feLlbA5tBUPjDuO64jOOGcLdTvrq8/+1xv9VRXivO7WpdRWqTbp0lhcWQkJcSiOlJIyD3HbqKxcXTzi8ZQceZrJNaTccGUJ5/wetNpit8Tg5sTQR4BOsm0l/qI3RS1kjmuBBBe4gg6EHXgVqBB8qWK3JWkngPabKfwhivFJ02tsdE594rfbWxO4FRcxOC1rNGKyD9pcaPxSK8a2lN9CK22yNdwKSIIXz7Ud6KdKLyjFKjxp0ISp0UUIRRRRQhLvRTooQlnNeqJDU+odOtEKKXlgYzU37E7B3rd7UbdvtrYYjNYcmT3Uktxm89z5qPZKR1J8gCQz3K5QW2B087g1rRkkraggfO8MYMkrTdC7Y3rWl3Yttmtki5TnfisR0cxx5nwSPMnAFXQ2r4BorEdmXre5H1pGTbLWoYT7lvEfmj66srthtVp7abTyLVYYgayB8IluAF+UofKWr+5I6DwFbga5Q2i9JNdXvdFbT2cfX8R/p9mvjyVjUNjhhAdP3ndOX1WgaY2F290clH3M0jbEuJ/j5LPwh0+/mc5j9lbtHgRYqORiMwwgdktNJSPsAr0UVU09ZU1Tt+eRzj4kn5qRsijjGGNA8ljrjp21XhtTU+1wprahgpkRm3AftFRjrLhR211gw5iwIskpfaTaFeoIPmUdUH+rUv0VsUtzraFwdSzOYfAkf7pOSCKYYkaD7Fzr3l4I9T6LakXGyEanszYK1KjN8sppPmtrrzAeaCfoFVau1hciqIKT0rt12xjoR5VXbiJ4S7VugxJvWnGmLVqjBWtsAIYnHyX4IWfnjofleYvLZb0lyNkbTXjgdA8afzDh7R7RzUSr7E0tMlN7v0XLB1gtE9K+ea3rWmiZ+mLrLt9wiOw5sZwtvMPJ5VoUO4IrSnmS2s5FdNU1SyoYHsOQVA3xlhwV8u9fRplThAApsMlxWAK3TRmip+pbnFgW+G7MmyVhtmOykqW4o9gBRU1LKdhe84ARHGZDgBYm1WBySoYSatLstwTal1syxcb5/xZszgCkqkt5lOp80NdMD3rI+g1Yzh24TbVtjFjXnUbTF01PgLQ2QFsQT5I8FrHzz0HyfM2HPUk+J8a5k2o9JkjpHUtn4DQvOv8o/M+wc1PrfYWgCSp936qINHcKG2mjmmz9wEXqWjvJu6vXkn3I6IH9WpPt+n7XaWktwrbChNp6BMeMhsD7BWQxijwqjau5Vtc7fqpnPPiSVLI4IoRiNoHsXnkQIspBQ/GYfSfkutJUP7RWkap2D291mlX3U0lbFOq/j4zXwd0e/mb5TW/0UjBWVNK7fp5XMPUEj5L26OOQYe0HzVO90+AaI/GelaJuavWgZFtuihhXuQ8B3/CH11TDXW1950Xdn7beba/bZzXxmZCOU48weygfMZFdk61Hcza3T27Gnl2m/Qw6ACY8tsAPxlH5TavD3g9D4irZ2d9JFfb3tiuR7SPr+If1e3Xx5KOVtjhmBdB3XdOX0XF2VCUwojFeQ9D1qe9+tg7ztBqRyBcUB+K6C5DntJw3Jbz3HkodApPgfMEEwdMillZBFdXWy5QXGBs8Dg5rhkEKup4HwPLHjBC8tFOkBTwtRAp0UqEJ0UUqEIzX7aRzrAxX5xXvtUb1zwHvrxI7daSvQGThbrtxoafrK/2+02yOZE+Y8lllseKj5nwA7k+ABrrHtFtfbNo9EQrBbglxxA9ZLl8uFSXiPaWfd4AeAAFVj4Atr0A3XWktrPqP3vglQ7LIBeWPoSUp/KVV0K4+9JW0T66u+7Infw4/W8XfQfHPQKzbFRCGHt3DvO4eX1Sr8uOIZbW44tKEIBUpayAEgdySew99Na0tpUpSghKQSVKOAAO5J8q5+8U/FHJ1tPlafsMpUfSzCihSmzymeoH46v9Hn4qfHue4xANndnqraKq+zwaNHrO5AfmTyCea2tjoo99/HkFYjcXjL0Rop92JbPXammt5BVDUERgfL1p+N+SCPfUL3L0gl/U8r4Hp+zxm89EurddOPeeZP8AdVLLnqJx5avbOKxCro6o5ya6bt3o0s1NGBLH2jurifkMD4KAz36pe7unA8Ff3TPpAZi5KE3rTUJ9gn2lwJC2lj6AvmB+0VY7bTfjR+6yUtWa5eruXLzKtswBuQB4lIzhY96SfqrjuxeHW1fGIradOawk2+YxIZkOMPtLC23WllK0KHYgjqD7xWhePRjbKmMmkBifyIyR7QT8sJalv87DiTvBdoAeYU6rDw0cWTOt/gumtWyUN3pWG4lyXhKZZ8EOeAc8j2V7j3s8T/Z3rmO7WirstSaWrbgjgeRHUHp+yp5TVMdVH2kR0UIcSnDjB3nsyrhb2242q4jeGHuiUy0Dsy4fzVeB6dj05mao0hKtNzkwpEdyPJYcU06y6nlUhYOCkjwINdou4qtvFXw9R9XwX9YWSL+/cdGZzLaesppI++Y8VoHfzSPMCrR2D2zfbZG22tdmM6NJ/CenkeXQ+HBhu9rFQ0zxDvDj4/Vc7tM6RlXW5RoceO5IkvuJaaZbTzKWtRwEgeJJrppw1cOMLZmypuFwbbk6rlt4fe6KTEQf4ls+fzleJ6DoOut8KfD3H0hBZ1he4gF6kIzAYcT1itKH3wjwWsHp5JPmasnijbzbN9zkdbaJ2Ixo4j8R6eQ59T4cS0WsU4E8o73Lw+qKO1PGaq7xOcWTehRK0zpGQhy9py3LuacKTEPihvwLnmeyfee1XWi0Vd6qhS0bck8TyA6k9P2FIKmpjpYzJIdPmpf3P350ftKgt3q4etuPLzJtsMByQR4EjOED3qI+uq46k9IFLL6k2XTMOOyD0XcJC3Vn6QjlA+01S3Ues5V0mPyJEhyQ+6srcddWVLWo9yonqT7zWrv3dxZOFE105ZvRjbKaMGrBlfzJyB7AD88qA1V/ne7EXdCvPbPSB39Lw+GWCzyG89Q0t1pX28yv7qmbbrjL0TrR9qJcw9pmYvACpaguOT5etHxfygB765XIurqT8YisvbdROtLT7dOFx9GlmqYyIo9x3VpPyOR8EjBfqlju8cjxXbRp1D7aHG1JW2sBSVoOQoHsQR3Hvr91z64WeKGToi4RbDfpSpGlX1BALhKjAUflo/kZ+Mnt4jqOvQRtSXEJWhSVoUAUqScgg9iD4iuZNotnqrZyq7CfVp9V3Ij8iOYU9oa2Otj32ceY6LT929sbZu5ombYLkkIWsFyLL5cqjPgeyse7wI8QSK5M7k6Gn6M1BcbRc45jz4TymHm/JQPcHxB6EHxBFdl6phx/bXoV9ydaxGQPX/vfOKR3WASys/SkKT+Smp96Ndon0Nd92Su/hyer4O+o+OOpTPfaJs0PbtGrePl9Fz1cQULINfnNZC6xyy6fDBrH4zXYMbt9oKrIjBRToor2vKKKKVCE62TTUcLfQSOla0O4rdNIMh15KT8r2ft6U31rt2IlLwjLl1j4eNMJ0jsvpODyBDrkNMt7p3cd/bDn6lAfVUiV5LVDTBtcKKjohiO20APJKAP9leuvnhXTuq6qWodxe4n3nKuyJgjjawchhQVxi7jOaF2ndgxHS1PvjhhhSThSWQOZ4j6RhP5Zrl9qO5qeeX16VdT0hF3cXqvTtuCj6uPbVvcvhzOOkZ+xsVRO5rKnzmutvRnbY6azRy470mXH34HwAVb36cvqi3kNF5FKKzkmkTSoAq6Qoqivo08ppXQ18zRjNBGeKAtrsF/XGdT7RGCPGuj/AAn8Rqdw7YzpfUEoK1DHb/cspxXWa2kdj5uJH9YDPcGuXTLpaUCDW/6D1HMtd0iS4klyLKjuJdaeaVhTawchQPmDVcbXbMU99o3Rv0cNWu6H9DzHPzwny2176SUEcOYXZYHNOo32J3ej7t6Oblr5GrzECWp7Ceg58dHEj5qsZ9xyPCpIJwK4mq6SahnfTTtw9pwf30PJWpHI2Vgew6FLNMUgKjjfbd2NtHox6YkocvMoKat8dXXK8dXFD5qc5PmcDxopKSaunZTQDLnHA/fhzXqSRsTC95wAo04tuI8bdWx7S+nZQRqGS3+6pTZ6wmlDsPJxQ7fNBz3IrnBf7+5LdWVLKiT1yazOvNSTLtdJcuZJclSZDinXXnVZU4snJUT5k1oL7pcWevSu2dkdmKew0bYmDLjq53U/oOQ5eeVVVyuD6uUk8OQQ66XDkmvnmjGaKscAAYCYk6ErKTkGlRihC2bTlzU08nrXUHg83Fc1ztS3BlOl2dY3BDKlHJUyRzNE/QMp/JFcprW4UPj6avZ6Pm7uJ1XqK3lR9XItqHuXwy26AD9jhqlvSZbY6mzySkd6Mhw9+D8CVKbDO5lSG8naK8NR1xE6WTq/ZbVkHkC3W4apbPTqHGf2wY+pJH11IteW6xEz7VNjLGUPsONEeYUgj/bXJFDUOpKqKobxY4H3HKsiZgkjcw8wQuKWpo4Q+sgdD1Fa3W56vZDT60gdE+z9nStMPc19EaJ29ECqUlGHI70dqMUVvpBOlRRQhMeFbpo90NvJUfkkK+ytK71s2mJAQ8gHse9N9a3eiIS8Rw4LtXaZKZtshSUHKHmG3QfcpAP+2vVUd8PeqU6v2Z0nO5wt1ENMR73ONftZz/VB+upEr5311O6lqpad/FjiPccK7IniSNrxzAKo96QezrTqrTtw5T6uRbVs82OnM26Tj7HBVErogoeP011a4xNuHNd7TuzYrZdnWNwzUpSMqUyRyugfQMK/Irl5qK2qaeV06V1v6M7lHU2aOLPejJaffkfAhVvfoCyqLuTtVrlBNCklBwe9KrpGqiuEU6VfttpTpGBQSBqUAZTZbLqx5VIGgtOTLrc4sWFGclSpDiWmmWk5U4snASB5k1grBYly3UJCSST2xXSDhK4cP2Oba1qjUMYJ1DJb/csVxPWE0odz5OKHf5oOO5NVxtdtPT2KjdI85cdGt6n9BzP54T7baB9ZKAOA4nopN2K2kj7S6MZhrCHLzKCXZ76euV46NpPzU9vecnxqRqeKK4nq6uaunfUznLnHJ/fTorTjjbEwMZoAjNRtvvtDH3d0Y7ERyNXmIFO2+QroAvHVtR+Yrt7jg+FSQOtOsUlXNQVDKmndh7Tkfv5+CzJE2VhjfqCuMuvNOTbTdJcSZHciyo7imnWXU4U2sHBSR5g1oT7ZaWa6icWnDeNxrW9qfT0UK1HGb/dUVsdZzSR3Hm4kdvnAY7gVzevthXEdWFIIIOMEdRXbOyO09PfqNsrNHDRzeYP6HkefnlVVcqB9HKQeHIrWaVft1pTSsEV+BVjggjITHjCdBNKhKSs4oRhe21oK3h9NXs9HzaXF6s1DcMH1ce2pZJ8OZx1JA+xs1SnT1tU88np0z3rqHwd7cuaF2obnS2i1PvjgmKSoYKWQOVoH6RlX5YqlvSZco6azSRZ70mGj35PwBUpsMDpKoP5N1U615rpLTBtc2So4Qyw46onySgn/AGV6ajviF1SnR+zGrJ/OEPLhqiM9epce/axj+sT9Vck0VO6rqoqdvF7gPeQFZMrxHG555DK5OawdDr61g5Cva+3rWmE9TWy6ofCn1gHoOgrWSa+h9C3diAVJynLk6VFOnBIIooooQishaZBaeHXtWO8a/bS/VrBpORu+0hegcHK6F8Au5yD91dGS3sF/93wQo91gAOoHvKQlX5KqubXGzbXXE7SF/t91tsgx50J5LzLg8FA+PmD2I8QTXWHaXc62btaLh323KS24oBuXE5sqjPAe0g+7xB8QR764+9JOzz6Gu+84m/w5PW8HfUfHPUKzLFWiaHsHHVvDy+i3FSEuJKVJCkqGClQyCPEEVz94quFyToq4StQ2CKp/S76ytSWxkwFHuhX+jz8VXh2PYZ6B1+XG0PNrbcQlxtYKVIWAQoHuCD3HuqA7O7Q1WztX9og1adHN5EfkRyKea2ijro9x/HkVxIuWn3GXD7JrEqtriT2NdUdx+DDRGtnnZdqL2l5rhKlJhoDkZR/mjjl/JIHuqFrn6PbUKXlfAtQWaQ3nop5LrR+scqv766dt3pLstTGDLL2bujgfmMj4qAz2GqjdhrcjwVGmrW44R7JNbNpzSEm5zWI7Edx995YQ200gqWtR7AAdSfcKunpj0fExMhC73qeEyx8pFvjrdWfoK+UD7DVkNsdhNG7TJDtltvrLly8qrnMIckEeIScYQPckD66b7z6T7XTRkUhMr+QGQPaSPllL0tgqHuzL3Qog4Z+ElnQyomp9Wx0O3pOHIlsVhSIh8FueCnPIdk+89rRUdqK5iu14q71UmqrHZJ4DkB0A6fsqe01NHSsEcQwPmjtVb+KriBj6SgP6QssvF5kIxPeaV1jNKH3sHwWsd/JJ8yK2XiS4ioWzVkVBgONydVS28sMn2hFQf45wfmp8T17DrzL1RrCVdbnJmSJLkiS+4p1151XMpaiclRPiSatDYPY2S5yNuVY3EY9UH8R6+Q5dT4cWC73NtODDEe8ePh9V0P4VuIGPq6Ezo+8yh92YyMQHnD1lNJH3snxWgdvNI8washXGHS2sZVquceZHkuR5LDiXWnmlcqkLByFA+BBrpnw3cRULeSyJgT3G42qojeX2R7KZSB/HNj85PgevY9DbzY19tkdcqNuYz6wH4T18jz6Hw4FnugqGiCU94cPH6qbB0qr/ABOcJjOvBK1NpKMhq+KyuXbU4SiYfFaPBLnmOyvce9n6Kq+0XerslSKqjdgjiORHQjp+wpBU00dVGY5RouLGotISrZNfjSIzjD7Kyhxl1BStCh3CgeoPuNa09a3EE+yRXYrc7YfR27KC5e7aG7jy8qbnDIbkAeAJxhY9ygfqqtupfR7zFSFqsuqIb7B+Ki4RltLH0qRzA/YK6ds3pOtlTGBVkxP5g5I9hA+eFAarZ+oY7+F3gqCItrij2NZW3WBx1Y9k1dO2+j31Cp8fDNQWaM3nqppLrpx7hyp/vqaduOC/Q+in2pl19bqec2QQJaQ3GSf5ofG/KJHupwuPpKs1NGTHJ2jujQfmcD4pGCw1Uju83A8VXjhW4W5Ot50XUF+iqY0qyoLCXAUqnqB+In/R5+Mrx7DucdBEIS2hKEJCUpAASkYAA7ACk22hltDbaEobQAlKEjASB2AA7D3V+q5i2i2hqtoqr7RPo0eq3kB+ZPMqe0VFHRR7jOPM9UVTPj63PbH3L0VEeBLGLhPCT2WQQyg/QCpX5Sas1u1uja9o9Fy79clJW4keriRObCpL5HsoHu8SfAA+6uTu5Wt52r9Q3K7XGQZE6a8p95zwKiewHgB0AHgAKn3o22dkrq77zlb/AA4/V8XfQfHHQpnvtaIYewae87j5fVaTd5PrnVdfGsfX6dX6xZJr8E12DG3caAqyJyU6KXeilF5TopUUITxRSooQvXBlqjuAg1Omw2/N42m1I3cLe4Ho7gDcuC4rDclvPY+Sh3Cu4PuJBgHNeuFPVHUOuKZrlbILlA6Cdoc1wwQVtU874Hh7DghdodtN1NP7r2BFzsUwOEAfCIjhAfjK+atP9yh0Pga26uOGhNzrxo67R7lZ7nIts5r4r8dfKceIPgQfEHINXO2x49or0ZmLrS2q9YAEm5WtI9r3rZJ/NP1VyhtF6N6+gkdLbR2kfT8Q/q9mvhzVjUN8imaGz913Xl9FcGitB0vv1t/rBCfuZqu2qcV/ESXfg7o93K5g1uzFyiy0c7Eph5J7KadSofaDVTT0dTSu3J43NPQgj5qRslZIMsIPkvRTrG3DUNrtLSnJ1zhQm091SJKGwP6xFRnrLis230ew5i+ovclHaNaU+uJPkV9ED7aWpbZW1zgylhc8+AJ+PALxJPFFrI4BS936Duar3xCcWFp2wjybPp91m66nAKFKBC2IR81nspY+YO3yvI1z3k42tSazZkW6ygaatDgKVJjOFUl1Pkt3pgHyQB9JqrV41E5KUcrzV5bL+jOR721N44DUMGv8x/Ie08lE7hfmgFlN7/0WZ1vrmdqe6S7hcJjs2bJcLj0h5XMpaj4k1oj76nlnrSefU8oknpX4rpympWUzAxgwAoDJI55ySvqw+plYOelb3onXM7TV0izrfMdhzYzgcZkMq5VoUPEGo+719WX1MqyDRU0rKlhY8ZBRHI6M5BXVTh74rbTudGjWfULzFr1NgISskIYmnzQeyVn5h6H5PkLBdjjsa4mWjUjkVScK6eVWj2c41tS6MbYt95I1LaEAJS3JcKZDSfJDvXI9ygfpFcx7UejORsjqm0cDqWHT+U/kfYeSntvvzSBHU+/9V0Qp1D+jeK/bfV7LfNfE2SUrvHuyfU4PuX1QftqTrdqO03htLkG6QprahkKjSUOA/Yao6rtlbQuLaqFzD4gj48CpbHURSjMbgVke9OvM/cosVBU9JYYQPlOupSPtJrTdUb6aA0g2tVy1XbUuJH3iM8JDp/Jbya14KOpqXbkEbnHwBPyXt0rIxl7gFvVahubutp3aWwqul/mBrmBEeI2QX5Kh8lCf71HoPE1Wzczj7ix2nomjLUr1hBAuV0AwPelkH84/VVM9wNz7vre8P3S8XF+5TnvjPvryceCQOyQPADAFW1s76N6+4SNluQ7OPp+I/wBPt18OajlbfIYWlsHed15fVbhv9vtdt3dTOXGe56mM0C3Dgtqy3Gbz2Hmo91K8T7gBUGzZan1nrmnLnqfUcnvXjzXV9ttsFtgZBA0Na0YACrmed87y95ySnSxRmnTytVFI9qKD2oQnRRSoQjHSinSFCEYoqXNqeFrcDejTLt+0vBgSbc3JXEUuTPQyr1iQkqHKrrjCh1rQ9wdDXbbLV1z01fmmmbrblBEhDDodQCUBYwodD0UKbIbnRVFS+jhma6VnrNBBcOWo4jiFsOp5mRiVzSGngeSwSHlN9jXvjXdxkj2iKmlrgf3bk6YbvsWywpkJyGmc23HuLa3nGygLAS33Kik/F756VAqgUqKSCCDggjBB99J0lfb7pvikmbJu6HdIOD444L1JDNT47RpbnhkLaI2qnG04KsjyNe1vWTyR7LhT+CcUbS7Oan3t1DJsulY8eTPjxTMcTJkpYSGwpKSeZXc5WnpXv3f2G1fsXItTGrI8WK5ckOORhFlpf5ggpCs8vbqoVpvltn2wUDpW9sRncyN7GM8OPDVKhtR2XbBp3evJY6RrBx4e2vm/C61jJWpHXPlnFSDtjwm7jbv6Ua1HpuDAkWpx5yOlci4NsrK2zhXsnrjJrbP8X7vJ/wB1Wj/zdqm6W87P0croZquNr2nBBc0EEciMpdtLWytD2xuIPgVX1+5LeJ6mvIolZ69ascPR+7yEgC1Wg+H/AEu1UWaQ2V1RrncuboO0R4ruo4a5LbzTslKGgWCQ5hw9Dgg486cqW+2eoZJJTVLHNjGXEOB3R1OugWvJSVUZaHxkE6DTitEApGpS3d4bNc7H2q33HVkOFFiz5CozBjTUPkrCeY5Cewx40bQ8Nmud8bXcLhpOHClRYL6Yz6pU1DBCynmAAV3GPGtn76tv2T7f9oZ2PDf3hu5zjjw46Lx9ln7Tsdw73TGqi0Cg1tG5O22oNptWytN6mg/ALowlLhSlQW24hQylaFjopJ69R4gjuK16FEcnzI8VkAvPuJaQFHA5lKCRk+HUinOKeKeJs8Tg5hGQQcgjqD0Wu5jmOLHDBC+KSUnINeuPcnGT3qadccF26G3mk7tqO9W62s2u1sl+Stm5NuLCQQOiR1PUio72r2m1HvPqlWntMMR5FzTHclFEmQllHq0EBR5j0z7Q6U0xXe2VdM+riqGOiZ6zg4EDTOp4DRbLqaojeI3MIceAxqsfF1I6jpznFZJjV62R7BCT/J6Vmd4eHbWmxMW1v6tiwoqLktxuP8FmIfJKACrPL26KFb9G4BN4pTDbyLXaShxAWnN2aHQjI/vprmutjZCypkqoxG/O6S4YdjQ4OdcHithlNWFxjbGcjiMcMqKndYOvD23Cv8I5rxPapd5eUKwPIdKmf/F/by/912n/AM3apH0fu8nf7l2n/wA3arSbtBs03hWxfzt/VKmirz/wne4qBJV4ceJ6k14HHVudSTU92zgb3Wu0q4xokGzPSLdI+CS203drmZd5ErCVD3pWlQ8waibcXby+7V6unaa1JDEK6xOUrQlYWhSVJCkrQodFJIPQj3+VSChutrrZTBRzse8DOGuBONNcDlqNfFaU1PURN35WEDqQtZoAr6RY7syS1HYbW8+8sNttNjKlqJwlIHiSSBj31OequCndHRWl7hqC9wbTb7XAjGVJddurWW0gduUd1ZwMDuSBW3V3OioHsjqpmsc/RoJALjpwB48Rw6pOKnmmBdG0kDjjkoJpYoz2/wBtOnJa6MUjRRQhFGadFCEqMYp0UIXS/wBHD/ADP/H0r9EzVOONQf5TO4H8+3+rN1cf0cI/5AZ/4+k/omapxxq/5zG4H8+3+rN1QGyv+Pbp5O/1MU1uP9z0/mPkV1M2zPLtppHHT954X6BFUl47OFc2d+ZudpWJiA8vnvkFlPRhwn/nSQOyFH448FHm7E4uLp+U7A2Jt0lhxTL7Gl23W3E90KTCBSoe8EA1H/C3xG27iN28VCuiGBqeFGSxeLetIKJKFJ5fXJT2La+oUPBRI7EZqCxVlzsVZPfaJu9FG/dkHVriePhpoeTsdVJKuKCsjZRynDnDLT4j9+5VV9Gsrl3s1APH/B939YYraPSfDN928/ok39I1UvbJ8MTmw/Etf7paW1uaLu1ke+ArJyYbvr2VKjKPuGSg+KRjuk1EXpPTm+7ef0Sb+kaqy6O50149IFNXUbt5j48jw/huyD0IOhCYpYJKWyyRSDBDv/oKaPR8HHDbA911nfnpqI96ePPXG2+7Oq9L26xafkQbTPXFZdktvlxSUgYKsOAZ6+AFS36Pgf5N0DPb7qz/AM9NZXW/BBtnuFq+76ku6L0bndJCpUgx7j6tvnOM8qeU4HSogayx0W1VyffoTJGXPDQBnDt7jxHLKcuyq5bdAKN26cDPlhVb/wAZXuKMEac0wCOufVSP/wBtYzgl1A/q7i8cvsptpmVc2LpNebYBCErcTzqCcknGScZNTzuPwGbWaW281ReoKL58Ot1rlTGPW3PmR6xtpSk8w5OoyB0quXo+jniStZPc2ucT/wCEKsqGfZyt2dulRYYOzxG5rsjBPdJHMpic2uiradlY/e7wI96n/wBJz/B1oj8cPfq5r9ejJONt9a/jlr9XFfn0nH8HWiPxw9+rmv16Mn+DfWv45a/VxUL/AOmX+f8A/VOf/PvZ+SmDij4cYG/+h1NshqLqu2pU5ap6+gKj1Uw4f/drx+ScK888rrfaJun9eQ7Zc4jsG4Q7oyxIjPp5VtOJeSFJI8wa6YucTTOk+Kq+7a6mkIYs01uGq0TF4SmPJWwkllZ+Y4T7JPZRx2V0wfF1wufsi3K2680xFzqe3SI5uERpPWfHQ4n2gPF1sD6VJBHcJrZ2N2gqtmeztF4OIJ2B8TuQ3xnGehJwf+12vA5Xm50cdfvVNN67Dhw64/P5hSXxeDPDZuP+LFfpUVSL0dX+cO9+JJn5zVXe4vMf8GzcfHUfcxXX/wCoiqQ+jp68Q734kl/nNVr7I/4Gu3m//Q1erl/e1P7PmVLHpQE5sO3ZIyfhc39G1UeRPSSa7ix2GE6X04UNoS2CfhGcAAfP91SJ6T7rYtu/6XN/RtVQVPxh9NWBsTY7betlqMXCESbhkxnOmXnPAjoEz3asnpbhL2Dt3O7n3BdodjNcS90NqdKapuEdiJMu8UPvMxeb1aCVqThPMScYHiTVKNSekc11adQ3S3s6Z06tqJLejpUsSOZQQ4pIJ/bO+BVtOEA/5N+2/wCLkfpV1ya1x01tqL8Zyv0y6hGxGz1quV5utPVwB7In4aDnQb7xpr0ATrdq2ogpad8TyC4a+OgVldhOMKdB4jrpqLUqI9vsuslsRrmzHKvURXUIS2zIHMScJxhWT8VZ8hU/8e+wqtxdBo1lZ43rdRacaUp9LYyqTB+MtPTuWzlY93OPEVzQxnIPUeINdPuBnfxO6e2/+C93fD2p9PNJYWXTzKlw/itOnPcp+9q+hJPxqk22lofs5U0201nZjsd1j2jgWAboz4Y7h/ynllaFqqRXMkoKk53skHx4n9feoA9H1sKnWWrHtwrsxzWiwu+rtyFj2X5uM8/vDQIP4Sk/NrM+kN38N2uTG19ofzEgLRKvLiD0cfxlpjPkgHnUPnFI+TVm929a6d4Stj3n7HAjQUsc0WzWtHxXJThUsZHcpBKlqPknHiK5L3S6S71cpdwnyFy50t1b8iQ6cqdcUSpSj7ySTWdl4pNsb5JtPVtxDF3YWnqOfszk/wDkdD3UXBzbXSNt8Z77tXH9/vA8V5AMUGn3oq+1DUsU6KVCE1JKVEEYIOCKK3ffHRru3m82utNPN+rXar5MigeaA8rkI9xSUkfTWkUcUJUU6KyhdL/Rw/wBT/x9J/RM1TjjV6cTG4H8+3+rN17tkeL/AFXsPo17TljtFmmxHZjkwu3BDpcC1pSkj2VpGPYHh51GO6W4U/drXV41XdY8aLPui0reZhhQaSQ2lHshRJ7JHcmqmsWzlfQbVV12nA7GUENOcnVzTqOXAqS1dfDNboaZh7zcZ9xXXG2f5v8AFB/+E0/qNcjNrNyL1tLrG06osEj1FwhYPIrPq32yBztODxQodD9RHUCp4jekC13H0ejTgsOnlQkW4W0OFt/1nq/Veq5vvmObHXtjNVgSnkSlI8ABSOxWy1XaGV8V0Y0sncMDIII72Qfes3W4xVJhdTk5YPLXRdodn94LJvdoaDqaxLKWnf2uTEWoFyI+AOdpfvGcg+III71T30no/fvbw/8Ayk39I1VbNjOIHVOwF8m3DTqo8hia16qVb5yVKjvY+IshJBC09cEHsSDkGvXv1xGag4hZdlkX+322Au1NutMi3JcAUHCknm51K+aMYxTBZNgKqwbUMrqcg0rd7BJ7w3mkAEc8E4zzGvVbtXeo6y3mF+khx5aEaq93o+Dnhsg/jWd+emqLcUtxltcRe4qES5CEC8vAJS8oAdE+ANbFs5xmau2S0KxpWyWeyy4TUh6SHpyHi6VOEFQPKsDAx06VEe4OtZm4+t73qi4MsR512lKlvNRgQ0hSsZCeYk46eJNSPZ7Zqut20lwudS0dlNvbuoJ1cDqOWi0a2vhnoYYGE7zcZ9ywxuUxaSlUySpJGCC8sgj7asP6Pz/OUtf4snfoxVcK3jZndu6bI66j6qs0SHNnMx3o6WZwUWilxPKSeVQOR4danV+oZK+01VHTgb8jHNHIZIICaKKZsNTHLJwBBV1fScddutEfjh79Xr9ejKONt9a+f3Za/VxVWd+eKvU/EHZLTa79a7TAZt0lcppduQ6FKUpHIQrnWoYx5UbD8Vep+H6xXW1WK1WmezcZSZbjlwQ6VpUEcmE8i0jGB41VP9kLr/Yr7j3R2+9nG8MY397j5KQ/edP96/a8ncx08MLNcev+c5qM+cWF+rpq1PBFxRp3MsDeitTS86vtjP7mlOq9q4xkjvnxdQMBXzhhXzqoNu/unc959eTtWXeLEhz5bbTS2YQUGgG0BAxzEnqB161rVhv1x0ve4N3tMt2Bc4LyZEaSycLbWk5BH/48RkHoalNbsfHeNm6e1VgDZomNDXcd14aAfNpxg9RrxAWhFczTV76iLVricjqCfmut/Fsc8NG4h87Ur9IiqR+jqOOId78SS/zmq8G4nHhrnczQV40pdLLYGYV0i/BX34rTyXQMpJUnLhSDlPljrUWbJ7z3bYrWi9TWWFCnTVRHIZanhZb5VlJJ9lQOfZHjUXsGyF0t2zFfap2t7WUu3cOBGrWgZPLUJwrLnTz18NQwndbjOnirdek+62Lbz+lzf0bVUGR8YfTUw798T2pOIaJZY9/tlrt6LU466ybclwFRcCQebnWr5oxioeBwc1P9jLVVWSxw0FYAJG72cHI1cSNfIpmutTHV1bpouBx8guv3CD04b9t/xcj9KuuTeuOutdRfjOV+mXU9baceWt9sNEWPS9tsVgkwbQwGGXZTb5cWkKKsq5XAM9T2Aqu12uK7xdZs91KUOy33JC0o+KlS1lRA92TUc2Q2cuFmutyq6toDJnZbg503nnXpoQt2510NVTwRxHVo19wXjzirR+jmVjiDf/Ecv85qquVIGyW8122J1mrUtlhQp81URyH6qeFlvkWUkn2VA59keNTbaOhmuVoqaOnGXvYQM6DJ8U1UMzKepjlfwByVbv0nqj9wtvAe3wuaf/TaqghNTFv5xPak4h4llj362Wu3otTjrjJtyXAVFwJB5udavmjGKh4U2bGWqpsljgoawASN3s4ORq4ka+RWxdamOrq3TRcDj5BIUE06KmyaEhTAJIA6k9AKK3TZTRru4e8Oh9MMo9Yu7XuHEI/kqeTzk+4JCifcKCeaFbr0umyL2h9+IWvokcps+sIqQ84hOEonMJCFg/hNBpQ8yF+VURr+ijiu4erbxNbK3rRkxTcaesCVap7gz8EmIB9U5+CclCvNK1V/PhrTR152+1XdtNaggO2y92qSuLLiOj2m3Enr9IPQgjoQQR0NJRuyML24arC5oFGKdKrykTRmjFOhYSozRinQsopZzRTAoQkKCaDRihYRRmnRQhKnRSrKyjJp0YpULCCadLFOsISJoop4xWVlGaVGKeMVhYS7UZoNGKEJ0iadLFCyiinSxQsIq9fojtkntdb+y9dy45VZ9HxVKacWnKVzn0lttI96Wy6v3Eo86pZo/SF419qm1ac0/Adul6ukhEWJDZGVOuKOAPcO5JPQAEnoK/oN4TOHi38Mmyll0dFU3JuQBl3ac2MfCpqwPWLH8kYCE/yUJ8c0lI7AwvbQpjqnvHrwGW7idsv+E2mUx7VuVb2eRp9z2Gbo0nsw+fBQ+Q54dj7J9m4dFaoJGoSq/mP1fo6+bf6luGntSWqVZL3AcLUmDMbKHG1e8eIPcKGQRggkVh6/ol4h+E7bjibsyYusrKlVxYQUQ73CIZnRfchzBynPyFhSfdnrXMTe70R+6ehZMiXoOXC3Bs4ypDKVph3BCfJTaz6tZ96V5PzRW02QHiki3oqK0q3TWWym4O3khbOp9EahsS0HqZ1seQj6Qvl5SPeDitNKSCQRgjwNKrwlSzT5c0cvShCQop4oxQhKnRijloQlToxijFCEs06MUctCEs0CnijFCEqKeDRihCVFPBox1oQilTIoxQhFLNPGaMUISozTAJOAMk+Vbjo3ZnX+4UhtnTOidQ35xZwkwLY84n6Srl5QPeTijhxWVptZfSekb1rzUcCwadtcq9Xqe4Go0GE2XHXVe4DwHck4AHUkCrpbJeiQ3V15Ijy9dSYe3tnJCltOLTMuCk+SWkHkQfw15HzTXTvh24StuOGOzrjaOsw+6b6AiZfJxD06V7lOYHKnPyEBKfdnrSTpAOC9BpUO8BHAVA4ZLQNU6pEe6blT2Shx1shbNqaV3YZPis/LcHf4qfZ6quPRRWqTnUpXgv/Z" alt="Live Infinity" style="width:32px;height:32px;border-radius:8px;object-fit:cover;border:1px solid rgba(255,208,0,0.4);box-shadow:0 0 12px rgba(255,23,23,0.4);">' +
    '<div style="font-size:13.5px;font-weight:900;letter-spacing:.4px;"><span style="color:#ff1717">LIVE</span> <span style="color:#ffd000">INFINITY</span></div>' +
    '<div style="flex:1"></div>' +
    '<div id="ttlf-status" style="display:flex;align-items:center;font-size:9.5px;font-weight:900;letter-spacing:.4px;padding:3.5px 9px;border-radius:999px;border:1px solid #ff1717;color:#ff3355;background:rgba(255,23,23,.15);margin-right:6px;white-space:nowrap">● INATIVO</div>' +
    '<div id="ttlf-cfg" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,208,0,0.3);background:#141928;color:#ffd000;font-size:13px" data-tip="Minha assinatura / configurações">⚙️</div>' +
    '<div id="ttlf-power" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,208,0,0.35);background:#141928;color:#ffd000;font-size:14px;font-weight:bold" data-tip="Nenhuma LIVE no ar">⏻</div>' +
    '<div id="ttlf-min" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:10px;cursor:pointer;flex:none;border:1px solid rgba(255,23,23,0.35);background:#141928;color:#ff1717;font-size:15px;font-weight:bold" data-tip="Esconder">−</div></div>' +

    /* NOVO CARD DASHBOARD: GMV E VENDAS REALIZADAS EM TEMPO REAL DO TIKTOK SHOP */
    '<div style="display:flex;gap:8px;padding:0 12px 11px">' +
    '<div style="flex:1;background:#03050a;border:1px solid rgba(255,208,0,0.3);border-radius:13px;padding:9px 10px;text-align:center">' +
    '<div style="font-size:9px;color:rgba(255,255,255,0.6);text-transform:uppercase;font-weight:800">VENDAS DA LIVE</div>' +
    '<div id="ttlf-stat-vendas" style="font-size:17px;font-weight:900;color:#ffd000;margin-top:2px">0</div>' +
    '</div>' +
    '<div style="flex:1;background:#03050a;border:1px solid rgba(255,208,0,0.3);border-radius:13px;padding:9px 10px;text-align:center">' +
    '<div style="font-size:9px;color:rgba(255,255,255,0.6);text-transform:uppercase;font-weight:800">GMV ATUAL</div>' +
    '<div id="ttlf-stat-gmv" style="font-size:16px;font-weight:900;color:#ff1717;margin-top:2px">R$ 0,00</div>' +
    '</div>' +
    '</div>' +

    '<div style="display:flex;gap:7px;padding:0 14px 12px">' +
    '<button id="ttlf-on" style="flex:1;padding:9px;border:none;border-radius:12px;background:linear-gradient(135deg,#ffd000 0%,#ff9900 100%);color:#000;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(255,208,0,0.3)">🚀 Ativar tudo</button>' +
    '<button id="ttlf-off" style="flex:1;padding:9px;border:none;border-radius:12px;background:linear-gradient(135deg,#ff1717 0%,#d90000 100%);color:#fff;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(255,23,23,0.3)">🛑 Desativar tudo</button></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9.5v3.5l2.3 2.3"/><path d="M9 2h6"/></svg></b>Timer de Encerramento<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Encerra a LIVE automaticamente no horário definido (sobrevive a F5)</div>' +
    '<div style="text-align:center;color:rgba(255,255,255,0.55);font-size:10px;letter-spacing:2px;font-weight:800">TEMPO RESTANTE</div>' +
    '<div id="rt-restante" style="text-align:center;font-family:monospace;font-size:28px;font-weight:bold;letter-spacing:3px;color:#ffd000;background:#03050a;border:1px solid rgba(255,208,0,0.35);border-radius:14px;padding:10px;margin:4px 0 9px">--:--:--</div>' +

    '<div style="display:flex;gap:4px;margin-bottom:8px">' +
    '<button class="ttlf-preset" data-min="60">1h</button>' +
    '<button class="ttlf-preset" data-min="120">2h</button>' +
    '<button class="ttlf-preset" data-min="240">4h</button>' +
    '<button class="ttlf-preset" data-min="360">6h</button>' +
    '<button class="ttlf-preset" data-min="480">8h</button></div>' +
    '<label>Ou digite manualmente (minutos):</label>' +
    '<input id="rt-min" type="number" min="1" value="120" style="margin:4px 0 8px"/>' +
    '<button id="rt-armar" class="ttlf-go">▶ Iniciar timer</button>' +
    '<div style="display:flex;gap:6px;margin-top:6px">' +
    '<button id="rt-pausa" style="flex:1;padding:6px;border:none;border-radius:8px;background:#ffd000;color:#000;font-weight:bold;cursor:pointer;display:none">⏸ Pausar</button>' +
    '<button id="rt-cancel" style="flex:1;padding:6px;border:none;border-radius:8px;background:#ff1717;color:#fff;font-weight:bold;cursor:pointer;display:none">✖ Cancelar</button></div>' +
    '<div id="rt-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16v6"/><path d="M8 3h8l-1.2 7 3.2 3H4l3.2-3z"/></svg></b>Refixar produto<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Fixa sempre o produto nº 1 e refixa sozinho (desafixa cupom e grupo da LIVE)</div>' +

    /* BOTÕES EXTRAS DE AÇÃO RÁPIDA: FIXAR PRODUTO PRINCIPAL E BLOQUEAR CUPOM DE DESCONTO */
    '<div style="display:flex;gap:6px;margin-bottom:10px">' +
    '<button id="rf-btn-fixar-main" style="flex:1;padding:7px;border:1px solid rgba(255,208,0,0.3);border-radius:8px;background:#141928;color:#ffd000;font-weight:bold;font-size:11px;cursor:pointer">📌 Fixar Principal</button>' +
    '<button id="rf-btn-bloq-cupom" style="flex:1;padding:7px;border:1px solid rgba(255,23,23,0.4);border-radius:8px;background:#141928;color:#ff3355;font-weight:bold;font-size:11px;cursor:pointer">🚫 Bloquear Cupom</button>' +
    '</div>' +

    /* OPÇÃO DE BLOQUEIO OBRIGATÓRIO DE CUPOM */
    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:8px;background:#03050a;padding:8px;border-radius:8px;border:1px solid rgba(255,208,0,0.2)">' +
    '<input id="rf-bloq-cupom-check" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>' +
    '<span style="font-size:11px;color:#fff">Bloqueio Obrigatório de Cupom (Sempre Ignorar Cupom)</span>' +
    '</label>' +

    '<label>Intervalo (segundos):</label>' +
    '<input id="rf-intervalo" type="number" min="10" value="40" style="margin:4px 0 8px"/>' +
    '<button id="rf-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rf-status" class="ttlf-st">Desligado.</div></div></div>' +



    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z"/></svg></b>Oferta relâmpago<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando a Oferta relâmpago da LIVE encerrar, duplica e inicia de novo sozinho</div>' +
    '<button id="rd-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rd-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8 8 0 0 1-8 8H4l2.3-2.7A8 8 0 1 1 21 11.5z"/></svg></b>Comentários automáticos<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Envia seus comentários na LIVE, um por vez, girando a lista</div>' +
    '<label>Comentários (um por linha):</label>' +
    '<textarea id="rc-msgs" rows="4" style="margin:4px 0 8px">Oi, Fiquem à vontade para interagir, conhecer os produtos e tirar suas dúvidas!\n🛒 Toque no carrinho pra garantir a oferta!\n🔥 Frete grátis hoje!\n💥 Últimas unidades com desconto!</textarea>' +
    '<label>Intervalo (segundos):</label>' +
    '<input id="rc-int" type="number" min="10" value="90" style="margin:4px 0 8px"/>' +
    '<button id="rc-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="rc-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 8V5"/><circle cx="12" cy="3.5" r="1.2"/><path d="M9 12.5v2M15 12.5v2"/></svg></b>Respostas automáticas<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém citar a palavra-chave, responde sozinho (nunca responde você mesma)</div>' +
    '<label>Regras (palavras = resposta, uma por linha):</label>' +
    '<textarea id="ra-regras" rows="6" style="margin:4px 0 8px">frete = O frete é grátis! 🚚\ncomprei, finalizei, adquiri = Parabéns pela compra! Volte aqui depois para me dar seu feedback.</textarea>' +
    '<label style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><input id="ra-mencao" type="checkbox" checked style="width:auto;accent-color:#ffd000"/>Mencionar @pessoa na resposta</label>' +
    '<button id="ra-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="ra-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9.5" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/><path d="M3 4h2l2.4 11h10.2L20 8H6.2"/></svg></b>Intenção de compra<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Quando alguém adiciona o produto ao carrinho, menciona a pessoa (@nome) no chat com sua frase pronta</div>' +
    '<label>Frase quando ADICIONAR ao carrinho:</label>' +
    '<textarea id="ic-cart" rows="2" style="margin:4px 0 8px">garante o seu, finaliza a compra! 🛒</textarea>' +
    '<button id="ic-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="ic-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M5.7 5.7l12.6 12.6"/></svg></b>Bloqueio por Nome<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Bloqueia automaticamente quem ENTRA na LIVE com palavras suspeitas no nome (painel Atividade)</div>' +
    '<label>Palavras suspeitas (uma por linha):</label>' +
    '<textarea id="bn-palavras" rows="4" style="margin:4px 0 8px">recomenda\nachadinhos\nindica</textarea>' +
    '<button id="bn-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="bn-status" class="ttlf-st">Desligado.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5.2c0 4.8-3.4 8.3-7 9.8-3.6-1.5-7-5-7-9.8V6z"/></svg></b>Proteção Contra Violação<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Encerra a LIVE sozinho ao detectar aviso/violação do TikTok na tela (Liga automaticamente ao iniciar LIVE)</div>' +
    '<input id="rv-ativo" type="checkbox" style="display:none"/>' +
    '<button id="rv-botao" class="ttlf-go" style="margin-bottom:8px">▶ Ativar proteção</button>' +
    '<label>Esperar antes de encerrar (segundos, 0 = na hora):</label>' +
    '<input id="rv-delay" type="number" min="0" value="0" style="margin:4px 0 8px"/>' +
    '<div id="rv-status" class="ttlf-st">Inativa.</div></div></div>' +

    '<div class="ttlf-sec"><div class="ttlf-sec-h"><b class="ttlf-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.5 20a2 2 0 0 0 3 0"/></svg></b>Alerta de vendas (celular)<span>▾</span></div><div class="ttlf-sec-b">' +
    '<div class="ttlf-desc">Saiu venda na LIVE → notificação no seu celular via app gratuito ntfy (instale o app "ntfy" e inscreva-se no seu canal)</div>' +
    '<label>Nome do canal ntfy:</label>' +
    '<input id="nv-canal" placeholder="ex: liveinfinity-vendas-8k" style="margin:4px 0 8px" autocomplete="off" spellcheck="false"/>' +
    '<button id="nv-teste" style="width:100%;padding:8px;border:1px solid rgba(255,208,0,0.3);border-radius:11px;background:#141928;color:#ffd000;font-weight:700;cursor:pointer;margin-bottom:8px">Enviar teste pro celular</button>' +
    '<button id="nv-botao" class="ttlf-go">▶ Iniciar</button>' +
    '<div id="nv-status" class="ttlf-st">Desligado.</div></div></div>';

  document.body.appendChild(d);
  ttlfPersist(d);

  Array.prototype.slice.call(d.querySelectorAll('.ttlf-sec-h')).forEach(function (h) {
    h.addEventListener('click', function () {
      var b = h.nextElementSibling;
      var fechado = b.style.display === 'none';
      b.style.display = fechado ? 'block' : 'none';
      h.querySelector('span').textContent = fechado ? '▾' : '▸';
    });
  });

  // BIND DO BOTÃO ATIVAR TUDO E DESATIVAR TUDO
  document.getElementById('ttlf-on').addEventListener('click', function () {
    ['rf-botao', 'rd-botao', 'rc-botao', 'ra-botao', 'bn-botao', 'ic-botao', 'nv-botao'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b && (b.textContent.indexOf('▶') >= 0 || b.textContent.indexOf('Iniciar') >= 0)) { b.click(); }
    });
    var cv = document.getElementById('rv-ativo');
    if (cv && !cv.checked) {
      var bRv = document.getElementById('rv-botao');
      if (bRv) bRv.click();
    }
    var bRt = document.getElementById('rt-armar');
    if (bRt && bRt.style.display !== 'none') { bRt.click(); }
  });

  document.getElementById('ttlf-off').addEventListener('click', function () {
    ['rf-botao', 'rd-botao', 'rc-botao', 'ra-botao', 'bn-botao', 'ic-botao', 'nv-botao'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b && (b.textContent.indexOf('⏸') >= 0 || b.textContent.indexOf('Parar') >= 0)) { b.click(); }
    });
    var cv = document.getElementById('rv-ativo');
    if (cv && cv.checked) {
      var bRv = document.getElementById('rv-botao');
      if (bRv) bRv.click();
    }
    var bRtCan = document.getElementById('rt-cancel');
    if (bRtCan && bRtCan.style.display !== 'none') { bRtCan.click(); }
  });

  var ttlfMini = false;
  document.getElementById('ttlf-min').addEventListener('click', function () {
    ttlfMini = !ttlfMini;
    var mb = document.getElementById('ttlf-min');
    var topo = document.getElementById('ttlf-top');
    var linhaBtns = topo ? topo.children[1] : null;
    Array.prototype.slice.call(d.children).forEach(function (k) {
      if (k.id === 'ttlf-top') { return; }
      if (ttlfMini) { try { k.setAttribute('data-mini', '1'); } catch (e) {} k.style.display = 'none'; }
      else if (k.getAttribute && k.getAttribute('data-mini')) { k.style.display = ''; k.removeAttribute('data-mini'); }
    });
    if (linhaBtns) { linhaBtns.style.display = ttlfMini ? 'none' : 'flex'; }
    if (topo) { topo.style.borderRadius = ttlfMini ? '18px' : '18px 18px 0 0'; }
    d.style.maxHeight = ttlfMini ? 'none' : '84vh';
    d.style.overflow = ttlfMini ? 'visible' : 'auto';
    mb.textContent = ttlfMini ? '+' : '−';
  });

  var _cfgBtn = document.getElementById('ttlf-cfg'); if (_cfgBtn) { _cfgBtn.addEventListener('click', ttlfCfgPanel); }

  var bolha = document.createElement('div');
  bolha.id = 'ttlf-bolha';
  bolha.title = 'Live Infinity';
  bolha.style.cssText = 'position:fixed;top:64px;right:12px;z-index:999998;width:52px;height:52px;background:#070a12;border:2px solid #ffd000;border-radius:50%;box-shadow:0 10px 25px rgba(0,0,0,.9);display:none;align-items:center;justify-content:center;cursor:pointer;font-size:22px';
  bolha.innerHTML = '♾️';
  document.body.appendChild(bolha);

  ttlfDrag(d, document.getElementById('ttlf-head'), 'ttlf-pos-hub', null);
  ttlfDrag(bolha, bolha, 'ttlf-pos-bolha', function () { d.style.display = 'block'; bolha.style.display = 'none'; });
}

function ttlfInit() {
  if (!document.body) { setTimeout(ttlfInit, 1500); return; }
  if (document.getElementById('ttlf-hub')) { return; }
  ttlfBuildHub();

  /* ===== 1. REFIXAÇÃO COM BLOQUEIO OBRIGATÓRIO DE CUPOM ===== */
  (function () {
    'use strict';
    if (window.rfTimer) clearInterval(window.rfTimer); var PAD = 20; var rodando = false;
    function tb() { return Array.prototype.slice.call(document.querySelectorAll('button, [role="button"]')).filter(function (b) { var t = (b.textContent || '').trim(); return t === 'Fixar' || t === 'Desafixar'; }); }
    function ehProduto(b) { var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) break; var t = el.textContent || ''; if (t.indexOf('Lista de produtos nesta LIVE') > -1) return false; if (t.length > 600) return false; if (t.indexOf('Em estoque') > -1 || t.indexOf('Quantidade') > -1) return true; } return false; }
    function ehCupom(b) {
      var bloqCheck = document.getElementById('rf-bloq-cupom-check');
      if (bloqCheck && !bloqCheck.checked) return false;
      var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) break; var t = el.textContent || ''; if (t.indexOf('Em estoque') > -1 || t.indexOf('Quantidade') > -1) return false; if (/cupom|desconto|gasto m/i.test(t)) return true; } return false;
    }
    function st(m) { var e = document.getElementById('rf-status'); if (e) e.textContent = m; }
    function ciclo() { var bs = tb(); var prods = bs.filter(function (b) { return ehProduto(b) && !ehCupom(b); }); if (prods.length === 0) { st('Nenhum produto principal encontrado.'); return; } var alvo = prods[0]; var outros = bs.filter(function (b) { return b.textContent.trim() === 'Desafixar' && b !== alvo; }); if (outros.length > 0) { st('Removendo cupom/fixação extra...'); outros[0].click(); setTimeout(ciclo, 700); return; } if (alvo.textContent.trim() === 'Fixar') { alvo.click(); st('Produto nº 1 fixado ✅ ' + new Date().toLocaleTimeString()); setTimeout(confere, 2000); return; } alvo.click(); st('Refixando...'); setTimeout(ciclo, 600); }
    function confere() { var bs = tb(); var fx = bs.filter(function (b) { return b.textContent.trim() === 'Desafixar'; }); var prodFixado = fx.some(function (b) { return ehProduto(b) && !ehCupom(b); }); var intruso = fx.some(function (b) { return !(ehProduto(b) && !ehCupom(b)); }); if (!prodFixado || intruso) { st('Removendo cupom/intruso...'); setTimeout(ciclo, 300); } }
    function liga() { var s = Math.max(10, parseInt(document.getElementById('rf-intervalo').value, 10) || PAD); rodando = true; ciclo(); window.rfTimer = setInterval(ciclo, s * 1000); var b = document.getElementById('rf-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; }
    function desliga() { rodando = false; clearInterval(window.rfTimer); var b = document.getElementById('rf-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    
    var btnRf = document.getElementById('rf-botao');
    if (btnRf) btnRf.addEventListener('click', function () { rodando ? desliga() : liga(); });

    var btnFixMain = document.getElementById('rf-btn-fixar-main');
    if (btnFixMain) {
      btnFixMain.addEventListener('click', function () {
        st('Fixando produto principal...');
        ciclo();
      });
    }
    var btnBloqCupom = document.getElementById('rf-btn-bloq-cupom');
    if (btnBloqCupom) {
      btnBloqCupom.addEventListener('click', function () {
        st('Desafixando qualquer cupom ativo...');
        var bs = tb();
        var cuponsFixados = bs.filter(function (b) { return b.textContent.trim() === 'Desafixar' && ehCupom(b); });
        if (cuponsFixados.length > 0) {
          cuponsFixados[0].click();
          st('Cupom removido ✅');
        } else {
          st('Nenhum cupom fixado no momento.');
        }
      });
    }
  })();

  /* ===== 2. MÓDULO DE MÍDIA OPTIMIZADO (ÁUDIO LIMPO SEM PICOTAR) ===== */
  (function () {
    'use strict';
    var rodando = false;
    function st(m) { var e = document.getElementById('md-status'); if (e) e.textContent = m; }
    
    function regAudioHist(nome) {
      var item = '[' + ttlfNow() + '] Camada Disparada: ' + nome;
      window.ttlfAudioHistory.push(item);
      if (window.ttlfAudioHistory.length > 40) window.ttlfAudioHistory.shift();
      var box = document.getElementById('md-hist-box');
      if (box) {
        box.textContent = window.ttlfAudioHistory.join('\n');
        box.scrollTop = box.scrollHeight;
      }
      ttlfLog('📻 ' + item);
    }

    // CORREÇÃO CRÍTICA DE PICOTAMENTO: FECHA OS CONTEXTOS DE ÁUDIO APÓS A EXECUÇÃO E REUTILIZA O BUFFER PARA NÃO SOBRECARREGAR A CPU/MEMÓRIA
    function playSyntheticSound(type) {
      try {
        var AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        var ctx = new AudioCtx({ latencyHint: 'playback' });
        var volSlider = document.getElementById('md-volume-slider');
        var masterVol = (volSlider ? parseFloat(volSlider.value) : 80) / 100;

        var gain = ctx.createGain();
        gain.gain.value = masterVol;
        gain.connect(ctx.destination);

        var dur = 0.3;
        if (type === 'caixa') {
          dur = 0.4;
          var osc1 = ctx.createOscillator();
          osc1.type = 'sine';
          osc1.frequency.setValueAtTime(987.77, ctx.currentTime);
          osc1.connect(gain);
          osc1.start();
          osc1.stop(ctx.currentTime + 0.1);

          setTimeout(function() {
            try {
              var osc2 = ctx.createOscillator();
              osc2.type = 'sine';
              osc2.frequency.setValueAtTime(1318.51, ctx.currentTime);
              osc2.connect(gain);
              osc2.start();
              osc2.stop(ctx.currentTime + 0.3);
            } catch(e) {}
          }, 100);
        } else if (type === 'aplausos') {
          dur = 0.5;
          var bufferSize = ctx.sampleRate * 0.4;
          var buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          var data = buffer.getChannelData(0);
          for (var i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }
          var noise = ctx.createBufferSource();
          noise.buffer = buffer;
          noise.connect(gain);
          noise.start();
        } else if (type === 'risadas' || type === 'vinheta') {
          dur = 0.3;
          var osc = ctx.createOscillator();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(523.25, ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.25);
          osc.connect(gain);
          osc.start();
          osc.stop(ctx.currentTime + 0.25);
        }

        // LIMPEZA AUTOMÁTICA DO CONTEXTO PARA NUNCA PICOTAR O VÍDEO NATIVO DO TIKTOK
        setTimeout(function () {
          try { if (ctx && ctx.state !== 'closed') ctx.close(); } catch (e) {}
        }, (dur + 0.2) * 1000);

      } catch (e) {}
    }

    var btnVc = document.getElementById('md-vcable-btn');
    var selVc = document.getElementById('md-vcable-select');
    if (btnVc) {
      btnVc.addEventListener('click', function () {
        rodando = !rodando;
        var dev = selVc ? selVc.value : 'vcable';
        if (rodando) {
          btnVc.textContent = '⏸ Parar Roteamento';
          btnVc.style.background = '#ff1717';
          st('🟢 Roteamento VB-CABLE ATIVO (' + dev + ') ✅');
          regAudioHist('Roteamento VB-CABLE Iniciado');
        } else {
          btnVc.textContent = '▶ Iniciar Roteamento VB-CABLE';
          btnVc.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)';
          btnVc.style.color = '#000';
          st('Desativado. Áudio padrão do sistema.');
          regAudioHist('Roteamento VB-CABLE Parado');
        }
      });
    }

    Array.prototype.slice.call(document.querySelectorAll('.md-fx-btn')).forEach(function (b) {
      b.addEventListener('click', function () {
        var fx = b.getAttribute('data-fx');
        var nomes = { caixa: '🔔 Som de Venda / Caixa', aplausos: '👏 Efeito Aplausos', risadas: '😂 Efeito Risadas', vinheta: '⚡ Efeito Vinheta / Alerta' };
        playSyntheticSound(fx);
        regAudioHist(nomes[fx] || fx);
      });
    });

    var histClear = document.getElementById('md-hist-clear');
    if (histClear) {
      histClear.addEventListener('click', function () {
        window.ttlfAudioHistory = [];
        var box = document.getElementById('md-hist-box');
        if (box) box.textContent = 'Nenhum trecho disparado ainda.';
      });
    }
  })();

  /* ===== 3. COMENTÁRIOS AUTOMÁTICOS ===== */
  (function () {
    'use strict';
    if (window.rcTimer) { clearInterval(window.rcTimer); }
    var idx = 0; var rodando = false;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'rc-painel') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rc-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { st('Caixa de comentário não encontrada — a LIVE está no ar?'); return; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"]').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 60 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } else { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); }); } setTimeout(function () { if (ta.value === '') { st('Enviado ✅ "' + msg.slice(0, 28) + '" ' + new Date().toLocaleTimeString()); } else { st('⚠️ ENVIO FALHOU'); } }, 900); }, 400); }
    function proximo() { var linhas = document.getElementById('rc-msgs').value.split('\n').map(function (t) { return t.trim(); }).filter(function (t) { return t.length > 0; }); if (!linhas.length) { st('Escreva pelo menos 1 comentário na lista.'); return; } if (idx >= linhas.length) { idx = 0; } var mtx = linhas[idx]; if (mtx.length > 100) { mtx = mtx.slice(0, 97) + '...'; } enviar(mtx); idx = idx + 1; }
    function liga() { var s = parseInt(document.getElementById('rc-int').value, 10) || 60; if (s < 10) { s = 10; document.getElementById('rc-int').value = 10; } rodando = true; proximo(); window.rcTimer = setInterval(proximo, s * 1000); var b = document.getElementById('rc-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; }
    function desliga() { rodando = false; clearInterval(window.rcTimer); var b = document.getElementById('rc-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    document.getElementById('rc-botao').addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); } });
  })();

  /* ===== 4. RESPOSTAS AUTOMÁTICAS NO CHAT ===== */
  (function () {
    'use strict';
    if (window.raVarre) { clearInterval(window.raVarre); }
    if (window.raFila) { clearInterval(window.raFila); }
    var rodando = false; var vistos = new Map(); var vistoEm = new Map(); var fila = []; var ultimoEnvio = 0; var enviados = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ra-painel') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('ra-status'); if (e) { e.textContent = m; } }
    function norm(t) { return (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { st('Caixa de comentário não encontrada.'); return; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"]').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 60 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } else { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); }); } setTimeout(function () { if (ta.value === '') { enviados = enviados + 1; st('Respondido ✅ (' + enviados + ' no total) ' + new Date().toLocaleTimeString()); } else { st('⚠️ ENVIO FALHOU'); } }, 900); }, 400); }
    function itensComentario() { var ta = $s('textarea').filter(function (t) { var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph) && vis(t) && fora(t); })[0]; var painel = document; if (ta) { var pp = ta; for (var k = 0; k < 10 && pp; k++) { pp = pp.parentElement; if (!pp) { break; } if ($s('img', pp).length >= 1 && pp.getBoundingClientRect().height > 200) { painel = pp; } } } var rows = $s('[class*="cursor-pointer"],[class*="rounded"]', painel).filter(function (el) { if (!vis(el) || !fora(el)) { return false; } var imgs = $s('img', el).filter(function (im) { var r = im.getBoundingClientRect(); return r.width >= 14 && r.width <= 56; }); if (imgs.length !== 1) { return false; } var lv = $s('div,span', el).filter(function (x) { return x.children.length === 0 && (x.textContent || '').trim(); }); var txts = lv.map(function (x) { return x.textContent.trim(); }).filter(function (t) { return t !== 'Host' && t !== 'Anfitrião'; }); if (txts.length < 2) { return false; } var full = (el.textContent || '').trim(); if (/está vendo o produto|acabou de|entrou na|pedidos feitos|aparecer[aã]o aqui|Alternar modo|Console de LIVE/i.test(full)) { return false; } return full.length > 0 && full.length < 400; }); rows = rows.filter(function (el) { return !rows.some(function (o) { return o !== el && el.contains(o); }); }); var groups = new Map(); rows.forEach(function (el) { var pr = el.parentElement; if (!groups.has(pr)) { groups.set(pr, []); } groups.get(pr).push(el); }); var best = []; groups.forEach(function (v) { if (v.length > best.length) { best = v; } }); if (!best.length) { best = rows; } return best.map(function (row) { var lv = $s('div,span', row).filter(function (x) { return x.children.length === 0 && (x.textContent || '').trim(); }); var host = false, textos = []; for (var i2 = 0; i2 < lv.length; i2++) { var t = lv[i2].textContent.trim(); if (t === 'Host' || t === 'Anfitrião') { host = true; continue; } textos.push(t); } return { el: row, autor: textos.length ? textos[0] : '', texto: textos.length ? textos[textos.length - 1] : '', host: host }; }); }
    function regras() { var linhas = document.getElementById('ra-regras').value.split('\n'); var rs = []; for (var i = 0; i < linhas.length; i++) { var linha = linhas[i].replace('=>', '='); var ix = linha.indexOf('='); if (ix < 0) { continue; } var chaves = linha.slice(0, ix).split(',').map(norm).filter(function (c) { return c.length > 0; }); var resp = linha.slice(ix + 1).trim(); if (chaves.length && resp) { rs.push({ chaves: chaves, resp: resp }); } } return rs; }
    function marcarTudoVisto() { var agora = Date.now(); itensComentario().forEach(function (c) { var chave = c.autor + '|' + c.texto; try { c.el.dataset.raVisto = chave; } catch (e) {} vistos.set(chave, agora); }); }
    function varre() { if (!rodando) { return; } var rs = regras(); var mencionar = document.getElementById('ra-mencao').checked; var agora = Date.now(); var itens = itensComentario(); var cont = {}; itens.forEach(function (c) { var k = c.autor + '|' + c.texto; cont[k] = (cont[k] || 0) + 1; }); itens.forEach(function (c) { var chave = c.autor + '|' + c.texto; var vistoAntes = vistoEm.get(chave) || 0; vistoEm.set(chave, agora); if (c.el.dataset && c.el.dataset.raVisto === chave) { return; } try { c.el.dataset.raVisto = chave; } catch (e) {} if (c.host) { return; } if (vistos.has(chave)) { var repetido = cont[chave] >= 2; var passou15s = agora - vistos.get(chave) > 15000; if (!(repetido && passou15s)) { return; } } var tn = norm(c.texto); for (var i = 0; i < rs.length; i++) { var bate = rs[i].chaves.some(function (k) { return tn.indexOf(k) > -1; }); if (bate) { vistos.set(chave, agora); var resp = (mencionar && c.autor ? ('@' + c.autor + ' ') : '') + rs[i].resp; if (resp.length > 100) { resp = rs[i].resp; } if (resp.length > 100) { resp = resp.slice(0, 97) + '...'; } fila.push(resp); break; } } }); }
    function processaFila() { if (!rodando || !fila.length) { return; } var agora = Date.now(); if (agora - ultimoEnvio < 5000) { return; } ultimoEnvio = agora; enviar(fila.shift()); }
    function liga() { if (!regras().length) { st('Cadastre pelo menos 1 regra (palavra = resposta).'); return; } marcarTudoVisto(); rodando = true; var b = document.getElementById('ra-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando comentários... 👀'); }
    function desliga() { rodando = false; fila = []; var b = document.getElementById('ra-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    document.getElementById('ra-botao').addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); } });
    window.raVarre = setInterval(varre, 2000);
    window.raFila = setInterval(processaFila, 1000);
  })();

  /* ===== 5. BLOQUEIO POR NOME (HATERS) ===== */
  (function () {
    'use strict';
    if (window.bnTimer) { clearInterval(window.bnTimer); }
    var rodando = false; var tratados = {};
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function norm(x) { return (x || '').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); }
    function palavras() { var e = document.getElementById('bn-palavras'); if (!e) { return []; } return e.value.split('\n').map(function (x) { return norm(x); }).filter(function (x) { return x.length > 0; }); }
    function st(m) { var e = document.getElementById('bn-status'); if (e) { e.textContent = m; } }
    function disparar(el, tipos) { tipos.forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function clicar(el) { if (!el) { return; } try { el.scrollIntoView({ block: 'center' }); } catch (e) {} disparar(el, ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']); }
    function hover(el) { disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']); }
    function entradas() { var res = []; var vistos = []; $s('div,span,p').filter(function (x) { return vis(x) && fora(x) && x.children.length <= 4 && /acabou de entrar/i.test(x.textContent || '') && (x.textContent || '').length < 160; }).forEach(function (mk) { var row = mk; while (row.parentElement && /acabou de entrar/i.test(row.parentElement.textContent || '') && (row.parentElement.textContent || '').length < 160) { row = row.parentElement; } if (vistos.indexOf(row) > -1) { return; } vistos.push(row); var full = (row.textContent || '').replace(/\s+/g, ' ').trim(); var nome = full.replace(/\s*acabou de entrar.*/i, '').trim(); if (nome) { res.push({ row: row, nome: nome }); } }); return res; }
    function acharBloquear() { return $s('div,span,button,a,li').filter(function (x) { if (!vis(x) || x.children.length > 2) { return false; } var t = norm(x.textContent); return t.indexOf('bloquear') === 0; })[0]; }
    function maisBotoes(row) { var cs = $s('button,[role="button"],div,span,svg', row).filter(function (x) { if (!vis(x)) { return false; } var t = (x.textContent || '').trim(); return t.length <= 3; }); cs.sort(function (a, b) { return b.getBoundingClientRect().right - a.getBoundingClientRect().right; }); return cs.slice(0, 6); }
    function bloquear(item) { hover(item.row); setTimeout(function () { var mais = maisBotoes(item.row); var i = 0; (function tenta() { if (i >= mais.length) { st('Detectei "' + item.nome + '" mas não achei o botão "..."'); return; } clicar(mais[i]); i++; setTimeout(function () { var bl = acharBloquear(); if (bl) { clicar(bl); setTimeout(function () { var conf = $s('button,div,span,a').filter(function (x) { if (!vis(x) || x.children.length > 1) { return false; } var t = norm((x.textContent || '').trim()); return t === 'confirmar' || t === 'confirm' || t === 'sim' || t === 'ok'; })[0]; if (conf) { clicar(conf); } st('🚫 Bloqueado: ' + item.nome + ' (' + new Date().toLocaleTimeString() + ')'); }, 550); } else { tenta(); } }, 350); })(); }, 300); }
    function varre() { if (!rodando) { return; } var ps = palavras(); if (!ps.length) { return; } entradas().forEach(function (it) { var nn = norm(it.nome); if (!nn || tratados[nn]) { return; } if (ps.some(function (pw) { return nn.indexOf(pw) > -1; })) { tratados[nn] = 1; bloquear(it); } }); }
    function liga() { if (!palavras().length) { st('Cadastre pelo menos 1 palavra suspeita.'); return; } rodando = true; var b = document.getElementById('bn-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando entradas... 👀'); }
    function desliga() { rodando = false; var b = document.getElementById('bn-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var bb = document.getElementById('bn-botao'); if (bb) { bb.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    window.bnTimer = setInterval(varre, 3000);
  })();

  /* ===== 6. INTENÇÃO DE COMPRA ===== */
  (function () {
    'use strict';
    if (window.icTimer) { clearInterval(window.icTimer); }
    var rodando = false; var feitos = {}; var fila = []; var ocupado = false; var pendentes = []; var ultimoEnvio = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function st(m) { var e = document.getElementById('ic-status'); if (e) { e.textContent = m; } }
    function disparar(el, tipos) { tipos.forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function hover(el) { disparar(el, ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']); }
    function unhover(el) { disparar(el, ['mouseout', 'mouseleave', 'pointerout', 'pointerleave']); }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } disparar(el, ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']); }
    function acharCaixa() { var tas = $s('textarea').filter(function (t) { if (!vis(t) || !fora(t)) { return false; } var ph = t.getAttribute('placeholder') || ''; return /Digite|Diga|Say|coment|chat/i.test(ph); }); if (tas.length) { return tas[0]; } tas = $s('textarea.arco-textarea').filter(function (t) { return vis(t) && fora(t); }); return tas.length ? tas[0] : null; }
    function enviar(msg) { var ta = acharCaixa(); if (!ta) { return false; } var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set; ta.focus(); setter.call(ta, msg); ta.dispatchEvent(new Event('input', { bubbles: true })); setTimeout(function () { var tr = ta.getBoundingClientRect(); var sv = $s('svg,button,[role="button"],span').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } var r = b.getBoundingClientRect(); var cy = r.top + r.height / 2, ty = tr.top + tr.height / 2; if (((b.textContent || '').trim()) !== '') { return false; } return Math.abs(cy - ty) < 44 && r.left > tr.left - 6 && r.left < tr.right + 72 && r.width <= 40 && getComputedStyle(b).cursor === 'pointer'; }); if (sv.length) { sv.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); clicar(sv[sv.length - 1]); } setTimeout(function () { if (ta.value !== '') { ['keydown', 'keypress', 'keyup'].forEach(function (tp) { ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); }); } }, 250); }, 350); return true; }
    function achaAvatar(row) { var im = $s('img', row).filter(function (x) { return vis(x); }); if (im.length) { return im[0]; } var cs = $s('div,span', row).filter(function (x) { var r = x.getBoundingClientRect(); return vis(x) && r.width >= 16 && r.width <= 54 && r.height >= 16 && r.height <= 54; }); cs.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cs.length ? cs[0] : null; }
    function realVis(e) { try { var cs = getComputedStyle(e); if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.3) { return false; } var an = e.parentElement, k = 0; while (an && k < 8) { var c2 = getComputedStyle(an); if (c2.visibility === 'hidden' || c2.display === 'none' || parseFloat(c2.opacity) < 0.3) { return false; } an = an.parentElement; k++; } return true; } catch (_) { return false; } }
    function sobresReais() { var a = []; $s('div,span,p,h1,h2,h3,b,strong').forEach(function (e) { if (e.children.length > 3) { return; } var t = (e.textContent || '').trim(); var m = t.match(/^Sobre\s+(.{2,40})$/i); if (!m) { return; } if (!realVis(e)) { return; } var n = m[1].replace(/\s*[ⓘℹ️①(].*$/, '').trim(); if (n) { a.push(n); } }); return a; }
    function nomePopover(antes) { var depois = sobresReais(); var novos = depois.filter(function (n) { return antes.indexOf(n) < 0; }); if (novos.length) { return novos[0]; } return depois.length ? depois[0] : null; }
    function eventos() { var res = []; var vistos = []; $s('div,span,p').filter(function (x) { if (!vis(x) || !fora(x) || x.children.length !== 0) { return false; } var t = (x.textContent || '').trim(); if (t.length > 60) { return false; } return /adicionou o produto/i.test(t) && /carrinho/i.test(t); }).forEach(function (mk) { var row = mk; for (var i = 0; i < 6 && row.parentElement; i++) { row = row.parentElement; if (row.querySelector('img')) { break; } } if (vistos.indexOf(row) > -1) { return; } vistos.push(row); var t = (mk.textContent || ''); res.push({ row: row, tipo: /est[aá] vendo/i.test(t) ? 'ver' : 'cart' }); }); return res; }
    function processa() { if (ocupado || !rodando || !fila.length) { return; } ocupado = true; var it = fila.shift(); var av = achaAvatar(it.row); if (!av) { ocupado = false; return; } var antes = sobresReais(); function limpaHover() { unhover(av); var _pp = av; for (var _i = 0; _i < 4 && _pp; _i++) { unhover(_pp); _pp = _pp.parentElement; } try { document.body.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: 4, clientY: 4, view: window })); } catch (e) {} } function finaliza(nome) { limpaHover(); if (!nome) { st('Vi um evento mas não peguei o nome.'); setTimeout(function () { ocupado = false; }, 300); return; } var chave = 'cart|' + nome; if (feitos[chave]) { ocupado = false; return; } feitos[chave] = 1; var base = (document.getElementById('ic-cart') || { value: '' }).value || ''; base = base.trim(); if (!base) { ocupado = false; return; } var msg = '@' + nome + ' ' + base; if (msg.length > 100) { msg = msg.slice(0, 100); } pendentes.push({ texto: msg, label: 'Carrinho: @' + nome }); st('🛒 Carrinho: @' + nome + ' — na fila de envio'); setTimeout(function () { ocupado = false; }, 400); } var tent = 0; function tenta() { tent++; hover(av); setTimeout(function () { var nome = nomePopover(antes); if (nome) { finaliza(nome); return; } if (tent >= 7) { finaliza(null); return; } tenta(); }, 280); } tenta(); }
    function varre() { if (!rodando) { return; } try { var evs = eventos(); evs.forEach(function (ev) { if (ev.row.dataset && ev.row.dataset.icQ) { return; } try { ev.row.dataset.icQ = '1'; } catch (e) {} fila.push(ev); }); if (!ocupado && !fila.length && !pendentes.length) { st('Monitorando Intenção de compra... 👀'); } } catch (err) { st('erro varre: ' + ((err && err.message) || err)); } }
    function enviaPendentes() { if (!rodando || !pendentes.length) { return; } var agora = Date.now(); if (agora - ultimoEnvio < 4000) { return; } ultimoEnvio = agora; var item = pendentes.shift(); var ok = enviar(item.texto); st(ok ? ('💬 ' + item.label + ' — enviado (' + new Date().toLocaleTimeString() + ')') : ('Fila cheia — caixa não encontrada.')); }
    function liga() { rodando = true; var b = document.getElementById('ic-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando intenção de compra... 👀'); }
    function desliga() { rodando = false; fila = []; pendentes = []; ocupado = false; var b = document.getElementById('ic-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var bb = document.getElementById('ic-botao'); if (bb) { bb.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    window.icTimer = setInterval(function () { varre(); processa(); enviaPendentes(); }, 1200);
  })();

  /* ===== 7. ALERTA DE VENDAS NTFY ===== */
  (function () {
    'use strict';
    if (window.nvTimer) { clearInterval(window.nvTimer); }
    var rodando = false; var fila = []; var ultimo = 0; var total = 0;
    var RE = /(fez um pedido|realizou (um |o )?pedido|acabou de comprar|comprou|compraram|pagamento (confirmado|efetuado)|efetuou o pagamento|pedido pago|pagou o pedido|criou (um|o) pedido|placed an order)/i;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var q = el; while (q) { if (q.id === 'ttlf-hub' || q.id === 'ttlf-bolha') { return false; } q = q.parentElement; } return true; }
    function st(m) { var e = document.getElementById('nv-status'); if (e) { e.textContent = m; } }
    function canal() { var e = document.getElementById('nv-canal'); return e ? (e.value || '').trim() : ''; }
    function manda(titulo, corpo, tags, cb) { var c = canal(); if (!c) { if (cb) { cb(false); } return; } function direto() { try { fetch('https://ntfy.sh', { method: 'POST', body: JSON.stringify({ topic: c, title: titulo, message: corpo, tags: (tags || 'bell').split(','), priority: 5 }) }).then(function (r) { if (cb) { cb(r.ok); } }).catch(function () { if (cb) { cb(false); } }); } catch (e) { if (cb) { cb(false); } } } try { if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) { chrome.runtime.sendMessage({ type: 'ttlf-ntfy', canal: c, titulo: titulo, corpo: corpo, tags: tags || 'bell' }, function (resp) { if (chrome.runtime.lastError || !resp || !resp.ok) { direto(); } else { if (cb) { cb(true); } } }); return; } } catch (e) {} direto(); }
    function contaVendas(t) { return (String(t).match(/comprou o produto|acabou de comprar|fez um pedido|realizou (um |o )?pedido|placed an order/gi) || []).length; }
    function eventosVenda() { var res = []; var singles = $s('div,span,p').filter(function (x) { if (!vis(x) || !fora(x)) { return false; } var t = (x.textContent || '').trim(); if (!t || t.length > 90) { return false; } return contaVendas(t) === 1 && RE.test(t) && /R\$\s?\d/.test(t); }); singles.forEach(function (x) { for (var j = 0; j < singles.length; j++) { if (singles[j] !== x && x.contains(singles[j])) { return; } } res.push({ el: x, txt: (x.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 90) }); }); return res; }
    function marcarVistos() { eventosVenda().forEach(function (ev) { try { ev.el.dataset.nvQ = '1'; } catch (e) {} }); }
    function dlog(t) { try { var arr = []; try { arr = JSON.parse(localStorage.getItem('ttlf-nv-debug') || '[]'); } catch (e) {} arr.push(new Date().toTimeString().slice(0, 8) + ' ' + t); if (arr.length > 80) { arr = arr.slice(-80); } localStorage.setItem('ttlf-nv-debug', JSON.stringify(arr)); } catch (e) {} try { ttlfLog('[VendaDbg] ' + t); } catch (e) {} }
    function debugScan() { try { $s('div,span,p').forEach(function (x) { if (x.children.length > 3) { return; } if (!vis(x) || !fora(x)) { return; } var t = (x.textContent || '').trim(); if (!t || t.length > 160) { return; } if (!/(compr|pedido|pagou)/i.test(t)) { return; } if (x.dataset && x.dataset.nvDbg) { return; } try { x.dataset.nvDbg = '1'; } catch (e) {} dlog(t); }); } catch (e) {} }
    function varre() { if (!rodando) { return; } try { var agora = Date.now(); eventosVenda().forEach(function (ev) { if (ev.el.dataset && ev.el.dataset.nvQ) { return; } try { ev.el.dataset.nvQ = '1'; } catch (e) {} dlog('DETECTOU VENDA: ' + ev.txt); fila.push(ev.txt); }); } catch (err) { st('erro: ' + ((err && err.message) || err)); } }
    function corpoVenda(txt) {
      txt = txt || ''; var preco = null, prod = null; var mp = txt.match(/R\$\s?([\d.]+,\d{2}|[\d.,]+)/); if (mp) { preco = 'R$ ' + mp[1]; } var mn = txt.match(/n[ºo°.]?\s?(\d+)/i); if (mn) { prod = 'Produto nº ' + mn[1]; }
      if (preco) {
        var numP = parseFloat(mp[1].replace(/\./g, '').replace(',', '.'));
        if (!isNaN(numP) && numP < 1000000) {
          window.ttlfTotalGMVContado = (window.ttlfTotalGMVContado || 0) + numP;
        }
      }
      window.ttlfTotalVendasContadas = (window.ttlfTotalVendasContadas || 0) + 1;
      if (prod && preco) { return prod + ' — ' + preco; } if (preco) { return 'Venda de ' + preco + ' na sua LIVE!'; } if (prod) { return prod + ' vendido na sua LIVE!'; } return txt ? txt : 'Nova venda na sua LIVE! 🤑';
    }
    function envia() { if (!rodando || !fila.length) { return; } var agora = Date.now(); if (agora - ultimo < 1500) { return; } ultimo = agora; var txt = fila.shift(); manda('Venda Realizada - Parabéns!', corpoVenda(txt), 'moneybag', function (ok) { if (ok) { total = total + 1; st('🤑 Venda #' + total + ' — notificação enviada ' + new Date().toLocaleTimeString()); } else { st('⚠️ Falha ao enviar notificação — confira o canal.'); } }); }
    function liga() { if (!canal()) { st('Digite o nome do canal ntfy primeiro.'); return; } marcarVistos(); rodando = true; var b = document.getElementById('nv-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando vendas... 👀'); }
    function desliga() { rodando = false; fila = []; var b = document.getElementById('nv-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var bb = document.getElementById('nv-botao'); if (bb) { bb.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    var bt = document.getElementById('nv-teste'); if (bt) { bt.addEventListener('click', function () { if (!canal()) { st('Digite o nome do canal ntfy primeiro.'); return; } st('Enviando teste...'); manda('Venda Realizada - Parabéns!', 'Produto nº 13 — R$ 87,31 (TESTE)', 'moneybag', function (ok) { st(ok ? '✅ Teste enviado! Olha seu celular.' : '⚠️ Falha no teste — confira o canal.'); }); }); }
    window.nvTimer = setInterval(function () { debugScan(); varre(); envia(); }, 700);
  })();

  /* ===== 8. PROTEÇÃO CONTRA VIOLAÇÃO ===== */
  (function () {
    'use strict';
    if (window.rvTick) { clearInterval(window.rvTick); }
    var encerrando = false; var detectadoEm = 0; var confirmando = false; var ultimoAbrir = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rv-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharTimer() { var els = $s('div,span,p,b,strong'); for (var i = 0; i < els.length; i++) { var e = els[i]; if (e.children.length === 0) { var t = (e.textContent || '').trim(); if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && vis(e) && fora(e)) { return e; } } } return null; }
    function acharPower(tm) { var el = tm, tr = tm.getBoundingClientRect(); for (var up = 0; up < 9 && el; up++) { el = el.parentElement; if (!el) { break; } var cands = $s('button,[role="button"],svg', el).filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if (((b.textContent || '').trim()) !== '') { return false; } var r = b.getBoundingClientRect(); if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) { return false; } return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer'; }); if (cands.length) { cands.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cands[0]; } } return null; }
    function botaoConfirmar() { var bs = $s('button,[role="button"]').filter(function (b) { var t = (b.textContent || '').trim(); return vis(b) && fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel/i.test(t) && t.length < 40; }); return bs.length ? bs[bs.length - 1] : null; }
    function ehConfig(e) { var q = e; for (var k = 0; k < 14 && q; k++) { var t = (q.textContent || ''); if (t.length < 8000 && /(Configura[cç][oõ]es|Filtrar coment|Permitir coment|palavras-chave|Dura[cç][aã]o do silenciamento|Bloquear palavras|comunidade j[aá] sinalizou|potencialmente desagrad)/i.test(t)) { return true; } q = q.parentElement; } return false; }
    function achaAviso() { var dots = $s('span,sup,i,b,div'); for (var i = 0; i < dots.length; i++) { var e = dots[i]; var cls = (e.className || '').toString(); if (cls.indexOf('m4b-badge-dot') < 0) { continue; } if (!vis(e) || !fora(e)) { continue; } var r = e.getBoundingClientRect(); if (r.top > 170) { continue; } var p = e; for (var k = 0; k < 5 && p; k++) { var b = (p.querySelector) ? p.querySelector('button,[role="button"]') : null; if (b && vis(b) && fora(b)) { return b; } if (p.tagName === 'BUTTON') { return p; } p = p.parentElement; } } var all = $s('div,span,i,sup,b'); for (var j = 0; j < all.length; j++) { var e2 = all[j]; if (!vis(e2) || !fora(e2) || e2.children.length > 0) { continue; } var r2 = e2.getBoundingClientRect(); if (r2.top > 170) { continue; } if (r2.width < 5 || r2.width > 18 || r2.height < 5 || r2.height > 18) { continue; } var bg = getComputedStyle(e2).backgroundColor || ''; var m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/); if (!m) { continue; } var R = +m[1], G = +m[2], B = +m[3], A = (m[4] === undefined ? 1 : +m[4]); if (A < 0.6) { continue; } if (!(R > 160 && G < 115 && B < 130)) { continue; } var p2 = e2; for (var k2 = 0; k2 < 5 && p2; k2++) { var b2 = (p2.querySelector) ? p2.querySelector('button,[role="button"]') : null; if (b2 && vis(b2) && fora(b2)) { return b2; } if (p2.tagName === 'BUTTON' || (p2.getAttribute && p2.getAttribute('role') === 'button')) { return p2; } try { if (getComputedStyle(p2).cursor === 'pointer') { return p2; } } catch (_) {} p2 = p2.parentElement; } } return null; }
    function detecta() { var els = $s('div,span,p,h1,h2,h3,b,strong'); var temPainel = false; for (var i = 0; i < els.length; i++) { var t0 = (els[i].textContent || '').trim(); if (/^Lembrete de viola/i.test(t0) && els[i].children.length <= 3 && vis(els[i])) { temPainel = true; break; } } if (temPainel) { var conta = null; for (var j = 0; j < els.length; j++) { if (els[j].children.length > 0) { continue; } var tj = (els[j].textContent || '').trim(); var mm = tj.match(/^Todos?\s*\((\d+)\)/i); if (mm) { conta = parseInt(mm[1], 10); break; } } if (conta !== null) { if (conta > 0) { return 'Violação no painel (Todos ' + conta + ')'; } return null; } return null; } var re = /(sua live pode ser suspensa|sua transmiss[aã]o pode ser suspensa|live foi encerrada por viola|live ser[aá] encerrada por viola|viola[cç][aã]o das diretrizes|conte[uú]do impr[oó]prio detect|penalidade aplicad|foi sinalizada por viola)/i; for (var k = 0; k < els.length; k++) { var e = els[k]; if (e.children.length !== 0) { continue; } var cls = (e.className || '').toString(); if (cls.indexOf('text-body') > -1) { continue; } if (!vis(e) || !fora(e)) { continue; } var x = (e.textContent || '').trim(); if (x && x.length < 300 && re.test(x)) { if (ehConfig(e)) { continue; } return x.slice(0, 70); } } return null; }
    function tick() { sincBtn(); var cb = document.getElementById('rv-ativo'); if (!cb) { return; } if (!cb.checked) { st('Inativa.'); encerrando = false; confirmando = false; detectadoEm = 0; return; } var agora = Date.now(); var tm = acharTimer(); if (confirmando) { var cf = botaoConfirmar(); if (cf) { cf.click(); } if (!acharTimer()) { confirmando = false; st('LIVE encerrada pela proteção. ' + new Date().toLocaleTimeString()); } return; } if (encerrando) { if (!tm) { st('LIVE encerrada pela proteção. ' + new Date().toLocaleTimeString()); } else if (agora - detectadoEm > 180000) { encerrando = false; detectadoEm = 0; } return; } if (!tm) { st('Ativa 🛡️ — aguardando LIVE no ar.'); detectadoEm = 0; return; } var av = detecta(); if (!av) { var _ic = achaAviso(); if (_ic && (Date.now() - ultimoAbrir > 6000)) { ultimoAbrir = Date.now(); clicar(_ic); st('🔎 Verificando aviso de violação...'); return; } st('Ativa 🛡️ monitorando a tela (' + new Date().toLocaleTimeString() + ')'); detectadoEm = 0; return; } if (!detectadoEm) { detectadoEm = agora; } var atraso = (parseInt(document.getElementById('rv-delay').value, 10) || 0) * 1000; var falta = detectadoEm + atraso - agora; if (falta > 0) { st('⚠️ AVISO DETECTADO! Encerrando em ' + Math.ceil(falta / 1000) + 's — "' + av + '"'); return; } var pw = acharPower(tm); if (pw) { clicar(pw); encerrando = true; confirmando = true; st('⚠️ Aviso detectado — ENCERRANDO A LIVE!'); } else { st('⚠️ Aviso detectado, mas não achei o botão de desligar!'); } }
    function sincBtn() { var cb = document.getElementById('rv-ativo'); var b = document.getElementById('rv-botao'); if (!cb || !b) { return; } if (cb.checked) { b.textContent = '⏸ Desativar proteção'; b.style.background = '#ff1717'; } else { b.textContent = '▶ Ativar proteção'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; } }
    var btnRv = document.getElementById('rv-botao'); if (btnRv) { btnRv.addEventListener('click', function () { var cb = document.getElementById('rv-ativo'); if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change', { bubbles: true })); } sincBtn(); }); }
    sincBtn();
    window.rvTick = setInterval(tick, 2000);
  })();

  /* ===== 9. TIMER DE ENCERRAMENTO REGRESSIVO ===== */
  (function () {
    'use strict';
    if (window.rtTick) { clearInterval(window.rtTick); }
    var fase = 'off'; var deadline = 0; var resto = 0; var confirmando = false;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rt-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function acharTimer() { var els = $s('div,span,p,b,strong'); for (var i = 0; i < els.length; i++) { var e = els[i]; if (e.children.length === 0) { var t = (e.textContent || '').trim(); if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && vis(e) && fora(e)) { return e; } } } return null; }
    function acharPower(tm) { var el = tm, tr = tm.getBoundingClientRect(); for (var up = 0; up < 9 && el; up++) { el = el.parentElement; if (!el) { break; } var cands = $s('button,[role="button"],svg', el).filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if (((b.textContent || '').trim()) !== '') { return false; } var r = b.getBoundingClientRect(); if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) { return false; } return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer'; }); if (cands.length) { cands.sort(function (a, b) { return a.getBoundingClientRect().left - b.getBoundingClientRect().left; }); return cands[0]; } } return null; }
    function botaoConfirmar() { var bs = $s('button,[role="button"]').filter(function (b) { var t = (b.textContent || '').trim(); return vis(b) && fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel/i.test(t) && t.length < 40; }); return bs.length ? bs[bs.length - 1] : null; }
    function fmt(ms) { var s = Math.max(0, Math.round(ms / 1000)); var h = Math.floor(s / 3600), m = Math.floor((s - h * 3600) / 60), x = s - h * 3600 - m * 60; function z(n) { return (n < 10 ? '0' : '') + n; } return z(h) + ':' + z(m) + ':' + z(x); }
    function mostra(ms) { var e = document.getElementById('rt-restante'); if (e) { e.textContent = fmt(ms); } }
    function salva() { try { localStorage.setItem('ttlf-rt-estado', JSON.stringify({ fase: fase, deadline: deadline, resto: resto })); } catch (e) {} }
    function botoes() { var a = document.getElementById('rt-armar'); var p = document.getElementById('rt-pausa'); var c = document.getElementById('rt-cancel'); if (!a || !p || !c) { return; } if (fase === 'off') { a.style.display = 'block'; p.style.display = 'none'; c.style.display = 'none'; } else { a.style.display = 'none'; p.style.display = 'block'; c.style.display = 'block'; p.textContent = (fase === 'pausado') ? '▶ Retomar' : '⏸ Pausar'; } }
    function armar() { var min = parseInt(document.getElementById('rt-min').value, 10) || 120; if (min < 1) { min = 1; } deadline = Date.now() + min * 60000; fase = 'contando'; salva(); botoes(); st('Timer iniciado ⏲️ encerra às ' + new Date(deadline).toLocaleTimeString()); }
    function pausaRetoma() { if (fase === 'contando') { resto = deadline - Date.now(); fase = 'pausado'; st('Pausado com ' + fmt(resto) + ' restantes.'); } else if (fase === 'pausado') { deadline = Date.now() + resto; fase = 'contando'; st('Retomado — encerra às ' + new Date(deadline).toLocaleTimeString()); } salva(); botoes(); }
    function cancela() { fase = 'off'; deadline = 0; resto = 0; confirmando = false; salva(); botoes(); st('Desligado.'); }
    function tick() { if (confirmando) { var cf = botaoConfirmar(); if (cf) { cf.click(); } if (!acharTimer()) { confirmando = false; st('LIVE encerrada pelo timer às ' + new Date().toLocaleTimeString() + ' ✅'); } return; } if (fase === 'off') { var min = parseInt(document.getElementById('rt-min').value, 10) || 0; mostra(min * 60000); return; } if (fase === 'pausado') { mostra(resto); return; } var falta = deadline - Date.now(); mostra(falta); if (falta > 0) { return; } var tm = acharTimer(); if (!tm) { st('Tempo esgotado — LIVE já estava fora do ar.'); cancela(); return; } var pw = acharPower(tm); if (!pw) { st('⏰ Tempo esgotado, mas não achei o botão de desligar!'); return; } clicar(pw); confirmando = true; fase = 'off'; deadline = 0; salva(); botoes(); st('⏰ Tempo esgotado — ENCERRANDO A LIVE!'); }
    try { var sv = localStorage.getItem('ttlf-rt-estado'); if (sv) { sv = JSON.parse(sv); if (sv.fase === 'contando' && sv.deadline > Date.now()) { fase = 'contando'; deadline = sv.deadline; st('Timer recuperado — encerra às ' + new Date(deadline).toLocaleTimeString()); } else if (sv.fase === 'pausado' && sv.resto > 0) { fase = 'pausado'; resto = sv.resto; st('Pausado com ' + fmt(resto) + ' restantes.'); } } } catch (e) {}
    botoes();
    var btnArmar = document.getElementById('rt-armar'); if (btnArmar) { btnArmar.addEventListener('click', armar); }
    var btnPausa = document.getElementById('rt-pausa'); if (btnPausa) { btnPausa.addEventListener('click', pausaRetoma); }
    var btnCancel = document.getElementById('rt-cancel'); if (btnCancel) { btnCancel.addEventListener('click', cancela); }
    $s('.ttlf-preset').forEach(function (b) { b.addEventListener('click', function () { var inp = document.getElementById('rt-min'); if (inp) { inp.value = b.getAttribute('data-min'); inp.dispatchEvent(new Event('input', { bubbles: true })); } }); });
    window.rtTick = setInterval(tick, 500);
  })();

  /* ===== 10. DUPLICAR OFERTA RELÂMPAGO ===== */
  (function () {
    'use strict';
    if (window.rdTick) { clearInterval(window.rdTick); }
    var rodando = false; var fase = 'watch'; var t0 = 0; var espera = 0;
    function $s(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function vis(el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
    function fora(el) { var p = el; while (p) { if (p.id === 'ttlf-hub' || p.id === 'ttlf-bolha') { return false; } p = p.parentElement; } return true; }
    function st(m) { var e = document.getElementById('rd-status'); if (e) { e.textContent = m; } }
    function clicar(el) { if (el && typeof el.click === 'function') { el.click(); return; } ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {} }); }
    function achaExato(txt) { return $s('button,[role="button"],a,span,div').filter(function (b) { if (!vis(b) || !fora(b)) { return false; } if ((b.textContent || '').trim() !== txt) { return false; } return b.tagName === 'BUTTON' || b.tagName === 'A' || getComputedStyle(b).cursor === 'pointer'; }); }
    function tick() { if (!rodando) { return; } var agora = Date.now(); if (agora < espera) { return; } if (fase === 'watch') { var cands = achaExato('Duplicar').filter(function (b) { var el = b; for (var i = 0; i < 6 && el; i++) { el = el.parentElement; if (!el) { break; } var t = el.textContent || ''; if (t.indexOf('foi encerrada') > -1) { return true; } if (t.length > 500) { break; } } return false; }); if (cands.length) { clicar(cands[0]); fase = 'm1'; t0 = agora; st('Oferta encerrada detectada — duplicando...'); } else { st('Monitorando oferta relâmpago... 👀'); } return; } if (fase === 'm1') { var b1 = achaExato('Duplicar e começar agora'); if (b1.length) { clicar(b1[b1.length - 1]); fase = 'm2'; t0 = agora; st('Duplicando e iniciando...'); return; } if (agora - t0 > 20000) { fase = 'watch'; st('Tentando de novo...'); } return; } if (fase === 'm2') { var b2 = achaExato('Iniciar').filter(function (b) { var el = b; for (var i = 0; i < 10 && el; i++) { el = el.parentElement; if (!el) { break; } var cls = (el.className || '').toString(); if ((cls.indexOf('modal') > -1 || el.getAttribute('role') === 'dialog') && (el.textContent || '').indexOf('Oferta rel') > -1) { return true; } } return false; }); if (!b2.length) { b2 = achaExato('Iniciar'); } if (b2.length) { clicar(b2[b2.length - 1]); fase = 'watch'; espera = agora + 30000; st('Oferta relâmpago relançada! ✅ ' + new Date().toLocaleTimeString()); return; } if (agora - t0 > 20000) { fase = 'watch'; st('Tentando de novo...'); } return; } }
    function liga() { rodando = true; fase = 'watch'; espera = 0; var b = document.getElementById('rd-botao'); b.textContent = '⏸ Parar'; b.style.background = '#ff1717'; st('Monitorando oferta relâmpago... 👀'); }
    function desliga() { rodando = false; var b = document.getElementById('rd-botao'); b.textContent = '▶ Iniciar'; b.style.background = 'linear-gradient(135deg,#ffd000,#ffaa00)'; b.style.color = '#000'; st('Desligado.'); }
    var btnRd = document.getElementById('rd-botao'); if (btnRd) { btnRd.addEventListener('click', function () { if (rodando) { desliga(); } else { liga(); }; }); }
    window.rdTick = setInterval(tick, 2000);
  })();

}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && (msg.type === 'ttlf-show' || msg.action === 'toggleUI')) {
      ttlfShowUI();
    }
  });
}

ttlfBoot();
